#' ODE model 1 -  
#'  
#' Primo modello Per mattia
#' @param Data data con numero di colonne pari al numero di tipi (maturo, premature ert)
#' @param covariates data.frame con le covariate (non viene usato)
#' @param formulae formuale per cose regressive
#' @param nt per quanti tempi ogni serie e' stata osservata (11)
#' @param nrep numero di replicazioni(3)
#' @param nlatentk numero di funzioni k
#' @param priors lista delle prior
#' @param nshapek numero di forme da provare per ognik
#' @param tmin   tempo della prima osservazione
#' @param tmax   tempo dell'ultima
#' @param nstep  quanti punti mettere tra t cosecutivi per il calcolo delle ode
#' @param prior Tutti i parametri devono avere lunghezze giuste
#' \itemize{
#' \item{RegCoef} {Non Vengono usati}
#' } 
#' @param  start valori iniziali dei parametri 
#' \itemize{
#' \item{RegCoef} {Una lista con un elemento o tanti quanti Kmax}
#' \item{sigma2} {sia par1 che par2 devono avere la stessa lunghezza del numero di colonne di data} 
#' \item{MinK e simili} {par1 e par2 devono avere lunghezza pari a nlatentk}
#' }
#' @param  MCMC itaration thin e burnin dell MCMC 
#' @param  Adapt una lista contenente i parametri per fare l'adapt dei parametri (se necessario)
#' \itemize{
#' \item{start} {Numero di iterazioni iniziali senza adapt } 
#' \item{end} {end x burnin dice a quale iterazione l'adapt si ferma}
#' \item{exp} {esponenzuale per l'adapt}
#' \item{acc} {l'acceptance ratio targer}
#' \item{batch} {nel caso di adapt univariato, serve a determinare ogni quante iterazioni va fatto l'aggiornamento della varianza}
#' \item{epsilon} {il valore  da aggiungere alla diagonale della matrice di covarianza dell'adapt multivariato}
#' \item{sd} {contiene le deviazioni standard per la proposta del metropolis. nella lista ci deve essere sempre General, che e' il valore di base, mentre se si vuole specificare la sd per una altro parametro, ad esempio, sigma2, basta aggiungere l'elemento. } 
#' }
#' @param  DoParallel Se usare il calcolo in parallelo
#' @param  Nthreads  numero di cores da usare
#' @return BOH
#' 
#' @details 
#' questo e' il primo modello. Assumo solo 3 possibili funzioni per i k, costante, sigmoide e spike. 
#' 
#' 
#' @name ODE_MODEL1 
#' @useDynLib OdePackRT1
#' @export 
ODE_MODEL = function(
    Data        = ySIM,
    covariates  = Cov,
    nt          = 11,
    nrep          = 3,
    nlatentk      = 3,
    nshapek       = 3,
    tmin         = 0,
    tmax         = 10,
    nstep         = 1,
    formulae    =  list(~ cov1,~ cov2,~ 1),

    priors  = list(
                    RegCoef = list(
                        type        = "Normal",
                        Par1        = 0, ## (1 o stessa dimension)
                        Par2        = 100
                    ),
                    sigma2 = list(
                        type        = "InverseGamma",
                        Par1        = 1, 
                        Par2        = c(diag(1,3)) ## diagonale Psi
                    ),
                    MinK   = list(
                        type        = "Gamma",
                        Par1        = 1,
                        Par2        = 1
                    ),
                    MaxK   = list(
                        type        = "Gamma",
                        Par1        = 1,
                        Par2        = 1
                    ),
                    x0   = list(
                        type        = "Gamma",
                        Par1        = 1,
                        Par2        = 1
                    ),
                    lambda   = list(
                        type        = "Gamma",
                        Par1        = 1,
                        Par2        = 1
                    ),
                    xi   = list(
                        type        = "Dirichlet",
                        Par1        = 1,
                        Par2        = 1
                    )
        ) ,
            
    start   = list(
        Y0,  
        xi,
        RegCoef,
        sigma2,
        MinK,
        MaxK,
        x0,
        lambda,
        TypekFunc
        
    ),            
    MCMC = list(
                    iter        = 15000, 
                    burnin      = 10000, 
                    thin        = 1
                    ),
    Adapt= list(
                    start       = 250,
                    end         = 0.9,
                    exp         = 0.5,
                    acc        = 0.234,
                    batch       = 50,
                    epsilon     = 0.000000001,
                    sd          = list(
                                    General     = 0.1,    
                                    Beta        = 0.01
                                    )
                ),
    IterShow       = 200,
    DoParallel = TRUE,
    Nthreads = 1,
    Verbose = 1,
    saveODE = T,
    A = NULL
)
{

    
    #####
    # COSE STANDARD
    #####
    InitsVector = c(
        "Y0",
        "RegCoef",
        "sigma2",
        "MinK",
        "MaxK",
        "x0",
        "xi",
        "lambda",
        "TypekFunc"
    )
    
    nInits_r = c()
    Inits_r = list()
    for(i in 1:length(InitsVector))
    {
        w   = which(names(start)==InitsVector[i])
        if(length(w)==0)
        {
            nInits_r[i] = 1
            Inits_r[[i]] = -99999
        }else{
            Inits_r[[i]] = unlist(start[[w]])
            nInits_r[i] = length(start[[w]])
        }
    }
    names(Inits_r)                  = InitsVector
    
    storage.mode(nInits_r)          = "integer"
    storage.mode(Inits_r)           = "list"
    
    for(i in 1:length(InitsVector))
    {
        storage.mode(Inits_r[[i]]) = "double"
    }
    
    
    
    ParametersVector = c(
        "Y0",
        "RegCoef",
        "sigma2",
        "MinK",
        "MaxK",
        "x0",
        "xi",
        "lambda"
    )
    
    PriorsVector = c(
        "NoPrior",
        "Normal",
        "Gamma",
        "InverseGamma",
        "Uniform",
        "InverseWishart",
        "HuangWand",
        "Dirichlet"
    )
    
    Prior_r = list()
    NamePrior_r = c()
    nParameters_r = c()
    for(i in 1:length(ParametersVector))
    {
        w   = which(names(priors)==ParametersVector[i])
        if(length(w)==0)
        {
            nParameters_r[i] = 1
            Prior_r[[i]] = -99999
            NamePrior_r[i] = 1
        }else{
            Prior_r[[i]] = unlist(priors[[w]][-1])
            NamePrior_r[i] =  which(unlist(priors[[w]][1])==PriorsVector)
            nParameters_r[i] = length(priors[[w]][-1])
        }
    }
    NamePrior_r                         = NamePrior_r-1
    names(Prior_r)                  = ParametersVector
    storage.mode(NamePrior_r)       = "integer"
    storage.mode(nParameters_r) = "integer"
    storage.mode(Prior_r)           = "list"
    
    for(i in 1:length(ParametersVector))
    {
        storage.mode(Prior_r[[i]]) = "double"
    }
    
    
    SdVector         = c(
        "General",
        "RegCoef",
        "sigma2",
        "MinK",
        "MaxK",
        "x0",
        "lambda",
        "Y0"
    )
    
    nSd_r   = c()
    Sd_r   = list()
    for(i in 1:length(SdVector))
    {
        w   = which(names(Adapt$sd)==SdVector[i])
        if(length(w)==0)
        {
            nSd_r[i]     = 1
            Sd_r[[i]]    = Adapt$sd$General
        }else{
            Sd_r[[i]]    = unlist(Adapt$sd[[w]])
            nSd_r[i]     = length(Adapt$sd[[w]])
        }
    }
    
    storage.mode(nSd_r)          = "integer"
    storage.mode(Sd_r)           = "list"
    
    for(i in 1:length(SdVector))
    {
        storage.mode(Sd_r[[i]]) = "double"
    }
    
    
    MCMC_r = c(
        MCMC$iter,
        MCMC$burnin,
        MCMC$thin,
        round((MCMC$iter-MCMC$burnin)/MCMC$thin)
    )
    storage.mode(MCMC_r)        = "integer"
    
    
    Adaptpar_r = c(
        Adapt$start,
        round(Adapt$end*MCMC$burnin),
        Adapt$exp,
        Adapt$acc,
        Adapt$batch ,
        Adapt$epsilon
    )
    if(!Adapt$doUpdate)
    {
        Adaptpar_r[1] = MCMC$iter*2
        Adaptpar_r[2] = MCMC$iter*3 
    }
    
    storage.mode(Adaptpar_r)        = "double"

    
    
    #####
    # Observations
    #####
    
    nvar    = ncol(Data)
    nobsTOT = nrow(Data)
    nG      = nobsTOT/(nt*nrep)
    
    IndexNotNA = which(!is.na(Data[1:nt,1]))-1
    
    Data_r  = c(t(Data))
    storage.mode(Data_r) = "double"
    storage.mode(IndexNotNA) = "integer"
    #####
    # Integer
    #####    
    
    indices_r       = c(
        nvar,
        nobsTOT,
        nG,
        nt,
        nrep,
        IterShow,
        as.numeric(DoParallel),
        Nthreads,
        Verbose,
        nlatentk,
        nshapek,
        nstep,
        as.numeric(saveODE),
        nNotna = length(IndexNotNA)
    )
    storage.mode(indices_r)     = "integer"
    
    
    
    deltat = (tmax-tmin)/(nt-1)
    deltat = deltat/nstep
    indicesDouble_r       = c(
        
        tmin,
        tmax,
        deltat
    )
 
    storage.mode(indicesDouble_r)     = "double"
    
    #####
    # model
    ##### 
    print(Inits_r)
    print(nInits_r)
    print("A")
    print(NamePrior_r)
    print("B")
    print(nParameters_r)
    print("D")
    print(Prior_r)
    out =.Call("ODE_T1",
               nInits_r,
               Inits_r,
               NamePrior_r,
               nParameters_r,
               Prior_r,
               nSd_r,
               Sd_r,
               MCMC_r,
               Adaptpar_r, 
               Data_r,
               indices_r,
               indicesDouble_r,
               IndexNotNA
            )

    
    ret = list(sigma2 = (t(out$sigma2)),MinV = t(out$MinV),MaxV = t(out$MaxV), x0 = t(out$x0),lambda = t(out$lambda), Yinit = t(out$Y), TypeKFunc = t(out$TypeKFunc)+1)
return(ret)




}
