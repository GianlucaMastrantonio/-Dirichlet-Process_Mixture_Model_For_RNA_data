#' ODE model 2 -  
#'  
#' Secondo Modello Furlan
#' @param Data data con numero di colonne pari al numero di tipi (maturo, premature ert)
#' @param covariates data.frame con le covariate (non viene usato)
#' @param formulae formuale per cose regressive
#' @param nt per quanti tempi ogni serie e' stata osservata (11)
#' @param nrep numero di replicazioni(3)
#' @param nlatentk numero di funzioni k
#' @param priors lista delle prior
#' @param tmin   tempo della prima osservazione
#' @param tmax   tempo dell'ultima
#' @param nstep  quanti punti mettere tra t cosecutivi per il calcolo delle ode
#' @param prior Tutti i parametri devono avere lunghezze giuste
#' \itemize{
#' \item{RegCoef} {Non Vengono usati}
#' } 
#' @param  start valori iniziali dei parametri 
#' \itemize{
#' \item{RegCoef} {Una lista con un elemento o tanti quanti Kmax}
#' \item{sigma2} {sia par1 che par2 devono avere la stessa lunghezza del numero di colonne di data} 
#' \item{MinK e simili} {par1 e par2 devono avere lunghezza pari a nlatentk}
#' }
#' @param  MCMC itaration thin e burnin dell MCMC 
#' @param  Adapt una lista contenente i parametri per fare l'adapt dei parametri (se necessario)
#' \itemize{
#' \item{start} {Numero di iterazioni iniziali senza adapt } 
#' \item{end} {end x burnin dice a quale iterazione l'adapt si ferma}
#' \item{exp} {esponenzuale per l'adapt}
#' \item{acc} {l'acceptance ratio targer}
#' \item{batch} {nel caso di adapt univariato, serve a determinare ogni quante iterazioni va fatto l'aggiornamento della varianza}
#' \item{epsilon} {il valore  da aggiungere alla diagonale della matrice di covarianza dell'adapt multivariato}
#' \item{sd} {contiene le deviazioni standard per la proposta del metropolis. nella lista ci deve essere sempre General, che e' il valore di base, mentre se si vuole specificare la sd per una altro parametro, ad esempio, sigma2, basta aggiungere l'elemento. } 
#' }
#' @param  DoParallel Se usare il calcolo in parallelo
#' @param  Nthreads  numero di cores da usare
#' @param Rparam se i parametri appartengono a R
#' @return BOH
#' 
#' @details 
#' questo e' il primo modello. Assumo solo 3 possibili funzioni per i k, costante, sigmoide e spike. 
#' 
#' 
#' @name ODE_MODEL_T2
#' @useDynLib OdePackRT1
#' @export 
ODE_MODEL_T2 = function(
    NAME        = "SS",
    DIR         = "/Users/gianlucamastrantonio/Dropbox (Politecnico di Torino Staff)/lavori/ode/",
    Data        = ySIM,
    covariates  = Cov,
    nt          = 11,
    nrep          = 3,
    nlatentk      = 3,
    tmin         = 0,
    tmax         = 10,
    nstep         = 1,
    formulae    =  list(~ cov1,~ cov2,~ 1),

    priors  = list(
            sigma2 = list(
                type        = "InverseGamma",
                Par1        = 1, 
                Par2        = c(diag(1,3)) ## diagonale Psi
            ),
            MinK   = list(
                type        = "Gamma",
                Par1        = 1,
                Par2        = 1
            ),
            
            Eta1KMean   = list(
                type        = "Gamma",
                Par1        = 1,
                Par2        = 1
            ),
            Eta2KMean   = list(
                type        = "Gamma",
                Par1        = 1,
                Par2        = 1
            ),
            MeanKMean   = list(
                type        = "Gamma",
                Par1        = 1,
                Par2        = 1
            ),
            VarKMean   = list(
                type        = "Dirichlet",
                Par1        = 1,
                Par2        = 1
            ),
            Eta1KVar   = list(
                type        = "Gamma",
                Par1        = 1,
                Par2        = 1
            ),
            Eta2KVar   = list(
                type        = "Gamma",
                Par1        = 1,
                Par2        = 1
            ),
            MeanKVar   = list(
                type        = "Gamma",
                Par1        = 1,
                Par2        = 1
            ),
            VarKVar   = list(
                type        = "Dirichlet",
                Par1        = 1,
                Par2        = 1
            ),
            
            
            Eta1K   = list(
                type        = "Gamma",
                Par1        = 1,
                Par2        = 1
            ),
            Eta2K   = list(
                type        = "Gamma",
                Par1        = 1,
                Par2        = 1
            ),
            MeanK   = list(
                type        = "Gamma",
                Par1        = 1,
                Par2        = 1
            ),
            VarK   = list(
                type        = "Dirichlet",
                Par1        = 1,
                Par2        = 1
            )
        ),
            
    start   = list(
        Y0,  
        MinK,
        EtaK1,
        EtaK2,
        MeanK,
        Vark,
        EtaK1Mean,
        EtaK2Mean,
        MeanKMean,
        VarkMean,
        EtaK1Var,
        EtaK2Var,
        MeanKVar,
        VarkVar
        
    ),            
    MCMC = list(
                    iter        = 15000, 
                    burnin      = 10000, 
                    thin        = 1
                    ),
    Adapt= list(
                    start       = 250,
                    end         = 0.9,
                    exp         = 0.5,
                    acc        = 0.234,
                    batch       = 50,
                    epsilon     = 0.000000001,
                    sd          = list(
                                    General     = 0.1,    
                                    Beta        = 0.01
                                    )
                ),
    sample_Var = T,
    sample_Ode = T,
    IterShow       = 1,
    DoParallel = TRUE,
    Nthreads = 1,
    Verbose = 1,
    saveODE = T,
    Rparam = T,
    SampleOdeType = 1,
    RandomEffect = F,
    abs_err = 10^(-10),
    rel_err = 10^(-6),
    A = NULL
)
{
    TEXT = paste(DIR,NAME,".txt",sep="")
    
    #####
    # COSE STANDARD
    #####
    InitsVector = c(
        "Beta0",
        "Beta1",
        "sigma2",
        "Y0",
        "MinK",
        "EtaK1",
        "EtaK2",
        "MeanK",
        "VarK",
        "EtaK1Mean",
        "EtaK2Mean",
        "MeanKMean",
        "VarKMean",
        "EtaK1Var",
        "EtaK2Var",
        "MeanKVar",
        "VarKVar"
    )
    
    nInits_r = c()
    Inits_r = list()
    for(i in 1:length(InitsVector))
    {
        w   = which(names(start)==InitsVector[i])
        if(length(w)==0)
        {
            nInits_r[i] = 1
            Inits_r[[i]] = -99999
        }else{
            Inits_r[[i]] = unlist(start[[w]])
            nInits_r[i] = length(start[[w]])
        }
    }
    names(Inits_r)                  = InitsVector
    
    storage.mode(nInits_r)          = "integer"
    storage.mode(Inits_r)           = "list"
    
    for(i in 1:length(InitsVector))
    {
        storage.mode(Inits_r[[i]]) = "double"
    }
    
    
    
    ParametersVector = c(
        "Beta0",
        "Beta1",
        "sigma2",
        "Y0",
        "MinK",
        "EtaK1",
        "EtaK2",
        "MeanK",
        "VarK",
        "EtaK1Mean",
        "EtaK2Mean",
        "MeanKMean",
        "VarKMean",
        "EtaK1Var",
        "EtaK2Var",
        "MeanKVar",
        "VarKVar"
    )
    
    PriorsVector = c(
        "NoPrior",
        "Normal",
        "Gamma",
        "InverseGamma",
        "Uniform",
        "InverseWishart",
        "HuangWand",
        "Dirichlet",
        "PositiveTruncatedNormal",
        "TruncatedNormal"
    )
    
    Prior_r = list()
    NamePrior_r = c()
    nParameters_r = c()
    for(i in 1:length(ParametersVector))
    {
        w   = which(names(priors)==ParametersVector[i])
        if(length(w)==0)
        {
            nParameters_r[i] = 1
            Prior_r[[i]] = -99999
            NamePrior_r[i] = 1
        }else{
            Prior_r[[i]] = unlist(priors[[w]][-1])
            NamePrior_r[i] =  which(unlist(priors[[w]][1])==PriorsVector)
            nParameters_r[i] = length(priors[[w]][-1])
        }
    }
    NamePrior_r                         = NamePrior_r-1
    names(Prior_r)                  = ParametersVector
    storage.mode(NamePrior_r)       = "integer"
    storage.mode(nParameters_r) = "integer"
    storage.mode(Prior_r)           = "list"
    
    for(i in 1:length(ParametersVector))
    {
        storage.mode(Prior_r[[i]]) = "double"
    }
    
    
    SdVector         = c(
        "Beta0",
        "Beta1",
        "General",
        "MinK",
        "Eta1K",
        "Eta2K",
        "MeanK",
        "VarK",
        "Y0",
        "EtaK1Mean",
        "EtaK2Mean",
        "MeanKMean",
        "VarKMean",
        "EtaK1Var",
        "EtaK2Var",
        "MeanKVar",
        "VarKVar"
    )
    
    nSd_r   = c()
    Sd_r   = list()
    for(i in 1:length(SdVector))
    {
        w   = which(names(Adapt$sd)==SdVector[i])
        if(length(w)==0)
        {
            nSd_r[i]     = 1
            Sd_r[[i]]    = Adapt$sd$General
        }else{
            Sd_r[[i]]    = unlist(Adapt$sd[[w]])
            nSd_r[i]     = length(Adapt$sd[[w]])
        }
    }
    
    storage.mode(nSd_r)          = "integer"
    storage.mode(Sd_r)           = "list"
    
    for(i in 1:length(SdVector))
    {
        storage.mode(Sd_r[[i]]) = "double"
    }
    
    
    MCMC_r = c(
        MCMC$iter,
        MCMC$burnin,
        MCMC$thin,
        round((MCMC$iter-MCMC$burnin)/MCMC$thin)
    )
    storage.mode(MCMC_r)        = "integer"
    
    
    Adaptpar_r = c(
        Adapt$start,
        round(Adapt$end*MCMC$burnin),
        Adapt$exp,
        Adapt$acc,
        Adapt$batch ,
        Adapt$epsilon,
        Adapt$lambda
    )
    if(!Adapt$doUpdate)
    {
        Adaptpar_r[1] = MCMC$iter*2
        Adaptpar_r[2] = MCMC$iter*3 
    }
    
    storage.mode(Adaptpar_r)        = "double"

    
    
    #####
    # Observations
    #####
    
    nvar    = ncol(Data)
    nobsTOT = nrow(Data)
    nG      = nobsTOT/(nt*nrep)
    
    IndexNotNA = which(!is.na(Data[1:nt,1]))-1
    
    Data_r  = c(t(Data))
    storage.mode(Data_r) = "double"
    storage.mode(IndexNotNA) = "integer"
    #####
    # Integer
    #####    
    if(RandomEffect)
    {
        Rparam = T
    }
    
    indices_r       = c(
        nvar,
        nobsTOT,
        nG,
        nt,
        nrep,
        IterShow,
        as.numeric(DoParallel),
        Nthreads,
        Verbose,
        nlatentk,
        nstep,
        as.numeric(saveODE),
        nNotna = length(IndexNotNA),
        as.numeric(Rparam),
        as.numeric(sample_Var),
        as.numeric(sample_Ode),
        SampleOdeType
    )
    storage.mode(indices_r)     = "integer"
    
    
    
    deltat = (tmax-tmin)/(nt-1)
    deltat = deltat/nstep
    indicesDouble_r       = c(
        
        tmin,
        tmax,
        deltat,
        abs_err,
        rel_err
    )
 
    storage.mode(indicesDouble_r)     = "double"
    

    storage.mode(TEXT) = "character"
    #####
    # model
    ##### 

    out =.Call("ODE_T2",
               nInits_r,
               Inits_r,
               NamePrior_r,
               nParameters_r,
               Prior_r,
               nSd_r,
               Sd_r,
               MCMC_r,
               Adaptpar_r, 
               Data_r,
               indices_r,
               indicesDouble_r,
               IndexNotNA,
               TEXT
            )

    # if(Rparam)
    # {
    #     out$MinK = exp(out$MinK)
    #     out$VarK = exp(out$VarK)
    #     out$MeanK = exp(out$MeanK)
        
    #     out$VarKMean = exp(out$VarKMean)
    #     out$MeanKMean = exp(out$MeanKMean)
        
    #     out$VarKVar = exp(out$VarKVar)
    #     out$MeanKVar = exp(out$MeanKVar)
    # }
    
    ret = list(MinK = t(out$MinK),VarK = t(out$VarK),MeanK = t(out$MeanK), EtaK1 = t(out$EtaK1), EtaK2 = t(out$EtaK2), Y = t(out$Y), Y0 = t(out$Y0),
               Beta0 = t(out$Beta0),
               Beta1 = t(out$Beta1)
               
# VarKMean = t(out$VarKMean),MeanKMean = t(out$MeanKMean), EtaK1Mean = t(out$EtaK1Mean), EtaK2Mean = t(out$EtaK2Mean),
# VarKVar = t(out$VarKVar),MeanKVar = t(out$MeanKVar), EtaK1Var = t(out$EtaK1Var), EtaK2Var = t(out$EtaK2Var)
 )
return(ret)




}
