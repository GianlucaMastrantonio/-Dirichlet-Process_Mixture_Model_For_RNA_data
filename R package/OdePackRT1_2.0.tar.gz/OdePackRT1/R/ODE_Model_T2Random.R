#' ODE model 2  Effetti random
#'
#' Secondo Modello Furlan
#' @param Data data con numero di colonne pari al numero di tipi (maturo, premature ert)
#' @param covariates data.frame con le covariate (non viene usato)
#' @param formulae formuale per cose regressive
#' @param nt per quanti tempi ogni serie e' stata osservata (11)
#' @param nrep numero di replicazioni(3)
#' @param nlatentk numero di funzioni k
#' @param priors lista delle prior
#' @param tmin   tempo della prima osservazione
#' @param tmax   tempo dell'ultima
#' @param nstep  quanti punti mettere tra t cosecutivi per il calcolo delle ode
#' @param prior Tutti i parametri devono avere lunghezze giuste
#' \itemize{
#' \item{RegCoef} {Non Vengono usati}
#' }
#' @param  start valori iniziali dei parametri
#' \itemize{
#' \item{RegCoef} {Una lista con un elemento o tanti quanti Kmax}
#' \item{sigma2} {sia par1 che par2 devono avere la stessa lunghezza del numero di colonne di data}
#' \item{MinK e simili} {par1 e par2 devono avere lunghezza pari a nlatentk}
#' }
#' @param  MCMC itaration thin e burnin dell MCMC
#' @param  Adapt una lista contenente i parametri per fare l'adapt dei parametri (se necessario)
#' \itemize{
#' \item{start} {Numero di iterazioni iniziali senza adapt }
#' \item{end} {end x burnin dice a quale iterazione l'adapt si ferma}
#' \item{exp} {esponenzuale per l'adapt}
#' \item{acc} {l'acceptance ratio targer}
#' \item{batch} {nel caso di adapt univariato, serve a determinare ogni quante iterazioni va fatto l'aggiornamento della varianza}
#' \item{epsilon} {il valore  da aggiungere alla diagonale della matrice di covarianza dell'adapt multivariato}
#' \item{sd} {contiene le deviazioni standard per la proposta del metropolis. nella lista ci deve essere sempre General, che e' il valore di base, mentre se si vuole specificare la sd per una altro parametro, ad esempio, sigma2, basta aggiungere l'elemento. }
#' }
#' @param  DoParallel Se usare il calcolo in parallelo
#' @param  Nthreads  numero di cores da usare
#' @param Rparam se i parametri appartengono a R
#' @return BOH
#'
#' @details
#' questo e' il primo modello. Assumo solo 3 possibili funzioni per i k, costante, sigmoide e spike.
#'
#'
#' @name ODE_MODEL_T2Random
#' @useDynLib OdePackRT1
#' @export
ODE_MODEL_T2Random = function(
    NAME        = "SS",
    DIR         = "/Users/gianlucamastrantonio/Dropbox (Politecnico di Torino Staff)/lavori/ode/",
    Data        = ySIM,
    covariates  = Cov,
    nt          = 11,
    nrep          = 3,
    nlatentk      = 3,
    tmin         = 0,
    tmax         = 10,
    nstep         = 1,
    Kmax         = 1,
    formulae    =  list(~ cov1,~ cov2,~ 1),

    priors  = list(
            sigma2 = list(
                type        = "InverseGamma",
                Par1        = 1,
                Par2        = c(diag(1,3)) ## diagonale Psi
            ),
            MinK   = list(
                type        = "Gamma",
                Par1        = 1,
                Par2        = 1
            ),
            Eta1K   = list(
                type        = "Gamma",
                Par1        = 1,
                Par2        = 1
            ),
            Eta2K   = list(
                type        = "Gamma",
                Par1        = 1,
                Par2        = 1
            ),
            MeanK   = list(
                type        = "Gamma",
                Par1        = 1,
                Par2        = 1
            ),
            VarK   = list(
                type        = "Dirichlet",
                Par1        = 1,
                Par2        = 1
            ),
            DPpar   = list(
                type        = "Gamma",
                Par1        = 1,
                Par2        = 1
            ),
            RegCoef = list(
                        type        = "Normal",
                        Par1        = 0, ## (1 o stessa dimension)
                        Par2        = 100
            ),
            sigmaMat = list(
                type        = "InverseWishart",
                Par1        = 1,
                Par2        = c(diag(1,3)) ## diagonale Psi
            )
        ),

    start   = list(
        Y0,
        MinK,
        EtaK1,
        EtaK2,
        MeanK,
        VarK,
        RegCoef,
        sigmaMat,
        DPpar,
        stMat,
        piMat,
        SH

    ),
    MCMC = list(
                    iter        = 15000,
                    burnin      = 10000,
                    thin        = 1
                    ),
    Adapt= list(
                    start       = 250,
                    end         = 0.9,
                    exp         = 0.5,
                    acc        = 0.234,
                    batch       = 50,
                    epsilon     = 0.000000001,
                    sd          = list(
                                    General     = 0.1,
                                    Beta        = 0.01
                                    )
                ),

    IterShow       = 1,
    DoParallel = TRUE,
    Nthreads = 1,
    Verbose = 1,
    saveODE = T,
    Rparam = T,
    Spike  = F,
    LimSpike = 5,
    LimC     = 1,
    SampleOdeType = 1,
    RandomEffect = F,
    abs_err = 10^(-10),
    rel_err = 10^(-6),
    ClustType = 1,
    IterStartRandom = 0,
    addStartRandom = 100,
    sample_Var = T,
    sample_Ode = T,
    sample_RandomPar = T,
    sample_Pi = T,
    sample_DpPar = T,
    sample_st = T,
    Do_MergeSplit = F,
    Use_pi = F,
    ExpMolt = 0.1,
    ExpLambda = 5,
    TypeK = 1,
    MoltSF = 1,
    A = NULL
)
{

  # if(TypeK > 2)
  # {
  #   abseta1 = abs(start$EtaK1);
  #   abseta2 = abs(start$EtaK2);


  #   start$EtaK1 = ifelse(
  #       ((start$EtaK1* start$EtaK2)>0)&&(abseta1>abseta2) &&(start$EtaK1>0),
  #       start$EtaK1+ LimSpike,
  #       start$EtaK1
  #       )
  #   start$EtaK1 = ifelse(
  #       ((start$EtaK1* start$EtaK2)>0)&&(abseta1>abseta2) &&(start$EtaK1<0),
  #       start$EtaK1- LimSpike,
  #       start$EtaK1
  #       )

  #   start$EtaK2 = ifelse(
  #       ((start$EtaK1* start$EtaK2)>0)&&(abseta2>abseta1) &&(start$EtaK2>0),
  #       start$EtaK2+ LimSpike,
  #       start$EtaK2
  #       )
  #   start$EtaK2 = ifelse(
  #       ((start$EtaK1* start$EtaK2)>0)&&(abseta2>abseta1) &&(start$EtaK2<0),
  #       start$EtaK2- LimSpike,
  #       start$EtaK2
  #       )

  # }


  priors$Eta1K$Par3  = priors$Eta1K$Par3-LimSpike
  priors$Eta1K$Par4  = priors$Eta1K$Par4+LimSpike

  priors$Eta2K$Par3  = priors$Eta2K$Par3-LimSpike
  priors$Eta2K$Par4  = priors$Eta2K$Par4+LimSpike

  start$EtaK1 = ifelse(start$EtaK1>0,start$EtaK1+LimSpike,start$EtaK1-LimSpike )
  start$EtaK2 = ifelse(start$EtaK2>0,start$EtaK2+LimSpike,start$EtaK2-LimSpike )



  # start$EtaK1[which(abs(start$EtaK1)<0.1)] = 0.0
  # start$EtaK2[which(abs(start$EtaK2)<0.1)] = 0.0


    TEXT = paste(DIR,NAME,".txt",sep="")

    #####
    # COSE STANDARD
    #####
    InitsVector = c(
        "Beta0",
        "Beta1",
        "sigma2",
        "Y0",
        "MinK",
        "EtaK1",
        "EtaK2",
        "MeanK",
        "VarK",
        "DPpar",
        "stMat",
        "piMat",
        "RegCoef",
        "sigmaMat",
        "SH"

    )

    nInits_r = c()
    Inits_r = list()
    for(i in 1:length(InitsVector))
    {
        w   = which(names(start)==InitsVector[i])
        if(length(w)==0)
        {
            nInits_r[i] = 1
            Inits_r[[i]] = -99999
        }else{
            Inits_r[[i]] = unlist(start[[w]])
            nInits_r[i] = length(start[[w]])
        }
    }
    names(Inits_r)                  = InitsVector

    storage.mode(nInits_r)          = "integer"
    storage.mode(Inits_r)           = "list"

    for(i in 1:length(InitsVector))
    {
        storage.mode(Inits_r[[i]]) = "double"
    }



    ParametersVector = c(
        "Beta0",
        "Beta1",
        "sigma2",
        "Y0",
        "MinK",
        "EtaK1",
        "EtaK2",
        "MeanK",
        "VarK",
        "DPpar",
        "RegCoef",
        "sigmaMat"
    )

    PriorsVector = c(
        "NoPrior",
        "Normal",
        "Gamma",
        "InverseGamma",
        "Uniform",
        "InverseWishart",
        "HuangWand",
        "Dirichlet",
        "PositiveTruncatedNormal",
        "TruncatedNormal"
    )

    Prior_r = list()
    NamePrior_r = c()
    nParameters_r = c()
    for(i in 1:length(ParametersVector))
    {
        w   = which(names(priors)==ParametersVector[i])
        if(length(w)==0)
        {
            nParameters_r[i] = 1
            Prior_r[[i]] = -99999
            NamePrior_r[i] = 1
        }else{
            Prior_r[[i]] = unlist(priors[[w]][-1])
            NamePrior_r[i] =  which(unlist(priors[[w]][1])==PriorsVector)
            nParameters_r[i] = length(priors[[w]][-1])
        }
    }
    NamePrior_r                         = NamePrior_r-1
    names(Prior_r)                  = ParametersVector
    storage.mode(NamePrior_r)       = "integer"
    storage.mode(nParameters_r) = "integer"
    storage.mode(Prior_r)           = "list"

    for(i in 1:length(ParametersVector))
    {
        storage.mode(Prior_r[[i]]) = "double"
    }


    SdVector         = c(
        "Beta0",
        "Beta1",
        "General",
        "MinK",
        "EtaK1",
        "EtaK2",
        "MeanK",
        "VarK",
        "Y0",
        "DPpar",
        "RegCoef",
        "sigmaMat",
        "SF"

    )

    nSd_r   = c()
    Sd_r   = list()
    for(i in 1:length(SdVector))
    {
        w   = which(names(Adapt$sd)==SdVector[i])
        if(length(w)==0)
        {
            nSd_r[i]     = 1
            Sd_r[[i]]    = Adapt$sd$General
        }else{
            Sd_r[[i]]    = unlist(Adapt$sd[[w]])
            nSd_r[i]     = length(Adapt$sd[[w]])
        }
    }

    storage.mode(nSd_r)          = "integer"
    storage.mode(Sd_r)           = "list"

    for(i in 1:length(SdVector))
    {
        storage.mode(Sd_r[[i]]) = "double"
    }


    MCMC_r = c(
        MCMC$iter,
        MCMC$burnin,
        MCMC$thin,
        round((MCMC$iter-MCMC$burnin)/MCMC$thin)
    )
    storage.mode(MCMC_r)        = "integer"


    Adaptpar_r = c(
        Adapt$start,
        round(Adapt$end*MCMC$burnin),
        Adapt$exp,
        Adapt$acc,
        Adapt$batch ,
        Adapt$epsilon,
        Adapt$lambda
    )
    if(!Adapt$doUpdate)
    {
        Adaptpar_r[1] = MCMC$iter*2
        Adaptpar_r[2] = MCMC$iter*3
    }

    storage.mode(Adaptpar_r)        = "double"



    #####
    # Observations
    #####

    nvar    = ncol(Data)
    nobsTOT = nrow(Data)
    nG      = nobsTOT/(nt*nrep)

    IndexNotNA = which(!is.na(Data[1:nt,1]))-1

    Data_r  = c(t(Data))
    storage.mode(Data_r) = "double"
    storage.mode(IndexNotNA) = "integer"
    #####
    # Integer
    #####
    if(RandomEffect)
    {
        Rparam = T
    }

    indices_r       = c(
        nvar,
        nobsTOT,
        nG,
        nt,
        nrep,
        IterShow,
        as.numeric(DoParallel),
        Nthreads,
        Verbose,
        nlatentk,
        nstep,
        as.numeric(saveODE),
        nNotna = length(IndexNotNA),
        as.numeric(Rparam),
        as.numeric(sample_Var),
        as.numeric(sample_Ode),
        SampleOdeType,
        Kmax ,
        ClustType,
        as.numeric(sample_RandomPar),
        as.numeric(sample_Pi),
        as.numeric(sample_DpPar),
        as.numeric(sample_st),
        IterStartRandom,
        addStartRandom,
        as.numeric(Use_pi),
        as.numeric(Spike),
        as.numeric(Do_MergeSplit),
        TypeK
    )
    storage.mode(indices_r)     = "integer"



    deltat = (tmax-tmin)/(nt-1)
    deltat = deltat/nstep
    indicesDouble_r       = c(

        tmin,
        tmax,
        deltat,
        abs_err,
        rel_err,
        LimSpike,
        LimC,
        ExpMolt,
        ExpLambda,
        MoltSF
    )

    storage.mode(indicesDouble_r)     = "double"


    storage.mode(TEXT) = "character"
    #####
    # model
    #####

    out =.Call("ODE_T2Random",
               nInits_r,
               Inits_r,
               NamePrior_r,
               nParameters_r,
               Prior_r,
               nSd_r,
               Sd_r,
               MCMC_r,
               Adaptpar_r,
               Data_r,
               indices_r,
               indicesDouble_r,
               IndexNotNA,
               TEXT
            )

    # if(Rparam)
    # {
    #     out$MinK = exp(out$MinK)
    #     out$VarK = exp(out$VarK)
    #     out$MeanK = exp(out$MeanK)

    #     out$VarKMean = exp(out$VarKMean)
    #     out$MeanKMean = exp(out$MeanKMean)

    #     out$VarKVar = exp(out$VarKVar)
    #     out$MeanKVar = exp(out$MeanKVar)
    # }

    ReplaceValuest = function(xx )
    {
        find    <- unique(sort(xx))
        replace <- 1:length(unique(sort(xx)))
        found   <- match(xx, find)
        return(ifelse(is.na(found), xx, replace[found]))
    }

    findmode = function(x){
                        TT = table(as.vector(x))
                        return(as.numeric(names(TT)[TT==max(TT)][1]))
                }


#print((out$Beta_11))

    for(ik in 1:3)
    {
        for(ic in 1:2)
        {
            if(ic==1)
            {
                if(ik==1)
                {
                    st_app  = out$st_11
                    pi_app  = out$pi_11
                    DPpar_app = matrix(out$DPpar[1,],nrow=1)
                    ncovs_r = 4
                    nvars_r = 4
                    Beta_app = out$Beta_11
                    Sigma_app = out$Sigma_11
                }
                if(ik==2)
                {
                    st_app  = out$st_21
                    pi_app  = out$pi_21
                    DPpar_app = matrix(out$DPpar[3,],nrow=1)
                    ncovs_r = 4
                    nvars_r = 4
                    Beta_app = out$Beta_21
                    Sigma_app = out$Sigma_21
                }
                if(ik==3)
                {
                    st_app  = out$st_31
                    pi_app  = out$pi_31
                    DPpar_app = matrix(out$DPpar[5,],nrow=1)
                    ncovs_r = 4
                    nvars_r = 4
                    Beta_app = out$Beta_31
                    Sigma_app = out$Sigma_31
                }



                NAMEPAR = c("EtaK1","EtaK2","VarK","MeanK")
            }
            if(ic==2)
            {
                if(ik==1)
                {
                    st_app  = out$st_12
                    pi_app  = out$pi_12
                    DPpar_app = matrix(out$DPpar[2,],nrow=1)
                    ncovs_r = 1
                    nvars_r = 1
                    Beta_app = out$Beta_12
                    Sigma_app = out$Sigma_12
                }
                if(ik==2)
                {
                    st_app  = out$st_22
                    pi_app  = out$pi_22
                    DPpar_app = matrix(out$DPpar[4,],nrow=1)
                    ncovs_r = 1
                    nvars_r = 1
                    Beta_app = out$Beta_22
                    Sigma_app = out$Sigma_22
                }
                if(ik==3)
                {
                    st_app  = out$st_32
                    pi_app  = out$pi_32
                    DPpar_app = matrix(out$DPpar[6,],nrow=1)
                    ncovs_r = 1
                    nvars_r = 1
                    Beta_app = out$Beta_32
                    Sigma_app = out$Sigma_32
                }


                NAMEPAR = c("MinK")
            }

            #print("SS")


            stRep = matrix(NA, ncol=ncol(st_app), nrow=nrow(st_app))
            for(i in 1:ncol(st_app))
            {
                stRep[,i] = ReplaceValuest(st_app[,i])
            }

            Kvec = apply(st_app,2,function(x){  length(table(x)) })
            TKvec = table(Kvec)
            #print(TKvec)
            TKvec = TKvec[TKvec>1]
            ModelOutput = list()
            #print(TKvec)
            h = 0
            rownames(st_app) = paste("st","_",1:nG ,sep="")
            rownames(stRep) = paste("st","_",1:nG,sep="")



            for(k in as.numeric(names(TKvec)))
            {
                h = h+1
                index = which(Kvec==k)

                Clustering = list()
                Clustering[[1]] = stRep[,index]
                Clustering[[2]] = apply(stRep[,index],1,findmode)

                Appxi     = matrix(NA, ncol=TKvec[h], nrow =k  )
                for(i in 1:length(index))
                {
                    W = unique(sort(st_app[,index[i]]))+1
                    Appxi[,i] = pi_app[W,index[i]]
                }
                rownames(Appxi) = paste("pi","_",1:k,sep="")
                Clustering[[3]] = as.mcmc(t(Appxi))
                rownames(DPpar_app) = paste("eta",sep="")
                Clustering[[4]] = as.mcmc(t(DPpar_app))
                namesOUT = c("pi","DPpar")

                Clustering[[1]] = as.mcmc(t(stRep[,index]))

                names(Clustering) =  c("st","MAP", namesOUT)


                # App=list()
                # App2=list()
                # for(i in 1:nvars_r)
                # {
                #     App[[i]] = rep(i,  DimCov_r[i])
                #     App2[[i]] = 1:DimCov_r[i]
                # }
                # unlist(App)
            #NAMEPAR
                AppBeta     = matrix(NA, ncol=TKvec[h], nrow =ncovs_r*k  )
                AppSigma    = matrix(NA, ncol=TKvec[h], nrow =nvars_r^2*k  )

                MatIndexBeta = matrix(1:(ncovs_r*Kmax), nrow=Kmax,byrow=T)
                MatIndexSigma = matrix(1:(nvars_r^2*Kmax), nrow=Kmax,byrow=T)
                for(i in 1:length(index))
                {
                    W = unique(sort(st_app[,index[i]]))+1
                    WBeta = c(t(MatIndexBeta[W,]))
                    WSigma = c(t(MatIndexSigma[W,]))

                    AppBeta[,i] = Beta_app[WBeta,index[i]]
                    AppSigma[,i] = Sigma_app[WSigma,index[i]]

                }
                LikelihoodParameters = list()
                rownames(AppBeta) = paste("Beta","_",NAMEPAR ,",",rep(1:k,each=sum(ncovs_r)),sep="")
                LikelihoodParameters[[1]] = as.mcmc(t(AppBeta))

                rownames(AppSigma) = paste("Sigma","_",rep(1:nvars_r, each=nvars_r), rep(1:nvars_r, times=nvars_r),",",rep(1:k,each=nvars_r^2),sep="")
                LikelihoodParameters[[2]] = as.mcmc(t(AppSigma))


                names(LikelihoodParameters) =  c("Beta", "Sigma")



                ModelOutput[[k]] = list(Clustering=Clustering,LikelihoodParameters = LikelihoodParameters)
            }

            names(ModelOutput) = paste("K=",1:length(ModelOutput),sep="")

            if(ic==1)
            {
                if(ik==1)
                {
                    ModelOutput_11 = list(ModelOutput=ModelOutput,PostK       = c(Kvec))

                }
                if(ik==2)
                {
                    ModelOutput_21 = list(ModelOutput=ModelOutput,PostK       = c(Kvec))
                }
                if(ik==3)
                {
                    ModelOutput_31 = list(ModelOutput=ModelOutput,PostK       = c(Kvec))
                }
            }
            if(ic==2)
            {
                if(ik==1)
                {
                    ModelOutput_12 =list(ModelOutput=ModelOutput,PostK       = c(Kvec))
                }
                if(ik==2)
                {
                    ModelOutput_22 = list(ModelOutput=ModelOutput,PostK       = c(Kvec))
                }
                if(ik==3)
                {
                   ModelOutput_32 = list(ModelOutput=ModelOutput,PostK       = c(Kvec))
                }


            }

        }
    }





    ret = list(
        MinK = t(out$MinK),VarK = t(out$VarK),MeanK = t(out$MeanK), EtaK1 = t(out$EtaK1), EtaK2 = t(out$EtaK2), Y = t(out$Y), Y0 = t(out$Y0),
               Beta0 = t(out$Beta0),
               Beta1 = t(out$Beta1),
               SF_1  = t(out$SF_1),
               SF_2  = t(out$SF_2),
               SF_3  = t(out$SF_3),
                ModelOutput_11= ModelOutput_11,
                ModelOutput_21= ModelOutput_21,
                ModelOutput_31= ModelOutput_31,
                ModelOutput_12= ModelOutput_12,
                ModelOutput_22= ModelOutput_22,
                ModelOutput_32= ModelOutput_32


 )
return(ret)




}
