
#include <iostream>
using std::cout; using std::endl; using std::string;
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>
#include "Functions.h"
#include "MatricesAndVectors.h"
#include <string>
#include <vector>

   
//******* To Load ***/
const double    Class_ToLoad::Dzero          = 0.0;
const double    Class_ToLoad::Done          = 1.0;
const double    Class_ToLoad::Dtwo          = 2.0;
const double    Class_ToLoad::DMinusOne     = -1.0;

const int       Class_ToLoad::Izero         = 0;
const int       Class_ToLoad::Ione          = 1;

int             Class_ToLoad::info          = 0;

 



//
//
//int Class_ToLoad::addpointer(double *app)
//{
//    PointerDouble.push_back(app);
//    return((int)PointerDouble.size());
//}
//int Class_ToLoad::addpointer(int *app)
//{
//    PointerInt.push_back(app);
//    return((int)PointerInt.size());
//}
//int Class_ToLoad::addpointer(double **app)
//{
//    PointerPointerDouble.push_back(app);
//    return((int)PointerPointerDouble.size());
//}
//int Class_ToLoad::addpointer(int **app)
//{
//    PointerPointerInt.push_back(app);
//    return((int)PointerPointerInt.size());
//}
//
//void Class_ToLoad::zeropointer(double *app, int pos)
//{
//    Class_ToLoad::PointerDouble[pos] = 0;
//}
//void Class_ToLoad::zeropointer(int *app, int pos)
//{
//    Class_ToLoad::PointerInt[pos] = 0;
//}
//void Class_ToLoad::zeropointer(double **app, int pos)
//{
//    Class_ToLoad::PointerPointerDouble[pos] = 0;
//}
//void Class_ToLoad::zeropointer(int **app, int pos)
//{
//    Class_ToLoad::PointerPointerInt[pos] = 0;
////}
/******************************
 Poly funcrtions
 ******************************/

/*****  void MatrixPoly(int nrow, int ncol, int UserControledMemory) *****/

//void MatrixNotSparse::MatrixPoly(int nrow, int ncol, int UserControledMemory)
//{
//    UsContPoly = 0;
//    nRowsPoly = nrow;
//    nColsPoly = ncol;
//    DimTotPoly = nRowsPoly*nColsPoly;
//
//    nVals       = DimTotPoly;
//
//    ColPointerPoly      = 0;
//    RowIndexPoly        = 0;
//
//    isSparse   = 0;
//
//    if(DimTotPoly==0)
//    {
//        PPoly=0;
//    }else{
//        if(UserControledMemory==1)
//        {
//            PPoly = Calloc(nRowsPoly*nColsPoly, double);
//            UsContPoly = 1;
//        }else{
//            PPoly = (double*)R_alloc(nRowsPoly*nColsPoly,sizeof(double));
//        }
//    }
//}
//
//
//void SparseMatrix::MatrixPoly(int nrow, int ncol, int nval, int UserControledMemory)
//{
//    UsContPoly = 0;
//    nRowsPoly = nrow;
//    nColsPoly = ncol;
//    DimTotPoly = nRowsPoly*nColsPoly;
//
//    isSparse   = 1;
//
//    nVals = nval;
//
//    if(DimTotPoly==0)
//    {
//        ColPointerPoly  = 0;
//        RowIndexPoly    = 0;
//        PPoly      = 0;
//    }else{
//        if(UserControledMemory==1)
//        {
//            ColPointerPoly  = Calloc(nColsPoly+1, int);
//            RowIndexPoly    = Calloc(nVals, int);
//            PPoly           = Calloc(nVals, double);
//
//            UsContPoly = 1;
//        }else{
//
//            ColPointerPoly  = (int*)R_alloc(nColsPoly+1, sizeof(int));
//            RowIndexPoly    = (int*)R_alloc(nVals, sizeof(int));
//            PPoly           = (double*)R_alloc(nVals, sizeof(double));
//        }
//    }
//}
//void SparseMatrix::MatrixPoly(int nrow, int ncol, int nval,Vector<int> *colpointerpoly, Vector<int> *rowindexpoly,  int usr)
//{
//    UsContPoly = 0;
//    nRowsPoly = nrow;
//    nColsPoly = ncol;
//    DimTotPoly = nRowsPoly*nColsPoly;
//
//    isSparse   = 1;
//
//    nVals = nval;
//
//
//
//
//    if(DimTotPoly==0)
//    {
//        ColPointerPoly  = 0;
//        RowIndexPoly    = 0;
//        PPoly      = 0;
//    }else{
//
//        if(colpointerpoly->UsCont!=rowindexpoly->UsCont)
//        {
//            error("colpointerpoly->UsCont!=rowindexpoly->UsCont different");
//        }else{
//            UsContPoly = colpointerpoly->UsCont;
//        }
//
//        ColPointerPoly  = colpointerpoly->P;
//        RowIndexPoly    = rowindexpoly->P;
//        if(UsContPoly==1)
//        {
//
//            PPoly      = Calloc(nVals, double);
//            UsContPoly = 1;
//        }else{
//            PPoly      = (double*)R_alloc(nVals, sizeof(double));
//        }
//    }
//}
///***** void InitPoly(double init)  *****/
//
//void MatrixNotSparse::InitPoly(double init)
//{
//    for(int i=0;i<nRowsPoly*nColsPoly;i++)
//    {
//        PPoly[i] = init;
//    }
//}
//
//void SparseMatrix::InitPoly(double init)
//{
//    for(int i=0;i<nVals;i++)
//    {
//        PPoly[i] = init;
//    }
//}
//
//
///*****  void Set(int i, int j,double val) *****/
//
//void MatrixNotSparse::Set(int i, int j,double val)
//{
//    PPoly[i*nColsPoly+j] = val;
//}
//
//
//void SparseMatrix::Set(int row, int col,double val)
//{
//    int i;
//    for (i = ColPointerPoly[col]; i < ColPointerPoly[col + 1]; i++)
//    {
//        if (RowIndexPoly[i] == row)
//        {
//            PPoly[i] = val;
//            return ;
//        }
//    }
//    error("Value not found: Set(int i, int j,double val)");
//}
//
//
//
//
///*****  double Get(int i, int j) *****/
//
//double MatrixNotSparse::Get(int i, int j)
//{
//    return(PPoly[i*nColsPoly+j]);
//}
//
//double SparseMatrix::Get(int row, int col)
//{
//    //return(PPoly[i*nColsPoly+j]);
//
//    int i;
//    for (i = ColPointerPoly[col]; i < ColPointerPoly[col + 1]; i++)
//    {
//        if (RowIndexPoly[i] == row)
//        {
//            return(PPoly[i]);
//        }
//    }
//    return(0.0);
//}
//
///*****  double* PGet(int i, int j) *****/
//
//double *MatrixNotSparse::PGet(int i, int j)
//{
//    return(&PPoly[i*nColsPoly+j]);
//}
//
//double *SparseMatrix::PGet(int row, int col)
//{
//    int i;
//    for (i = ColPointerPoly[col]; i < ColPointerPoly[col + 1]; i++)
//    {
//        if (RowIndexPoly[i] == row)
//        {
//            return(&PPoly[i]);
//        }
//    }
//    error("Pointer do not exist");
//}
//
///*****  void Print(string ToPrint) *****/
//
//void MatrixNotSparse::Print(string ToPrint)
//{
//    REprintf("%s \n Matrix nrows=%i ncols=%i address=%p \n", ToPrint.c_str(),nRowsPoly, nColsPoly,PPoly);
//    for(int i=0;i<nRowsPoly;i++)
//    {
//        for(int j=0;j<nColsPoly;j++)
//        {
//            PrintTemplate(PPoly[i*nColsPoly+j]);
//        }
//        REprintf("\n");
//    }
//}
//
//
//
//
//void SparseMatrix::set_cell(int row, int col, int dim, Vector<int>  *rowInd, Vector<int>  *colPtr)
//{
//    int cols = dim;
//
//    int i, j;
//
//    int *colptr = colPtr->P;
//    int *rowind = rowInd->P;
//
//    for (i = colptr[col]; i < colptr[col + 1]; i++)
//    {
//        if (rowind[i] == row)
//        {
//            return ;
//        }
//    }
//
//    Vector<int> VnewRowind(colptr[cols] + 1,rowInd->UsCont);
//    int* newRowind = VnewRowind.P;
//
//    for (i = 0; i < col; i++)
//    {
//        for (j = colptr[i]; j < colptr[i + 1]; j++)
//        {
//            newRowind[j] = rowind[j];
//        }
//    }
//    for (j = colptr[i]; j < colptr[i + 1] && rowind[j] < row; j++)
//    {
//        newRowind[j] = rowind[j];
//    }
//    newRowind[j] = row;
//    for ( ; j < colptr[cols]; j++)
//    {
//        newRowind[j + 1] = rowind[j];
//    }
//    for (i++; i <= cols; i++)
//    {
//        colptr[i]++;
//    }
//
//    int *app;
//    app     = rowInd->P;
//    rowInd->P = newRowind;
//    rowInd->nElem++;
//
//    VnewRowind.P = app;
//    VnewRowind.nElem--;
//    VnewRowind.Destroy();
//
//}
///******************************
// Specific functions
// ******************************/
//
//
//
//void App_ObjectSparseMatrix::create_FullObjectNNGPUni(Vector<int> * nneigh,Matrix<int> *neigh, int neighmax, int usr)
//{
//    UserControlledMemory = usr;
//
//    int nElem = nneigh[0].nElem;
//    nRows = nElem;
//    nCols = nElem;
////    for(int i=0;i<nElem;i++)
////    {
////        Neigh.push_back(Vector<int>(nneigh[0].vec(i),neigh->Pmat(i,0)) );
////    }
//
//    rowInd = Vector<int>(nElem,UserControlledMemory);
//    colPtr = Vector<int>(nElem+1,UserControlledMemory);
//    colPtr.Pvec(0)[0] = 0;
//    for(int i=0;i<nElem;i++)
//    {
//        rowInd.Pvec(i)[0]      = i;
//        colPtr.Pvec(i+1)[0]    = i+1;
//    }
//
//    int iObs,jObs,j;
//    for(iObs=0;iObs<nElem;iObs++)
//    {
//        for(j=0;j<nneigh->vec(iObs);j++)
//        {
//            jObs = neigh->mat(iObs,j);
//            if(jObs!=iObs)
//            {
//                if(jObs<iObs)
//                {
//                    SparseMatrix::set_cell(iObs, jObs, nElem, &rowInd, &colPtr);
//                }else{
//                    SparseMatrix::set_cell(jObs,iObs, nElem, &rowInd, &colPtr);
//                }
//            }
//        }
//    }
//    nVal = rowInd.nElem;
//}
//
//void App_ObjectSparseMatrix::create_FullObjectNNGPCoreg(int dimcoreg,Vector<int> * nneigh,Matrix<int> *neigh, int neighmax, int usr)
//{
//    int nElem = nneigh[0].nElem;
//    int DimCoreg = dimcoreg;
//    UserControlledMemory = usr;
//
//    nRows = nElem;
//    nCols = nElem;
//
//
//
////    for(int i=0;i<nElem;i++)
////    {
////        Neigh.push_back(Vector<int>(nneigh[0].vec(i),neigh->Pmat(i,0)) );
////    }
//
//    rowInd = Vector<int>(nElem*DimCoreg,UserControlledMemory);
//    colPtr = Vector<int>(nElem*DimCoreg+1,UserControlledMemory);
//    colPtr.Pvec(0)[0] = 0;
//    for(int i=0;i<nElem*DimCoreg;i++)
//    {
//        rowInd.Pvec(i)[0]      = i;
//        colPtr.Pvec(i+1)[0]    = i+1;
//    }
//
//    int iObs,jObs,i,j,k1,k2;
//    for(iObs=0;iObs<nElem;iObs++)
//    {
//        for(i=0;i<DimCoreg;i++)
//        {
//            for(j=0;j<i;j++)
//            {
//                SparseMatrix::set_cell(iObs*DimCoreg+i, iObs*DimCoreg+j, nElem, &rowInd, &colPtr);
//            }
//        }
//    }
//    for(iObs=0;iObs<nElem;iObs++)
//    {
//
//        for(j=0;j<nneigh->vec(iObs);j++)
//        {
//            jObs = neigh->mat(iObs,j);
//            if(jObs!=iObs)
//            {
//                if(jObs<iObs)
//                {
//                    for(k1=0;k1<DimCoreg;k1++)
//                    {
//                        for(k2=0;k2<DimCoreg;k2++)
//                        {
//                            SparseMatrix::set_cell(iObs*DimCoreg+k1, jObs*DimCoreg+k2, nElem, &rowInd, &colPtr);
//                        }
//                    }
//                }else{
//                    for(k1=0;k1<DimCoreg;k1++)
//                    {
//                        for(k2=0;k2<DimCoreg;k2++)
//                        {
//                            SparseMatrix::set_cell(jObs*DimCoreg+k1, iObs*DimCoreg+k2, nElem, &rowInd, &colPtr);
//                        }
//                    }
//                }
//            }
//        }
//    }
//
//    nVal = rowInd.nElem;
//
//
//}
//




/*******************
 UTILS
 ******************/
void Class_Utils::compute_dist(int nelem, int dimcoords, double *coords, double *ret)
{
    if(dimcoords==2)
    {
        for(int i=0;i<nelem;i++)
        {
            for(int j=0;j<nelem;j++)
            {
                ret[i*nelem+j] =  pow(  pow(coords[i*dimcoords]-coords[j*dimcoords],2.0)+pow(coords[i*dimcoords+1]-coords[j*dimcoords+1],2.0)   ,0.5);
            }
        }
        
    }else{
        if(dimcoords==1)
        {
            for(int i=0;i<nelem;i++)
            {
                for(int j=0;j<nelem;j++)
                {
                    ret[i*nelem+j] =  pow(  pow(coords[i*dimcoords]-coords[j*dimcoords],2.0)  ,0.5);
                }
            }
            
        }else{
            error("Dimension coords: compute_dist");
        }
    }
    
}

void Class_Utils::compute_dist(int nelem, int dimcoords, double *coords, double *ret, double *ret2)
{
    if(dimcoords==3)
    {
        for(int i=0;i<nelem;i++)
        {
            for(int j=0;j<nelem;j++)
            {
                ret[i*nelem+j] =  pow(  pow(coords[i*dimcoords]-coords[j*dimcoords],2.0)+pow(coords[i*dimcoords+1]-coords[j*dimcoords+1],2.0)   ,0.5);
                ret2[i*nelem+j] =  pow(  pow(coords[i*dimcoords+2]-coords[j*dimcoords+2],2.0) ,0.5);
            }
        }
        
    }else{
        error("Dimension coords: compute_dist");
    }
    
}



void Class_Utils::compute_dist(int nelem,Matrix<double> *coords, Matrix<double> *dist)
{
    Class_Utils::compute_dist(nelem, coords->nCols, coords->P, dist->P);
}
void Class_Utils::compute_dist(Matrix<double> *coords, Matrix<double> *dist)
{
    Class_Utils::compute_dist(coords->nRows, coords->nCols, coords->P, dist->P);
}


void Class_Utils::compute_dist(int nelem,Matrix<double> *coords, Matrix<double> *dist, Matrix<double> *dist2)
{
    Class_Utils::compute_dist(nelem, coords->nCols, coords->P, dist->P, dist2->P);
}
void Class_Utils::compute_dist(Matrix<double> *coords, Matrix<double> *dist, Matrix<double> *dist2)
{
    Class_Utils::compute_dist(coords->nRows, coords->nCols, coords->P, dist->P, dist2->P);
}


void Class_Utils::external_dgemv(Matrix<double> *Mat, Vector<double> *Vec, Vector<double> *ret, const double Add)
{
    // Ancpra da cpntrollare
    double Done = 1.0;
    int    Ione = 1;
    F77_NAME(dgemv)("T",&Mat->nCols,&Mat->nRows,&Done ,Mat->P,&Mat->nCols,Vec->P,&Ione,&Add,ret->P,&Ione );
}

void Class_Utils::external_dsymv_MatMoltX(Matrix<double> *Inv, Vector<double> *mu, Vector<double> *ret)
{
    double Done = 1.0;
    double Dzero = 0.0;
    int    Ione = 1;
    
    F77_NAME(dsymv)("L", &mu->nElem, &Done, Inv->P, &mu->nElem, mu->P, & Ione, &Dzero, ret->P, &Ione);
    
}

void Class_Utils::external_dgemm(Matrix<double> *Mat1, Matrix<double> *Mat2, Matrix<double> *ret, const  double Add)
{
    double Done = 1.0;
    //    double Dzero = 0.0;
    //    int    Ione = 1;
    F77_NAME(dgemm)("N","N",&Mat2->nCols,&Mat1->nRows,&Mat2->nRows,&Done,Mat2->P,&Mat2->nCols,Mat1->P,&Mat1->nCols,&Add,ret->P,&Mat2->nCols);
    
}
void Class_Utils::external_vec1vec2(Vector <double> *y1, Vector <double> *y2,double *ret)
{
    int n = y1[0].nElem;
    int    Ione = 1;
    ret[0] = F77_NAME(ddot)(&n,y1->P, &Ione, y2->P, &Ione);
}
void Class_Utils::external_ytSigmaInvy(Vector <double> *y, Matrix <double> * SigmaInv,double *ret)
{
    int n = y->nElem;
    double retVec_P[n];
    Vector <double> retVec(n,retVec_P);
    
    external_dsymv_MatMoltX(SigmaInv, y, &retVec);
    Class_Utils::external_vec1vec2(&retVec, y,ret);
}

//static void external_dsymv_MatMoltX(Matrix<double> *Inv, Vector<double> *mu, Vector<double> *ret);
//static void external_dgemv(Matrix<double> *Mat, Vector<double> *Vec, Vector<double> *ret, const  double Add);
//static void external_dgemm(Matrix<double> *Mat1, Matrix<double> *Mat2, Matrix<double> *ret, const  double Add);
//
//static void external_ytSigmaInvy(Vector <double> *y, Matrix <double> * SigmaInv,double *ret);
//static void external_vec1vec2(Vector <double> *y1, Vector <double> *y2,double *ret);
//

//F77_NAME(dsymv)("L",&n, &Done,sigmaInv ,&n,&ObsMinusMean[0],&Ione, &Dzero, &ObsMinusMeanInvCov[0]  ,&Ione );
//des = -0.5*logdet[0]-0.5*F77_NAME(ddot)(&n,&ObsMinusMeanInvCov[0], &Ione, &ObsMinusMean[0], &Ione);



void Class_Utils::external_computeCholesky(Matrix<double> *Sigma)
{
    
    int info;
    F77_NAME(dpotrf)("L",&Sigma->nCols, Sigma->P, &Sigma->nCols, &info);
    if(info != 0)
    {
        if(Sigma->nRows==1)
        {
            Sigma->Pmat(0,0)[0] = pow(Sigma->Pmat(0,0)[0],0.5);
        }else{
            error("Cpp error Cholesky failed - function: external_computeCholesk\n");
        }
        
    }
    
    
}



double Class_Utils::external_computeLogDetCholesky(Matrix<double> *Chol)
{
    
    double logdetAcc = 0;
    for(int i =0;i<Chol->nRows;i++)
    {
        logdetAcc += 2.0*log(Chol->mat(i,i));
    }
    return(logdetAcc);
}


void Class_Utils::external_computeInverseFromCholesky(Matrix<double> *Chol)
{
    
    int info;
    F77_NAME(dpotri)("L",&Chol->nCols, Chol->P, &Chol->nCols, &info);
    if(info != 0)
    {
        if(Chol->nRows==1)
        {
            Chol->Pmat(0,0)[0] = pow(1.0/Chol->Pmat(0,0)[0],2);
        }else{
            error("CCpp error Cholesky inverse  - function: external_computeCholesk\n");
        }
        
    }
    
    
}



void Class_Utils::compute_Sigma_Chol_LogDet_FromInverse(Matrix<double> *Inv, Matrix <double> *Retmat,Matrix <double> *RetChol, double *logDet)
{
  
  
  for(int jj1=0;jj1<Inv->nRows;jj1++)
  {
    for(int jj2=0;jj2<Inv->nRows;jj2++)
    {
      Retmat->Pmat(Inv->nRows-1-jj1,Inv->nRows-1-jj2)[0] = Inv->mat(jj1,jj2);
    }
  }
  
  external_computeCholesky(Retmat);
  external_computeInverseTriMatrix(Retmat);
  
  for(int jj1=0;jj1<Inv->nRows;jj1++)
  {
    for(int jj2=0;jj2<Inv->nRows;jj2++)
    {
      RetChol->Pmat(Inv->nRows-1-jj2,Inv->nRows-1-jj1)[0] = Retmat->mat(jj2,jj1);
    }
  }

  logDet[0]  = external_computeLogDetCholesky(RetChol);
  
  
  for(int irow=0;irow<Inv->nRows;irow++)
  {
    for(int icol=irow;icol<Inv->nRows;icol++)
    {
      Retmat->Pmat(irow,icol)[0] = 0.0;
      for(int istar=0;istar<irow+1;istar++)
      {
        Retmat->Pmat(irow,icol)[0] += RetChol->mat(irow,istar)*RetChol->mat(icol,istar);
      }  
    }
  }
}


void Class_Utils::external_computeInverseTriMatrix(Matrix<double> *Tri)
{
    
    int info;
    F77_NAME(dtrtri)("L","N",&Tri->nCols, Tri->P, &Tri->nCols, &info);
    if(info != 0)
    {
        if(Tri->nRows==1)
        {
            Tri->Pmat(0,0)[0] = pow(1.0/Tri->Pmat(0,0)[0],2);
        }else{
            error("CCpp error Triangular inverse  - function: external_computeInverseTriMatrix\n");
        }
        
    }
    
    
}
void Class_Utils::external_computeInverseTriMatrix_Lower(Matrix<double> *Tri)
{
    
    int info;
    F77_NAME(dtrtri)("U","N",&Tri->nCols, Tri->P, &Tri->nCols, &info);
    if(info != 0)
    {
        if(Tri->nRows==1)
        {
            Tri->Pmat(0,0)[0] = pow(1.0/Tri->Pmat(0,0)[0],2);
        }else{
            error("CCpp error Triangular inverse  - function: external_computeInverseTriMatrix\n");
        }
        
    }
    
    
}



void Class_Utils::external_computeInverseFromCholesky_Lower(Matrix<double> *Chol)
{
    
    int info;
    F77_NAME(dpotri)("U",&Chol->nCols, Chol->P, &Chol->nCols, &info);
    if(info != 0)
    {
        if(Chol->nRows==1)
        {
            Chol->Pmat(0,0)[0] = pow(1.0/Chol->Pmat(0,0)[0],2);
        }else{
            error("CCpp error Cholesky inverse  - function: external_computeCholesk\n");
        }
        
    }
    
    
}





double Class_Utils::ModOp(double x, double y)
{
    double ret = fmod(x,y);
    if(ret<0)
    {
        ret = y+ret;
    }
    return(ret);
}
void Class_Utils::log_sum_exp(double *ret, int k, double *logx)
{
    // it computes log(sum_i^k e^logx_i)
    double max = logx[0];
    int i;
    for(i=1;i<k;i++)
    {
        if(logx[i]>max)
        {
            max = logx[i];
        }
    }
    ret[0] = 0.0;
    for(i=0;i<k;i++)
    {
        ret[0] += exp(logx[i]-max);
    }
    ret[0] = max+log(ret[0]);
}
void Class_Utils::log_sum_exp_Type2(double *ret, int k, double *logx, double *a_i)
{
    // it computes log(sum_i^k a_i e^logx_i)
    double log_i[k];
    log_i[0] = log(a_i[0]);
    double max = logx[0]+log_i[0];
    int i;
    for(i=1;i<k;i++)
    {
        log_i[i] = log(a_i[i]);
        if((logx[i]+log_i[i])>max)
        {
            max = logx[i]+log_i[i];
        }
    }
    ret[0] = 0.0;
    for(i=0;i<k;i++)
    {
        ret[0] += exp(logx[i]+log_i[i]-max);
    }
    ret[0] = max+log(ret[0]);
}
void Class_Utils::log_sum_exp(double *ret, int k, double *logx, int* nonzero)
{
    // questo tiene conto del fatto che alcuni elementi non vanno considerati
    // non tiene conto del fatot che k possa essere zero
    double max = logx[nonzero[0]];
    int i,i2;
    for(i2=1;i2<k;i2++)
    {
        i = nonzero[i2];
        if(logx[i]>max)
        {
            max = logx[i];
        }
    }
    ret[0] = 0.0;
    for(i2=0;i2<k;i2++)
    {
        i = nonzero[i2];
        ret[0] += exp(logx[i]-max);
    }
    ret[0] = max+log(ret[0]);
}
//void Class_Utils::PrintTemplate(double val)
//{
//    REprintf("%f ", val);
//};
//void Class_Utils::PrintTemplate(int val)
//{
//    REprintf("%i ", val);
//};



double Class_Utils::log1mexp(double x)
{
    double ret;
    if(x>(-0.1))
    {
        ret = log(-expm1(x));
    }else{
        ret = log1p(-exp(x));
    }
    return(ret);
}

double Class_Utils::CircDist(double dist, double Cicle)
{
    double ret;
    double app;
    
    app = Class_Utils::ModOp(dist,Cicle);
    if(app<Cicle/2.0)
    {
        ret = app;
    }else{
        ret = Cicle-app;
    }
    return(ret);
}
//
SEXP Class_Utils::getListElement(SEXP list, const char *str)
{
    SEXP elmt = R_NilValue, names = getAttrib(list, R_NamesSymbol);
    for (R_len_t i = 0; i < length(list); i++)
        if(strcmp(CHAR(STRING_ELT(names, i)), str) == 0) {
            elmt = VECTOR_ELT(list, i);
            break; }
    return elmt;
}

int Class_Utils::FindIndexString(vector <string> *Names, string *name)
{
    int Found = -1;
    for(int i=0;i<Names->size();i++)
    {
        if(Names[0][i]==name[0])
        {
            Found = i;
        }
    }
    if(Found== (-1))
    {
        error("FindIndexString: %s not found",name->c_str());;
    }
    return(Found);
    
}


int Class_Utils::sample_DiscreteVarEqualProb( int K)
{
    int k;
    double sum = 1.0;
    double prob[K];
	
    for(k=0;k<K;k++)
    {
        prob[k] = 1.0/K;
    }
    
    double u = runif(0.0,1.0);
    //REprintf("u %f ",u);
    sum = 0.0;
    k = -1;
    do{
        k++;
        sum += prob[k];
        //REprintf("%f ",sum );
    }while(sum<u);
    
    //REprintf("K=%i\n",k);
    return(k);
}
int Class_Utils::sample_DiscreteVar(double *logprob_NonNormalized, int K)
{
    int k;
    double sum = 0.0;;
    double prob[K];
    Class_Utils::log_sum_exp(&sum, K, logprob_NonNormalized);
    
    for(k=0;k<K;k++)
    {
        prob[k] = exp(logprob_NonNormalized[k]-sum);
    }
    
    double u = runif(0.0,1.0);
    //REprintf("u %f ",u);
    sum = 0.0;
    k = -1;
    do{
        k++;
        sum += prob[k];
        //REprintf("%f ",sum );
    }while(sum<u);
    
    //REprintf("K=%i\n",k);
    return(k);
}
int Class_Utils::sample_DiscreteVarTEST(double *logprob_NonNormalized, int K)
{
    int k;
    double sum = 0.0;;
    double prob[K];
    Class_Utils::log_sum_exp(&sum, K, logprob_NonNormalized);
    
    for(k=0;k<K;k++)
    {
        prob[k] = exp(logprob_NonNormalized[k]-sum);
    }
    
    double u = runif(0.0,1.0);
    //REprintf("u %f ",u);
    sum = 0.0;
    k = -1;
    do{
        k++;
        
        sum += prob[k];
        REprintf("P=%f %f %f\n",prob[k],u,sum);
        //REprintf("%f ",sum );
    }while(sum<u);
    
    REprintf("K=%i\n",k);
    return(k);
}
int Class_Utils::sample_DiscreteVar(double *logprob_NonNormalized, int K, int *nonzero)
{
    
    REprintf("COntrollare che funzioni bene");
    int k,k1;
    double sum = 0.0;;
    double prob[K];
    REprintf("S1\n");
    log_sum_exp(&sum, K, logprob_NonNormalized,nonzero);
    REprintf("S2\n");
    for(k1=0;k1<K;k1++)
    {
        k = nonzero[k1];
        REprintf("k %i %i\n",k, k1);
        prob[k] = exp(logprob_NonNormalized[k]-sum);
    }
    REprintf("S3\n");
    double u = runif(0.0,1.0);
    //REprintf("u %f ",u);
    sum = 0.0;
    k1 = -1;
    do{
        k1++;
        k   = nonzero[k1];
        sum += prob[k];
        //REprintf("%f ",sum );
    }while(sum<u);
    REprintf("S4\n");
    //REprintf("K=%i\n",k);
    return(k);
}

int Class_Utils::sample_DiscreteVarFixed(double *logprob_NonNormalized, int KnonZero, int *nonzero)
{
    // dimension logprob_NonNormalized - K
    // dimensione nonzero - Kzero
    int k,k1;
    double sum = 0.0;;
    double prob[KnonZero];
    //REprintf("S1\n");
    log_sum_exp(&sum, KnonZero, logprob_NonNormalized,nonzero);
    //REprintf("S2\n");
    for(k1=0;k1<KnonZero;k1++)
    {
        k = nonzero[k1];
        prob[k1] = exp(logprob_NonNormalized[k]-sum);
    }
    //REprintf("S3\n");
    double u = runif(0.0,1.0);
    //REprintf("u %f ",u);
    sum = 0.0;
    k1 = -1;
    do{
        k1++;
        k   = nonzero[k1];
        sum += prob[k1];
        //REprintf("%f ",sum );
    }while(sum<u);
    //REprintf("S4\n");
    //REprintf("K=%i\n",k);
    return(k);
}



//
//
//double Class_Utils::log1mexp(double x)
//{
//    double ret;
//    if(x>(-0.1))
//    {
//        ret = log(-expm1(x));
//    }else{
//        ret = log1p(-exp(x));
//    }
//    return(ret);
//}









