
#include <iostream>

#include "MatricesAndVectors.h"
#include <string>
#include <vector>
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>
#include "DensityPriorParam.h"
#include "Functions.h"

//using namespace std;
using std::cout; using std::endl; using std::string;


