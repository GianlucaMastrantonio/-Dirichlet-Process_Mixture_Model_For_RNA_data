

#include <iostream>
//#include <iomanip>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <map>
#include <algorithm>
#include <R.h>
#include <Rmath.h>
#include <Rinternals.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>
#include <R_ext/Utils.h>
//#include "T_Matrix.h"
using namespace std;

//#define _USE_MATH_DEFINES
//double ModOp(double x, double y)
//{
//    double ret = fmod(x,y);
//    if(ret<0)
//    {
//        ret = y+ret;
//    }
//    return(ret);
//}
//void log_sum_exp(double *ret, int k, double *logx)
//{
//    // it computes log(sum_i^k e^logx_i)
//    double max = logx[0];
//    int i;
//    for(i=1;i<k;i++)
//    {
//        if(logx[i]>max)
//        {
//            max = logx[i];
//        }
//    }
//    ret[0] = 0.0;
//    for(i=0;i<k;i++)
//    {
//        ret[0] += exp(logx[i]-max);
//    }
//    ret[0] = max+log(ret[0]);
//}
//void log_sum_exp(double *ret, int k, double *logx, int* nonzero)
//{
//    // questo tiene conto del fatto che alcuni elementi non vanno considerati
//    // non tiene conto del fatot che k possa essere zero
//    double max = logx[nonzero[0]];
//    int i,i2;
//    for(i2=1;i2<k;i2++)
//    {
//        i = nonzero[i2];
//        if(logx[i]>max)
//        {
//            max = logx[i];
//        }
//    }
//    ret[0] = 0.0;
//    for(i2=0;i2<k;i2++)
//    {
//        i = nonzero[i2];
//        ret[0] += exp(logx[i]-max);
//    }
//    ret[0] = max+log(ret[0]);
//}
//void PrintTemplate(double val)
//{
//    Rprintf("%f ", val);
//};
//void PrintTemplate(int val)
//{
//    Rprintf("%i ", val);
//};
//
//
//
//double log1mexp(double x)
//{
//    double ret;
//    if(x>(-0.1))
//    {
//        ret = log(-expm1(x));
//    }else{
//        ret = log1p(-exp(x));
//    }
//    return(ret);
//}
//
//double CircDist(double dist, double Cicle)
//{
//    double ret;
//    double app;
//    
//    app = ModOp(dist,Cicle);
//    if(app<Cicle/2.0)
//    {
//        ret = app;
//    }else{
//        ret = Cicle-app;
//    }
//    return(ret);
//}
////
//SEXP getListElement(SEXP list, const char *str)
//{
//    SEXP elmt = R_NilValue, names = getAttrib(list, R_NamesSymbol);
//    for (R_len_t i = 0; i < length(list); i++)
//        if(strcmp(CHAR(STRING_ELT(names, i)), str) == 0) {
//            elmt = VECTOR_ELT(list, i);
//            break; }
//    return elmt;
//}
//
//int FindIndexString(vector <string> *Names, string *name)
//{
//    int Found = -1;
//    for(int i=0;i<Names->size();i++)
//    {
//        if(Names[0][i]==name[0])
//        {
//            Found = i;
//        }
//    }
//    if(Found== (-1))
//    {
//        error("FindIndexString: %s not found",name->c_str());;
//    }
//    return(Found);
//    
//}
//
//
//int sample_DiscreteVar(double *logprob_NonNormalized, int K)
//{
//    int k;
//    double sum = 0.0;;
//    double prob[K];
//    log_sum_exp(&sum, K, logprob_NonNormalized);
//    
//    for(k=0;k<K;k++)
//    {
//        prob[k] = exp(logprob_NonNormalized[k]-sum);
//    }
//    
//    double u = runif(0.0,1.0);
//    //Rprintf("u %f ",u);
//    sum = 0.0;
//    k = -1;
//    do{
//        k++;
//        sum += prob[k];
//        //Rprintf("%f ",sum );
//    }while(sum<u);
//    
//    //Rprintf("K=%i\n",k);
//    return(k);
//}


// QUI
//int sample_DiscreteVar(double *logprob_NonNormalized, int K, int *nonzero)
//{
//    int k,k1;
//    double sum = 0.0;;
//    double prob[K];
//    log_sum_exp(&sum, K, logprob_NonNormalized,nonzero);
//    
//    for(k1=0;k1<K;k1++)
//    {
//        k = nonzero[k1];
//        prob[k] = exp(logprob_NonNormalized[k]-sum);
//    }
//    
//    double u = runif(0.0,1.0);
//    //Rprintf("u %f ",u);
//    sum = 0.0;
//    k1 = -1;
//    do{
//        k1++;
//        k   = nonzero[k1];
//        sum += prob[k];
//        //Rprintf("%f ",sum );
//    }while(sum<u);
//    
//    //Rprintf("K=%i\n",k);
//    return(k);
//}
//
//double FromSegmentToR(double val, double lim1, double lim2)
//{
//    return(log ((val-lim1)/(lim2-val)));
//}
//double FromRToSegment(double val, double lim1, double lim2)
//{
//    return( (lim1+lim2*exp(val))/(1.0+exp(val) ));
//}
//double logJacobianFromSegmentToR(double ValOnR)
//{
//    return(  ValOnR-2.0*log(1.0+exp(ValOnR))  );
//}
//void SwitchAdresses(double **par1, double **par2)
//{
//    double *app;
//    app     = *par1;
//    *par1 = *par2;
//    *par2   = app;
//}
//
//
//void FromVecProbToVarInR(double *prob, double *VarInR, int dim, int refClass)
//{
//    // assume che la media e VarInR della classa di riferimento sia 0;
//    for(int k=0;k<dim;k++)
//    {
//        VarInR[k] = log(prob[k])-log(prob[refClass]);
//    }
//}
//
//
//
//void CondParametersRegCoefMNorm(int niid, int n, int ncov, double *y, double *covariates, double *sigmainv, double *desmean, double *descov, double *deschol,  double moltBeta_ie_add)
//{
//    
//    //CondParametersRegCoefMNorm(nObs, nProcsL1, ncov=Covariates.nCols, OmegaKl1.P, Covariates.P, Inv.P, meanapp, varapp, chol,  moltBeta_ie_add);
//    double Done = 1.0;
//    int Ione = 1;
//    double Dzero = 0.0;
//    double C[ncov*n];
//    int info;
//    int i;
//    
//    
//
//
//    
//    i=0;
//    F77_NAME(dsymm)("R", "L",&ncov,&n,&Done,sigmainv,&n,&covariates[i*(n*ncov)], &ncov, &Dzero, &C[0],&ncov);
//    
//    //cov
//    F77_NAME(dgemm)("N", "T", &ncov, &ncov, &n, &Done, &C[0], &ncov, &covariates[i*(n*ncov)], &ncov, &moltBeta_ie_add, descov, &ncov);
//    //mean
//    F77_NAME(dgemv)("N",&ncov,&n,&Done,&C[0],&ncov,&y[i*n],&Ione, &moltBeta_ie_add ,desmean ,&Ione);
//    
//
//    
//    for(i=1;i<niid;i++)
//    {
//        F77_NAME(dsymm)("R", "L",&ncov,&n,&Done,sigmainv,&n,&covariates[i*(n*ncov)], &ncov, &Dzero, &C[0],&ncov);
//        
//        //cov
//        F77_NAME(dgemm)("N", "T", &ncov, &ncov, &n, &Done, &C[0], &ncov, &covariates[i*(n*ncov)], &ncov, &Done, descov, &ncov);
//        //mean
//        F77_NAME(dgemv)("N",&ncov,&n,&Done,&C[0],&ncov,&y[i*n],&Ione, &Done,desmean ,&Ione);
//    
//    }
//    
//    F77_NAME(dpotrf)("L",&ncov, descov, &ncov, &info);
//    if(info != 0)
//    {
//        error("Cpp error - function: CondParametersRegCoefMNorm(int n, int ncov, double *y, double *covariates, double *sigmainv, double *desmean, double *descov, double *deschol,  double moltBeta_ie_add) \n Cholesky failed\n");
//    }
//    F77_NAME(dpotri)("L",&ncov, descov, &ncov, &info);
//    if(info != 0)
//    {
//        error("C++ error: Cholesky inverse failed in CondParametersRegCoefMNorm\n");
//    }
//    double appmean[ncov];
//    for(int i=0;i<ncov;i++)
//    {
//        appmean[i] = desmean[i];
//    }
//    
//    F77_NAME(dsymv)("L", &ncov, &Done, descov, &ncov, appmean, &Ione, &Dzero, desmean, &Ione);
//    
//    
//    
//    // chol
//    for(int i=0;i<ncov;i++)
//    {
//        for(int j=i;j<ncov;j++)
//        {
//            deschol[i*ncov+j] = descov[i*ncov+j];
//        }
//    }
//    F77_NAME(dpotrf)("L",&ncov, deschol, &ncov, &info);
//    if(info != 0)
//    {
//        error("c++ error:     Cholesky failed in CondParametersRegCoefMNorm Chol \n");
//    }
//    
//    
//}
//
//
//void CondParametersRegCoefMNorm(int n, int ncov, double *y, double *covariates, double *sigmainv, double *desmean, double *descov, double *deschol,  double moltBeta_ie_add)
//{
//    Rprintf("\n\n\n\nCondParametersRegCoefMNorm USare l'altra formula\n\n\n\n");
//    double Done = 1.0;
//    int Ione = 1;
//    double Dzero = 0.0;
//    double C[ncov*n];
//    
//
//
//    F77_NAME(dsymm)("R", "L",&ncov,&n,&Done,sigmainv,&n,covariates, &ncov, &Dzero, &C[0],&ncov);
//
//    //cov
//    F77_NAME(dgemm)("N", "T", &ncov, &ncov, &n, &Done, &C[0], &ncov, covariates, &ncov, &moltBeta_ie_add, descov, &ncov);
//    //mean
//    F77_NAME(dgemv)("N",&ncov,&n,&Done,&C[0],&ncov,y,&Ione, &moltBeta_ie_add ,desmean ,&Ione);
//
//    int info;
//
//    
//    F77_NAME(dpotrf)("L",&ncov, descov, &ncov, &info);
//    if(info != 0)
//    {
//        error("Cpp error - function: CondParametersRegCoefMNorm(int n, int ncov, double *y, double *covariates, double *sigmainv, double *desmean, double *descov, double *deschol,  double moltBeta_ie_add) \n Cholesky failed\n");
//    }
//    F77_NAME(dpotri)("L",&ncov, descov, &ncov, &info);
//    if(info != 0)
//    {
//        error("C++ error: Cholesky inverse failed in CondParametersRegCoefMNorm\n");
//    }
//    double appmean[ncov];
//    for(int i=0;i<ncov;i++)
//    {
//        appmean[i] = desmean[i];
//    }
//   
//    F77_NAME(dsymv)("L", &ncov, &Done, descov, &ncov, appmean, &Ione, &Dzero, desmean, &Ione);
//    
//    
//    
//    // chol
//    for(int i=0;i<ncov;i++)
//    {
//        for(int j=i;j<ncov;j++)
//        {
//            deschol[i*ncov+j] = descov[i*ncov+j];
//        }
//    }
//    F77_NAME(dpotrf)("L",&ncov, deschol, &ncov, &info);
//    if(info != 0)
//    {
//        error("c++ error:     Cholesky failed in CondParametersRegCoefMNorm Chol \n");
//    }
//
//    
//}
//
////void FromVecProbToVarInR(double *prob, double *VarInR, double *mu, int dim, int refClass)
////{
////    // assume che la media e VarInR della classa di riferimento sia 0;
////    for(int k=0;k<dim;k++)
////    {
////        VarInR[k] = log(prob[k])-log(prob[refClass])-mu[k];
////    }
////}
//
//
//
//void copyElements(int dim, double *from, double *to)
//{
//    for(int i=0;i<dim;i++)
//    {
//        to[i] = from[i];
//    }
//};








