

#include "CovFunctionsV3.h"

using std::cout; using std::endl;
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>



/****************
 get_value_BASE(int n, double* dist);
 ************/

void Class_Exponential::get_valueAcc(int n, double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = exp(-1.0*dist[i]*Parameters[0][0].ParameterAcc);
    }
}
void Class_Exponential::get_valueProp(int n, double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = exp(-1.0*dist[i]*Parameters[0][0].ParameterProp);
    }
}


void Class_Exponential::get_valueAcc_Part1(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = exp(-1.0*dist[i]*Parameters[0][0].ParameterAcc);;
    }
}
void Class_Exponential::get_valueAcc_Part2(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = 0.0;
        
    }
}
void Class_Exponential::get_valueProp_Part1(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =  exp(-1.0*dist[i]*Parameters[0][0].ParameterProp);
    }
}
void Class_Exponential::get_valueProp_Part2(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =  0.0;
    }
}



















void Class_ExponentialCirc::get_valueAcc(int n, double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = exp(-1.0*Class_Utils::CircDist(dist[i],Parameters[1][0].ParameterAcc)*Parameters[0][0].ParameterAcc);
    }
}
void Class_ExponentialCirc::get_valueProp(int n, double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = exp(-1.0*Class_Utils::CircDist(dist[i],Parameters[1][0].ParameterProp)*Parameters[0][0].ParameterProp);
    }
}



void Class_ExponentialCirc::get_valueAcc_Part1(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = exp(-1.0*Class_Utils::CircDist(dist[i],Parameters[1][0].ParameterAcc)*Parameters[0][0].ParameterAcc);;
    }
}
void Class_ExponentialCirc::get_valueAcc_Part2(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = 0.0;
        
    }
}
void Class_ExponentialCirc::get_valueProp_Part1(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =  exp(-1.0*Class_Utils::CircDist(dist[i],Parameters[1][0].ParameterProp)*Parameters[0][0].ParameterProp);
    }
}
void Class_ExponentialCirc::get_valueProp_Part2(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =  0.0;
    }
}
















void Class_Exponential_LinearCovSeason::get_valueAcc(int n, double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = exp(-1.0*dist[i]*Parameters[0][0].ParameterAcc)+
        Parameters[3][0].ParameterAcc*exp(-1.0*Class_Utils::CircDist(dist[i],Parameters[2][0].ParameterAcc)*Parameters[1][0].ParameterAcc);
        //REprintf("%f %f %f \n",dist[i],ModOp(dist[i],Parameters[2][0].ParameterAcc),Parameters[2][0].ParameterAcc);
    }
}
void Class_Exponential_LinearCovSeason::get_valueProp(int n, double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = exp(-1.0*dist[i]*Parameters[0][0].ParameterProp)+
        Parameters[3][0].ParameterProp*exp(-1.0*Class_Utils::CircDist(dist[i],Parameters[2][0].ParameterProp)*Parameters[1][0].ParameterProp);
    }
}




void Class_Exponential_LinearCovSeason::get_valueAcc_Part1(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = exp(-1.0*dist[i]*Parameters[0][0].ParameterAcc);
    }
}
void Class_Exponential_LinearCovSeason::get_valueAcc_Part2(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =(Parameters[3][0].ParameterAcc)*exp(-1.0*Class_Utils::CircDist(dist[i],Parameters[2][0].ParameterAcc)*Parameters[1][0].ParameterAcc);
        
    }
}
void Class_Exponential_LinearCovSeason::get_valueProp_Part1(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =  exp(-1.0*dist[i]*Parameters[0][0].ParameterProp);
    }
}
void Class_Exponential_LinearCovSeason::get_valueProp_Part2(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = (Parameters[3][0].ParameterProp)*exp(-1.0*Class_Utils::CircDist(dist[i],Parameters[2][0].ParameterProp)*Parameters[1][0].ParameterProp);
    }
}



















void Class_ExponentialExponential::get_valueAcc(int n, double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = exp(-1.0*dist1[i]*Parameters[0][0].ParameterAcc)*exp(-1.0*dist2[i]*Parameters[1][0].ParameterAcc);
    }
}
void Class_ExponentialExponential::get_valueProp(int n, double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = exp(-1.0*dist1[i]*Parameters[0][0].ParameterProp)*exp(-1.0*dist2[i]*Parameters[1][0].ParameterProp);
    }
}

void Class_ExponentialExponential::get_valueAcc_Part1(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = exp(-1.0*dist1[i]*Parameters[0][0].ParameterAcc)*exp(-1.0*dist2[i]*Parameters[1][0].ParameterAcc);
    }
}
void Class_ExponentialExponential::get_valueAcc_Part2(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = 0.0;
    }
}
void Class_ExponentialExponential::get_valueProp_Part1(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =  exp(-1.0*dist1[i]*Parameters[0][0].ParameterProp)*exp(-1.0*dist2[i]*Parameters[1][0].ParameterProp);
    }
}
void Class_ExponentialExponential::get_valueProp_Part2(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =  0.0;
    }
}

















void Class_GneitingPlusCirc::get_valueAcc(int n, double* dist1, double* dist2, double *ret)
{
    double ret1;
    double ret2;
    for(int i=0;i<n;i++)
    {
        get_valueAcc_Part1(n,dist1, dist2, &ret1);
        get_valueAcc_Part2(n,dist1, dist2, &ret2);
        ret[i] = ret1+ret2;
    }
}
void Class_GneitingPlusCirc::get_valueProp(int n, double* dist1, double* dist2, double *ret)
{
    double ret1;
    double ret2;
    for(int i=0;i<n;i++)
    {
        get_valueProp_Part1(n,dist1, dist2, &ret1);
        get_valueProp_Part2(n,dist1, dist2, &ret2);
        ret[i] = ret1+ret2;
    }
}

void Class_GneitingPlusCirc::get_valueAcc_Part1(int n,  double* dist1, double* dist2, double *ret)
{
    
    for(int i=0;i<n;i++)
    {
        double app     = Parameters[1][0].ParameterAcc*pow(dist2[i],2.0)+1.0;
        ret[i] = exp(-1.0*log(app)-Parameters[0][0].ParameterAcc*dist1[i]/(pow(app,Parameters[3][0].ParameterAcc/2.0)));
    }
}
void Class_GneitingPlusCirc::get_valueAcc_Part2(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = (Parameters[4][0].ParameterAcc)*exp(-1.0*Class_Utils::CircDist(dist2[i],Parameters[5][0].ParameterAcc)*Parameters[2][0].ParameterAcc);
    }
}
void Class_GneitingPlusCirc::get_valueProp_Part1(int n,  double* dist1, double* dist2, double *ret)
{
    
    for(int i=0;i<n;i++)
    {
        double app     = Parameters[1][0].ParameterProp*pow(dist2[i],2.0)+1.0;
        ret[i] = exp(-1.0*log(app)-Parameters[0][0].ParameterProp*dist1[i]/(pow(app,Parameters[3][0].ParameterProp/2.0)));
    }
}
void Class_GneitingPlusCirc::get_valueProp_Part2(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = (Parameters[4][0].ParameterProp)*exp(-1.0*Class_Utils::CircDist(dist2[i],Parameters[5][0].ParameterProp)*Parameters[2][0].ParameterProp);
    }
}













void Class_GneitingCov::get_valueAcc(int n, double* dist1, double* dist2, double *ret)
{
    double ret1;
    //double ret2;
    for(int i=0;i<n;i++)
    {
        get_valueAcc_Part1(n,dist1, dist2, &ret1);
       // get_valueAcc_Part2(n,dist1, dist2, &ret2);
        ret[i] = ret1;
    }
}
void Class_GneitingCov::get_valueProp(int n, double* dist1, double* dist2, double *ret)
{
    double ret1;
    //double ret2;
    for(int i=0;i<n;i++)
    {
        get_valueProp_Part1(n,dist1, dist2, &ret1);
       // get_valueProp_Part2(n,dist1, dist2, &ret2);
        ret[i] = ret1;
    }
}

void Class_GneitingCov::get_valueAcc_Part1(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        double app     = Parameters[1][0].ParameterAcc*pow(dist2[i],2.0)+1.0;
        ret[i] = Parameters[3][0].ParameterAcc*exp(-1.0*log(app)- Parameters[0][0].ParameterAcc*dist1[i]/(pow(app,Parameters[2][0].ParameterAcc/2.0)));
        //REprintf("%f \n",ret[i]);
        //ret[i] = exp(-1.0*log(app)- Parameters[0][0].ParameterAcc*dist1[i]/(pow(app,Parameters[2][0].ParameterAcc/2.0)));
    }
}
void Class_GneitingCov::get_valueAcc_Part2(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = 0.0;
    }
}
void Class_GneitingCov::get_valueProp_Part1(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        double  app     = Parameters[1][0].ParameterProp*pow(dist2[i],2.0)+1.0;
        ret[i] = Parameters[3][0].ParameterProp*exp(-1.0*log(app)-Parameters[0][0].ParameterProp*dist1[i]/(pow(app,Parameters[2][0].ParameterProp/2.0)));
        // REprintf("%f \n",ret[i]);
        // ret[i] = exp(-1.0*log(app)-Parameters[0][0].ParameterProp*dist1[i]/(pow(app,Parameters[2][0].ParameterProp/2.0)));
    }
}
void Class_GneitingCov::get_valueProp_Part2(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = 0.0;
    }
}

















void Class_GneitingCovPlusCirc::get_valueAcc(int n, double* dist1, double* dist2, double *ret)
{
    double ret1;
    double ret2;
    for(int i=0;i<n;i++)
    {
        get_valueAcc_Part1(n,dist1, dist2, &ret1);
        get_valueAcc_Part2(n,dist1, dist2, &ret2);
        ret[i] = ret1+ret2;
    }
}
void Class_GneitingCovPlusCirc::get_valueProp(int n, double* dist1, double* dist2, double *ret)
{
    double ret1;
    double ret2;
    for(int i=0;i<n;i++)
    {
        get_valueProp_Part1(n,dist1, dist2, &ret1);
        get_valueProp_Part2(n,dist1, dist2, &ret2);
        ret[i] = ret1+ret2;
    }
}



void Class_GneitingCovPlusCirc::get_valueAcc_Part1(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        double app     = Parameters[1][0].ParameterAcc*pow(dist2[i],2.0)+1.0;
        ret[i] = Parameters[6][0].ParameterAcc*exp(-1.0*log(app)-Parameters[0][0].ParameterAcc*dist1[i]/(pow(app,Parameters[3][0].ParameterAcc/2.0)));
    }
}
void Class_GneitingCovPlusCirc::get_valueAcc_Part2(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = (Parameters[4][0].ParameterAcc)*exp(-1.0*Class_Utils::CircDist(dist2[i],Parameters[5][0].ParameterAcc)*Parameters[2][0].ParameterAcc);
    }
}
void Class_GneitingCovPlusCirc::get_valueProp_Part1(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        double app     = Parameters[1][0].ParameterProp*pow(dist2[i],2.0)+1.0;
        ret[i] = Parameters[6][0].ParameterProp*exp(-1.0*log(app)-Parameters[0][0].ParameterProp*dist1[i]/(pow(app,Parameters[3][0].ParameterProp/2.0)));
    }
}
void Class_GneitingCovPlusCirc::get_valueProp_Part2(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = (Parameters[4][0].ParameterProp)*exp(-1.0*Class_Utils::CircDist(dist2[i],Parameters[5][0].ParameterProp)*Parameters[2][0].ParameterProp);
    }
}









void Class_ExponentialExponentialCov::get_valueAcc(int n, double* dist1, double* dist2, double *ret)
{
    double ret1;
    double ret2;
    for(int i=0;i<n;i++)
    {
        get_valueAcc_Part1(n,dist1, dist2, &ret1);
        get_valueAcc_Part2(n,dist1, dist2, &ret2);
        ret[i] = ret1+ret2;
    }
}
void Class_ExponentialExponentialCov::get_valueProp(int n, double* dist1, double* dist2, double *ret)
{
    double ret1;
    double ret2;
    for(int i=0;i<n;i++)
    { 
        get_valueProp_Part1(n,dist1, dist2, &ret1);
        get_valueProp_Part2(n,dist1, dist2, &ret2);
        ret[i] = ret1+ret2;
    }
}



void Class_ExponentialExponentialCov::get_valueAcc_Part1(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i]     = Parameters[2][0].ParameterAcc* exp(-1.0*dist1[i]*Parameters[0][0].ParameterAcc)* exp(-1.0*dist2[i]*Parameters[1][0].ParameterAcc);

    }
}
void Class_ExponentialExponentialCov::get_valueAcc_Part2(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = 0.0;
    }
}
void Class_ExponentialExponentialCov::get_valueProp_Part1(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = Parameters[2][0].ParameterProp* exp(-1.0*dist1[i]*Parameters[0][0].ParameterProp)* exp(-1.0*dist2[i]*Parameters[1][0].ParameterProp);
    }
}
void Class_ExponentialExponentialCov::get_valueProp_Part2(int n,  double* dist1, double* dist2, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = 0.0;
    }
}










// PM10

//string par1 = "varTot";
//ret.push_back(par1);
//string par2 = "decayTot";
//ret.push_back(par2);
//
//string par3 = "varYear";
//ret.push_back(par3);
//string par4 = "decayYear";
//ret.push_back(par4);
//
//string par5 = "varWeek";
//ret.push_back(par5);
//string par6 = "decayWeek";
//ret.push_back(par6);
//
//string par7 = "nugget";
//ret.push_back(par7);
void Class_CovPM10Mod1::get_valueAcc(int n, double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =    Parameters[0][0].ParameterAcc*
                    exp(-1.0*dist[i]*Parameters[1][0].ParameterAcc)+
                    Parameters[2][0].ParameterAcc*
                    exp(-1.0*Class_Utils::CircDist(dist[i],SeasYear)*Parameters[3][0].ParameterAcc)+
                    Parameters[4][0].ParameterAcc*
                    exp(-1.0*Class_Utils::CircDist(dist[i],SeasWeek)*Parameters[5][0].ParameterAcc)+
                    Parameters[6][0].ParameterAcc*Class_Utils::ifelse(dist[i], 0.0, 1.0, 0.0);
    }
}
void Class_CovPM10Mod1::get_valueProp(int n, double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =  Parameters[0][0].ParameterProp*
        exp(-1.0*dist[i]*Parameters[1][0].ParameterProp)+
        Parameters[2][0].ParameterProp*
        exp(-1.0*Class_Utils::CircDist(dist[i],SeasYear)*Parameters[3][0].ParameterProp)+
        Parameters[4][0].ParameterProp*
        exp(-1.0*Class_Utils::CircDist(dist[i],SeasWeek)*Parameters[5][0].ParameterProp)+
        Parameters[6][0].ParameterProp*Class_Utils::ifelse(dist[i], 0.0, 1.0, 0.0);
    }
}




void Class_CovPM10Mod1::get_valueAcc_Part1(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = Parameters[0][0].ParameterAcc*
        exp(-1.0*dist[i]*Parameters[1][0].ParameterAcc)+
        Parameters[2][0].ParameterAcc*
        exp(-1.0*Class_Utils::CircDist(dist[i],SeasYear)*Parameters[3][0].ParameterAcc)+
        Parameters[4][0].ParameterAcc*
        exp(-1.0*Class_Utils::CircDist(dist[i],SeasWeek)*Parameters[5][0].ParameterAcc)+
        Parameters[6][0].ParameterAcc*Class_Utils::ifelse(dist[i], 0.0, 1.0, 0.0);
    }
}
void Class_CovPM10Mod1::get_valueAcc_Part2(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = 0.0;
        
    }
}
void Class_CovPM10Mod1::get_valueProp_Part1(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =  Parameters[0][0].ParameterProp*
        exp(-1.0*dist[i]*Parameters[1][0].ParameterProp)+
        Parameters[2][0].ParameterProp*
        exp(-1.0*Class_Utils::CircDist(dist[i],SeasYear)*Parameters[3][0].ParameterProp)+
        Parameters[4][0].ParameterProp*
        exp(-1.0*Class_Utils::CircDist(dist[i],SeasWeek)*Parameters[5][0].ParameterProp)+
        Parameters[6][0].ParameterProp*Class_Utils::ifelse(dist[i], 0.0, 1.0, 0.0);
    }
}
void Class_CovPM10Mod1::get_valueProp_Part2(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = 0.0;
    }
}









void Class_CovPM10Mod1_2::get_valueAcc(int n, double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =    Parameters[0][0].ParameterAcc*
        exp(-1.0*dist[i]*Parameters[1][0].ParameterAcc)+
        Parameters[2][0].ParameterAcc*
        exp(-1.0*Class_Utils::CircDist(dist[i],SeasYear)*Parameters[3][0].ParameterAcc)+
        Parameters[4][0].ParameterAcc*Class_Utils::ifelse(dist[i], 0.0, 1.0, 0.0);
    }
}
void Class_CovPM10Mod1_2::get_valueProp(int n, double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =  Parameters[0][0].ParameterProp*
        exp(-1.0*dist[i]*Parameters[1][0].ParameterProp)+
        Parameters[2][0].ParameterProp*
        exp(-1.0*Class_Utils::CircDist(dist[i],SeasYear)*Parameters[3][0].ParameterProp)+
        Parameters[4][0].ParameterProp*Class_Utils::ifelse(dist[i], 0.0, 1.0, 0.0);
    }
}




void Class_CovPM10Mod1_2::get_valueAcc_Part1(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = Parameters[0][0].ParameterAcc*
        exp(-1.0*dist[i]*Parameters[1][0].ParameterAcc)+
        Parameters[2][0].ParameterAcc*
        exp(-1.0*Class_Utils::CircDist(dist[i],SeasYear)*Parameters[3][0].ParameterAcc)+
        Parameters[4][0].ParameterAcc*Class_Utils::ifelse(dist[i], 0.0, 1.0, 0.0);
    }
}
void Class_CovPM10Mod1_2::get_valueAcc_Part2(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = 0.0;
        
    }
}
void Class_CovPM10Mod1_2::get_valueProp_Part1(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =  Parameters[0][0].ParameterProp*
        exp(-1.0*dist[i]*Parameters[1][0].ParameterProp)+
        Parameters[2][0].ParameterProp*
        exp(-1.0*Class_Utils::CircDist(dist[i],SeasYear)*Parameters[3][0].ParameterProp)+
        Parameters[4][0].ParameterProp*Class_Utils::ifelse(dist[i], 0.0, 1.0, 0.0);
    }
}
void Class_CovPM10Mod1_2::get_valueProp_Part2(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = 0.0;
    }
}














void Class_ExponentialPlusNugget_Tstudent::get_valueAcc(int n, double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =    Parameters[3][0].ParameterAcc*Parameters[0][0].ParameterAcc*
        exp(-1.0*dist[i]*Parameters[1][0].ParameterAcc)+
        Parameters[2][0].ParameterAcc*Class_Utils::ifelse(dist[i], 0.0, 1.0, 0.0);
    }
}
void Class_ExponentialPlusNugget_Tstudent::get_valueProp(int n, double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =  Parameters[3][0].ParameterProp*Parameters[0][0].ParameterProp*
        exp(-1.0*dist[i]*Parameters[1][0].ParameterProp)+
        Parameters[2][0].ParameterProp*Class_Utils::ifelse(dist[i], 0.0, 1.0, 0.0);
    }
}




void Class_ExponentialPlusNugget_Tstudent::get_valueAcc_Part1(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = Parameters[3][0].ParameterAcc*Parameters[0][0].ParameterAcc*
        exp(-1.0*dist[i]*Parameters[1][0].ParameterAcc)+
        Parameters[2][0].ParameterAcc*Class_Utils::ifelse(dist[i], 0.0, 1.0, 0.0);
    }
}
void Class_ExponentialPlusNugget_Tstudent::get_valueAcc_Part2(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = 0.0;
        
    }
}
void Class_ExponentialPlusNugget_Tstudent::get_valueProp_Part1(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =  Parameters[3][0].ParameterProp*Parameters[0][0].ParameterProp*
        exp(-1.0*dist[i]*Parameters[1][0].ParameterProp)+
        Parameters[2][0].ParameterProp*Class_Utils::ifelse(dist[i], 0.0, 1.0, 0.0);
    }
}
void Class_ExponentialPlusNugget_Tstudent::get_valueProp_Part2(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = 0.0;
    }
}














void Class_ExponentialPlusNugget::get_valueAcc(int n, double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =    Parameters[0][0].ParameterAcc*
        exp(-1.0*dist[i]*Parameters[1][0].ParameterAcc)+
        Parameters[2][0].ParameterAcc*Class_Utils::ifelse(dist[i], 0.0, 1.0, 0.0);
    }
}
void Class_ExponentialPlusNugget::get_valueProp(int n, double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =  Parameters[0][0].ParameterProp*
        exp(-1.0*dist[i]*Parameters[1][0].ParameterProp)+
        Parameters[2][0].ParameterProp*Class_Utils::ifelse(dist[i], 0.0, 1.0, 0.0);
    }
}




void Class_ExponentialPlusNugget::get_valueAcc_Part1(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = Parameters[0][0].ParameterAcc*
        exp(-1.0*dist[i]*Parameters[1][0].ParameterAcc)+
        Parameters[2][0].ParameterAcc*Class_Utils::ifelse(dist[i], 0.0, 1.0, 0.0);
    }
}
void Class_ExponentialPlusNugget::get_valueAcc_Part2(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = 0.0;
        
    }
}
void Class_ExponentialPlusNugget::get_valueProp_Part1(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] =  Parameters[0][0].ParameterProp*
        exp(-1.0*dist[i]*Parameters[1][0].ParameterProp)+
        Parameters[2][0].ParameterProp*Class_Utils::ifelse(dist[i], 0.0, 1.0, 0.0);
    }
}
void Class_ExponentialPlusNugget::get_valueProp_Part2(int n,  double* dist, double *ret)
{
    for(int i=0;i<n;i++)
    {
        ret[i] = 0.0;
    }
}











