
#include <iostream>
#include <list>
#include <vector>
//#include "T_Matrix.h"
#include "Gaussian.h"
//#include "MatricesAndVectors.h"
//#include "F_Utils.h"
using std::cout; using std::endl;
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>


//void Class_Gaussian_NNGP_Multivariate::update_BFAcc(Vector <int> *Element,vector <int> *Order)
//{
//    int DimCoreg =  CovMat[0]->DimCoreg;
//    int nObs;
//
//    double appsigma[(DimCoreg*(Msparemax+1))*(DimCoreg*(Msparemax+1))];
//    int indexa[DimCoreg];
//
//    Matrix<double> AppSigma(DimCoreg*(Msparemax+1),DimCoreg*(Msparemax+1),appsigma);
//    Vector<int> IndexA(DimCoreg,indexa);
//
//    CovMat[0]->ParSigmaCoreg->update_allMatricesAcc();
//    CovMat[0]->update_TjAcc(Order);
//
//    int iii;
//    for(int iii2=0;iii2<Element->nElem;iii2++)
//    {
//        iii = Element->vec(iii2);
//        nObs = CovMat[iii]->Nneigh+1;
//        for(int i=0;i<IndexA.nElem;i++)
//        {
//            IndexA.Pvec(i)[0] = i+(DimCoreg)*CovMat[iii]->Nneigh;
//        }
//
//        AppSigma.nRows = nObs*DimCoreg;
//        AppSigma.nCols = AppSigma.nRows;
//        AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//
//        if(CovMat[iii]->SpaceOrTime==1)
//        {
//            CoregMatrix::external_SigmaTotAcc(nObs, DimCoreg , &AppSigma, &CovMat[iii]->ParSigmaCoreg->SigmaAcc, &CovMat[iii]->Dist ,  CovMat[iii]->CovFunctions, CovMat[iii]->TjAcc);
//        }else{
//            CoregMatrix::external_SigmaTotAcc(nObs, DimCoreg , &AppSigma, &CovMat[iii]->ParSigmaCoreg->SigmaAcc, &CovMat[iii]->Dist, &CovMat[iii]->Dist2 ,  CovMat[iii]->CovFunctions, CovMat[iii]->TjAcc);
//        }
//
//        Class_MultivariateNormal::external_computeBandF_NNGP(&IndexA,  &BAcc[iii], &CovMat[iii]->SigmaAcc, &AppSigma);
//
//        CovMat[iii]->update_SigmaCholAcc();
//        CovMat[iii]->update_logdeterminantAcc();
//        CovMat[iii]->update_SigmaInvAcc();
//    }
//
//    AppSigma.nRows = DimCoreg*(Msparemax+1)*DimCoreg;
//    AppSigma.nCols = AppSigma.nRows;
//    AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//
//}


//void Class_Gaussian_NNGP_Multivariate::update_BFProp(Vector <int> *Element,vector <int> *Order)
//{
//
//
//    int DimCoreg =  CovMat[0]->DimCoreg;
//    int nObs;
//
//
//    double appsigma[(DimCoreg*(Msparemax+1))*(DimCoreg*(Msparemax+1))];
//    int indexa[DimCoreg];
//
//    Matrix<double> AppSigma(DimCoreg*(Msparemax+1),DimCoreg*(Msparemax+1),appsigma);
//    Vector<int> IndexA(DimCoreg,indexa);
//
//    CovMat[0]->ParSigmaCoreg->update_allMatricesProp();
//    CovMat[0]->update_TjProp(Order);
//
//    int iii;
//    for(int iii2=0;iii2<Element->nElem;iii2++)
//    {
//        iii = Element->vec(iii2);
//        nObs = CovMat[iii]->Nneigh+1;
//        for(int i=0;i<IndexA.nElem;i++)
//        {
//            IndexA.Pvec(i)[0] = i+(DimCoreg)*CovMat[iii]->Nneigh;
//        }
//
//        AppSigma.nRows = nObs*DimCoreg;
//        AppSigma.nCols = AppSigma.nRows;
//        AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//
//
//        if(CovMat[iii]->SpaceOrTime==1)
//        {
//            CoregMatrix::external_SigmaTotProp(nObs, DimCoreg , &AppSigma, &CovMat[iii]->ParSigmaCoreg->SigmaProp, &CovMat[iii]->Dist ,  CovMat[iii]->CovFunctions, CovMat[iii]->TjProp);
//        }else{
//            CoregMatrix::external_SigmaTotProp(nObs, DimCoreg , &AppSigma, &CovMat[iii]->ParSigmaCoreg->SigmaProp, &CovMat[iii]->Dist ,&CovMat[iii]->Dist2 ,  CovMat[iii]->CovFunctions, CovMat[iii]->TjProp);
//        }
//
//        Class_MultivariateNormal::external_computeBandF_NNGP(&IndexA,  &BProp[iii], &CovMat[iii]->SigmaProp, &AppSigma);
//
//        CovMat[iii]->update_SigmaCholProp();
//        CovMat[iii]->update_logdeterminantProp();
//        CovMat[iii]->update_SigmaInvProp();
//
//    }
//
//    AppSigma.nRows = DimCoreg*(Msparemax+1)*DimCoreg;
//    AppSigma.nCols = AppSigma.nRows;
//    AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//
//
//}
//









/************
 updata_SigmaSigmaCholSigmaInv_BASE
 *********/
//void CoregMatrix::update_SigmaAcc()
//{
//    
//    //Matrix<double> app(nTot,nTot,SigmaAcc->PGet(0,0));
//    int i,j,iObs,jObs,k;
//    double covVal;
//    double covVal2;
//    
//    for(iObs=0;iObs<nObs;iObs++)
//    {
//        for(i=0;i<DimCoreg;i++)
//        {
//            for(j=i;j<DimCoreg;j++)
//            {
//                SigmaAcc.Pmat(iObs*DimCoreg+i,iObs*DimCoreg+j)[0] = ParSigmaCoreg->SigmaAcc.mat(i,j);
//                
//            }
//            CovFunctions[0][i]->get_valueAcc_Part2(1, Dist.Pmat(iObs,iObs), &covVal2);
//            SigmaAcc.Pmat(iObs*DimCoreg+i,iObs*DimCoreg+i)[0] += covVal2;
//        }
//    }
//    for(iObs=0;iObs<nObs;iObs++)
//    {
//        for(jObs=iObs+1;jObs<nObs;jObs++)
//        {
//            for(i=0;i<DimCoreg;i++)
//            {
//                for(j=0;j<DimCoreg;j++)
//                {
//                    SigmaAcc.Pmat(iObs*DimCoreg+i,jObs*DimCoreg+j)[0]  = 0.0;
//                    for(k=0;k<DimCoreg;k++)
//                    {
//                        CovFunctions[0][k]->get_valueAcc_Part1(1, Dist.Pmat(iObs,jObs), &covVal);
//                        
//                        SigmaAcc.Pmat(iObs*DimCoreg+i,jObs*DimCoreg+j)[0] += covVal*TjAcc[k].mat(i,j);
//                        //SigmaProp->Set(iObs*DimCoreg+i,jObs*DimCoreg+j,covVal*TjProp[k].mat(i,j));
//                    }
//                    
//                    
//                }
//                CovFunctions[0][i]->get_valueAcc_Part2(1, Dist.Pmat(iObs,jObs), &covVal2);
//                SigmaAcc.Pmat(iObs*DimCoreg+i,jObs*DimCoreg+i)[0] += covVal2;
//            }
//        }
//    }
//    
//}

//void CoregMatrix::update_SigmaProp()
//{
//    int i,j,iObs,jObs,k;
//    double covVal;
//    double covVal2;
//
//    for(iObs=0;iObs<nObs;iObs++)
//    {
//        for(i=0;i<DimCoreg;i++)
//        {
//            for(j=i;j<DimCoreg;j++)
//            {
//                SigmaProp.Pmat(iObs*DimCoreg+i,iObs*DimCoreg+j)[0] = ParSigmaCoreg->SigmaProp.mat(i,j);
//            }
//            CovFunctions[0][i]->get_valueProp_Part2(1, Dist.Pmat(iObs,iObs), &covVal2);
//            SigmaProp.Pmat(iObs*DimCoreg+i,iObs*DimCoreg+i)[0] += covVal2;
//        }
//    }
//    for(iObs=0;iObs<nObs;iObs++)
//    {
//        for(jObs=iObs+1;jObs<nObs;jObs++)
//        {
//            for(i=0;i<DimCoreg;i++)
//            {
//                for(j=0;j<DimCoreg;j++)
//                {
//                    SigmaProp.Pmat(iObs*DimCoreg+i,jObs*DimCoreg+j)[0]  = 0.0;
//                    for(k=0;k<DimCoreg;k++)
//                    {
//                        CovFunctions[0][k]->get_valueProp_Part1(1, Dist.Pmat(iObs,jObs), &covVal);
//
//                        SigmaProp.Pmat(iObs*DimCoreg+i,jObs*DimCoreg+j)[0] += covVal*TjProp[k].mat(i,j);
//                    }
//                }
//                CovFunctions[0][i]->get_valueProp_Part2(1, Dist.Pmat(iObs,jObs), &covVal2);
//                SigmaProp.Pmat(iObs*DimCoreg+i,jObs*DimCoreg+i)[0] += covVal2;
//            }
//        }
//    }
//
//}



//void Class_MatrixCoreg_Spectral::update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj, vector <int> *Order)
//{
//    // *** per me va messo 1 al posto di UserControlledMemory, altrimenti se UserControlledMemory=0 non le cancelli mai fino alla fine del programma
//
//    double CopySigma_P[DimCoreg*DimCoreg];
//    Matrix<double> CopySigma(DimCoreg,DimCoreg,CopySigma_P);
//
//
//    int i,j,k, k1, info;
//    for(i=0;i<DimCoreg;i++)
//    {
//        for(j=0;j<DimCoreg;j++)
//        {
//            //Rprintf("TJPRO2AAAAA\n");
//            CopySigma.Pmat(i,j)[0] = SigmaCoreg->mat(i,j);
//        }
//    }
//    // stessa cosa qui
//    SigmaCoreg->compute_SpectralDecompositionQLambdaSquaredQ_PositiveDefiniteMatrix(&info, &CopySigma, 1);
//    if(info!=0)
//    {
//        error("Spectral decomposition error: function update_Tj_BASE");
//
//    }
//
//    //SigmaCoreg->Print("SIGA");
//    for(k1=0;k1<DimCoreg;k1++)
//    {
//        k = Order[0][k1];
//        for(i=0;i<DimCoreg;i++)
//        {
//            for(j=0;j<DimCoreg;j++)
//            {
//                tj[0][k].Pmat(i,j)[0] = CopySigma.mat(i,k1)*CopySigma.mat(j,k1);
//            }
//        }
//        //tj[0][k].Print("Tj");
//    }
//
//    //CopySigma.Destroy();
//
//};

//void Class_MatrixCoreg_Chol::update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj, vector <int> *Order)
//{
//    //Rprintf("TJPRO\n");
//    // SigmaCoreg->Print("SIGMA");
//    double CopySigma[DimCoreg*DimCoreg];
//    int i,j,k,k1, info;
//    for(i=0;i<DimCoreg;i++)
//    {
//        for(j=0;j<DimCoreg;j++)
//        {
//            //Rprintf("TJPRO2AAAAA\n");
//            CopySigma[i*DimCoreg+j] = SigmaCoreg->mat(i,j);
//        }
//    }
//
//    F77_NAME(dpotrf)("U",&DimCoreg, &CopySigma[0], &DimCoreg, &info);
//    if(info != 0)
//    {
//        error("Cpp error Cholesky failed - function: update_Tj_BASE\n");
//    }
//
//    for(i=0;i<DimCoreg;i++)
//    {
//        for(j=i+1;j<DimCoreg;j++)
//        {
//            CopySigma[i*DimCoreg+j] = 0.0;
//        }
//    }
//    for(k1=0;k1<DimCoreg;k1++)
//    {
//        k = Order[0][k1];
//        for(i=0;i<DimCoreg;i++)
//        {
//            for(j=0;j<DimCoreg;j++)
//            {
//                tj[0][k].Pmat(i,j)[0] = CopySigma[i*DimCoreg+k1]*CopySigma[j*DimCoreg+k1];
//            }
//        }
//    }
//};





//
//void Class_Gaussian_NNGP_Multivariate::update_BFAccKC()
//{
//    int DimCoreg =  CovMat[0]->DimCoreg;
//    int nObs;
//
//    double appsigma[(DimCoreg*(Msparemax+1))*(DimCoreg*(Msparemax+1))];
//    double appsigma2[((DimCoreg-1)*(Msparemax+1))*((DimCoreg-1)*(Msparemax+1))];
//    int indexa[DimCoreg-1];
//
//    Matrix<double> AppSigma(DimCoreg*(Msparemax+1),DimCoreg*(Msparemax+1),appsigma);
//    Matrix<double> AppSigma2((DimCoreg-1)*(Msparemax+1),(DimCoreg-1)*(Msparemax+1),appsigma2);
//    Vector<int> IndexA(DimCoreg-1,indexa);
//
//
//
//    CovMat[0]->ParSigmaCoreg->update_allMatricesAcc();
//    CovMat[0]->update_TjAcc();
//
//
//    for(int iii=0;iii<CovMat.size();iii++)
//    {
//        //Rprintf("\nObs %i \n",iii);
//        nObs = CovMat[iii]->Nneigh+1;
//        for(int i=0;i<IndexA.nElem;i++)
//        {
//            IndexA.Pvec(i)[0] = i+(DimCoreg-1)*CovMat[iii]->Nneigh;
//        }
//
//        AppSigma.nRows = nObs*DimCoreg;
//        AppSigma.nCols = AppSigma.nRows;
//        AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//        AppSigma2.nRows = nObs*(DimCoreg-1);
//        AppSigma2.nCols =  AppSigma2.nRows;
//        AppSigma2.DimTot = AppSigma2.nRows*AppSigma2.nCols;
//
//        CoregMatrix::external_SigmaTotAcc(nObs, DimCoreg , &AppSigma, &CovMat[iii]->ParSigmaCoreg->SigmaAcc, &CovMat[iii]->Dist ,  CovMat[iii]->CovFunctions, CovMat[iii]->TjAcc);
//        //AppSigma.PrintTriUpper("SIGMATOT");
//        CoregMatrix::external_SigmaTot_fromCoreg_to_CoregLessOne(nObs, DimCoreg , &AppSigma2, &AppSigma);
//        //AppSigma2.PrintTriUpper("SIGMAMiss");
//
//        Class_MultivariateNormal::external_computeBandF_NNGP(&IndexA,  &BAcc[iii], &CovMat[iii]->SigmaAcc, &AppSigma2);
//
//
//        CovMat[iii]->update_SigmaCholAcc();
//        CovMat[iii]->update_logdeterminantAcc();
//        CovMat[iii]->update_SigmaInvAcc();
//
//    }
//
//
//    AppSigma.nRows = DimCoreg*(Msparemax+1)*DimCoreg;
//    AppSigma.nCols = AppSigma.nRows;
//    AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//    AppSigma2.nRows = (DimCoreg-1)*(Msparemax+1);
//    AppSigma2.nCols =  AppSigma2.nRows;
//    AppSigma2.DimTot = AppSigma2.nRows*AppSigma2.nCols;
//
//}
//
//
//void Class_Gaussian_NNGP_Multivariate::update_BFPropKC()
//{
//
//
//    int DimCoreg =  CovMat[0]->DimCoreg;
//    int nObs;
//
//
//    double appsigma[(DimCoreg*(Msparemax+1))*(DimCoreg*(Msparemax+1))];
//    double appsigma2[((DimCoreg-1)*(Msparemax+1))*((DimCoreg-1)*(Msparemax+1))];
//    int indexa[DimCoreg-1];
//
//    Matrix<double> AppSigma(DimCoreg*(Msparemax+1),DimCoreg*(Msparemax+1),appsigma);
//    Matrix<double> AppSigma2((DimCoreg-1)*(Msparemax+1),(DimCoreg-1)*(Msparemax+1),appsigma2);
//    Vector<int> IndexA(DimCoreg-1,indexa);
//
//    CovMat[0]->ParSigmaCoreg->update_allMatricesProp();
//    CovMat[0]->update_TjProp();
//    for(int iii=0;iii<CovMat.size();iii++)
//    {
//        nObs = CovMat[iii]->Nneigh+1;
//        for(int i=0;i<IndexA.nElem;i++)
//        {
//            IndexA.Pvec(i)[0] = i+(DimCoreg-1)*CovMat[iii]->Nneigh;
//        }
//
//        AppSigma.nRows = nObs*DimCoreg;
//        AppSigma.nCols = AppSigma.nRows;
//        AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//        AppSigma2.nRows = nObs*(DimCoreg-1);
//        AppSigma2.nCols =  AppSigma2.nRows;
//        AppSigma2.DimTot = AppSigma2.nRows*AppSigma2.nCols;
//
//        CoregMatrix::external_SigmaTotProp(nObs, DimCoreg , &AppSigma, &CovMat[iii]->ParSigmaCoreg->SigmaProp, &CovMat[iii]->Dist ,  CovMat[iii]->CovFunctions, CovMat[iii]->TjProp);
//        CoregMatrix::external_SigmaTot_fromCoreg_to_CoregLessOne(nObs, DimCoreg , &AppSigma2, &AppSigma);
//
//
//        Class_MultivariateNormal::external_computeBandF_NNGP(&IndexA,  &BProp[iii], &CovMat[iii]->SigmaProp, &AppSigma2);
//
//        CovMat[iii]->update_SigmaCholProp();
//        CovMat[iii]->update_logdeterminantProp();
//        CovMat[iii]->update_SigmaInvProp();
//
//    }
//
//    AppSigma.nRows = DimCoreg*(Msparemax+1)*DimCoreg;
//    AppSigma.nCols = AppSigma.nRows;
//    AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//    AppSigma2.nRows = (DimCoreg-1)*(Msparemax+1);
//    AppSigma2.nCols =  AppSigma2.nRows;
//    AppSigma2.DimTot = AppSigma2.nRows*AppSigma2.nCols;
//
//
//    //    AppSigma.Destroy();
//    //    AppSigma2.Destroy();
//    //    IndexA.Destroy();
//
//}
//
//
//
//void Class_Gaussian_NNGP_Multivariate::update_BFAcc()
//{
//    int DimCoreg =  CovMat[0]->DimCoreg;
//    int nObs;
//
//    double appsigma[(DimCoreg*(Msparemax+1))*(DimCoreg*(Msparemax+1))];
//    int indexa[DimCoreg];
//
//    Matrix<double> AppSigma(DimCoreg*(Msparemax+1),DimCoreg*(Msparemax+1),appsigma);
//    Vector<int> IndexA(DimCoreg,indexa);
//
//    CovMat[0]->ParSigmaCoreg->update_allMatricesAcc();
//    CovMat[0]->update_TjAcc();
//
//    for(int iii=0;iii<CovMat.size();iii++)
//    {
//        nObs = CovMat[iii]->Nneigh+1;
//        for(int i=0;i<IndexA.nElem;i++)
//        {
//            IndexA.Pvec(i)[0] = i+(DimCoreg)*CovMat[iii]->Nneigh;
//        }
//
//        AppSigma.nRows = nObs*DimCoreg;
//        AppSigma.nCols = AppSigma.nRows;
//        AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//
//        if(CovMat[iii]->SpaceOrTime==1)
//        {
//            CoregMatrix::external_SigmaTotAcc(nObs, DimCoreg , &AppSigma, &CovMat[iii]->ParSigmaCoreg->SigmaAcc, &CovMat[iii]->Dist ,  CovMat[iii]->CovFunctions, CovMat[iii]->TjAcc);
//        }else{
//            CoregMatrix::external_SigmaTotAcc(nObs, DimCoreg , &AppSigma, &CovMat[iii]->ParSigmaCoreg->SigmaAcc, &CovMat[iii]->Dist, &CovMat[iii]->Dist2 ,  CovMat[iii]->CovFunctions, CovMat[iii]->TjAcc);
//        }
//
//        Class_MultivariateNormal::external_computeBandF_NNGP(&IndexA,  &BAcc[iii], &CovMat[iii]->SigmaAcc, &AppSigma);
//
//        CovMat[iii]->update_SigmaCholAcc();
//        CovMat[iii]->update_logdeterminantAcc();
//        CovMat[iii]->update_SigmaInvAcc();
//    }
//
//    AppSigma.nRows = DimCoreg*(Msparemax+1)*DimCoreg;
//    AppSigma.nCols = AppSigma.nRows;
//    AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//
//}
//
//
//void Class_Gaussian_NNGP_Multivariate::update_BFProp()
//{
//
//
//    int DimCoreg =  CovMat[0]->DimCoreg;
//    int nObs;
//
//
//    double appsigma[(DimCoreg*(Msparemax+1))*(DimCoreg*(Msparemax+1))];
//    int indexa[DimCoreg];
//
//    Matrix<double> AppSigma(DimCoreg*(Msparemax+1),DimCoreg*(Msparemax+1),appsigma);
//    Vector<int> IndexA(DimCoreg,indexa);
//
//    CovMat[0]->ParSigmaCoreg->update_allMatricesProp();
//    CovMat[0]->update_TjProp();
//    for(int iii=0;iii<CovMat.size();iii++)
//    {
//        nObs = CovMat[iii]->Nneigh+1;
//        for(int i=0;i<IndexA.nElem;i++)
//        {
//            IndexA.Pvec(i)[0] = i+(DimCoreg)*CovMat[iii]->Nneigh;
//        }
//
//        AppSigma.nRows = nObs*DimCoreg;
//        AppSigma.nCols = AppSigma.nRows;
//        AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//
//
//        if(CovMat[iii]->SpaceOrTime==1)
//        {
//            CoregMatrix::external_SigmaTotProp(nObs, DimCoreg , &AppSigma, &CovMat[iii]->ParSigmaCoreg->SigmaProp, &CovMat[iii]->Dist ,  CovMat[iii]->CovFunctions, CovMat[iii]->TjProp);
//        }else{
//            CoregMatrix::external_SigmaTotProp(nObs, DimCoreg , &AppSigma, &CovMat[iii]->ParSigmaCoreg->SigmaProp, &CovMat[iii]->Dist ,&CovMat[iii]->Dist2 ,  CovMat[iii]->CovFunctions, CovMat[iii]->TjProp);
//        }
//
//        Class_MultivariateNormal::external_computeBandF_NNGP(&IndexA,  &BProp[iii], &CovMat[iii]->SigmaProp, &AppSigma);
//
//        CovMat[iii]->update_SigmaCholProp();
//        CovMat[iii]->update_logdeterminantProp();
//        CovMat[iii]->update_SigmaInvProp();
//
//    }
//
//    AppSigma.nRows = DimCoreg*(Msparemax+1)*DimCoreg;
//    AppSigma.nCols = AppSigma.nRows;
//    AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//
//
//}



//
//void Class_Gaussian_NNGP_Multivariate::update_BFAcc(vector <int> *Order)
//{
//    int DimCoreg =  CovMat[0]->DimCoreg;
//    int nObs;
//
//    double appsigma[(DimCoreg*(Msparemax+1))*(DimCoreg*(Msparemax+1))];
//    int indexa[DimCoreg];
//
//    Matrix<double> AppSigma(DimCoreg*(Msparemax+1),DimCoreg*(Msparemax+1),appsigma);
//    Vector<int> IndexA(DimCoreg,indexa);
//
//    CovMat[0]->ParSigmaCoreg->update_allMatricesAcc();
//    CovMat[0]->update_TjAcc(Order);
//
//    for(int iii=0;iii<CovMat.size();iii++)
//    {
//        nObs = CovMat[iii]->Nneigh+1;
//        for(int i=0;i<IndexA.nElem;i++)
//        {
//            IndexA.Pvec(i)[0] = i+(DimCoreg)*CovMat[iii]->Nneigh;
//        }
//
//        AppSigma.nRows = nObs*DimCoreg;
//        AppSigma.nCols = AppSigma.nRows;
//        AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//
//        if(CovMat[iii]->SpaceOrTime==1)
//        {
//            CoregMatrix::external_SigmaTotAcc(nObs, DimCoreg , &AppSigma, &CovMat[iii]->ParSigmaCoreg->SigmaAcc, &CovMat[iii]->Dist ,  CovMat[iii]->CovFunctions, CovMat[iii]->TjAcc);
//        }else{
//            CoregMatrix::external_SigmaTotAcc(nObs, DimCoreg , &AppSigma, &CovMat[iii]->ParSigmaCoreg->SigmaAcc, &CovMat[iii]->Dist, &CovMat[iii]->Dist2 ,  CovMat[iii]->CovFunctions, CovMat[iii]->TjAcc);
//        }
//
//        Class_MultivariateNormal::external_computeBandF_NNGP(&IndexA,  &BAcc[iii], &CovMat[iii]->SigmaAcc, &AppSigma);
//
//        CovMat[iii]->update_SigmaCholAcc();
//        CovMat[iii]->update_logdeterminantAcc();
//        CovMat[iii]->update_SigmaInvAcc();
//    }
//
//    AppSigma.nRows = DimCoreg*(Msparemax+1)*DimCoreg;
//    AppSigma.nCols = AppSigma.nRows;
//    AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//
//}


//void Class_Gaussian_NNGP_Multivariate::update_BFProp(vector <int> *Order)
//{
//
//
//    int DimCoreg =  CovMat[0]->DimCoreg;
//    int nObs;
//
//
//    double appsigma[(DimCoreg*(Msparemax+1))*(DimCoreg*(Msparemax+1))];
//    int indexa[DimCoreg];
//
//    Matrix<double> AppSigma(DimCoreg*(Msparemax+1),DimCoreg*(Msparemax+1),appsigma);
//    Vector<int> IndexA(DimCoreg,indexa);
//
//    CovMat[0]->ParSigmaCoreg->update_allMatricesProp();
//    CovMat[0]->update_TjProp(Order);
//    for(int iii=0;iii<CovMat.size();iii++)
//    {
//        nObs = CovMat[iii]->Nneigh+1;
//        for(int i=0;i<IndexA.nElem;i++)
//        {
//            IndexA.Pvec(i)[0] = i+(DimCoreg)*CovMat[iii]->Nneigh;
//        }
//
//        AppSigma.nRows = nObs*DimCoreg;
//        AppSigma.nCols = AppSigma.nRows;
//        AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//
//
//        if(CovMat[iii]->SpaceOrTime==1)
//        {
//            CoregMatrix::external_SigmaTotProp(nObs, DimCoreg , &AppSigma, &CovMat[iii]->ParSigmaCoreg->SigmaProp, &CovMat[iii]->Dist ,  CovMat[iii]->CovFunctions, CovMat[iii]->TjProp);
//        }else{
//            CoregMatrix::external_SigmaTotProp(nObs, DimCoreg , &AppSigma, &CovMat[iii]->ParSigmaCoreg->SigmaProp, &CovMat[iii]->Dist ,&CovMat[iii]->Dist2 ,  CovMat[iii]->CovFunctions, CovMat[iii]->TjProp);
//        }
//
//        Class_MultivariateNormal::external_computeBandF_NNGP(&IndexA,  &BProp[iii], &CovMat[iii]->SigmaProp, &AppSigma);
//
//        CovMat[iii]->update_SigmaCholProp();
//        CovMat[iii]->update_logdeterminantProp();
//        CovMat[iii]->update_SigmaInvProp();
//
//    }
//
//    AppSigma.nRows = DimCoreg*(Msparemax+1)*DimCoreg;
//    AppSigma.nCols = AppSigma.nRows;
//    AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//
//
//}









//
//void Class_Gaussian_NNGP_Multivariate::update_BFAccKC(Vector <int> *Element)
//{
//
//    int DimCoreg =  CovMat[0]->DimCoreg;
//    int nObs;
//
//    double appsigma[(DimCoreg*(Msparemax+1))*(DimCoreg*(Msparemax+1))];
//    double appsigma2[((DimCoreg-1)*(Msparemax+1))*((DimCoreg-1)*(Msparemax+1))];
//    int indexa[DimCoreg-1];
//
//    Matrix<double> AppSigma(DimCoreg*(Msparemax+1),DimCoreg*(Msparemax+1),appsigma);
//    Matrix<double> AppSigma2((DimCoreg-1)*(Msparemax+1),(DimCoreg-1)*(Msparemax+1),appsigma2);
//    Vector<int> IndexA(DimCoreg-1,indexa);
//
//
//
//    CovMat[0]->ParSigmaCoreg->update_allMatricesAcc();
//    CovMat[0]->update_TjAcc();
//
//    int iii;
//    for(int iii2=0;iii2<Element->nElem;iii2++)
//    {
//        iii = Element->vec(iii2);
//        //Rprintf("\nObs %i \n",iii);
//        nObs = CovMat[iii]->Nneigh+1;
//        for(int i=0;i<IndexA.nElem;i++)
//        {
//            IndexA.Pvec(i)[0] = i+(DimCoreg-1)*CovMat[iii]->Nneigh;
//        }
//
//        AppSigma.nRows = nObs*DimCoreg;
//        AppSigma.nCols = AppSigma.nRows;
//        AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//        AppSigma2.nRows = nObs*(DimCoreg-1);
//        AppSigma2.nCols =  AppSigma2.nRows;
//        AppSigma2.DimTot = AppSigma2.nRows*AppSigma2.nCols;
//
//        CoregMatrix::external_SigmaTotAcc(nObs, DimCoreg , &AppSigma, &CovMat[iii]->ParSigmaCoreg->SigmaAcc, &CovMat[iii]->Dist ,  CovMat[iii]->CovFunctions, CovMat[iii]->TjAcc);
//        //AppSigma.PrintTriUpper("SIGMATOT");
//        CoregMatrix::external_SigmaTot_fromCoreg_to_CoregLessOne(nObs, DimCoreg , &AppSigma2, &AppSigma);
//        //AppSigma2.PrintTriUpper("SIGMAMiss");
//
//        Class_MultivariateNormal::external_computeBandF_NNGP(&IndexA,  &BAcc[iii], &CovMat[iii]->SigmaAcc, &AppSigma2);
//        //BAcc[iii].Print("B");
//        // CovMat[iii]->SigmaAcc.PrintTriUpper("F");
//
//        CovMat[iii]->update_SigmaCholAcc();
//        CovMat[iii]->update_logdeterminantAcc();
//        CovMat[iii]->update_SigmaInvAcc();
//
//    }
//
//
//    AppSigma.nRows = DimCoreg*(Msparemax+1)*DimCoreg;
//    AppSigma.nCols = AppSigma.nRows;
//    AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//    AppSigma2.nRows = (DimCoreg-1)*(Msparemax+1);
//    AppSigma2.nCols =  AppSigma2.nRows;
//    AppSigma2.DimTot = AppSigma2.nRows*AppSigma2.nCols;
//
//
//    //    AppSigma.Destroy();
//    //    AppSigma2.Destroy();
//    //    IndexA.Destroy();
//
//}
//
//
//void Class_Gaussian_NNGP_Multivariate::update_BFPropKC(Vector <int> *Element)
//{
//
//    error("CovMat[iii]->ParSigmaCoreg->SigmaProp forse CovMat[0]->ParSigmaCoreg->SigmaProp");
//    int DimCoreg =  CovMat[0]->DimCoreg;
//    int nObs;
//
//
//    double appsigma[(DimCoreg*(Msparemax+1))*(DimCoreg*(Msparemax+1))];
//    double appsigma2[((DimCoreg-1)*(Msparemax+1))*((DimCoreg-1)*(Msparemax+1))];
//    int indexa[DimCoreg-1];
//
//    Matrix<double> AppSigma(DimCoreg*(Msparemax+1),DimCoreg*(Msparemax+1),appsigma);
//    Matrix<double> AppSigma2((DimCoreg-1)*(Msparemax+1),(DimCoreg-1)*(Msparemax+1),appsigma2);
//    Vector<int> IndexA(DimCoreg-1,indexa);
//
//    CovMat[0]->ParSigmaCoreg->update_allMatricesProp();
//    CovMat[0]->update_TjProp();
//
//    int iii;
//    for(int iii2=0;iii2<Element->nElem;iii2++)
//    {
//        iii = Element->vec(iii2);
//
//        nObs = CovMat[iii]->Nneigh+1;
//        for(int i=0;i<IndexA.nElem;i++)
//        {
//            IndexA.Pvec(i)[0] = i+(DimCoreg-1)*CovMat[iii]->Nneigh;
//        }
//
//        AppSigma.nRows = nObs*DimCoreg;
//        AppSigma.nCols = AppSigma.nRows;
//        AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//        AppSigma2.nRows = nObs*(DimCoreg-1);
//        AppSigma2.nCols =  AppSigma2.nRows;
//        AppSigma2.DimTot = AppSigma2.nRows*AppSigma2.nCols;
//
//        CoregMatrix::external_SigmaTotProp(nObs, DimCoreg , &AppSigma, &CovMat[iii]->ParSigmaCoreg->SigmaProp, &CovMat[iii]->Dist ,  CovMat[iii]->CovFunctions, CovMat[iii]->TjProp);
//        CoregMatrix::external_SigmaTot_fromCoreg_to_CoregLessOne(nObs, DimCoreg , &AppSigma2, &AppSigma);
//
//
//        Class_MultivariateNormal::external_computeBandF_NNGP(&IndexA,  &BProp[iii], &CovMat[iii]->SigmaProp, &AppSigma2);
//
//        CovMat[iii]->update_SigmaCholProp();
//        CovMat[iii]->update_logdeterminantProp();
//        CovMat[iii]->update_SigmaInvProp();
//
//    }
//
//    AppSigma.nRows = DimCoreg*(Msparemax+1)*DimCoreg;
//    AppSigma.nCols = AppSigma.nRows;
//    AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
//    AppSigma2.nRows = (DimCoreg-1)*(Msparemax+1);
//    AppSigma2.nCols =  AppSigma2.nRows;
//    AppSigma2.DimTot = AppSigma2.nRows*AppSigma2.nCols;
//
//
//    //    AppSigma.Destroy();
//    //    AppSigma2.Destroy();
//    //    IndexA.Destroy();
//
//}




void CoregMatrix::update_SigmaCholAcc()
{
    int info;
    for(int i=0;i<nTot;i++)
    {
        for(int j=i;j<nTot;j++)
        {
            SigmaCholAcc.Pmat(i,j)[0] = SigmaAcc.mat(i,j);
        }
    }
    F77_NAME(dpotrf)("L",&nTot, SigmaCholAcc.Pmat(0,0), &nTot, &info);
    if(info != 0)
    {
        error("Cpp error Cholesky failed - function: uupdate_SigmaCholAcc\n");
    }
}

void CoregMatrix::update_logdeterminantAcc()
{
    logdeterminantAcc = 0.0;
    for(int i=0;i<nTot;i++)
    {
        logdeterminantAcc += 2.0*log(SigmaCholAcc.mat(i,i));
    }
}

void CoregMatrix::update_SigmaInvAcc()
{
    int info;
    for(int i=0;i<nTot;i++)
    {
        for(int j=i;j<nTot;j++)
        {
            SigmaInvAcc.Pmat(i,j)[0] = SigmaCholAcc.mat(i,j);
        }
    }
    F77_NAME(dpotri)("L",&nTot,SigmaInvAcc.Pmat(0,0), &nTot, &info);
    if(info != 0)
    {
        error("Cpp error Cholesky inverse - function: update_SigmaCholAcc\n");
    }
    
}





void CoregMatrix::external_SigmaTotProp(int nobs, int dimcoreg, Matrix<double> *out, Matrix<double> *ParSigmaCoreg_Sigma, Matrix<double> * dist ,  vector<Poly_CovCorFunction*>*   covfunctions, vector <Matrix<double> > * tj)
{
    int i,j,iObs,jObs,k;
    double covVal;
    double covVal2;
    //Rprintf("T1\n");
    for(iObs=0;iObs<nobs;iObs++)
    {
        for(i=0;i<dimcoreg;i++)
        {
            covfunctions[0][i]->get_valueProp_Part1(1, dist->Pmat(iObs,iObs), &covVal);
            for(j=i;j<dimcoreg;j++)
            {
                out->Pmat(iObs*dimcoreg+i,iObs*dimcoreg+j)[0] = ParSigmaCoreg_Sigma->mat(i,j)*covVal;
            }
            covfunctions[0][i]->get_valueProp_Part2(1, dist->Pmat(iObs,iObs), &covVal2);
            out->Pmat(iObs*dimcoreg+i,iObs*dimcoreg+i)[0] += covVal2;
            
        }
    }
    //Rprintf("T2\n");
    for(iObs=0;iObs<nobs;iObs++)
    {
        for(jObs=iObs+1;jObs<nobs;jObs++)
        {
            for(i=0;i<dimcoreg;i++)
            {
                for(j=0;j<dimcoreg;j++)
                {
                    //printf("i=%i %i%i %i\n", iObs,jObs,i,j);
                    out->Pmat(iObs*dimcoreg+i,jObs*dimcoreg+j)[0]  = 0.0;
                    for(k=0;k<dimcoreg;k++)
                    {
                        //printf("k=%i\n",k);
                        covfunctions[0][k]->get_valueProp_Part1(1, dist->Pmat(iObs,jObs), &covVal);
                        
                        out->Pmat(iObs*dimcoreg+i,jObs*dimcoreg+j)[0] += covVal*tj[0][k].mat(i,j);
                        
                    }
                }
                //printf("ss %i\n",i);
                covfunctions[0][i]->get_valueProp_Part2(1, dist->Pmat(iObs,jObs), &covVal2);
                out->Pmat(iObs*dimcoreg+i,jObs*dimcoreg+i)[0] += covVal2;
            }
        }
    }
    //out->PrintTriUpper("WSS");
    
}

void CoregMatrix::external_SigmaTotProp(int nobs, int dimcoreg, Matrix<double> *out, Matrix<double> *ParSigmaCoreg_Sigma, Matrix<double> * dist1, Matrix<double> * dist2 ,  vector<Poly_CovCorFunction*>*   covfunctions, vector <Matrix<double> > * tj)
{
    int i,j,iObs,jObs,k;
    double covVal;
    double covVal2;
    
    for(iObs=0;iObs<nobs;iObs++)
    {
        for(i=0;i<dimcoreg;i++)
        {
            covfunctions[0][i]->get_valueProp_Part1(1, dist1->Pmat(iObs,iObs), dist2->Pmat(iObs,iObs), &covVal);
            for(j=i;j<dimcoreg;j++)
            {
                out->Pmat(iObs*dimcoreg+i,iObs*dimcoreg+j)[0] = ParSigmaCoreg_Sigma->mat(i,j)*covVal;
            }
            covfunctions[0][i]->get_valueProp_Part2(1, dist1->Pmat(iObs,iObs), dist2->Pmat(iObs,iObs), &covVal2);
            out->Pmat(iObs*dimcoreg+i,iObs*dimcoreg+i)[0] += covVal2;
            
        }
    }
    for(iObs=0;iObs<nobs;iObs++)
    {
        for(jObs=iObs+1;jObs<nobs;jObs++)
        {
            for(i=0;i<dimcoreg;i++)
            {
                for(j=0;j<dimcoreg;j++)
                {
                    out->Pmat(iObs*dimcoreg+i,jObs*dimcoreg+j)[0]  = 0.0;
                    for(k=0;k<dimcoreg;k++)
                    {
                        covfunctions[0][k]->get_valueProp_Part1(1, dist1->Pmat(iObs,jObs), dist2->Pmat(iObs,jObs), &covVal);
                        
                        out->Pmat(iObs*dimcoreg+i,jObs*dimcoreg+j)[0] += covVal*tj[0][k].mat(i,j);
                    }
                }
                covfunctions[0][i]->get_valueProp_Part2(1, dist1->Pmat(iObs,jObs),dist2->Pmat(iObs,jObs), &covVal2);
                out->Pmat(iObs*dimcoreg+i,jObs*dimcoreg+i)[0] += covVal2;
            }
        }
    }
    
}




void CoregMatrix::external_SigmaTotAcc(int nobs, int dimcoreg, Matrix<double> *out, Matrix<double> *ParSigmaCoreg_Sigma, Matrix<double> * dist ,  vector<Poly_CovCorFunction*>*   covfunctions, vector <Matrix<double> > * tj)
{
    int i,j,iObs,jObs,k;
    double covVal;
    double covVal2;
    
    for(iObs=0;iObs<nobs;iObs++)
    {
        for(i=0;i<dimcoreg;i++)
        {
            covfunctions[0][i]->get_valueAcc_Part1(1, dist->Pmat(iObs,iObs), &covVal);
            for(j=i;j<dimcoreg;j++)
            {
                out->Pmat(iObs*dimcoreg+i,iObs*dimcoreg+j)[0] = ParSigmaCoreg_Sigma->mat(i,j)*covVal;
            }
            
            covfunctions[0][i]->get_valueAcc_Part2(1, dist->Pmat(iObs,iObs), &covVal2);
            out->Pmat(iObs*dimcoreg+i,iObs*dimcoreg+i)[0] += covVal2;
            // Rprintf("CovVal2 iObs=%i i=%i %f %f \n",iObs,i,covVal2,dist->Pmat(i,i));
            //Rprintf("TOt %f \n ",out->Pmat(iObs*dimcoreg+i,iObs*dimcoreg+i)[0]);
        }
    }
    for(iObs=0;iObs<nobs;iObs++)
    {
        for(jObs=iObs+1;jObs<nobs;jObs++)
        {
            for(i=0;i<dimcoreg;i++)
            {
                for(j=0;j<dimcoreg;j++)
                {
                    out->Pmat(iObs*dimcoreg+i,jObs*dimcoreg+j)[0]  = 0.0;
                    for(k=0;k<dimcoreg;k++)
                    {
                        covfunctions[0][k]->get_valueAcc_Part1(1, dist->Pmat(iObs,jObs), &covVal);
                        
                        out->Pmat(iObs*dimcoreg+i,jObs*dimcoreg+j)[0] += covVal*tj[0][k].mat(i,j);
                    }
                }
                covfunctions[0][i]->get_valueAcc_Part2(1, dist->Pmat(iObs,jObs), &covVal2);
                out->Pmat(iObs*dimcoreg+i,jObs*dimcoreg+i)[0] += covVal2;
            }
        }
    }
}



void CoregMatrix::external_SigmaTotAcc(int nobs, int dimcoreg, Matrix<double> *out, Matrix<double> *ParSigmaCoreg_Sigma, Matrix<double> * dist1, Matrix<double> * dist2 ,  vector<Poly_CovCorFunction*>*   covfunctions, vector <Matrix<double> > * tj)
{
    int i,j,iObs,jObs,k;
    double covVal;
    double covVal2;
    
    for(iObs=0;iObs<nobs;iObs++)
    {
        for(i=0;i<dimcoreg;i++)
        {
            covfunctions[0][i]->get_valueAcc_Part1(1, dist1->Pmat(iObs,iObs),dist2->Pmat(iObs,iObs), &covVal);
            for(j=i;j<dimcoreg;j++)
            {
                out->Pmat(iObs*dimcoreg+i,iObs*dimcoreg+j)[0] = ParSigmaCoreg_Sigma->mat(i,j)*covVal;
            }
              
            covfunctions[0][i]->get_valueAcc_Part2(1, dist1->Pmat(iObs,iObs),dist2->Pmat(iObs,iObs), &covVal2);
            out->Pmat(iObs*dimcoreg+i,iObs*dimcoreg+i)[0] += covVal2;
            // Rprintf("CovVal2 iObs=%i i=%i %f %f \n",iObs,i,covVal2,dist->Pmat(i,i));
            //Rprintf("TOt %f \n ",out->Pmat(iObs*dimcoreg+i,iObs*dimcoreg+i)[0]);
        }
    }
    for(iObs=0;iObs<nobs;iObs++)
    {
        for(jObs=iObs+1;jObs<nobs;jObs++)
        {
            for(i=0;i<dimcoreg;i++)
            {
                for(j=0;j<dimcoreg;j++)
                {
                    out->Pmat(iObs*dimcoreg+i,jObs*dimcoreg+j)[0]  = 0.0;
                    for(k=0;k<dimcoreg;k++)
                    {
                        covfunctions[0][k]->get_valueAcc_Part1(1, dist1->Pmat(iObs,jObs),dist2->Pmat(iObs,jObs), &covVal);
                        
                        out->Pmat(iObs*dimcoreg+i,jObs*dimcoreg+j)[0] += covVal*tj[0][k].mat(i,j);
                    }
                }
                covfunctions[0][i]->get_valueAcc_Part2(1, dist1->Pmat(iObs,jObs),dist2->Pmat(iObs,jObs), &covVal2);
                out->Pmat(iObs*dimcoreg+i,jObs*dimcoreg+i)[0] += covVal2;
            }
        }
    }
}










void CoregMatrix::external_SigmaTot_fromCoreg_to_CoregLessOne(int nobs, int dimcoreg, Matrix<double>* out, Matrix <double>* SigmaTot)
{
    
    //Matrix<double> app(nTot,nTot,SigmaAcc->PGet(0,0));
    int i,j,iObs,jObs;
    
    
    
    
    for(iObs=0;iObs<nobs;iObs++)
    {
        for(i=0;i<dimcoreg-1;i++)
        {
            for(j=i;j<dimcoreg-1;j++)
            {
                out->Pmat(iObs*(dimcoreg-1)+i,iObs*(dimcoreg-1)+j)[0] =  SigmaTot->Pmat(iObs*dimcoreg+i,iObs*dimcoreg+j)[0]+SigmaTot->Pmat(iObs*dimcoreg+(dimcoreg-1),iObs*dimcoreg+(dimcoreg-1))[0] - SigmaTot->Pmat(iObs*dimcoreg+i,iObs*dimcoreg+(dimcoreg-1))[0]-SigmaTot->Pmat(iObs*dimcoreg+j,iObs*dimcoreg+(dimcoreg-1))[0];
                
            }
        }
    }
    for(iObs=0;iObs<nobs;iObs++)
    {
        for(jObs=iObs+1;jObs<nobs;jObs++)
        {
            for(i=0;i<(dimcoreg-1);i++)
            {
                for(j=0;j<(dimcoreg-1);j++)
                {
                    //for(k=0;k<(dimcoreg-1);k++)
                    //{
                    out->Pmat(iObs*(dimcoreg-1)+i,jObs*(dimcoreg-1)+j)[0] = SigmaTot->Pmat(iObs*dimcoreg+i,jObs*dimcoreg+j)[0]+SigmaTot->Pmat(iObs*dimcoreg+(dimcoreg-1),jObs*dimcoreg+(dimcoreg-1))[0] - SigmaTot->Pmat(iObs*dimcoreg+i,jObs*dimcoreg+(dimcoreg-1))[0]-SigmaTot->Pmat(iObs*dimcoreg+(dimcoreg-1),jObs*dimcoreg+j)[0];
                    //}
                    
                    
                }
            }
        }
    }
    
    
    
    
}




/*******/

void CoregMatrix::update_SigmaCholProp()
{
    int info;
    for(int i=0;i<nTot;i++)
    {
        for(int j=i;j<nTot;j++)
        {
            SigmaCholProp.Pmat(i,j)[0] = SigmaProp.mat(i,j);
        }
    }
    F77_NAME(dpotrf)("L",&nTot, SigmaCholProp.Pmat(0,0), &nTot, &info);
    if(info != 0)
    {
        error("Cpp error Cholesky failed - function: uupdate_SigmaCholProp\n");
    }
}

void CoregMatrix::update_logdeterminantProp()
{
    logdeterminantProp = 0.0;
    for(int i=0;i<nTot;i++)
    {
        logdeterminantProp += 2.0*log(SigmaCholProp.mat(i,i));
    }
}

void CoregMatrix::update_SigmaInvProp()
{
    int info;
    for(int i=0;i<nTot;i++)
    {
        for(int j=i;j<nTot;j++)
        {
            SigmaInvProp.Pmat(i,j)[0] = SigmaCholProp.mat(i,j);
        }
    }
    F77_NAME(dpotri)("L",&nTot,SigmaInvProp.Pmat(0,0), &nTot, &info);
    if(info != 0)
    {
        error("Cpp error Cholesky inverse - function: update_SigmaCholProp\n");
    }
    
}
/************
 update_Tj_BASE()
 *********/


void Class_MatrixCoreg_Spectral::update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj)
{
    // *** per me va messo 1 al posto di UserControlledMemory, altrimenti se UserControlledMemory=0 non le cancelli mai fino alla fine del programma
    
    double CopySigma_P[DimCoreg*DimCoreg];
    Matrix<double> CopySigma(DimCoreg,DimCoreg,CopySigma_P);
    
    
    int i,j,k, info;
    for(i=0;i<DimCoreg;i++)
    {
        for(j=0;j<DimCoreg;j++)
        {
            //Rprintf("TJPRO2AAAAA\n");
            CopySigma.Pmat(i,j)[0] = SigmaCoreg->mat(i,j);
        }
    }
    // stessa cosa qui
    SigmaCoreg->compute_SpectralDecompositionQLambdaSquaredQt_PositiveDefiniteMatrix(&info, &CopySigma, 1);
    if(info!=0)
    {
        error("Spectral decomposition error: function update_Tj_BASE");
        
    }
    
    //SigmaCoreg->Print("SIGA");
    for(k=0;k<DimCoreg;k++)
    {
        for(i=0;i<DimCoreg;i++)
        {
            for(j=0;j<DimCoreg;j++)
            {
                tj[0][k].Pmat(i,j)[0] = CopySigma.mat(i,k)*CopySigma.mat(j,k);
            }
        }
        //tj[0][k].Print("Tj");
    }
    
    //CopySigma.Destroy();
    
};

void Class_MatrixCoreg_Chol::update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj)
{
    //Rprintf("TJPRO\n");
    // SigmaCoreg->Print("SIGMA");
    double CopySigma[DimCoreg*DimCoreg];
    int i,j,k, info;
    for(i=0;i<DimCoreg;i++)
    {
        for(j=0;j<DimCoreg;j++)
        {
            //Rprintf("TJPRO2AAAAA\n");
            CopySigma[i*DimCoreg+j] = SigmaCoreg->mat(i,j);
        }
    }
    
    F77_NAME(dpotrf)("U",&DimCoreg, &CopySigma[0], &DimCoreg, &info);
    if(info != 0)
    {
        error("Cpp error Cholesky failed - function: update_Tj_BASE\n");
    }
    
    for(i=0;i<DimCoreg;i++)
    {
        for(j=i+1;j<DimCoreg;j++)
        {
            CopySigma[i*DimCoreg+j] = 0.0;
        }
    }
    for(k=0;k<DimCoreg;k++)
    {
        for(i=0;i<DimCoreg;i++)
        {
            for(j=0;j<DimCoreg;j++)
            {
                tj[0][k].Pmat(i,j)[0] = CopySigma[i*DimCoreg+k]*CopySigma[j*DimCoreg+k];
            }
        }
    }
};

void Class_MatrixCoreg_Ind::update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj)
{
    //Rprintf("TJPRO\n");
    // SigmaCoreg->Print("SIGMA");
    double CopySigma[DimCoreg*DimCoreg];
    int i,j,k;
    for(i=0;i<DimCoreg;i++)
    {
        for(j=0;j<DimCoreg;j++)
        {
            //Rprintf("TJPRO2AAAAA\n");
            CopySigma[i*DimCoreg+j] = SigmaCoreg->mat(i,j);
        }
    }
//
//    F77_NAME(dpotrf)("U",&DimCoreg, &CopySigma[0], &DimCoreg, &info);
//    if(info != 0)
//    {
//        error("Cpp error Cholesky failed - function: update_Tj_BASE\n");
//    }
//
    for(i=0;i<DimCoreg;i++)
    {
        for(j=i+1;j<DimCoreg;j++)
        {
            CopySigma[i*DimCoreg+j] = 0.0;
        }
        for(j=0;j<i-1;j++)
        {
            CopySigma[i*DimCoreg+j] = 0.0;
        }
        CopySigma[i*DimCoreg+i] = SigmaCoreg->mat(i,i);
    }
    for(k=0;k<DimCoreg;k++)
    {
        for(i=0;i<DimCoreg;i++)
        {
            for(j=0;j<DimCoreg;j++)
            {
                tj[0][k].Pmat(i,j)[0] = CopySigma[i*DimCoreg+k]*CopySigma[j*DimCoreg+k];
            }
        }
    }
};







void Class_Gaussian_NNGP_Multivariate_V2::update_BFAcc()
{
    int DimCoreg =  CovMat[0]->DimCoreg;
    int nObs;
    
    double appsigma[(DimCoreg*(Msparemax+1))*(DimCoreg*(Msparemax+1))];
    int indexa[DimCoreg];
    
    Matrix<double> AppSigma(DimCoreg*(Msparemax+1),DimCoreg*(Msparemax+1),appsigma);
    Vector<int> IndexA(DimCoreg,indexa);
    
    CovMat[0]->ParSigmaCoreg->update_allMatricesAcc();
    CovMat[0]->update_TjAcc();
    
    
    int iii;
    for(int iii2=0;iii2<ElementComp.nElem;iii2++)
    {
        
        iii = ElementComp.vec(iii2);
        //REprintf("%i %i \n",iii2,iii);
        nObs = CovMat[iii]->Nneigh+1;
        for(int i=0;i<IndexA.nElem;i++)
        {
            IndexA.Pvec(i)[0] = i+(DimCoreg)*CovMat[iii]->Nneigh;
        }
        
        AppSigma.nRows = nObs*DimCoreg;
        AppSigma.nCols = AppSigma.nRows;
        AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
        
        //CovMat[iii]->Dist.Print("Dist1");
        //CovMat[iii]->Dist2.Print("Dist2");
        //IndexA.Print("Indexa");
        if(CovMat[iii]->SpaceOrTime==1)
        {
            CoregMatrix::external_SigmaTotAcc(nObs, DimCoreg , &AppSigma, &CovMat[0]->ParSigmaCoreg->SigmaAcc, &CovMat[iii]->Dist ,  CovMat[iii]->CovFunctions, CovMat[0]->TjAcc);
        }else{
            CoregMatrix::external_SigmaTotAcc(nObs, DimCoreg , &AppSigma, &CovMat[0]->ParSigmaCoreg->SigmaAcc, &CovMat[iii]->Dist, &CovMat[iii]->Dist2 ,  CovMat[iii]->CovFunctions, CovMat[0]->TjAcc);
        }
        
        //REprintf("%i %i\n",iii2,iii);
        //REprintf("AA2\n");
        //        if(iii2==1200)
        //        {
        //            IndexA.Print("Indexa");
        //            BAcc[iii].Print("BAcc[iii]");
        //            CovMat[iii]->SigmaAcc.Print("CovMat[iii]->SigmaAcc");
        //            AppSigma.Print("AppSigma");
        //            CovMat[iii]->Dist.Print("Dist");
        //            CovMat[iii]->Dist2.Print("Dist2");
        //        }
        Class_MultivariateNormal::external_computeBandF_NNGP(&IndexA,  &BAcc[iii], &CovMat[iii]->SigmaAcc, &AppSigma);
        //REprintf("AA3\n");
        //CovMat[iii]->SigmaAcc.Print("Sigma");
        CovMat[iii]->update_SigmaCholAcc();
        CovMat[iii]->update_logdeterminantAcc();
        CovMat[iii]->update_SigmaInvAcc();
        //REprintf("AA4\n");
    }
    
    AppSigma.nRows = DimCoreg*(Msparemax+1)*DimCoreg;
    AppSigma.nCols = AppSigma.nRows;
    AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
    
}


void Class_Gaussian_NNGP_Multivariate_V2::update_BFProp()
{
    
    
    int DimCoreg =  CovMat[0]->DimCoreg;
    int nObs;
    
    
    double appsigma[(DimCoreg*(Msparemax+1))*(DimCoreg*(Msparemax+1))];
    int indexa[DimCoreg];
    
    Matrix<double> AppSigma(DimCoreg*(Msparemax+1),DimCoreg*(Msparemax+1),appsigma);
    Vector<int> IndexA(DimCoreg,indexa);
    
    CovMat[0]->ParSigmaCoreg->update_allMatricesProp();
    CovMat[0]->update_TjProp();
    
    int iii;
    for(int iii2=0;iii2<ElementComp.nElem;iii2++)
    {
        
        
        
        
        iii = ElementComp.vec(iii2);
        //Rprintf("%i \n",iii);
        nObs = CovMat[iii]->Nneigh+1;
        for(int i=0;i<IndexA.nElem;i++)
        {
            IndexA.Pvec(i)[0] = i+(DimCoreg)*CovMat[iii]->Nneigh;
        }
        
        
        // IndexA.Print("IndexA");
        AppSigma.nRows = nObs*DimCoreg;
        AppSigma.nCols = AppSigma.nRows;
        AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
        
        
        if(CovMat[iii]->SpaceOrTime==1)
        {
            CoregMatrix::external_SigmaTotProp(nObs, DimCoreg , &AppSigma, &CovMat[0]->ParSigmaCoreg->SigmaProp, &CovMat[iii]->Dist ,  CovMat[iii]->CovFunctions, CovMat[0]->TjProp);
        }else{
            CoregMatrix::external_SigmaTotProp(nObs, DimCoreg , &AppSigma, &CovMat[0]->ParSigmaCoreg->SigmaProp, &CovMat[iii]->Dist ,&CovMat[iii]->Dist2 ,  CovMat[iii]->CovFunctions, CovMat[0]->TjProp);
        }
        // CovMat[iii]->Dist.Print("DIST");
        // AppSigma.Print("SIGMATOT");
        Class_MultivariateNormal::external_computeBandF_NNGP(&IndexA,  &BProp[iii], &CovMat[iii]->SigmaProp, &AppSigma);
        
        //BProp[iii].Print("Bprop");
        //CovMat[iii]->SigmaProp.Print("F");
        //CovMat[iii]->ParSigmaCoreg->SigmaProp.Print("CoregProp");
        
        CovMat[iii]->update_SigmaCholProp();
        CovMat[iii]->update_logdeterminantProp();
        CovMat[iii]->update_SigmaInvProp();
        
    }
    
    AppSigma.nRows = DimCoreg*(Msparemax+1)*DimCoreg;
    AppSigma.nCols = AppSigma.nRows;
    AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
    
    
}













void Class_Gaussian_NNGP_Multivariate::update_BFAcc(Vector <int> *Element)
{
    int DimCoreg =  CovMat[0]->DimCoreg;
    int nObs;
    
    double appsigma[(DimCoreg*(Msparemax+1))*(DimCoreg*(Msparemax+1))];
    int indexa[DimCoreg];
    
    Matrix<double> AppSigma(DimCoreg*(Msparemax+1),DimCoreg*(Msparemax+1),appsigma);
    Vector<int> IndexA(DimCoreg,indexa);
    
    CovMat[0]->ParSigmaCoreg->update_allMatricesAcc();
    CovMat[0]->update_TjAcc();
    
    
    int iii;
    for(int iii2=0;iii2<Element->nElem;iii2++)
    {
        
        iii = Element->vec(iii2);
        nObs = CovMat[iii]->Nneigh+1;
        for(int i=0;i<IndexA.nElem;i++)
        {
            IndexA.Pvec(i)[0] = i+(DimCoreg)*CovMat[iii]->Nneigh;
        }
        
        AppSigma.nRows = nObs*DimCoreg;
        AppSigma.nCols = AppSigma.nRows;
        AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
       
        if(CovMat[iii]->SpaceOrTime==1)
        {
            CoregMatrix::external_SigmaTotAcc(nObs, DimCoreg , &AppSigma, &CovMat[0]->ParSigmaCoreg->SigmaAcc, &CovMat[iii]->Dist ,  CovMat[iii]->CovFunctions, CovMat[0]->TjAcc);
        }else{
            CoregMatrix::external_SigmaTotAcc(nObs, DimCoreg , &AppSigma, &CovMat[0]->ParSigmaCoreg->SigmaAcc, &CovMat[iii]->Dist, &CovMat[iii]->Dist2 ,  CovMat[iii]->CovFunctions, CovMat[0]->TjAcc);
        }
        //REprintf("%i %i\n",iii2,iii);
        //REprintf("AA2\n");
//        if(iii2==1200)
//        {
//            IndexA.Print("Indexa");
//            BAcc[iii].Print("BAcc[iii]");
//            CovMat[iii]->SigmaAcc.Print("CovMat[iii]->SigmaAcc");
//            AppSigma.Print("AppSigma");
//            CovMat[iii]->Dist.Print("Dist");
//            CovMat[iii]->Dist2.Print("Dist2");
//        }
        Class_MultivariateNormal::external_computeBandF_NNGP(&IndexA,  &BAcc[iii], &CovMat[iii]->SigmaAcc, &AppSigma);
        //REprintf("AA3\n");
        CovMat[iii]->update_SigmaCholAcc();
        CovMat[iii]->update_logdeterminantAcc();
        CovMat[iii]->update_SigmaInvAcc();
        //REprintf("AA4\n");
    }
    
    AppSigma.nRows = DimCoreg*(Msparemax+1)*DimCoreg;
    AppSigma.nCols = AppSigma.nRows;
    AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
    
}


void Class_Gaussian_NNGP_Multivariate::update_BFProp(Vector <int> *Element)
{
    
    
    int DimCoreg =  CovMat[0]->DimCoreg;
    int nObs;
    
    
    double appsigma[(DimCoreg*(Msparemax+1))*(DimCoreg*(Msparemax+1))];
    int indexa[DimCoreg];
    
    Matrix<double> AppSigma(DimCoreg*(Msparemax+1),DimCoreg*(Msparemax+1),appsigma);
    Vector<int> IndexA(DimCoreg,indexa);
    
    CovMat[0]->ParSigmaCoreg->update_allMatricesProp();
    CovMat[0]->update_TjProp();
    
    int iii;
    for(int iii2=0;iii2<Element->nElem;iii2++)
    {
        
        
        
        
        iii = Element->vec(iii2);
        //Rprintf("%i \n",iii);
        nObs = CovMat[iii]->Nneigh+1;
        for(int i=0;i<IndexA.nElem;i++)
        {
            IndexA.Pvec(i)[0] = i+(DimCoreg)*CovMat[iii]->Nneigh;
        }
        
        
       // IndexA.Print("IndexA");
        AppSigma.nRows = nObs*DimCoreg;
        AppSigma.nCols = AppSigma.nRows;
        AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
        
        
        if(CovMat[iii]->SpaceOrTime==1)
        {
            CoregMatrix::external_SigmaTotProp(nObs, DimCoreg , &AppSigma, &CovMat[0]->ParSigmaCoreg->SigmaProp, &CovMat[iii]->Dist ,  CovMat[iii]->CovFunctions, CovMat[0]->TjProp);
        }else{
            CoregMatrix::external_SigmaTotProp(nObs, DimCoreg , &AppSigma, &CovMat[0]->ParSigmaCoreg->SigmaProp, &CovMat[iii]->Dist ,&CovMat[iii]->Dist2 ,  CovMat[iii]->CovFunctions, CovMat[0]->TjProp);
        }
       // CovMat[iii]->Dist.Print("DIST");
       // AppSigma.Print("SIGMATOT");
        Class_MultivariateNormal::external_computeBandF_NNGP(&IndexA,  &BProp[iii], &CovMat[iii]->SigmaProp, &AppSigma);
        
        //BProp[iii].Print("Bprop");
        //CovMat[iii]->SigmaProp.Print("F");
        //CovMat[iii]->ParSigmaCoreg->SigmaProp.Print("CoregProp");
        
        CovMat[iii]->update_SigmaCholProp();
        CovMat[iii]->update_logdeterminantProp();
        CovMat[iii]->update_SigmaInvProp();
        
    }
    
    AppSigma.nRows = DimCoreg*(Msparemax+1)*DimCoreg;
    AppSigma.nCols = AppSigma.nRows;
    AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
    
    
}



void Class_Gaussian_NNGP_Multivariate::update_BFAcc_DimMinusOne(Vector <int> *Element)
{
    int DimCoreg =  CovMat[0]->DimCoreg;
    int nObs;
    
    double appsigma[(DimCoreg*(Msparemax+1))*(DimCoreg*(Msparemax+1))];
    double appsigma2[((DimCoreg-1)*(Msparemax+1))*((DimCoreg-1)*(Msparemax+1))];
    int indexa[DimCoreg-1];
    
    Matrix<double> AppSigma(DimCoreg*(Msparemax+1),DimCoreg*(Msparemax+1),appsigma);
    Matrix<double> AppSigma2((DimCoreg-1)*(Msparemax+1),(DimCoreg-1)*(Msparemax+1),appsigma2);
    Vector<int> IndexA(DimCoreg-1,indexa);
    
    CovMat[0]->ParSigmaCoreg->update_allMatricesAcc();
    CovMat[0]->update_TjAcc();
    
    int iii;
    for(int iii2=0;iii2<Element->nElem;iii2++)
    {
        iii = Element->vec(iii2);
        nObs = CovMat[iii]->Nneigh+1;
        for(int i=0;i<IndexA.nElem;i++)
        {
            IndexA.Pvec(i)[0] = i+(DimCoreg-1)*CovMat[iii]->Nneigh;
        }
        
        AppSigma.nRows = nObs*DimCoreg;
        AppSigma.nCols = AppSigma.nRows;
        AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
        AppSigma2.nRows = nObs*(DimCoreg-1);
        AppSigma2.nCols =  AppSigma2.nRows;
        AppSigma2.DimTot = AppSigma2.nRows*AppSigma2.nCols;
        
        if(CovMat[iii]->SpaceOrTime==1)
        {
            CoregMatrix::external_SigmaTotAcc(nObs, DimCoreg , &AppSigma, &CovMat[0]->ParSigmaCoreg->SigmaAcc, &CovMat[iii]->Dist ,  CovMat[iii]->CovFunctions, CovMat[0]->TjAcc);
        }else{
            CoregMatrix::external_SigmaTotAcc(nObs, DimCoreg , &AppSigma, &CovMat[0]->ParSigmaCoreg->SigmaAcc, &CovMat[iii]->Dist, &CovMat[iii]->Dist2 ,  CovMat[iii]->CovFunctions, CovMat[0]->TjAcc);
        }
        
        CoregMatrix::external_SigmaTot_fromCoreg_to_CoregLessOne(nObs, DimCoreg , &AppSigma2, &AppSigma);
       
        Class_MultivariateNormal::external_computeBandF_NNGP(&IndexA,  &BAcc[iii], &CovMat[iii]->SigmaAcc, &AppSigma2);
        
        CovMat[iii]->update_SigmaCholAcc();
        CovMat[iii]->update_logdeterminantAcc();
        CovMat[iii]->update_SigmaInvAcc();
    }
    
    AppSigma.nRows = DimCoreg*(Msparemax+1)*DimCoreg;
    AppSigma.nCols = AppSigma.nRows;
    AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
    
    AppSigma2.nRows = (DimCoreg-1)*(Msparemax+1);
    AppSigma2.nCols =  AppSigma2.nRows;
    AppSigma2.DimTot = AppSigma2.nRows*AppSigma2.nCols;
    
}


void Class_Gaussian_NNGP_Multivariate::update_BFProp_DimMinusOne(Vector <int> *Element)
{
    
    
    int DimCoreg =  CovMat[0]->DimCoreg;
    int nObs;
    
    
    double appsigma[(DimCoreg*(Msparemax+1))*(DimCoreg*(Msparemax+1))];
    double appsigma2[((DimCoreg-1)*(Msparemax+1))*((DimCoreg-1)*(Msparemax+1))];
    int indexa[DimCoreg-1];
    
    Matrix<double> AppSigma(DimCoreg*(Msparemax+1),DimCoreg*(Msparemax+1),appsigma);
    Matrix<double> AppSigma2((DimCoreg-1)*(Msparemax+1),(DimCoreg-1)*(Msparemax+1),appsigma2);
    Vector<int> IndexA(DimCoreg-1,indexa);
    
    CovMat[0]->ParSigmaCoreg->update_allMatricesProp();
    CovMat[0]->update_TjProp();
    
    int iii;
    for(int iii2=0;iii2<Element->nElem;iii2++)
    {
        
        iii = Element->vec(iii2);
        
        nObs = CovMat[iii]->Nneigh+1;
        //Rprintf("Cont %i elem %i, nNeif %i",iii2,iii, nObs-1);
        for(int i=0;i<IndexA.nElem;i++)
        {
            IndexA.Pvec(i)[0] = i+(DimCoreg-1)*CovMat[iii]->Nneigh;
        }
        // IndexA.Print("IndexA");
        AppSigma.nRows = nObs*DimCoreg;
        AppSigma.nCols = AppSigma.nRows;
        AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
        AppSigma2.nRows = nObs*(DimCoreg-1);
        AppSigma2.nCols =  AppSigma2.nRows;
        AppSigma2.DimTot = AppSigma2.nRows*AppSigma2.nCols;
        
        if(CovMat[iii]->SpaceOrTime==1)
        {
            CoregMatrix::external_SigmaTotProp(nObs, DimCoreg , &AppSigma, &CovMat[0]->ParSigmaCoreg->SigmaProp, &CovMat[iii]->Dist ,  CovMat[iii]->CovFunctions, CovMat[0]->TjProp);
        }else{
            CoregMatrix::external_SigmaTotProp(nObs, DimCoreg , &AppSigma, &CovMat[0]->ParSigmaCoreg->SigmaProp, &CovMat[iii]->Dist ,&CovMat[iii]->Dist2 ,  CovMat[iii]->CovFunctions, CovMat[0]->TjProp);
        }
       
         CoregMatrix::external_SigmaTot_fromCoreg_to_CoregLessOne(nObs, DimCoreg , &AppSigma2, &AppSigma);
        
        //AppSigma.PrintTriUpper("SIGMA1");
        //AppSigma2.PrintTriUpper("SIGMA2");
        
        Class_MultivariateNormal::external_computeBandF_NNGP(&IndexA,  &BProp[iii], &CovMat[iii]->SigmaProp, &AppSigma2);
        //CovMat[iii]->SigmaProp.PrintTriUpper("SIGMA");
        
        
        //BProp[iii].Print("Bprop");
        //CovMat[iii]->SigmaProp.Print("F");
        //CovMat[iii]->ParSigmaCoreg->SigmaProp.Print("CoregProp");
        
        CovMat[iii]->update_SigmaCholProp();
        CovMat[iii]->update_logdeterminantProp();
        CovMat[iii]->update_SigmaInvProp();
        
    }
    
    AppSigma.nRows = DimCoreg*(Msparemax+1)*DimCoreg;
    AppSigma.nCols = AppSigma.nRows;
    AppSigma.DimTot = AppSigma.nRows*AppSigma.nCols;
    AppSigma2.nRows = (DimCoreg-1)*(Msparemax+1);
    AppSigma2.nCols =  AppSigma2.nRows;
    AppSigma2.DimTot = AppSigma2.nRows*AppSigma2.nCols;
    
}






void CoregMatrixNNGP::update_SigmaCholAcc()
{
    int info;
    for(int i=0;i<nTot;i++)
    {
        for(int j=i;j<nTot;j++)
        {
            SigmaCholAcc.Pmat(i,j)[0] = SigmaAcc.mat(i,j);
        }
    }
    F77_NAME(dpotrf)("L",&nTot, SigmaCholAcc.Pmat(0,0), &nTot, &info);
    if(info != 0)
    {
        error("Cpp error Cholesky failed - function: uupdate_SigmaCholAcc\n");
    }
}

void CoregMatrixNNGP::update_logdeterminantAcc()
{
    logdeterminantAcc = 0.0;
    for(int i=0;i<nTot;i++)
    {
        logdeterminantAcc += 2.0*log(SigmaCholAcc.mat(i,i));
    }
}

void CoregMatrixNNGP::update_SigmaInvAcc()
{
    int info;
    for(int i=0;i<nTot;i++)
    {
        for(int j=i;j<nTot;j++)
        {
            SigmaInvAcc.Pmat(i,j)[0] = SigmaCholAcc.mat(i,j);
        }
    }
    F77_NAME(dpotri)("L",&nTot,SigmaInvAcc.Pmat(0,0), &nTot, &info);
    if(info != 0)
    {
        error("Cpp error Cholesky inverse - function: update_SigmaCholAcc\n");
    }
    
}



void CoregMatrixNNGP::update_SigmaCholProp()
{
    int info;
    for(int i=0;i<nTot;i++)
    {
        for(int j=i;j<nTot;j++)
        {
            SigmaCholProp.Pmat(i,j)[0] = SigmaProp.mat(i,j);
        }
    }
    F77_NAME(dpotrf)("L",&nTot, SigmaCholProp.Pmat(0,0), &nTot, &info);
    if(info != 0)
    {
        error("Cpp error Cholesky failed - function: uupdate_SigmaCholProp\n");
    }
}

void CoregMatrixNNGP::update_logdeterminantProp()
{
    logdeterminantProp = 0.0;
    for(int i=0;i<nTot;i++)
    {
        logdeterminantProp += 2.0*log(SigmaCholProp.mat(i,i));
    }
}

void CoregMatrixNNGP::update_SigmaInvProp()
{
    int info;
    for(int i=0;i<nTot;i++)
    {
        for(int j=i;j<nTot;j++)
        {
            SigmaInvProp.Pmat(i,j)[0] = SigmaCholProp.mat(i,j);
        }
    }
    F77_NAME(dpotri)("L",&nTot,SigmaInvProp.Pmat(0,0), &nTot, &info);
    if(info != 0)
    {
        error("Cpp error Cholesky inverse - function: update_SigmaCholProp\n");
    }
    
}
















