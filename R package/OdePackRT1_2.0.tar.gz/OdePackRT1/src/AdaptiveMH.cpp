#include <iostream>
#include "MatricesAndVectors.h"
#include "AdaptiveMH.h"
//using std::cout; using std::endl;
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>
#include <R_ext/Utils.h>



void Poly_Adapt::SetAccPropEqual()
{
    for(int i=0;i<nParameters;i++)
    {
        Parameters[i]->AddressPropExt[0]        = Parameters[i]->ParameterAcc;
        Parameters[i]->AddressAccExt[0]         = Parameters[i]->ParameterAcc;   
    }
}
/***** void add_parameters(Class_Parameter* parameter, string name) *****/

int Class_AdaptHaario::add_parameters(Class_Parameter* parameter)
{
  int ret =0; if((parameter[0].PriorParameter[0].NamePrior!="NoPrior")&(parameter[0].PriorParameter[0].NamePrior!="DiscreteUniform"))
    {
        Parameters.push_back(parameter);
        //Parameters[Parameters.size()-1] = parameter;
        NameParameters.push_back(parameter[0].NameParameter);
      ret = 1;
    }else{
      ret = 0;
        REprintf("\n\n %s not added to the Adaptive MH\n\n ",parameter[0].NameParameter.c_str());
    }
  return(ret);
}


//* void add_finalizedConstruct(double Add_varmean, double epsilon, double *sdadapt, double lambda, int usr,Class_AdaptPar *adapt )  */

void Class_AdaptHaario::add_finalizedConstruct( double epsilon, double *sdadapt, double lambda, int usr,Class_AdaptPar *adapt )
{
    sumalpha = 0.0;
    iterBatch = 0;
    
    nParameters = (int)Parameters.size();
    int UserControlledMemory        = usr;
    
    nFails                  = 0;
    TransParametersProp     = Vector <double> (nParameters,UserControlledMemory);
    TransParametersAcc      = Vector <double> (nParameters,UserControlledMemory);
    
    Mean        = Vector<double>(nParameters,UserControlledMemory);
    MeanStart       = Vector<double>(nParameters,UserControlledMemory);
    SigmaChol   = Matrix<double>(nParameters,nParameters,UserControlledMemory);
    Sigma       = Matrix<double>(nParameters,nParameters,UserControlledMemory);
    SigmaStart  = Matrix<double>(nParameters,nParameters,UserControlledMemory);
    Lambda      = lambda;
    Adapt       = adapt;
    Epsilon     = epsilon;
    NumAccRatio             = 0.0;
    AcceptedRatio            = 0.0;
    AppDenAccRatio      = 0.0;
    //AddVarmean = Add_varmean;
    
    
    
    int i,j;
    for(i=0;i<nParameters;i++)
    {
        Parameters[i]->update_TransParameterAcc_FromParameterAcc(TransParametersAcc.Pvec(i));
        Parameters[i]->update_TransParameterProp_FromParameterProp(TransParametersProp.Pvec(i));
    }
    
    
    for(i=0;i<nParameters;i++)
    {
        //Mean.Pvec(i)[0] = TransParametersAcc.vec(i)+rnorm(0.0,Add_varmean);
        //MeanStart.Pvec(i)[0]  = TransParametersAcc.vec(i)+rnorm(0.0,Add_varmean);
        Mean.Pvec(i)[0] = TransParametersAcc.vec(i);
        MeanStart.Pvec(i)[0]  = TransParametersAcc.vec(i);

    }
    
    for(i=0;i<nParameters;i++)
    {
        for(j=0;j<nParameters;j++)
        {
            SigmaChol.Pmat(i,j)[0] = 0.0;
            Sigma.Pmat(i,j)[0] = 0.0;
            SigmaStart.Pmat(i,j)[0] = 0.0;
        }
        SigmaChol.Pmat(i,i)[0] = sdadapt[i];
        Sigma.Pmat(i,i)[0] = sdadapt[i]*sdadapt[i];
        SigmaStart.Pmat(i,i)[0] = sdadapt[i];
    }
    epsilon2 = 0.0;
}



void Class_AdaptHaario::add_finalizedConstruct_OnlyOneSd( double epsilon, double *sdadapt, double lambda, int usr,Class_AdaptPar *adapt )
{
    epsilon2 = 0.0;
    sumalpha = 0.0;
    iterBatch = 0;
    
    nParameters = (int)Parameters.size();
    int UserControlledMemory        = usr;
    
    nFails                  = 0;
    TransParametersProp     = Vector <double> (nParameters,UserControlledMemory);
    TransParametersAcc      = Vector <double> (nParameters,UserControlledMemory);
    
    Mean        = Vector<double>(nParameters,UserControlledMemory);
    MeanStart       = Vector<double>(nParameters,UserControlledMemory);
    SigmaChol   = Matrix<double>(nParameters,nParameters,UserControlledMemory);
    Sigma       = Matrix<double>(nParameters,nParameters,UserControlledMemory);
    SigmaStart  = Matrix<double>(nParameters,nParameters,UserControlledMemory);
    Lambda      = lambda;
    Adapt       = adapt;
    Epsilon     = epsilon;
    NumAccRatio             = 0.0;
    AcceptedRatio            = 0.0;
  AppDenAccRatio      = 0.0;
    
    //AddVarmean = Add_varmean;
    
    
    
    int i,j;
    for(i=0;i<nParameters;i++)
    {
        Parameters[i]->update_TransParameterAcc_FromParameterAcc(TransParametersAcc.Pvec(i));
        Parameters[i]->update_TransParameterProp_FromParameterProp(TransParametersProp.Pvec(i));
    }
    
    
    for(i=0;i<nParameters;i++)
    {
        //Mean.Pvec(i)[0] = TransParametersAcc.vec(i)+rnorm(0.0,Add_varmean);
        //MeanStart.Pvec(i)[0]  = TransParametersAcc.vec(i)+rnorm(0.0,Add_varmean);
        
        Mean.Pvec(i)[0] = TransParametersAcc.vec(i);
        MeanStart.Pvec(i)[0]  = TransParametersAcc.vec(i);
        
    }
    
    for(i=0;i<nParameters;i++)
    {
        for(j=0;j<nParameters;j++)
        {
            SigmaChol.Pmat(i,j)[0] = 0.0;
            Sigma.Pmat(i,j)[0] = 0.0;
            SigmaStart.Pmat(i,j)[0] = 0.0;
        }
        SigmaChol.Pmat(i,i)[0] = sdadapt[0];
        Sigma.Pmat(i,i)[0] = sdadapt[0]*sdadapt[0];
        SigmaStart.Pmat(i,i)[0] = sdadapt[0];
    }
}




/* ::Samp() */
void Class_AdaptHaario::Samp()
{
    int i;
    int Ione       = 1;
   
    
//if(DoUpdatePoly[0]==1)
//    {
        if(nParameters>1)
        {
            double AppPar_p[nParameters];
            for(i=0;i<nParameters;i++)
            {
                //Parameters[i][0].ParameterProp = rnorm(0.0,1.0);
                AppPar_p[i] = rnorm(0.0,1.0);;
            }
            F77_NAME(dtrmv)("L", "N", "N", &nParameters, SigmaChol.Pvec(0), &nParameters, &AppPar_p[0], &Ione);
            for(i=0;i<nParameters;i++)
            {
                TransParametersProp.Pvec(i)[0] = AppPar_p[i]+TransParametersAcc.vec(i);
                
                //REprintf("%i %f %f\n",i,TransParametersProp.Pvec(i)[0],TransParametersAcc.Pvec(i)[0]);
                Parameters[i]->update_ParameterProp_FromTransParameterProp(TransParametersProp.Pvec(i));
                
                //Parameters[i]->PrintObject("Par");
                
                Parameters[i]->AddressPropExt[0]      = Parameters[i]->ParameterProp;
                

            }
        }
        if(nParameters==1)
        {
            i = 0;
            
            TransParametersProp.Pvec(i)[0] = rnorm(TransParametersAcc.vec(i),SigmaChol.mat(i,i));
            Parameters[i]->update_ParameterProp_FromTransParameterProp(TransParametersProp.Pvec(i));
            Parameters[i]->AddressPropExt[0]      = Parameters[i]->ParameterProp;
        }
   // }
    
    
    
    
    
}

/* UpdateIfAccepted() */
void Class_AdaptHaario::UpdateIfAccepted()
{
    double app;
    NumAccRatio++;
    for(int i=0;i<nParameters;i++)
    {
        app = Parameters[i][0].ParameterProp;
        Parameters[i][0].ParameterProp = Parameters[i][0].ParameterAcc;
        Parameters[i][0].ParameterAcc = app;
        
        app = TransParametersProp.Pvec(i)[0];
        TransParametersProp.Pvec(i)[0] = TransParametersAcc.Pvec(i)[0];
        TransParametersAcc.Pvec(i)[0] = app;
        
        Parameters[i]->AddressPropExt[0]        = Parameters[i]->ParameterAcc;
        Parameters[i]->AddressAccExt[0]         = Parameters[i]->ParameterAcc;
        
    }
    
}

void Class_AdaptHaario::UpdateIfNotAccepted()
{
    //double app;
   
    for(int i=0;i<nParameters;i++)
    {

        
        Parameters[i]->AddressPropExt[0]        = Parameters[i]->ParameterAcc;
        Parameters[i]->AddressAccExt[0]         = Parameters[i]->ParameterAcc;
        
    }
    
}





/* Class_AdaptHaario::PostSamp(double AccRatio) */
void Class_AdaptHaario::PostSamp(double alpha)
{
    int i,j;
    int info;
    double appmean[nParameters];
    
    //REprintf("Class_ %i\n",Class_ToLoad::iterations);
    
    

        
        
        if(nParameters>1)
        {
            if(DoUpdatePoly[0]==1)
            {
              
              //REprintf("La %f Ad %f Al %f t %f ",Lambda, Adapt->Molt,alpha,Adapt->TargetRatio);
                Lambda     = exp(log(Lambda)+Adapt->Molt*(alpha-Adapt->TargetRatio));
              //REprintf("La %f \n",Lambda);
                for(i=0;i<nParameters;i++)
                {
                    for(j=i;j<nParameters;j++)
                    {
                        SigmaChol.Pmat(i,j)[0] = Sigma.mat(i,j)*Lambda;
                    }
                    SigmaChol.Pmat(i,i)[0] += Epsilon+epsilon2;
                    
                }
                F77_NAME(dpotrf)("L",&nParameters, SigmaChol.Pvec(0), &nParameters, &info);
                if(info != 0)
                {
                
                    nFails ++;
                  //REprintf("\n\nWarning): Sigma Adapt Non positive Definite. nFails=%i\n\n",  nFails);
                    //REprintf("\n\nWarning (%s): Sigma Adapt Non positive Definite. nFails=%i\n\n", NameObject.c_str(), nFails);
//                    Sigma.PrintTriUpper("SIGMAMAT/Users/gianlucamastrantonio/Dropbox (Politecnico di Torino Staff)/github/ODE_T1/ODE_RT1/srcAd");
//                    TransParametersProp.Print("Prop");
//                    TransParametersAcc.Print("Acc");
                    
                    for(i=0;i<nParameters;i++)
                    {
                        for(j=i;j<nParameters;j++)
                        {
                            //SigmaChol.Pmat(i,j)[0] = SigmaStart.mat(i,j);
                            SigmaChol.Pmat(i,j)[0] = 0.0;
                        }
                        SigmaChol.Pmat(i,i)[0] = pow(Sigma.mat(i,i)*Lambda,0.5);
                    }
                    epsilon2 = (epsilon2+Epsilon)*1.2;
                    
                }else{
                    nFails = 0;
                }
                if(nFails>20)
                {
                    //REprintf("Too many Sigma Adapt Non positive Definite.\n");
                    
                    nFails = 0;
                }
                
                
                
                for(i=0;i<nParameters;i++)
                {
                    appmean[i]      = TransParametersAcc.vec(i)-Mean.vec(i);
                    Mean.Pvec(i)[0] = Mean.vec(i)+Adapt->Molt*appmean[i];
                }
                for(i=0;i<nParameters;i++)
                {
                    for(j=i;j<nParameters;j++)
                    {
                        Sigma.Pmat(i,j)[0] =  Sigma.mat(i,j)+(appmean[i]*appmean[j]-Sigma.mat(i,j))*Adapt->Molt;
                    }
                }
                
                
            }else{
                //Lambda     = exp(log(Lambda)+Adapt->Molt*(alpha-Adapt->TargetRatio));
                
                for(i=0;i<nParameters;i++)
                {
                    appmean[i]      = TransParametersAcc.vec(i)-Mean.vec(i);
                    Mean.Pvec(i)[0] = Mean.vec(i)+Adapt->Molt*appmean[i];
                }
                for(i=0;i<nParameters;i++)
                {
                    for(j=i;j<nParameters;j++)
                    {
                        Sigma.Pmat(i,j)[0] =  Sigma.mat(i,j)+(appmean[i]*appmean[j]-Sigma.mat(i,j))*Adapt->Molt;
                    }
                }
                
     
                
            }
            
            for(i=0;i<nParameters;i++)
            {
                if(Parameters[i]->isCircular==1)
                {
                    double app;
                    app = Parameters[i]->ParameterAcc;
                    Parameters[i]->AddressPropExt[0]    =  Class_Utils::ModOp(Parameters[i]->AddressPropExt[0], 2.0*M_PI);
                    Parameters[i]->AddressAccExt[0]     =  Class_Utils::ModOp(Parameters[i]->AddressAccExt[0] , 2.0*M_PI);
                    Parameters[i]->ParameterAcc         =  Class_Utils::ModOp(Parameters[i]->ParameterAcc, 2.0*M_PI);
                    Parameters[i]->ParameterProp        =  Class_Utils::ModOp(Parameters[i]->ParameterProp, 2.0*M_PI);
                    
                    //app         = Mean.Pvec(i)[0];
                    Mean.Pvec(i)[0]                     = Mean.vec(i)-(app-Parameters[i]->ParameterAcc);
                    
                    TransParametersProp.Pvec(i)[0]      = TransParametersProp.Pvec(i)[0]-(app-Parameters[i]->ParameterAcc);
                    TransParametersAcc.Pvec(i)[0]       = TransParametersAcc.Pvec(i)[0]-(app-Parameters[i]->ParameterAcc);
                }
                
                
            }
        }
    
        if(nParameters==1)
        {
            //REprintf("UniAdapt");
            if(DoUpdatePoly[0]==1)
            {
                i = 0;
                iterBatch++;
                sumalpha += alpha;
                //REprintf("Sumalpha %f iterbatch %i BAtch=%i",sumalpha/iterBatch, iterBatch,Adapt->Batch );
                if(iterBatch>Adapt->Batch)
                {
                    //REprintf("SigmaCHol pre %f ", SigmaChol.Pmat(i,i)[0]);
//SigmaChol.Pmat(i,i)[0]  = exp(log(Lambda)+Adapt->Molt*(sumalpha/iterBatch-Adapt->TargetRatio));
                    SigmaChol.Pmat(i,i)[0]  = pow(exp(2.0*log(SigmaChol.Pmat(i,i)[0])+Adapt->Molt*(sumalpha/iterBatch-Adapt->TargetRatio)),0.5);
                    //REprintf("SigmaCHol post %f ", SigmaChol.Pmat(i,i)[0]);
                    sumalpha                = 0.0;
                    iterBatch               = 0;
                }
            }
            
            i = 0;
            if(Parameters[i]->isCircular==1)
            {
                Parameters[i]->AddressPropExt[0]    =  Class_Utils::ModOp(Parameters[i]->AddressPropExt[0], 2.0*M_PI);
                Parameters[i]->AddressAccExt[0]     =  Class_Utils::ModOp(Parameters[i]->AddressAccExt[0] , 2.0*M_PI);
                Parameters[i]->ParameterAcc         =  Class_Utils::ModOp(Parameters[i]->ParameterAcc, 2.0*M_PI);
                Parameters[i]->ParameterProp        =  Class_Utils::ModOp(Parameters[i]->ParameterProp, 2.0*M_PI);
                
                TransParametersProp.Pvec(i)[0]      =  Class_Utils::ModOp(TransParametersProp.Pvec(i)[0], 2.0*M_PI);
                TransParametersAcc.Pvec(i)[0]       =  Class_Utils::ModOp(TransParametersAcc.Pvec(i)[0], 2.0*M_PI);
            }
            
            
            
        }

    AcceptedRatio = NumAccRatio/(Adapt->DenAccRatio-AppDenAccRatio);
}












/***** void add_parameters(Class_Parameter* parameter, string name) *****/

int Class_AdaptHaario_V2::add_parameters(Class_Parameter* parameter)
{
  int ret =0; if((parameter[0].PriorParameter[0].NamePrior!="NoPrior")&(parameter[0].PriorParameter[0].NamePrior!="DiscreteUniform"))
    {
        Parameters.push_back(parameter);
        //Parameters[Parameters.size()-1] = parameter;
        NameParameters.push_back(parameter[0].NameParameter);
      ret = 1;
    }else{
      ret = 0;
        REprintf("\n\n %s not added to the Adaptive MH\n\n ",parameter[0].NameParameter.c_str());
    }
  return(ret);
}


//* void add_finalizedConstruct(double Add_varmean, double epsilon, double *sdadapt, double lambda, int usr,Class_AdaptPar *adapt )  */

void Class_AdaptHaario_V2::add_finalizedConstruct( double epsilon, double *sdadapt, double lambda, int usr,Class_AdaptPar *adapt )
{
    sumalpha = 0.0;
    iterBatch = 0;
    
    nParameters = (int)Parameters.size();
    int UserControlledMemory        = usr;
    
    nFails                  = 0;
    TransParametersProp     = Vector <double> (nParameters,UserControlledMemory);
    TransParametersAcc      = Vector <double> (nParameters,UserControlledMemory);
    
    Mean        = Vector<double>(nParameters,UserControlledMemory);
    MeanStart       = Vector<double>(nParameters,UserControlledMemory);
    SigmaChol   = Matrix<double>(nParameters,nParameters,UserControlledMemory);
    Sigma       = Matrix<double>(nParameters,nParameters,UserControlledMemory);
    SigmaStart  = Matrix<double>(nParameters,nParameters,UserControlledMemory);
    Lambda      = lambda;
    Adapt       = adapt;
    Epsilon     = epsilon;
    NumAccRatio             = 0.0;
    AcceptedRatio            = 0.0;
    AppDenAccRatio      = 0.0;
    //AddVarmean = Add_varmean;
    
    
    
    int i,j;
    for(i=0;i<nParameters;i++)
    {
        Parameters[i]->update_TransParameterAcc_FromParameterAcc(TransParametersAcc.Pvec(i));
        Parameters[i]->update_TransParameterProp_FromParameterProp(TransParametersProp.Pvec(i));
    }
    
    
    for(i=0;i<nParameters;i++)
    {
        //Mean.Pvec(i)[0] = TransParametersAcc.vec(i)+rnorm(0.0,Add_varmean);
        //MeanStart.Pvec(i)[0]  = TransParametersAcc.vec(i)+rnorm(0.0,Add_varmean);
        Mean.Pvec(i)[0] = TransParametersAcc.vec(i);
        MeanStart.Pvec(i)[0]  = TransParametersAcc.vec(i);

    }
    
    for(i=0;i<nParameters;i++)
    {
        for(j=0;j<nParameters;j++)
        {
            SigmaChol.Pmat(i,j)[0] = 0.0;
            Sigma.Pmat(i,j)[0] = 0.0;
            SigmaStart.Pmat(i,j)[0] = 0.0;
        }
        SigmaChol.Pmat(i,i)[0] = sdadapt[i];
        Sigma.Pmat(i,i)[0] = sdadapt[i]*sdadapt[i];
        SigmaStart.Pmat(i,i)[0] = sdadapt[i];
    }
    epsilon2 = 0.0;
}



void Class_AdaptHaario_V2::add_finalizedConstruct_OnlyOneSd( double epsilon, double *sdadapt, double lambda, int usr,Class_AdaptPar *adapt )
{
    epsilon2 = 0.0;
    sumalpha = 0.0;
    iterBatch = 0;
    
    nParameters = (int)Parameters.size();
    int UserControlledMemory        = usr;
    
    nFails                  = 0;
    TransParametersProp     = Vector <double> (nParameters,UserControlledMemory);
    TransParametersAcc      = Vector <double> (nParameters,UserControlledMemory);
    
    Mean        = Vector<double>(nParameters,UserControlledMemory);
    MeanStart       = Vector<double>(nParameters,UserControlledMemory);
    SigmaChol   = Matrix<double>(nParameters,nParameters,UserControlledMemory);
    Sigma       = Matrix<double>(nParameters,nParameters,UserControlledMemory);
    SigmaStart  = Matrix<double>(nParameters,nParameters,UserControlledMemory);
    Lambda      = lambda;
    Adapt       = adapt;
    Epsilon     = epsilon;
    NumAccRatio             = 0.0;
    AcceptedRatio            = 0.0;
    AppDenAccRatio      = 0.0;
    //AddVarmean = Add_varmean;
    
    
    
    int i,j;
    for(i=0;i<nParameters;i++)
    {
        Parameters[i]->update_TransParameterAcc_FromParameterAcc(TransParametersAcc.Pvec(i));
        Parameters[i]->update_TransParameterProp_FromParameterProp(TransParametersProp.Pvec(i));
    }
    
    
    for(i=0;i<nParameters;i++)
    {
        //Mean.Pvec(i)[0] = TransParametersAcc.vec(i)+rnorm(0.0,Add_varmean);
        //MeanStart.Pvec(i)[0]  = TransParametersAcc.vec(i)+rnorm(0.0,Add_varmean);
        
        Mean.Pvec(i)[0] = TransParametersAcc.vec(i);
        MeanStart.Pvec(i)[0]  = TransParametersAcc.vec(i);
        
    }
    
    for(i=0;i<nParameters;i++)
    {
        for(j=0;j<nParameters;j++)
        {
            SigmaChol.Pmat(i,j)[0] = 0.0;
            Sigma.Pmat(i,j)[0] = 0.0;
            SigmaStart.Pmat(i,j)[0] = 0.0;
        }
        SigmaChol.Pmat(i,i)[0] = sdadapt[0];
        Sigma.Pmat(i,i)[0] = sdadapt[0]*sdadapt[0];
        SigmaStart.Pmat(i,i)[0] = sdadapt[0];
    }
}




/* ::Samp() */
void Class_AdaptHaario_V2::Samp()
{
    int i;
    int Ione       = 1;
   
    
//if(DoUpdatePoly[0]==1)
//    {
        if(nParameters>1)
        {
            double AppPar_p[nParameters];
            for(i=0;i<nParameters;i++)
            {
                //Parameters[i][0].ParameterProp = rnorm(0.0,1.0);
                AppPar_p[i] = rnorm(0.0,1.0);;
            }
            F77_NAME(dtrmv)("L", "N", "N", &nParameters, SigmaChol.Pvec(0), &nParameters, &AppPar_p[0], &Ione);
            for(i=0;i<nParameters;i++)
            {
                TransParametersProp.Pvec(i)[0] = AppPar_p[i]+TransParametersAcc.vec(i);
                
                //REprintf("%i %f %f\n",i,TransParametersProp.Pvec(i)[0],TransParametersAcc.Pvec(i)[0]);
                Parameters[i]->update_ParameterProp_FromTransParameterProp(TransParametersProp.Pvec(i));
                
                //Parameters[i]->PrintObject("Par");
                
                Parameters[i]->AddressPropExt[0]      = Parameters[i]->ParameterProp;
                

            }
        }
        if(nParameters==1)
        {
            i = 0;
            
            TransParametersProp.Pvec(i)[0] = rnorm(TransParametersAcc.vec(i),SigmaChol.mat(i,i));
            Parameters[i]->update_ParameterProp_FromTransParameterProp(TransParametersProp.Pvec(i));
            Parameters[i]->AddressPropExt[0]      = Parameters[i]->ParameterProp;
        }
   // }
    
    
    
    
    
}

/* UpdateIfAccepted() */
void Class_AdaptHaario_V2::UpdateIfAccepted()
{
    double app;
    NumAccRatio++;
    for(int i=0;i<nParameters;i++)
    {
        app = Parameters[i][0].ParameterProp;
        Parameters[i][0].ParameterProp = Parameters[i][0].ParameterAcc;
        Parameters[i][0].ParameterAcc = app;
        
        app = TransParametersProp.Pvec(i)[0];
        TransParametersProp.Pvec(i)[0] = TransParametersAcc.Pvec(i)[0];
        TransParametersAcc.Pvec(i)[0] = app;
        
        Parameters[i]->AddressPropExt[0]        = Parameters[i]->ParameterAcc;
        Parameters[i]->AddressAccExt[0]         = Parameters[i]->ParameterAcc;
        
    }
    
}

void Class_AdaptHaario_V2::UpdateIfNotAccepted()
{
    //double app;
   
    for(int i=0;i<nParameters;i++)
    {

        
        Parameters[i]->AddressPropExt[0]        = Parameters[i]->ParameterAcc;
        Parameters[i]->AddressAccExt[0]         = Parameters[i]->ParameterAcc;
        
    }
    
}


/* Class_AdaptHaario::PostSamp(double AccRatio) */
void Class_AdaptHaario_V2::PostSamp(double alpha)
{
    int i,j;
    int info;
    double appmean[nParameters];
    
    //REprintf("Class_ %i\n",Class_ToLoad::iterations);
    
    

        
        
        if(nParameters>1)
        {
            if(DoUpdatePoly[0]==1)
            {
              if((iterBatch+1)>Adapt->Batch)
              {
                Lambda     = exp(log(Lambda)+Adapt->Molt*(alpha-Adapt->TargetRatio));
                for(i=0;i<nParameters;i++)
                {
                    for(j=i;j<nParameters;j++)
                    {
                        SigmaChol.Pmat(i,j)[0] = Sigma.mat(i,j)*Lambda;
                    }
                    SigmaChol.Pmat(i,i)[0] += Epsilon+epsilon2;
                    
                }
                F77_NAME(dpotrf)("L",&nParameters, SigmaChol.Pvec(0), &nParameters, &info);
                if(info != 0)
                {
                
                    nFails ++;
                    REprintf("\n\nWarning (%s): Sigma Adapt Non positive Definite. nFails=%i\n\n", NameObject.c_str(), nFails);
                    Sigma.PrintTriUpper("SIGMAMATAd");
                    TransParametersProp.Print("Prop");
                    TransParametersAcc.Print("Acc");
                    
                    for(i=0;i<nParameters;i++)
                    {
                        for(j=i;j<nParameters;j++)
                        {
                            //SigmaChol.Pmat(i,j)[0] = SigmaStart.mat(i,j);
                            SigmaChol.Pmat(i,j)[0] = 0.0;
                        }
                        SigmaChol.Pmat(i,i)[0] = pow(Sigma.mat(i,i)*Lambda,0.5);
                    }
                    epsilon2 = (epsilon2+Epsilon)*1.2;
                    
                }else{
                    nFails = 0;
                }
                if(nFails>20)
                {
                    REprintf("Too many Sigma Adapt Non positive Definite.\n");

                    
                    nFails = 0;
                }
              }
                
                
                
                
                for(i=0;i<nParameters;i++)
                {
                    appmean[i]      = TransParametersAcc.vec(i)-Mean.vec(i);
                    Mean.Pvec(i)[0] = Mean.vec(i)+Adapt->Molt*appmean[i];
                }
                for(i=0;i<nParameters;i++)
                {
                    for(j=i;j<nParameters;j++)
                    {
                        Sigma.Pmat(i,j)[0] =  Sigma.mat(i,j)+(appmean[i]*appmean[j]-Sigma.mat(i,j))*Adapt->Molt;
                    }
                }
                
                
            }else{
                //Lambda     = exp(log(Lambda)+Adapt->Molt*(alpha-Adapt->TargetRatio));
                
                for(i=0;i<nParameters;i++)
                {
                    appmean[i]      = TransParametersAcc.vec(i)-Mean.vec(i);
                    Mean.Pvec(i)[0] = Mean.vec(i)+Adapt->Molt*appmean[i];
                }
                for(i=0;i<nParameters;i++)
                {
                    for(j=i;j<nParameters;j++)
                    {
                        Sigma.Pmat(i,j)[0] =  Sigma.mat(i,j)+(appmean[i]*appmean[j]-Sigma.mat(i,j))*Adapt->Molt;
                    }
                }
                
     
                
            }
            
            for(i=0;i<nParameters;i++)
            {
                if(Parameters[i]->isCircular==1)
                {
                    double app;
                    app = Parameters[i]->ParameterAcc;
                    Parameters[i]->AddressPropExt[0]    =  Class_Utils::ModOp(Parameters[i]->AddressPropExt[0], 2.0*M_PI);
                    Parameters[i]->AddressAccExt[0]     =  Class_Utils::ModOp(Parameters[i]->AddressAccExt[0] , 2.0*M_PI);
                    Parameters[i]->ParameterAcc         =  Class_Utils::ModOp(Parameters[i]->ParameterAcc, 2.0*M_PI);
                    Parameters[i]->ParameterProp        =  Class_Utils::ModOp(Parameters[i]->ParameterProp, 2.0*M_PI);
                    
                    //app         = Mean.Pvec(i)[0];
                    Mean.Pvec(i)[0]                     = Mean.vec(i)-(app-Parameters[i]->ParameterAcc);
                    
                    TransParametersProp.Pvec(i)[0]      = TransParametersProp.Pvec(i)[0]-(app-Parameters[i]->ParameterAcc);
                    TransParametersAcc.Pvec(i)[0]       = TransParametersAcc.Pvec(i)[0]-(app-Parameters[i]->ParameterAcc);
                }
                
                
            }
        }
    
        if(nParameters>1)
        {
          if(DoUpdatePoly[0]==1)
          {
              iterBatch++;

              if(iterBatch>Adapt->Batch)
              {

                  iterBatch               = 0;
              }
          }
        }
        if(nParameters==1)
        {
            //REprintf("UniAdapt");
            if(DoUpdatePoly[0]==1)
            {
                i = 0;
                iterBatch++;
                sumalpha += alpha;
                //REprintf("Sumalpha %f iterbatch %i BAtch=%i",sumalpha/iterBatch, iterBatch,Adapt->Batch );
                if(iterBatch>Adapt->Batch)
                {
                    //REprintf("SigmaCHol pre %f ", SigmaChol.Pmat(i,i)[0]);
//SigmaChol.Pmat(i,i)[0]  = exp(log(Lambda)+Adapt->Molt*(sumalpha/iterBatch-Adapt->TargetRatio));
                    SigmaChol.Pmat(i,i)[0]  = pow(exp(2.0*log(SigmaChol.Pmat(i,i)[0])+Adapt->Molt*(sumalpha/iterBatch-Adapt->TargetRatio)),0.5);
                    //REprintf("SigmaCHol post %f ", SigmaChol.Pmat(i,i)[0]);
                    sumalpha                = 0.0;
                    iterBatch               = 0;
                }
            }
            
            i = 0;
            if(Parameters[i]->isCircular==1)
            {
                Parameters[i]->AddressPropExt[0]    =  Class_Utils::ModOp(Parameters[i]->AddressPropExt[0], 2.0*M_PI);
                Parameters[i]->AddressAccExt[0]     =  Class_Utils::ModOp(Parameters[i]->AddressAccExt[0] , 2.0*M_PI);
                Parameters[i]->ParameterAcc         =  Class_Utils::ModOp(Parameters[i]->ParameterAcc, 2.0*M_PI);
                Parameters[i]->ParameterProp        =  Class_Utils::ModOp(Parameters[i]->ParameterProp, 2.0*M_PI);
                
                TransParametersProp.Pvec(i)[0]      =  Class_Utils::ModOp(TransParametersProp.Pvec(i)[0], 2.0*M_PI);
                TransParametersAcc.Pvec(i)[0]       =  Class_Utils::ModOp(TransParametersAcc.Pvec(i)[0], 2.0*M_PI);
            }
            
            
            
        }

    AcceptedRatio = NumAccRatio/(Adapt->DenAccRatio-AppDenAccRatio);
}



