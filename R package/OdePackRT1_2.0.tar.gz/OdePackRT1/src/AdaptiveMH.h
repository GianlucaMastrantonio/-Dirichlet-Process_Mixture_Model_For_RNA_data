// C_MhAdapt
#ifndef AdaptiveMH_H
#define AdaptiveMH_H
#include "MatricesAndVectors.h"
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>
#include "DensityPriorParam.h"


/******************************
 AdaptParam
 ******************************/

class Class_AdaptPar
{
private:
    
public:
    int Start;
    int End;
    double Exp;
    double TargetRatio;
    double Molt;
    double BetaCov;
    int     DoUpdate;
    int Batch;
    int FirstPostUpdate;
    
    double DenAccRatio;
    
    void PrintObject()
    {
        REprintf("Start=%i\n",Start);
        REprintf("End=%i\n",End);
        REprintf("Exp=%f\n",Exp);
        REprintf("TargetRatio=%f\n",TargetRatio);
        REprintf("DoUpdate=%i\n",DoUpdate);
        REprintf("Batch=%i\n",Batch);
    };
    
    // CONSTRUCTORS
    Class_AdaptPar(){};
    Class_AdaptPar(int start, int end, double exp, double targetRatio, int batch)
    {
        Start   = start;
        End     = end;
        Exp     = exp;
        TargetRatio    =targetRatio;
        Molt            = 1.0;
        DoUpdate        = 0;
        Batch           = batch;
        DenAccRatio     = 0.0;
        FirstPostUpdate = 0;
    }
    //DESTRUCTORS
    ~Class_AdaptPar(){};

    
    //UPDATES
    void Update(int iteration)
    {
        DenAccRatio++;
        Molt = 1.0/pow(iteration+1,Exp);
        if((iteration>Start) & (iteration<End))
        {
            DoUpdate = 1;
            
            
        }else{
            if(DoUpdate==1)
            {
                FirstPostUpdate = 1;
            }else{
                FirstPostUpdate = 0;
            }
            DoUpdate = 0;
        }
    }
    
    
    
   
};



/******************************
Polymorphism
 ******************************/

class Poly_Adapt
{
private:
    
public:
    int nParameters;
    string NameObject;
    vector <Class_Parameter*> Parameters;
    vector <string> NameParameters;
    
    Vector <double> TransParametersProp;
    Vector <double> TransParametersAcc;
    
    Vector<double>Mean;
    Vector<double>MeanStart;
    Matrix<double>SigmaChol;
    Matrix<double>Sigma;
    Matrix<double>SigmaStart;
    double Lambda;
    Vector <double> LambdaVec;
    int    SampInt;
    double Epsilon;
    double sumalpha;
    int iterBatch;
    
    
    int nFails;
    
    double NumAccRatio;
    double AcceptedRatio;
    double AppDenAccRatio;
    
    Class_AdaptPar * Adapt;
    
    int IsAccepted;
    int *DoUpdatePoly;
    
    
    //double AddVarmean;
    
    //COSTRUCTORS
    Poly_Adapt(){};
    
    //DESTRUCTORS
    ~Poly_Adapt(){}

    
    // Print
    virtual void PrintObject(string ToPrint) = 0;
    virtual void PrintObjectEnd(string ToPrint) = 0;
  virtual void PrintObjectNoCov(string ToPrint) = 0;
    // function
    double get_logDensityParameterWithLogJacobian_DiffPropAcc()
    {
        double ret = 0.0;
        for(int i=0;i<Parameters.size();i++)
        {
            ret += Parameters[i]->compute_NoNormlogDensity_forVariable_DiffPropLessAcc();
            ret += Parameters[i]->compute_LogJacobian_DiffPropLessAcc();
        }
        return(ret);
    }
    double get_LogJacobian_DiffPropAcc()
    {
        double ret = 0.0;
        for(int i=0;i<Parameters.size();i++)
        {
            //ret += Parameters[i]->compute_NoNormlogDensity_forVariable_DiffPropLessAcc();
            ret += Parameters[i]->compute_LogJacobian_DiffPropLessAcc();
        }
        return(ret);
    }
    
    //ADDS
    void add_name(string name)
    {
        NameObject = name;
    }
  void  SetAccPropEqual();
    virtual int add_parameters(Class_Parameter* parameter) = 0;
    virtual void add_finalizedConstruct( double epsilon, double *sdadapt, double lambda, int usr,Class_AdaptPar *adapt ) = 0;
    virtual void add_finalizedConstruct_OnlyOneSd( double epsilon, double *sdadapt, double lambda, int usr,Class_AdaptPar *adapt ) = 0;
    virtual void PostSamp(double alpha) = 0;
    virtual void Samp() = 0;
    virtual void UpdateIfAccepted() = 0;
    virtual void UpdateIfNotAccepted() = 0;
    virtual void CheckMultiUpdate() = 0;
    virtual void compute_TransFromAcc()
    {
        error("Non overrided function compute_TransFromAcc()");
    }
  void reset_AccRatio()
  {
    NumAccRatio   = 0.0;
    AcceptedRatio = 0.0;
    AppDenAccRatio = Adapt->DenAccRatio;
  }
    
    //Parameters[i]->update_ParameterAcc_FromTransParameterAcc(TransParametersAcc.Pvec(i));
};

/******************************
 Adapt
******************************/


class Class_AdaptHaario: public Poly_Adapt
{
private:
    
public:
    double epsilon2;
    
    
    
    //COSTRUCTORS
    Class_AdaptHaario(){};
    
    //DESTRUCTORS
    ~Class_AdaptHaario(){}
 
    
    void PrintObject(string ToPrint)  override
    {
        REprintf("\n\n\n %s",ToPrint.c_str() );
        REprintf("doUpdata %i molt %f target %f\n",DoUpdatePoly[0], Adapt->Molt, Adapt->TargetRatio);
        REprintf("Adapt parameter %s \n", NameObject.c_str());
        REprintf("Number parameters = %i \n", nParameters);
        for(int i=0;i<nParameters;i++)
        {
            REprintf("Parameter %s\n", NameParameters[i].c_str());
            REprintf("Acc %f Prop %f\n", Parameters[i][0].ParameterAcc,Parameters[i][0].ParameterProp);
            REprintf("TransAcc %f TransProp %f\n", TransParametersAcc.Pvec(i)[0],TransParametersProp.Pvec(i)[0]);
        }
        REprintf("Lambda %f Epsilon %f AccRati %f \n",Lambda,Epsilon,AcceptedRatio);
        
        Mean.Print("Mean Adapt");
        SigmaChol.Print("SigmaChol");
        Sigma.Print("Sigma");
        SigmaStart.Print("SigmaStart");

    }
  void PrintObjectEnd(string ToPrint)  override
  {
    REprintf("%s ",ToPrint.c_str() );
    REprintf("Parameters %s ", NameObject.c_str());
    REprintf("Final AccRatio %f Target %f Lambda %f \n",AcceptedRatio,Adapt->TargetRatio, Lambda);
  }
  void PrintObjectNoCov(string ToPrint)  override
  {
      REprintf("\n\n\n %s",ToPrint.c_str() );
      REprintf("doUpdata %i molt %f\n",DoUpdatePoly[0], Adapt->Molt);
      REprintf("Adapt parameter %s \n", NameObject.c_str());
      REprintf("Number parameters = %i \n", nParameters);
      for(int i=0;i<nParameters;i++)
      {
          REprintf("Parameter %s\n", NameParameters[i].c_str());
          REprintf("Acc %f Prop %f\n", Parameters[i][0].ParameterAcc,Parameters[i][0].ParameterProp);
          REprintf("TransAcc %f TransProp %f\n", TransParametersAcc.Pvec(i)[0],TransParametersProp.Pvec(i)[0]);
      }
      REprintf("Lambda %f Epsilon %f AccRati %f \n",Lambda,Epsilon,AcceptedRatio);
      
      Mean.Print("Mean Adapt");
     

  }
    

    //ADDS
    int add_parameters(Class_Parameter* parameter)  override;
    void add_finalizedConstruct(double epsilon, double *sdadapt, double lambda, int usr,Class_AdaptPar *adapt )  override;
    void add_finalizedConstruct_OnlyOneSd( double epsilon, double *sdadapt, double lambda, int usr,Class_AdaptPar *adapt )  override;
    // FUNCTIONS
    void PostSamp(double alpha)  override;
    void Samp() override;
    void UpdateIfAccepted() override;
    void UpdateIfNotAccepted() override;
    
    void CheckMultiUpdate() override
    {
        if(nParameters==0)
        {
            DoUpdatePoly =   new int;
            DoUpdatePoly[0] = 0;
            REprintf("\n MH adapt %s has not parameters: \n",NameObject.c_str());
        }
        if(nParameters==1)
        {
            DoUpdatePoly = &Adapt->DoUpdate;
        }
        if(nParameters>1)
        {
            DoUpdatePoly = &Adapt->DoUpdate;

        }
    }
   void compute_TransFromAcc() override
    {
//        if(nParameters>1)
//        {
//            error("Nparameters>1 in compute_TransFromAcc()");
//        }
//        Parameters[0]->update_TransParameterAcc_FromParameterAcc(TransParametersAcc.Pvec(0));
//		 
		 for(int i=0;i<Parameters.size();i++)
		 {
			 Parameters[i]->update_TransParameterAcc_FromParameterAcc(TransParametersAcc.Pvec(i));
		 }
		 
    }
};






class Class_AdaptHaario_V2: public Poly_Adapt
{
private:
    
public:
    double epsilon2;
    
    
    
    //COSTRUCTORS
    Class_AdaptHaario_V2(){};
    
    //DESTRUCTORS
    ~Class_AdaptHaario_V2(){}
 
    
  void PrintObjectEnd(string ToPrint)  override
  {
    REprintf("%s ",ToPrint.c_str() );
    REprintf("Parameters %s ", NameObject.c_str());
    REprintf("Final AccRatio %f Target %f Lambda %f \n",AcceptedRatio,Adapt->TargetRatio, Lambda);
  }
    void PrintObject(string ToPrint)  override
    {
        REprintf("\n\n\n %s",ToPrint.c_str() );
        REprintf("doUpdata %i molt %f\n",DoUpdatePoly[0], Adapt->Molt);
        REprintf("Adapt parameter %s \n", NameObject.c_str());
        REprintf("Number parameters = %i \n", nParameters);
        for(int i=0;i<nParameters;i++)
        {
            REprintf("Parameter %s\n", NameParameters[i].c_str());
            REprintf("Acc %f Prop %f\n", Parameters[i][0].ParameterAcc,Parameters[i][0].ParameterProp);
            REprintf("TransAcc %f TransProp %f\n", TransParametersAcc.Pvec(i)[0],TransParametersProp.Pvec(i)[0]);
        }
        REprintf("Lambda %f Epsilon %f AccRati %f \n",Lambda,Epsilon,AcceptedRatio);
        
        Mean.Print("Mean Adapt");
        SigmaChol.Print("SigmaChol");
        Sigma.Print("Sigma");
        SigmaStart.Print("SigmaStart");

    }
  void PrintObjectNoCov(string ToPrint)  override
  {
      REprintf("\n\n\n %s",ToPrint.c_str() );
      REprintf("doUpdata %i molt %f\n",DoUpdatePoly[0], Adapt->Molt);
      REprintf("Adapt parameter %s \n", NameObject.c_str());
      REprintf("Number parameters = %i \n", nParameters);
      for(int i=0;i<nParameters;i++)
      {
          REprintf("Parameter %s\n", NameParameters[i].c_str());
          REprintf("Acc %f Prop %f\n", Parameters[i][0].ParameterAcc,Parameters[i][0].ParameterProp);
          REprintf("TransAcc %f TransProp %f\n", TransParametersAcc.Pvec(i)[0],TransParametersProp.Pvec(i)[0]);
      }
      REprintf("Lambda %f Epsilon %f AccRati %f \n",Lambda,Epsilon,AcceptedRatio);
      
      Mean.Print("Mean Adapt");
     

  }
    

    //ADDS
    int add_parameters(Class_Parameter* parameter)  override;
    void add_finalizedConstruct(double epsilon, double *sdadapt, double lambda, int usr,Class_AdaptPar *adapt )  override;
    void add_finalizedConstruct_OnlyOneSd( double epsilon, double *sdadapt, double lambda, int usr,Class_AdaptPar *adapt )  override;
    // FUNCTIONS
    void PostSamp(double alpha)  override;
    void Samp() override;
    void UpdateIfAccepted() override;
    void UpdateIfNotAccepted() override;
    
    void CheckMultiUpdate() override
    {
        if(nParameters==0)
        {
            DoUpdatePoly =   new int;
            DoUpdatePoly[0] = 0;
            REprintf("\n MH adapt %s has not parameters: \n",NameObject.c_str());
        }
        if(nParameters==1)
        {
            DoUpdatePoly = &Adapt->DoUpdate;
        }
        if(nParameters>1)
        {
            DoUpdatePoly = &Adapt->DoUpdate;

        }
    }
   void compute_TransFromAcc() override
    {
		 for(int i=0;i<Parameters.size();i++)
		 {
			 Parameters[i]->update_TransParameterAcc_FromParameterAcc(TransParametersAcc.Pvec(i));
		 }
//        if(nParameters>1)
//        {
//            error("Nparameters>1 in compute_TransFromAcc()");
//        }
//        Parameters[0]->update_TransParameterAcc_FromParameterAcc(TransParametersAcc.Pvec(0));
    }
};






#endif




















