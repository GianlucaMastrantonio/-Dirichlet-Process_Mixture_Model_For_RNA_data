#include <iostream>
#include <string>
#include <list>
#include <vector>
#ifdef _OPENMP
#include <omp.h>
#endif
#include <boost/numeric/odeint.hpp>

#include <R.h>//TTT
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>

#include "MatricesAndVectors.h"
#include "AdaptiveMH.h"
#include "ODE.h"//


extern "C" {


SEXP ODE_T1(
SEXP nInits_r,
SEXP Inits_r,
SEXP NamePrior_r,
SEXP nParameters_r,
SEXP Prior_r,
SEXP nSd_r,
SEXP Sd_r,
SEXP MCMC_r,
SEXP Adaptpar_r,
SEXP Data_r,
SEXP indices_r,
SEXP indicesDouble_r,
SEXP IndexNotNA_r
           ){

  /*****************************************
          UTILS
   *****************************************/
  GetRNGstate();


  int i,j;
  double      *appPointDouble;
  int         *appPointInteger;

  int indexPriorParameters;
  int indexInit;
  string Name;
  string appName;

  int UserControlledMemory = 1;
  /*****************************************
           NAMES
   *****************************************/

  /********** Init Values ************/
  const int nInitsVector_R                    = 10;
  string  InitsVector_R[nInitsVector_R ]      = {
      "Y0",
      "RegCoef",
      "sigma2",
      "MinK",
      "MaxK",
      "x0",
      "xi",
      "lambda",
      "TypekFunc",
      "Void"
  };

  vector <string> Names_ParametersInit;
  for(int i=0;i<nInitsVector_R;i++)
  {
      Names_ParametersInit.push_back(InitsVector_R[i]);
  }

  /********** Parameters ************/
  const int nParametersVector_R                           = 10;
  string ParametersVector_R[nParametersVector_R ]         = {
      "Y0",
      "RegCoef",
      "sigma2",
      "MinK",
      "MaxK",
      "x0",
      "xi",
      "lambda",
      "Void"
  };
  vector <string> Names_ParametersPrior;
  for(int i=0;i<nParametersVector_R;i++)
  {
      Names_ParametersPrior.push_back(ParametersVector_R[i]);
  }


  /********** Priors ************/
  const int nPriorsVector_R                   = 9;
  string PriorsVector_R[nPriorsVector_R]      = {
      "NoPrior",
      "Normal",
      "Gamma",
      "InverseGamma",
      "Uniform",
      "InverseWishart",
      "HuangWand",
      "Dirichlet",
      "Void"};
  vector <string> Names_Priors;
  for(int i=0;i<nPriorsVector_R;i++)
  {
      Names_Priors.push_back(PriorsVector_R[i]);
  }

  /********** SD Adapt ************/
  const int nSdVector_R                           = 10;
  string SdVector_R[nSdVector_R ]         = {
      "General",
      "RegCoef",
      "sigma2",
      "MinK",
      "MaxK",
      "x0",
      "lambda",
      "Y0",
      "Void"
  };
  vector <string> Names_Sd;
  for(int i=0;i<nSdVector_R;i++)
  {
      Names_Sd.push_back(SdVector_R[i]);
  }

  /*****************************************
   Indices
   *****************************************/

  int *indices                     = INTEGER(indices_r);

  i = 0;
  int nvar        = indices[i];i++;
  int nobsTOT     = indices[i];i++;
  int nG          = indices[i];i++;
  int nt          = indices[i];i++;
  int nrep        = indices[i];i++;
  int IterShow    = indices[i];i++;
  int DoParallel  = indices[i];i++;
  int Nthreads    = indices[i];i++;
  int Verbose     = indices[i];i++;
  int nlatentk    = indices[i];i++;
  int nshapek     = indices[i];i++;
  int nstep       = indices[i];i++;
  int saveODE     = indices[i];i++;
  int nNotna      = indices[i];i++;




  double *indicesD                     = REAL(indicesDouble_r);
  i = 0;
  double tmin        = indicesD[i];i++;
  double tmax        = indicesD[i];i++;
  double deltat      = indicesD[i];i++;


  /*****************************************
   ParallelComp
   *****************************************/


  #ifdef _OPENMP
  if(DoParallel==1)
  {
    omp_set_num_threads(min(Nthreads,omp_get_num_procs()));
  }else{
    omp_set_num_threads(1);
  }
  if(Verbose==1)
  {
    REprintf("ParmeterNthreads: %i\n",Nthreads);
    REprintf("NumberOfProcessors: %i\n ",omp_get_num_procs());
    REprintf("MaxNumberOfThreads: %i\n\n",omp_get_max_threads());
    # pragma omp parallel
    {
      REprintf("CheckThread: %i\n", omp_get_thread_num());
    }
    REprintf("\n");
  }
  #else
  if(DoParallel==1)
  {
    if(Verbose==1)
    {
      REprintf("OPENMP - not possible\n\n");
    }

  }
  #endif

  /*****************************************
   MCMC and ADAPT
   *****************************************/

  appPointInteger             = INTEGER(MCMC_r);
  int MCMCiter                = appPointInteger[0];
  int MCMCburnin              = appPointInteger[1];
  int MCMCthin                = appPointInteger[2];
  int MCMCiter_noTandB        = appPointInteger[3];
  int nSamples_save           = MCMCiter_noTandB+1;

  i=0;
  appPointDouble              = REAL(Adaptpar_r);
  int     AdaptStart          = (int)appPointDouble[i];i++;
  int     AdaptEnd            = (int)appPointDouble[i];i++;
  double  AdaptExp            = appPointDouble[i];i++;
  double  AdaptAcc            = appPointDouble[i];i++;
  int     AdaptBatch          = (int)appPointDouble[i];i++;
  double  AdaptEps            = appPointDouble[i];i++;

  Class_AdaptPar      AdaptParameters(AdaptStart,AdaptEnd, AdaptExp, AdaptAcc, AdaptBatch);

  if(Verbose==1)
  {
    REprintf("MCMC parameters:\n");
    REprintf("Iterations=%i Burnin=%i Thin=%i SampleSave=%i\n\n", MCMCiter,MCMCburnin,MCMCthin , nSamples_save);

    REprintf("Adapt parameters:\n");
    REprintf("Start=%i End=%i AccRatio=%f \nBatch=%i Epsilon=%f Exponent=%f \n\n",AdaptStart,AdaptEnd ,AdaptAcc,AdaptBatch,AdaptEps,AdaptExp);
  }
  /*****************************************
  Parameters
  *****************************************/

  Name                 = "sigma2";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

  double *sigma2_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string sigma2_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *sigma2_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  vector<Poly_Prior* >            sigma2_Prior;
  vector<Class_Parameter>         sigma2_MCMC;

  if(sigma2_PriorName=="Uniform")
  {
      for(i=0;i<nvar;i++)
      {
          sigma2_Prior.push_back(new Class_Uniform);
          sigma2_Prior[i]->create_FullObject(UserControlledMemory);
      }

  }else{
    if(sigma2_PriorName=="InverseGamma")
    {
      for(i=0;i<nvar;i++)
      {
        sigma2_Prior.push_back(new Class_InverseGamma);
        sigma2_Prior[i]->create_FullObject(UserControlledMemory);
      }
    }else{
      error("Prior on sigma2 not well specified");
    }
  }

  for(i=0;i<nvar;i++)
  {
      for(int k=0;k<sigma2_Prior[i]->nHyperparams;k++)
      {
          sigma2_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = sigma2_PriorParameters[k*nvar+i];
          sigma2_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = sigma2_PriorParameters[k*nvar+i];
      }
  }
  for(i=0;i<nvar;i++)
  {
      sigma2_MCMC.push_back(Class_Parameter());
      appName = (("sigma2_")+to_string(i));
      sigma2_MCMC[i].create_FullObject(sigma2_InitParameters[i], appName,  sigma2_Prior[i]);
  }
  for(i=0;i<nvar;i++)
  {
      sigma2_MCMC[i].add_Pointerparameters_InVector();
  }

  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/

  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/

  Name                 = "lambda";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

  double *lambda_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string lambda_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *lambda_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  vector<Poly_Prior* >                  lambda_Prior; // uno per i k
  vector<  vector <Class_Parameter > >    lambda_MCMC; // k/nvar/cluster
  if(lambda_PriorName=="Uniform")
  {
      for(i=0;i<nlatentk;i++)
      {
          lambda_Prior.push_back(new Class_Uniform);
          lambda_Prior[i]->create_FullObject(UserControlledMemory);
      }

  }else{
    if(lambda_PriorName=="InverseGamma")
    {
      for(i=0;i<nlatentk;i++)
      {
        lambda_Prior.push_back(new Class_InverseGamma);
        lambda_Prior[i]->create_FullObject(UserControlledMemory);
      }
    }else{
      if(lambda_PriorName=="Normal")
      {
          for(i=0;i<nlatentk;i++)
          {
              lambda_Prior.push_back(new Class_Normal);
              lambda_Prior[i]->create_FullObject(UserControlledMemory);
          }

      }else{
        error("Prior on lambda not well specified");
      }

    }
  }

  for(i=0;i<nlatentk;i++)
  {
      for(int k=0;k<lambda_Prior[i]->nHyperparams;k++)
      {
          lambda_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = lambda_PriorParameters[k*nlatentk+i];
          lambda_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = lambda_PriorParameters[k*nlatentk+i];
      }
  }

  for(i=0;i<nG;i++)
  {
    lambda_MCMC.push_back(vector<Class_Parameter >());
    for(j=0;j<nlatentk;j++)
    {
      lambda_MCMC[i].push_back(Class_Parameter());
      appName = (("lambda_")+to_string(i)+to_string(j));
      lambda_MCMC[i][j].create_FullObject(lambda_InitParameters[i*nlatentk+j], appName,  lambda_Prior[j]);
    }
  }
  for(i=0;i<nG;i++)
  {

    for(j=0;j<nlatentk;j++)
    {
      lambda_MCMC[i][j].add_Pointerparameters_InVector();
      //lambda_MCMC[i][j].PrintObject("Lambda");
    }
  }



  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/

  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/

  Name                 = "x0";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

  double *x0_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string x0_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *x0_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  vector<Poly_Prior* >                  x0_Prior; // uno per i k
  vector< vector <Class_Parameter > >    x0_MCMC; // k/nvar/cluster
  if(x0_PriorName=="Uniform")
  {
    for(i=0;i<nlatentk;i++)
    {
      x0_Prior.push_back(new Class_Uniform);
      x0_Prior[i]->create_FullObject(UserControlledMemory);
    }

  }else{
    if(x0_PriorName=="InverseGamma")
    {
      for(i=0;i<nlatentk;i++)
      {
        x0_Prior.push_back(new Class_InverseGamma);
        x0_Prior[i]->create_FullObject(UserControlledMemory);
      }
    }else{
      error("Prior on x0 not well specified");
    }
  }

  for(i=0;i<nlatentk;i++)
  {
    for(int k=0;k<x0_Prior[i]->nHyperparams;k++)
    {
      x0_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = x0_PriorParameters[k*nlatentk+i];
      x0_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = x0_PriorParameters[k*nlatentk+i];
    }
  }

  for(i=0;i<nG;i++)
  {
    x0_MCMC.push_back(vector<Class_Parameter >());
    for(j=0;j<nlatentk;j++)
    {
      x0_MCMC[i].push_back(Class_Parameter());
      appName = (("x0_")+to_string(i)+to_string(j));
      x0_MCMC[i][j].create_FullObject(x0_InitParameters[i*nlatentk+j], appName,  x0_Prior[j]);
    }
  }
  for(i=0;i<nG;i++)
  {

    for(j=0;j<nlatentk;j++)
    {
      x0_MCMC[i][j].add_Pointerparameters_InVector();
    }
  }

  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/

  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/

  Name                 = "MaxK";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

  double *MaxK_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string MaxK_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *MaxK_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  vector<Poly_Prior* >                  MaxK_Prior; // uno per i k
  vector< vector <Class_Parameter > >    MaxK_MCMC; // k/nvar/cluster
  if(MaxK_PriorName=="Uniform")
  {
    for(i=0;i<nlatentk;i++)
    {
      MaxK_Prior.push_back(new Class_Uniform);
      MaxK_Prior[i]->create_FullObject(UserControlledMemory);
    }

  }else{
    if(MaxK_PriorName=="InverseGamma")
    {
      for(i=0;i<nlatentk;i++)
      {
        MaxK_Prior.push_back(new Class_InverseGamma);
        MaxK_Prior[i]->create_FullObject(UserControlledMemory);
      }
    }else{
      if(MaxK_PriorName=="Normal")
      {
        for(i=0;i<nlatentk;i++)
        {
          MaxK_Prior.push_back(new Class_Normal);
          MaxK_Prior[i]->create_FullObject(UserControlledMemory);
        }
      }else{
        error("Prior on MaxK not well specified");
      }
    }
  }

  for(i=0;i<nlatentk;i++)
  {
    for(int k=0;k<MaxK_Prior[i]->nHyperparams;k++)
    {
      MaxK_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = MaxK_PriorParameters[k*nlatentk+i];
      MaxK_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = MaxK_PriorParameters[k*nlatentk+i];
    }
  }

  for(i=0;i<nG;i++)
  {
    MaxK_MCMC.push_back(vector<Class_Parameter >());
    for(j=0;j<nlatentk;j++)
    {
      MaxK_MCMC[i].push_back(Class_Parameter());
      appName = (("MaxK_")+to_string(i)+to_string(j));
      MaxK_MCMC[i][j].create_FullObject(MaxK_InitParameters[i*nlatentk+j], appName,  MaxK_Prior[j]);
    }
  }
  for(i=0;i<nG;i++)
  {

    for(j=0;j<nlatentk;j++)
    {
      MaxK_MCMC[i][j].add_Pointerparameters_InVector();
    }
  }


  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/

  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/

  Name                 = "MinK";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

  double *MinK_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string MinK_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *MinK_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  vector<Poly_Prior* >                  MinK_Prior; // uno per i k
  vector< vector <Class_Parameter > >   MinK_MCMC; // k/nvar/cluster
  if(MinK_PriorName=="Uniform")
  {
    for(i=0;i<nlatentk;i++)
    {
      MinK_Prior.push_back(new Class_Uniform);
      MinK_Prior[i]->create_FullObject(UserControlledMemory);
    }

  }else{
    if(MinK_PriorName=="InverseGamma")
    {
      for(i=0;i<nlatentk;i++)
      {
        MinK_Prior.push_back(new Class_InverseGamma);
        MinK_Prior[i]->create_FullObject(UserControlledMemory);
      }
    }else{
      error("Prior on MinK not well specified");
    }
  }

  for(i=0;i<nlatentk;i++)
  {
    for(int k=0;k<MinK_Prior[i]->nHyperparams;k++)
    {
      MinK_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = MinK_PriorParameters[k*nlatentk+i];
      MinK_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = MinK_PriorParameters[k*nlatentk+i];
    }
  }

  for(i=0;i<nG;i++)
  {
    MinK_MCMC.push_back(vector<Class_Parameter >());
    for(j=0;j<nlatentk;j++)
    {
      MinK_MCMC[i].push_back(Class_Parameter());
      appName = (("MinK_")+to_string(i)+to_string(j));
      MinK_MCMC[i][j].create_FullObject(MinK_InitParameters[i*nlatentk+j], appName,  MinK_Prior[j]);
    }
  }
  for(i=0;i<nG;i++)
  {

    for(j=0;j<nlatentk;j++)
    {
      MinK_MCMC[i][j].add_Pointerparameters_InVector();
    }
  }



  REprintf("AA0\n");
  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/

  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/
  REprintf("AA0B1\n");
  Name                 = "Y0";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);
  REprintf("AA0B2 %i %i\n",indexPriorParameters,indexInit);
  double *Y0_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string Y0_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *Y0_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));

  REprintf("AA01\n");
  vector<Poly_Prior* >                  Y0_Prior; // uno per i k
  vector<  vector< Class_Parameter> >    Y0_MCMC; // k/nvar/cluster
  if(Y0_PriorName=="Uniform")
  {
    for(i=0;i<nvar;i++)
    {
      Y0_Prior.push_back(new Class_Uniform);
      Y0_Prior[i]->create_FullObject(UserControlledMemory);
    }

  }else{
    if(Y0_PriorName=="InverseGamma")
    {
      for(i=0;i<nvar;i++)
      {
        Y0_Prior.push_back(new Class_InverseGamma);
        Y0_Prior[i]->create_FullObject(UserControlledMemory);
      }
    }else{
      if(Y0_PriorName=="NoPrior")
      {
        for(i=0;i<nvar;i++)
        {
          Y0_Prior.push_back(new Class_NoPrior);
          Y0_Prior[i]->create_FullObject(UserControlledMemory);
        }
      }else{
        error("Prior on Y0 not well specified");
      }


    }
  }
//  i = nvar-1;
//  Y0_Prior.push_back(new Class_NoPrior);
//  Y0_Prior[i]->create_FullObject(UserControlledMemory);
//

  REprintf("AA02\n");
  for(i=0;i<nvar;i++)
  {
    for(int k=0;k<Y0_Prior[i]->nHyperparams;k++)
    {
      Y0_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = Y0_PriorParameters[k*nvar+i];
      Y0_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = Y0_PriorParameters[k*nvar+i];
    }
  }
  REprintf("TEST1\n");
  for(i=0;i<nG;i++)
  {
    Y0_MCMC.push_back(vector<Class_Parameter> ());
    for(j=0;j<nvar;j++)
    {
      Y0_MCMC[i].push_back(Class_Parameter());
      appName = (("Y0_")+to_string(i)+to_string(j));
      Y0_MCMC[i][j].create_FullObject(Y0_InitParameters[i*nvar+j], appName,  Y0_Prior[j]);
    }
  }
   for(i=0;i<nG;i++)
   {
     for(j=0;j<nvar;j++)
     {
       Y0_MCMC[i][j].add_Pointerparameters_InVector();
       //Y0_MCMC[i][h][j].PrintObject("Y");
     }
   }
  //error("AA\n");

  /*****************************************
   Latent ODE
   *****************************************/
#pragma mark Latent ODE
  REprintf("A0 \n");

  Name                 = "TypekFunc";
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);
  double *TypekFunc_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));

//  int TypekFunc_P[nG*nlatentk];
//  Matrix<int> TypeKFunc (nG,nlatentk,&TypekFunc_P[0]);
//  for(i=0;i<nG;i++)
//  {
//    for(j=0;j<nlatentk;j++)
//    {
//      TypeKFunc.Pmat(i,j)[0] = TypekFunc_InitParameters[i*nlatentk+j];
//    }
//  }


  // function k
  vector< vector < Function_K > > vecFK;
  for(int g=0;g<nG;g++)
  {
    vecFK.push_back(vector < Function_K >());
    for(i=0;i<nlatentk;i++)
    {
      vecFK[g].push_back(Function_K(&MinK_MCMC[g][i], &MaxK_MCMC[g][i], &lambda_MCMC[g][i], &x0_MCMC[g][i],TypekFunc_InitParameters[g*nlatentk+i]-1));
    }
  }





  vector < vector<ODE_FURLAN> > LatentODE;
  for(int g=0;g<nG;g++)
  {
    LatentODE.push_back(vector<ODE_FURLAN>());
    int j = 0;
    LatentODE[g].push_back(ODE_FURLAN(nt,nvar,&vecFK[g], tmin, tmax, deltat, nstep, &Y0_MCMC[g]));
    for(j=1;j<nrep;j++)
    {
      LatentODE[g].push_back(ODE_FURLAN(nt,nvar,&vecFK[g], tmin, tmax, deltat, nstep, &Y0_MCMC[g], &LatentODE[g][0]));
    }
  }

  for(int g=0;g<nG;g++)
  {
    for(int j=0;j<nrep;j++)
    {
      LatentODE[g][j].ODE_compute();
    }
  }

//  for(int g=0;g<nG;g++)
//  {
//    for(int j=0;j<nrep;j++)
//    {
//      REprintf("%i %i\n",g,j);
//      LatentODE[g][j].ODEMAT.Print("Mat");
//    }
//  }
//  error("");
//
  /*****************************************
   Observations
   *****************************************/
#pragma mark Observations
  REprintf("A1 \n");

  Matrix<double> ObsMatTot(nobsTOT,nvar,REAL(Data_r));
  vector <vector < Matrix <double> > > Obs;
  for(i=0;i<nG;i++)
  {
    Obs.push_back(vector < Matrix <double> >());
    for(j=0;j<nrep;j++)
    {
      int Ind = i*nrep*nt+j*nt;
      Obs[i].push_back(Matrix <double>(nt,nvar,ObsMatTot.Pmat(Ind,0)));

      //Obs[i][j].Print("D");
    }
  }

  Vector <int> IndexNotNA(nNotna,INTEGER(IndexNotNA_r));

  /*****************************************
   ADAPT par
   *****************************************/
 #pragma mark AdaptPar

  /*****************************************
   Adapt Param Like
   *****************************************/
  string NameAdapt;

  REprintf("A2 \n");
  int indexSd;

  Name                      = "MinK";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdMinK           = REAL(VECTOR_ELT(Sd_r, indexSd));

  Name                      = "MaxK";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdMaxK          = REAL(VECTOR_ELT(Sd_r, indexSd));

  Name                      = "x0";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *Sdx0           = REAL(VECTOR_ELT(Sd_r, indexSd));

  Name                      = "lambda";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *Sdlambda          = REAL(VECTOR_ELT(Sd_r, indexSd));

  Name                      = "Y0";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdY0            = REAL(VECTOR_ELT(Sd_r, indexSd));

  int addsd;
  int isd;
  double SDvec[50];
  vector< Poly_Adapt* >        AdaptLikeAllParam;
  for(i=0;i<nG;i++)
  {
    isd = 0;
    AdaptLikeAllParam.push_back(new Class_AdaptHaario());
    appName = ("AllPAram")+to_string(i);
    AdaptLikeAllParam[i]->add_name(appName);


    for(j=0;j<nlatentk;j++)
    {
      addsd = AdaptLikeAllParam[i]->add_parameters(&MinK_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdMinK[0];
        isd++;
      }
      addsd = AdaptLikeAllParam[i]->add_parameters(&MaxK_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdMaxK[0];
        isd++;
      }
      addsd = AdaptLikeAllParam[i]->add_parameters(&x0_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = Sdx0[0];
        isd++;
      }
      addsd = AdaptLikeAllParam[i]->add_parameters(&lambda_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = Sdlambda[0];
        isd++;
      }
    }
    for(int h=0;h<nvar;h++)
    {
      addsd = AdaptLikeAllParam[i]->add_parameters(&Y0_MCMC[i][h]);
      if(addsd==1)
      {
        SDvec[isd] = SdY0[0];
        isd++;
      }
    }
    AdaptLikeAllParam[i]->add_finalizedConstruct(AdaptEps, SDvec, 1.0, 1, &AdaptParameters);
    AdaptLikeAllParam[i]->CheckMultiUpdate();
  }


  /*****************************************
   FROM C++ to R
   *****************************************/
#pragma mark FROM C++ to R
  REprintf("A4 \n");

  int nProtect = 0;


  SEXP sigma2_out_r;
  PROTECT(sigma2_out_r    = allocMatrix(REALSXP, nvar, nSamples_save)); nProtect++;
  double *sigma2_out_P    = REAL(sigma2_out_r);

  SEXP MinV_out_r;
  PROTECT(MinV_out_r    = allocMatrix(REALSXP, nG*nlatentk, nSamples_save)); nProtect++;
  double *MinV_out_P    = REAL(MinV_out_r);
  SEXP MaxV_out_r;
  PROTECT(MaxV_out_r    = allocMatrix(REALSXP, nG*nlatentk, nSamples_save)); nProtect++;
  double *MaxV_out_P    = REAL(MaxV_out_r);
  SEXP x0_out_r;
  PROTECT(x0_out_r    = allocMatrix(REALSXP, nG*nlatentk, nSamples_save)); nProtect++;
  double *x0_out_P    = REAL(x0_out_r);
  SEXP lambda_out_r;
  PROTECT(lambda_out_r    = allocMatrix(REALSXP, nG*nlatentk, nSamples_save)); nProtect++;
  double *lambda_out_P    = REAL(lambda_out_r);


  int nY = 0;
  if(saveODE==1)
  {
    nY  = nG*nNotna*nvar;
  }else{
    nY = nG*nvar;
  }
  SEXP Y_out_r;
  PROTECT(Y_out_r    = allocMatrix(REALSXP, nY, nSamples_save)); nProtect++;
  double *Y_out_P    = REAL(Y_out_r);


  SEXP TypeKFunc_out_r;
  PROTECT(TypeKFunc_out_r    = allocMatrix(INTSXP, nG*nlatentk, nSamples_save)); nProtect++;
  int *TypeKFunc_out_P    = INTEGER(TypeKFunc_out_r);




  /*****************************************
   MCMC
   *****************************************/
  REprintf("R4wwA");
  int iterations = 0;
  int iMCMC_app = MCMCburnin;
  for(int iMCMC1=0;iMCMC1<nSamples_save;iMCMC1++)
  {

    for(int iMCMC2=0;iMCMC2<iMCMC_app;iMCMC2++)
    {
      R_CheckUserInterrupt();

      iterations ++;
      AdaptParameters.Update(iterations);

      if((iterations%IterShow)==0)
      {
        Rprintf("Iterations %i \n", iterations);
      }
//      if(iterations>250)
//      {
//        error("");
//      }
      /************* sigma2 *********************/

      for(i=0;i<nvar;i++)
      {
        double a = sigma2_MCMC[i].PriorParameter->HyperparametersAcc.vec(0)[0]+0.5*nNotna*nrep*nG;
        double b = sigma2_MCMC[i].PriorParameter->HyperparametersAcc.vec(1)[0];

        for(int g=0;g<nG;g++)
        {
          for(j=0;j<nrep;j++)
          {
            for(int t1=0;t1<nNotna;t1++)
            {
              int t = IndexNotNA.vec(t1);
              b += 0.5*pow(Obs[g][j].mat(t,i)-LatentODE[g][j].ODEMAT.mat(t,i), 2.0);
            }
          }
        }
        sigma2_MCMC[i].ParameterAcc = 1.0/rgamma(a, 1.0/b);
        //REprintf("%f %f %f \n", a, b,sigma2_MCMC[i].ParameterAcc);
      }


      /************* ODE parameters *********************/

      for(int g=0;g<nG;g++)
      {
        AdaptLikeAllParam[g]->Samp();
        //AdaptLikeAllParam[g]->PrintObject("");
        double MH = AdaptLikeAllParam[g]->get_logDensityParameterWithLogJacobian_DiffPropAcc();
        //for(j=0;j<nrep;j++)
        //{
          j = 0;
          LatentODE[g][j].ODE_compute_Prop();
        //}
        for(j=0;j<nrep;j++)
        {
          for(int t1=0;t1<nNotna;t1++)
          {
            int t = IndexNotNA.vec(t1);

            for(i=0;i<nvar;i++)
            {
              MH += -0.5*pow(Obs[g][j].mat(t,i)-LatentODE[g][j].ODEMATProp.mat(t,i), 2.0)/sigma2_MCMC[i].ParameterAcc;
              MH -= -0.5*pow(Obs[g][j].mat(t,i)-LatentODE[g][j].ODEMAT.mat(t,i), 2.0)/sigma2_MCMC[i].ParameterAcc;

              //REprintf("%i %i %f %f %f %f\n",t1,t, Obs[g][j].mat(t,i),LatentODE[g][j].ODEMATProp.mat(t,i),Obs[g][j].mat(t,i),LatentODE[g][j].ODEMAT.mat(t,i));
            }
          }
        }

        //REprintf("MH= %f \n", MH);
        double alphaRatio = min(1.0,exp(MH));
        if(runif(0.0,1.0)<alphaRatio)
        {
          AdaptLikeAllParam[g]->UpdateIfAccepted();
          //for(j=0;j<nrep;j++)
          //{
          j = 0;
          LatentODE[g][j].copyFromODEMATPropToAcc();
          //}
        }else{
          AdaptLikeAllParam[g]->UpdateIfNotAccepted();
        }
        AdaptLikeAllParam[g]->PostSamp(alphaRatio);


      }


      /************* SelPar *********************/

      for(int g=0;g<nG;g++)
      {
        double MH = 0.0;

        for(int k=0;k<nlatentk;k++)
        {
          LatentODE[g][0].FuncsParams[0][k].SelFuncProp = LatentODE[g][0].FuncsParams[0][k].SelFunc;
        }

        double u;
        u = runif(0.0,1.0*nlatentk);
        int k = (int)floor(u);
        u = runif(0.0,1.0*nshapek);

        LatentODE[g][0].FuncsParams[0][k].SelFuncProp = (int)floor(u);

        j = 0;
        LatentODE[g][j].ODE_compute_SelFuncProp();
        for(j=0;j<nrep;j++)
        {
          for(int t1=0;t1<nNotna;t1++)
          {
            int t = IndexNotNA.vec(t1);
            for(i=0;i<nvar;i++)
            {
              MH += -0.5*pow(Obs[g][j].mat(t,i)-LatentODE[g][j].ODEMATProp.mat(t,i), 2.0)/sigma2_MCMC[i].ParameterAcc;
              MH -= -0.5*pow(Obs[g][j].mat(t,i)-LatentODE[g][j].ODEMAT.mat(t,i), 2.0)/sigma2_MCMC[i].ParameterAcc;
            }
          }

        }

        if(runif(0.0,1.0)<exp(MH))
        {
          for(int k=0;k<nlatentk;k++)
          {
            LatentODE[g][0].FuncsParams[0][k].SelFunc = LatentODE[g][0].FuncsParams[0][k].SelFuncProp;
          }
          j = 0;
          LatentODE[g][j].copyFromODEMATPropToAcc();
//          for(j=0;j<nrep;j++)
//          {
//            LatentODE[g][j].copyFromODEMATPropToAcc();
//          }
        }

      }

      /************* *********************/
    }

    iMCMC_app = MCMCthin;

    /*****************************************
     From C++ To R (2)
     *****************************************/


    for(int g=0;g<nG;g++)
    {
      for(int k=0;k<nlatentk;k++)
      {
        TypeKFunc_out_P[iMCMC1*nlatentk*nG+g*nlatentk+k] = LatentODE[g][0].FuncsParams[0][k].SelFunc;
      }
    }




    for(int jj=0;jj<nvar;jj++)
    {
      sigma2_out_P[iMCMC1*nvar+jj] = sigma2_MCMC[jj].ParameterAcc;
    }

    for(int ii=0;ii<nG;ii++)
    {
      for(int jj=0;jj<nlatentk;jj++)
      {
        MinV_out_P[iMCMC1*nG*nlatentk+nlatentk*ii+jj]   = MinK_MCMC[ii][jj].ParameterAcc;
        MaxV_out_P[iMCMC1*nG*nlatentk+nlatentk*ii+jj]   = MaxK_MCMC[ii][jj].ParameterAcc;
        x0_out_P[iMCMC1*nG*nlatentk+nlatentk*ii+jj]     = x0_MCMC[ii][jj].ParameterAcc;
        lambda_out_P[iMCMC1*nG*nlatentk+nlatentk*ii+jj] = lambda_MCMC[ii][jj].ParameterAcc;
      }
    }

    int nrepApp = 1;
    if(saveODE==1)
    {
      for(int ii=0;ii<nG;ii++)
      {
        for(int jj=0;jj<nrepApp;jj++)
        {
          for(int t1=0;t1<nNotna;t1++)
          {
            int ir = IndexNotNA.vec(t1);
            for(int ic=0;ic<nvar;ic++)
            {
              Y_out_P[iMCMC1*nG*nrepApp*nNotna*nvar+ii*nrepApp*nNotna*nvar+jj*nNotna*nvar+t1*nvar+ic] =  LatentODE[ii][jj].ODEMAT.mat(ir,ic);
            }
          }
        }
      }
    }else{
      for(int ii=0;ii<nG;ii++)
      {
        for(int jj=0;jj<nrepApp;jj++)
        {
          for(int ir=0;ir<1;ir++)
          {
            for(int ic=0;ic<nvar;ic++)
            {
              Y_out_P[iMCMC1*nG*nrepApp*nvar+ii*nrepApp*nvar+jj*nvar+ic] = LatentODE[ii][jj].ODEMAT.mat(ir,ic);
            }
          }
        }
      }
    }


    /*****************************************
     Here, the second MCMC parentheses end
     *****************************************/
  }
  /*****************************************
   From C++ to R
   *****************************************/

  SEXP result,resultNames;
  int nResultListObjs = nProtect;

  PROTECT(result = allocVector(VECSXP, nResultListObjs)); nProtect++;
  PROTECT(resultNames = allocVector(VECSXP, nResultListObjs)); nProtect++;

  i=0;
  SET_VECTOR_ELT(result, i, sigma2_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("sigma2"));i++;
  SET_VECTOR_ELT(result, i, MinV_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("MinV"));i++;
  SET_VECTOR_ELT(result, i, MaxV_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("MaxV"));i++;
  SET_VECTOR_ELT(result, i, x0_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("x0"));i++;
  SET_VECTOR_ELT(result, i, lambda_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("lambda"));i++;
  SET_VECTOR_ELT(result, i, Y_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("Yinit"));i++;
  SET_VECTOR_ELT(result, i, TypeKFunc_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("TypeKFunc"));i++;

  namesgets(result, resultNames);

  UNPROTECT(nProtect);
  PutRNGstate();


  return(result);

  //PutRNGstate();
  //return(R_NilValue);


}
}
