#ifndef C_Gaussian_H
#define C_Gaussian_H
#include <vector>
#include <list>
#include "MatricesAndVectors.h"
//#include "DensityPriorParam.h"
#include "CovFunctionsV3.h"
//#include "C_MhAdaptV2.h"
//using std::cout; using std::endl;
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>
#include <R_ext/Utils.h>




/***********/
     
 
// COMMENT
// Non Penso servano CoregMatrixNNGP e CoregMatrix, forse basta anche  CovMatrix_ToPass

class CovariaceStructNNGP_CoregBased: public virtual CovMatrix_ToPass
{
private:
    /*** STUFFS ***/
    
    
public:
    
    
    int SpaceOrTime;
    int Nneigh;
    
    vector<Matrix <double> > *TjAcc;
    vector<Matrix <double> > *TjProp;
    
    
    Matrix<double> Dist;
    Matrix<double> Dist2;
    
    
    Class_Parameter_PDMatrixUnivSamp *ParSigmaCoreg;
    
    vector<Poly_CovCorFunction*>*   CovFunctions;
    
    
    // COSTRUCTORS
    CovariaceStructNNGP_CoregBased(){}
    
    //DESTRUCTORS
    ~CovariaceStructNNGP_CoregBased(){};
    void Destory(){
        
        for(int k=0;k<DimCoreg;k++)
        {
            TjAcc[0][k].Destroy();
            TjProp[0][k].Destroy();
            CovFunctions[0][k][0].Destroy();
        }
        
        
        
        Dist.Destroy();
        Dist2.Destroy();
        
        
        //ParSigmaCoreg->Destroy();
        
        
        
    }
  
    
    
    void create_object(int nneigh, Class_Parameter_PDMatrixUnivSamp *parsigma,vector<Poly_CovCorFunction*>*   covfunctions, int usr, Matrix<double> *coords)
    {
        SpaceOrTime             = 1;
        UserControlledMemory = usr;
        nObs        = 1;
        DimCoreg    = parsigma->Dim;
        nTot        = nObs*(DimCoreg);
        //nTot        = nObs*(DimCoreg-1);
        
        Nneigh      = nneigh;
        
        ParSigmaCoreg   = parsigma;
        CovFunctions    = covfunctions;
        
        
        
        
        //REprintf("A1\n");
        SigmaAcc        = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaCholAcc    = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaInvAcc     = Matrix<double>(nTot,nTot,UserControlledMemory);
        
        
        SigmaAcc.Init(0.0);
        SigmaCholAcc.Init(0.0);
        SigmaInvAcc.Init(0.0);
        
        
        
        //REprintf("A2\n");
        SigmaProp               = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaCholProp           = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaInvProp            = Matrix<double>(nTot,nTot,UserControlledMemory);
        
        TjAcc                   = new vector<Matrix <double> >;
        TjProp                   = new vector<Matrix <double> >;
        
        SigmaProp.Init(0.0);
        SigmaCholProp.Init(0.0);
        SigmaInvProp.Init(0.0);
        for(int i=0;i<DimCoreg;i++)
        {
            
            TjAcc->push_back(Matrix<double>(DimCoreg,DimCoreg,UserControlledMemory));
            TjAcc[0][i].Init(0.0);
        }
        for(int i=0;i<DimCoreg;i++)
        {
            TjProp->push_back(Matrix<double>(DimCoreg,DimCoreg,UserControlledMemory));
            TjProp[0][i].Init(0.0);
        }
        
        update_TjAcc();
        update_TjProp();
        
        if(coords->nCols>2)
        {
            SpaceOrTime             = 0;
            Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
            Dist2        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
            Class_Utils::compute_dist(Nneigh+1,coords, &Dist, &Dist2);
            
        }else{
            Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
            Class_Utils::compute_dist(Nneigh+1,coords, &Dist);
        }
        
        //Dist.Print("DIST");
        
    }
    
    void create_object(int nneigh, Class_Parameter_PDMatrixUnivSamp *parsigma,vector<Poly_CovCorFunction*>*   covfunctions, int usr, Matrix<double> *coords, vector<Matrix <double> > *tjAcc, vector<Matrix <double> > *tjProp)
    {
        SpaceOrTime             = 1;
        UserControlledMemory = usr;
        nObs        = 1;
        DimCoreg    = parsigma->Dim;
        nTot        = nObs*(DimCoreg);
        //nTot        = nObs*(DimCoreg-1);
        
        Nneigh      = nneigh;
        
        ParSigmaCoreg   = parsigma;
        CovFunctions    = covfunctions;
        
        
        
        
        
        SigmaAcc        = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaCholAcc    = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaInvAcc     = Matrix<double>(nTot,nTot,UserControlledMemory);
        
        
        SigmaAcc.Init(0.0);
        SigmaCholAcc.Init(0.0);
        SigmaInvAcc.Init(0.0);
        
        
        
        
        SigmaProp               = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaCholProp           = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaInvProp            = Matrix<double>(nTot,nTot,UserControlledMemory);
        
        SigmaProp.Init(0.0);
        SigmaCholProp.Init(0.0);
        SigmaInvProp.Init(0.0);
        
        TjProp  = tjProp;
        TjAcc   = tjAcc;
        
        //update_TjAcc();
        //update_TjProp();
        
        if(coords->nCols>2)
        {
            SpaceOrTime             = 0;
            Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
            Dist2        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
            Class_Utils::compute_dist(Nneigh+1,coords, &Dist, &Dist2);
            
        }else{
            Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
            Class_Utils::compute_dist(Nneigh+1,coords, &Dist);
        }
        
        //Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
        //Class_Utils::compute_dist(Nneigh+1,coords, &Dist);
        //Dist.Print("DIST");
    }

    void create_object_DimMinusOne(int nneigh, Class_Parameter_PDMatrixUnivSamp *parsigma,vector<Poly_CovCorFunction*>*   covfunctions, int usr, Matrix<double> *coords)
    {
        SpaceOrTime             = 1;
        UserControlledMemory = usr;
        nObs        = 1;
        DimCoreg    = parsigma->Dim;
        //nTot        = nObs*(DimCoreg);
        nTot        = nObs*(DimCoreg-1);
        
        Nneigh      = nneigh;
        
        ParSigmaCoreg   = parsigma;
        CovFunctions    = covfunctions;
        
        
        
        
        REprintf("A1\n");
        SigmaAcc        = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaCholAcc    = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaInvAcc     = Matrix<double>(nTot,nTot,UserControlledMemory);
        
        
        SigmaAcc.Init(0.0);
        SigmaCholAcc.Init(0.0);
        SigmaInvAcc.Init(0.0);
        
        
        
        REprintf("A2\n");
        SigmaProp               = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaCholProp           = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaInvProp            = Matrix<double>(nTot,nTot,UserControlledMemory);
        
        TjAcc                   = new vector<Matrix <double> >;
        TjProp                   = new vector<Matrix <double> >;
        
        SigmaProp.Init(0.0);
        SigmaCholProp.Init(0.0);
        SigmaInvProp.Init(0.0);
        for(int i=0;i<DimCoreg;i++)
        {
            
            TjAcc->push_back(Matrix<double>(DimCoreg,DimCoreg,UserControlledMemory));
            TjAcc[0][i].Init(0.0);
        }
        for(int i=0;i<DimCoreg;i++)
        {
            TjProp->push_back(Matrix<double>(DimCoreg,DimCoreg,UserControlledMemory));
            TjProp[0][i].Init(0.0);
        }
        
        update_TjAcc();
        update_TjProp();
        
        if(coords->nCols>2)
        {
            SpaceOrTime             = 0;
            Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
            Dist2        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
            Class_Utils::compute_dist(Nneigh+1,coords, &Dist, &Dist2);
            
        }else{
            Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
            Class_Utils::compute_dist(Nneigh+1,coords, &Dist);
        }
        
        //Dist.Print("DIST");
        
    }
    
    void create_object_DimMinusOne(int nneigh, Class_Parameter_PDMatrixUnivSamp *parsigma,vector<Poly_CovCorFunction*>*   covfunctions, int usr, Matrix<double> *coords, vector<Matrix <double> > *tjAcc, vector<Matrix <double> > *tjProp)
    {
        SpaceOrTime             = 1;
        UserControlledMemory = usr;
        nObs        = 1;
        DimCoreg    = parsigma->Dim;
        //nTot        = nObs*(DimCoreg);
        nTot        = nObs*(DimCoreg-1);
        
        Nneigh      = nneigh;
        
        ParSigmaCoreg   = parsigma;
        CovFunctions    = covfunctions;
        
        
        
        
        
        SigmaAcc        = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaCholAcc    = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaInvAcc     = Matrix<double>(nTot,nTot,UserControlledMemory);
        
        
        SigmaAcc.Init(0.0);
        SigmaCholAcc.Init(0.0);
        SigmaInvAcc.Init(0.0);
        
        
        
        
        SigmaProp               = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaCholProp           = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaInvProp            = Matrix<double>(nTot,nTot,UserControlledMemory);
        
        SigmaProp.Init(0.0);
        SigmaCholProp.Init(0.0);
        SigmaInvProp.Init(0.0);
        
        TjProp  = tjProp;
        TjAcc   = tjAcc;
        
        //update_TjAcc();
        //update_TjProp();
        
        if(coords->nCols>2)
        {
            SpaceOrTime             = 0;
            Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
            Dist2        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
            Class_Utils::compute_dist(Nneigh+1,coords, &Dist, &Dist2);
            
        }else{
            Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
            Class_Utils::compute_dist(Nneigh+1,coords, &Dist);
        }
        
        //Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
        //Class_Utils::compute_dist(Nneigh+1,coords, &Dist);
        //Dist.Print("DIST");
    }

    
    
    
    
    
    /***** FUNCTIONS *****/
    
    
    
    /***** UPDATES ****/
    virtual void update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj)=0;
    void update_TjAcc()
    {
        update_Tj_BASE(&ParSigmaCoreg->SigmaAcc, TjAcc);
    }
    void update_TjProp()
    {
        update_Tj_BASE(&ParSigmaCoreg->SigmaProp, TjProp);
    }
    
//    virtual void update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj,vector <int> *Order)=0;
//    void update_TjAcc(vector <int> *Order)
//    {
//        update_Tj_BASE(&ParSigmaCoreg->SigmaAcc, TjAcc,Order);
//    }
//    void update_TjProp(vector <int> *Order)
//    {
//        update_Tj_BASE(&ParSigmaCoreg->SigmaProp, TjProp,Order);
//    }
//    
    
      //  void update_SigmaAcc();
    void update_SigmaCholAcc();
    void update_logdeterminantAcc();
    void update_SigmaInvAcc();
    
    void update_SigmaCholProp();
    void update_logdeterminantProp();
    void update_SigmaInvProp();
    
    void UpdateIfAcceptedNoSigmaCoregNoTj()
    {
        //ParSigmaCoreg->UpdateIfAccepted();
        double *app;
        
        app                 = SigmaCholAcc.P;
        SigmaCholAcc.P      = SigmaCholProp.P;
        SigmaCholProp.P    = app;
        
        app                 = SigmaAcc.P;
        SigmaAcc.P         = SigmaProp.P;
        SigmaProp.P        = app;
        
        app                 = SigmaInvAcc.P;
        SigmaInvAcc.P       = SigmaInvProp.P;
        SigmaInvProp.P      = app;
        
        double app2 = logdeterminantProp;
        logdeterminantProp = logdeterminantAcc;
        logdeterminantAcc = app2;
        
        
    }
    
};





class CovariaceStruct_CoregBased: public  virtual CovMatrix_ToPass{ // in realtà questa è la struttura di covarianza
private:
    /*** STUFFS ***/
    
    
public:
    
    
    int SpaceOrTime;
    
    
    vector<Matrix <double> > *TjAcc;
    vector<Matrix <double> > *TjProp;
    
    
    Matrix<double> Dist;
    Matrix<double> Dist2;
    
    
    Class_Parameter_PDMatrixUnivSamp *ParSigmaCoreg;
    
    vector<Poly_CovCorFunction*>*   CovFunctions;
    
    
    // COSTRUCTORS
    CovariaceStruct_CoregBased(){}
    
    //DESTRUCTORS
    ~CovariaceStruct_CoregBased(){};
    void Destory(){
        
        for(int k=0;k<DimCoreg;k++)
        {
            TjAcc[0][k].Destroy();
            TjProp[0][k].Destroy();
            CovFunctions[0][k][0].Destroy();
        }
        
        
        
        Dist.Destroy();
        Dist2.Destroy();
   
    }
    
    void create_object( Class_Parameter_PDMatrixUnivSamp *parsigma,vector<Poly_CovCorFunction*>*   covfunctions, int usr, Matrix<double> *coords)
    {
        //REprintf("\n\n\n\n USARE CovariaceStruct_CoregBased \n \n \n");
        SpaceOrTime             = 1;
        UserControlledMemory = usr;
        nObs        = coords->nRows;
        DimCoreg    = parsigma->Dim;
        nTot        = nObs*(DimCoreg);
        //nTot        = nObs*(DimCoreg-1);
        
        
        
        ParSigmaCoreg   = parsigma;
        CovFunctions    = covfunctions;
        
        
        
        
        //REprintf("A1\n");
        SigmaAcc        = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaCholAcc    = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaInvAcc     = Matrix<double>(nTot,nTot,UserControlledMemory);
        
        
        SigmaAcc.Init(0.0);
        SigmaCholAcc.Init(0.0);
        SigmaInvAcc.Init(0.0);
        
        
        
        //REprintf("A2\n");
        SigmaProp               = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaCholProp           = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaInvProp            = Matrix<double>(nTot,nTot,UserControlledMemory);
        
        TjAcc                   = new vector<Matrix <double> >;
        TjProp                   = new vector<Matrix <double> >;
        
        SigmaProp.Init(0.0);
        SigmaCholProp.Init(0.0);
        SigmaInvProp.Init(0.0);
        for(int i=0;i<DimCoreg;i++)
        {
            
            TjAcc->push_back(Matrix<double>(DimCoreg,DimCoreg,UserControlledMemory));
            TjAcc[0][i].Init(0.0);
        }
        for(int i=0;i<DimCoreg;i++)
        {
            TjProp->push_back(Matrix<double>(DimCoreg,DimCoreg,UserControlledMemory));
            TjProp[0][i].Init(0.0);
        }
        
        update_TjAcc();
        update_TjProp();
        //coords->Print("Coords");
        if(coords->nCols>2)
        {
            SpaceOrTime             = 0;
            Dist        = Matrix<double>(coords->nRows,coords->nRows,UserControlledMemory);
            Dist2        = Matrix<double>(coords->nRows,coords->nRows,UserControlledMemory);
            Class_Utils::compute_dist(coords, &Dist, &Dist2);
            //Class_Utils::(coords, Matrix<double> *dist)
            
        }else{
            Dist        = Matrix<double>(coords->nRows,coords->nRows,UserControlledMemory);
            Class_Utils::compute_dist(coords, &Dist);
        }
        
        //Dist.Print("DIST");
        
    }
    
//    void create_object(int nneigh, Class_Parameter_PDMatrixUnivSamp *parsigma,vector<Poly_CovCorFunction*>*   covfunctions, int usr, Matrix<double> *coords, vector<Matrix <double> > *tjAcc, vector<Matrix <double> > *tjProp)
//    {
//        SpaceOrTime             = 1;
//        UserControlledMemory = usr;
//        nObs        = 1;
//        DimCoreg    = parsigma->Dim;
//        nTot        = nObs*(DimCoreg);
//        //nTot        = nObs*(DimCoreg-1);
//
//        Nneigh      = nneigh;
//
//        ParSigmaCoreg   = parsigma;
//        CovFunctions    = covfunctions;
//
//
//
//
//
//        SigmaAcc        = Matrix<double>(nTot,nTot,UserControlledMemory);
//        SigmaCholAcc    = Matrix<double>(nTot,nTot,UserControlledMemory);
//        SigmaInvAcc     = Matrix<double>(nTot,nTot,UserControlledMemory);
//
//
//        SigmaAcc.Init(0.0);
//        SigmaCholAcc.Init(0.0);
//        SigmaInvAcc.Init(0.0);
//
//
//
//
//        SigmaProp               = Matrix<double>(nTot,nTot,UserControlledMemory);
//        SigmaCholProp           = Matrix<double>(nTot,nTot,UserControlledMemory);
//        SigmaInvProp            = Matrix<double>(nTot,nTot,UserControlledMemory);
//
//        SigmaProp.Init(0.0);
//        SigmaCholProp.Init(0.0);
//        SigmaInvProp.Init(0.0);
//
//        TjProp  = tjProp;
//        TjAcc   = tjAcc;
//
//        //update_TjAcc();
//        //update_TjProp();
//
//        if(coords->nCols>2)
//        {
//            SpaceOrTime             = 0;
//            Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
//            Dist2        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
//            Class_Utils::compute_dist(Nneigh+1,coords, &Dist, &Dist2);
//
//        }else{
//            Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
//            Class_Utils::compute_dist(Nneigh+1,coords, &Dist);
//        }
//
//        //Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
//        //Class_Utils::compute_dist(Nneigh+1,coords, &Dist);
//        //Dist.Print("DIST");
//    }
//
//    void create_object_DimMinusOne(int nneigh, Class_Parameter_PDMatrixUnivSamp *parsigma,vector<Poly_CovCorFunction*>*   covfunctions, int usr, Matrix<double> *coords)
//    {
//        SpaceOrTime             = 1;
//        UserControlledMemory = usr;
//        nObs        = 1;
//        DimCoreg    = parsigma->Dim;
//        //nTot        = nObs*(DimCoreg);
//        nTot        = nObs*(DimCoreg-1);
//
//        Nneigh      = nneigh;
//
//        ParSigmaCoreg   = parsigma;
//        CovFunctions    = covfunctions;
//
//
//
//
//        REprintf("A1\n");
//        SigmaAcc        = Matrix<double>(nTot,nTot,UserControlledMemory);
//        SigmaCholAcc    = Matrix<double>(nTot,nTot,UserControlledMemory);
//        SigmaInvAcc     = Matrix<double>(nTot,nTot,UserControlledMemory);
//
//
//        SigmaAcc.Init(0.0);
//        SigmaCholAcc.Init(0.0);
//        SigmaInvAcc.Init(0.0);
//
//
//
//        REprintf("A2\n");
//        SigmaProp               = Matrix<double>(nTot,nTot,UserControlledMemory);
//        SigmaCholProp           = Matrix<double>(nTot,nTot,UserControlledMemory);
//        SigmaInvProp            = Matrix<double>(nTot,nTot,UserControlledMemory);
//
//        TjAcc                   = new vector<Matrix <double> >;
//        TjProp                   = new vector<Matrix <double> >;
//
//        SigmaProp.Init(0.0);
//        SigmaCholProp.Init(0.0);
//        SigmaInvProp.Init(0.0);
//        for(int i=0;i<DimCoreg;i++)
//        {
//
//            TjAcc->push_back(Matrix<double>(DimCoreg,DimCoreg,UserControlledMemory));
//            TjAcc[0][i].Init(0.0);
//        }
//        for(int i=0;i<DimCoreg;i++)
//        {
//            TjProp->push_back(Matrix<double>(DimCoreg,DimCoreg,UserControlledMemory));
//            TjProp[0][i].Init(0.0);
//        }
//
//        update_TjAcc();
//        update_TjProp();
//
//        if(coords->nCols>2)
//        {
//            SpaceOrTime             = 0;
//            Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
//            Dist2        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
//            Class_Utils::compute_dist(Nneigh+1,coords, &Dist, &Dist2);
//
//        }else{
//            Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
//            Class_Utils::compute_dist(Nneigh+1,coords, &Dist);
//        }
//
//        //Dist.Print("DIST");
//
//    }
//
//    void create_object_DimMinusOne(int nneigh, Class_Parameter_PDMatrixUnivSamp *parsigma,vector<Poly_CovCorFunction*>*   covfunctions, int usr, Matrix<double> *coords, vector<Matrix <double> > *tjAcc, vector<Matrix <double> > *tjProp)
//    {
//        SpaceOrTime             = 1;
//        UserControlledMemory = usr;
//        nObs        = 1;
//        DimCoreg    = parsigma->Dim;
//        //nTot        = nObs*(DimCoreg);
//        nTot        = nObs*(DimCoreg-1);
//
//        Nneigh      = nneigh;
//
//        ParSigmaCoreg   = parsigma;
//        CovFunctions    = covfunctions;
//
//
//
//
//
//        SigmaAcc        = Matrix<double>(nTot,nTot,UserControlledMemory);
//        SigmaCholAcc    = Matrix<double>(nTot,nTot,UserControlledMemory);
//        SigmaInvAcc     = Matrix<double>(nTot,nTot,UserControlledMemory);
//
//
//        SigmaAcc.Init(0.0);
//        SigmaCholAcc.Init(0.0);
//        SigmaInvAcc.Init(0.0);
//
//
//
//
//        SigmaProp               = Matrix<double>(nTot,nTot,UserControlledMemory);
//        SigmaCholProp           = Matrix<double>(nTot,nTot,UserControlledMemory);
//        SigmaInvProp            = Matrix<double>(nTot,nTot,UserControlledMemory);
//
//        SigmaProp.Init(0.0);
//        SigmaCholProp.Init(0.0);
//        SigmaInvProp.Init(0.0);
//
//        TjProp  = tjProp;
//        TjAcc   = tjAcc;
//
//        //update_TjAcc();
//        //update_TjProp();
//
//        if(coords->nCols>2)
//        {
//            SpaceOrTime             = 0;
//            Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
//            Dist2        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
//            Class_Utils::compute_dist(Nneigh+1,coords, &Dist, &Dist2);
//
//        }else{
//            Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
//            Class_Utils::compute_dist(Nneigh+1,coords, &Dist);
//        }
//
//        //Dist        = Matrix<double>(Nneigh+1,Nneigh+1,UserControlledMemory);
//        //Class_Utils::compute_dist(Nneigh+1,coords, &Dist);
//        //Dist.Print("DIST");
//    }

    
    
    
    
    
    /***** FUNCTIONS *****/
    
    
    
    /***** UPDATES ****/
    virtual void update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj)=0;
    void update_TjAcc()
    {
        update_Tj_BASE(&ParSigmaCoreg->SigmaAcc, TjAcc);
    }
    void update_TjProp()
    {
        update_Tj_BASE(&ParSigmaCoreg->SigmaProp, TjProp);
    }
    
    //    virtual void update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj,vector <int> *Order)=0;
    //    void update_TjAcc(vector <int> *Order)
    //    {
    //        update_Tj_BASE(&ParSigmaCoreg->SigmaAcc, TjAcc,Order);
    //    }
    //    void update_TjProp(vector <int> *Order)
    //    {
    //        update_Tj_BASE(&ParSigmaCoreg->SigmaProp, TjProp,Order);
    //    }
    //
    
        void update_SigmaAcc();
    void update_SigmaCholAcc();
    void update_logdeterminantAcc();
    void update_SigmaInvAcc();
    
    void update_SigmaCholProp();
    void update_logdeterminantProp();
    void update_SigmaInvProp();
    
    void UpdateIfAcceptedNoSigmaCoregNoTj()
    {
        //ParSigmaCoreg->UpdateIfAccepted();
        double *app;
        
        app                 = SigmaCholAcc.P;
        SigmaCholAcc.P      = SigmaCholProp.P;
        SigmaCholProp.P    = app;
        
        app                 = SigmaAcc.P;
        SigmaAcc.P         = SigmaProp.P;
        SigmaProp.P        = app;
        
        app                 = SigmaInvAcc.P;
        SigmaInvAcc.P       = SigmaInvProp.P;
        SigmaInvProp.P      = app;
        
        double app2 = logdeterminantProp;
        logdeterminantProp = logdeterminantAcc;
        logdeterminantAcc = app2;
        
        
    }
        
        
//    // external
    static void external_SigmaTotProp(int nobs, int dimcoreg, Matrix<double> *out, Matrix<double> *ParSigmaCoreg_Sigma, Matrix<double> * dist ,  vector<Poly_CovCorFunction*>*   covfunctions, vector <Matrix<double> > * tj);
    static void external_SigmaTotAcc(int nobs, int dimcoreg, Matrix<double> *out, Matrix<double> *ParSigmaCoreg_Sigma, Matrix<double> * dist ,  vector<Poly_CovCorFunction*>*   covfunctions, vector <Matrix<double> > * tj);

    static void external_SigmaTotProp(int nobs, int dimcoreg, Matrix<double> *out, Matrix<double> *ParSigmaCoreg_Sigma, Matrix<double> * dist1 , Matrix<double> * dist2 ,  vector<Poly_CovCorFunction*>*   covfunctions, vector <Matrix<double> > * tj);
    static void external_SigmaTotAcc(int nobs, int dimcoreg, Matrix<double> *out, Matrix<double> *ParSigmaCoreg_Sigma, Matrix<double> * dist1 ,Matrix<double> * dist2 ,  vector<Poly_CovCorFunction*>*   covfunctions, vector <Matrix<double> > * tj);

    static void external_SigmaTot_fromCoreg_to_CoregLessOne(int nobs, int dimcoreg, Matrix<double>* out, Matrix <double>* SigmaTot);
    
        
};



// TYPEDEF
typedef CovariaceStruct_CoregBased CoregMatrix ;
typedef  CovariaceStructNNGP_CoregBased CoregMatrixNNGP;















class CoregMatrixVECCHIA_VERSIONE_DA_TENERE_PER_VECCHI_CODICI: public  virtual CovMatrix_ToPass{
private:
    /*** STUFFS ***/
    
    
public:
    
    
    int SpaceOrTime;
    
    
    vector<Matrix <double> > TjAcc;
    vector<Matrix <double> > TjProp;
    
    
    Matrix<double> Dist;
    Matrix<double> Dist2;
    
    
    Class_Parameter_PDMatrixUnivSamp *ParSigmaCoreg;
    
    vector<Poly_CovCorFunction*>*   CovFunctions;
    
    
    // COSTRUCTORS
    CoregMatrixVECCHIA_VERSIONE_DA_TENERE_PER_VECCHI_CODICI(){}
    
    //DESTRUCTORS
    ~CoregMatrixVECCHIA_VERSIONE_DA_TENERE_PER_VECCHI_CODICI(){};
    void Destory(){
        
        for(int k=0;k<DimCoreg;k++)
        {
            TjAcc[k].Destroy();
            TjProp[k].Destroy();
            CovFunctions[0][k][0].Destroy();
        }
        
        
        
        Dist.Destroy();
        Dist2.Destroy();
        
        
        
        //ParSigmaCoreg->Destroy();
        
        
        
    }
    
    // MATRIX
    void create_objectSpaceOrTime(int nobs, Class_Parameter_PDMatrixUnivSamp *parsigma,vector<Poly_CovCorFunction*>*   covfunctions, int usr, Matrix<double> *coords)
    {
        SpaceOrTime             = 1;
        UserControlledMemory = usr;
        nObs        = nobs;
        DimCoreg    = parsigma->Dim;
        nTot        = nObs*DimCoreg;
        
        ParSigmaCoreg   = parsigma;
        CovFunctions    = covfunctions;
        
        
        
        
        
        SigmaAcc        = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaCholAcc    = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaInvAcc     = Matrix<double>(nTot,nTot,UserControlledMemory);
        
        
        SigmaAcc.Init(0.0);
        SigmaCholAcc.Init(0.0);
        SigmaInvAcc.Init(0.0);
        
        
        for(int i=0;i<DimCoreg;i++)
        {
            TjAcc.push_back(Matrix<double>(DimCoreg,DimCoreg,UserControlledMemory));
            TjAcc[i].Init(0.0);
        }
        
        SigmaProp               = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaCholProp           = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaInvProp            = Matrix<double>(nTot,nTot,UserControlledMemory);
        
        SigmaProp.Init(0.0);
        SigmaCholProp.Init(0.0);
        SigmaInvProp.Init(0.0);
        
        
        for(int i=0;i<DimCoreg;i++)
        {
            TjProp.push_back(Matrix<double>(DimCoreg,DimCoreg,UserControlledMemory));
            TjProp[i].Init(0.0);
        }
        
        
        update_TjAcc();
        update_TjProp();
        
        
        Dist        = Matrix<double>(nObs,nObs,UserControlledMemory);
        compute_dist(coords, &Dist);
        
    }
    
    void create_objectSpaceOrTimeKC(int nobs, Class_Parameter_PDMatrixUnivSamp *parsigma,vector<Poly_CovCorFunction*>*   covfunctions, int usr, Matrix<double> *coords)
    {
        SpaceOrTime             = 1;
        UserControlledMemory = usr;
        nObs        = nobs;
        DimCoreg    = parsigma->Dim;
        nTot        = nObs*(DimCoreg-1);
        
        ParSigmaCoreg   = parsigma;
        CovFunctions    = covfunctions;
        
        
        
        
        
        SigmaAcc        = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaCholAcc    = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaInvAcc     = Matrix<double>(nTot,nTot,UserControlledMemory);
        
        
        SigmaAcc.Init(0.0);
        SigmaCholAcc.Init(0.0);
        SigmaInvAcc.Init(0.0);
        
        
        for(int i=0;i<DimCoreg;i++)
        {
            TjAcc.push_back(Matrix<double>(DimCoreg,DimCoreg,UserControlledMemory));
            TjAcc[i].Init(0.0);
        }
        
        SigmaProp               = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaCholProp           = Matrix<double>(nTot,nTot,UserControlledMemory);
        SigmaInvProp            = Matrix<double>(nTot,nTot,UserControlledMemory);
        
        SigmaProp.Init(0.0);
        SigmaCholProp.Init(0.0);
        SigmaInvProp.Init(0.0);
        
        
        for(int i=0;i<DimCoreg;i++)
        {
            TjProp.push_back(Matrix<double>(DimCoreg,DimCoreg,UserControlledMemory));
            TjProp[i].Init(0.0);
        }
        
        
        update_TjAcc();
        update_TjProp();
        
        
        Dist        = Matrix<double>(nObs,nObs,UserControlledMemory);
        compute_dist(coords, &Dist);
        
    }
    
    
    
    
    
    /***** FUNCTIONS *****/
    
    void set_CovSpaceTime()
    {
        SpaceOrTime = 0;
    }
    
    
    void compute_dist(Matrix<double> *coords, Matrix<double> *dist)
    {
        REprintf("CAmbiare e usare la classe Utils\n");
        if(coords[0].nCols==2)
        {
            for(int i=0;i<nObs;i++)
            {
                for(int j=0;j<nObs;j++)
                {
                    dist->Pmat(i, j)[0] =  pow(  pow(coords[0].mat(i,0)-coords[0].mat(j,0),2.0)+pow(coords[0].mat(i,1)-coords[0].mat(j,1),2.0)   ,0.5);
                }
            }
            
        }else{
            if(coords[0].nCols==1)
            {
                for(int i=0;i<nObs;i++)
                {
                    for(int j=0;j<nObs;j++)
                    {
                        dist->Pmat(i, j)[0] =  pow(  pow(coords[0].mat(i,0)-coords[0].mat(j,0),2.0)  ,0.5);
                    }
                }
                
            }else{
                error("Dimension coords: compute_dist");
            }
        }
        
    }
    
    
    /***** UPDATES ****/
    virtual void update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj)=0;
    void update_TjAcc()
    {
        update_Tj_BASE(&ParSigmaCoreg->SigmaAcc, &TjAcc);
    }
    void update_TjProp()
    {
        update_Tj_BASE(&ParSigmaCoreg->SigmaProp, &TjProp);
    }
    
    //    virtual void update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj,vector <int> *Order)=0;
    //    void update_TjAcc(vector <int> *Order)
    //    {
    //        update_Tj_BASE(&ParSigmaCoreg->SigmaAcc, &TjAcc,Order);
    //    }
    //    void update_TjProp(vector <int> *Order)
    //    {
    //        update_Tj_BASE(&ParSigmaCoreg->SigmaProp, &TjProp,Order);
    //    }
    
    void update_SigmaAcc();
    void update_SigmaCholAcc();
    void update_logdeterminantAcc();
    void update_SigmaInvAcc();
    
    void update_MatricesAcc()
    {
        //ParSigmaCoreg->SigmaAcc.Print("SIGMAPRE");
        ParSigmaCoreg->update_allMatricesAcc();
        //ParSigmaCoreg->SigmaAcc.Print("SIGMAPOST");
        update_TjAcc();
        //TjAcc[0].Print("T1");
        //TjAcc[1].Print("T2");
        update_SigmaAcc();
        
        
        update_SigmaCholAcc();
        update_logdeterminantAcc();
        update_SigmaInvAcc();
    }
    
    //    void update_MatricesAcc( vector <int> *Order)
    //    {
    //        //ParSigmaCoreg->SigmaAcc.Print("SIGMAPRE");
    //        ParSigmaCoreg->update_allMatricesAcc();
    //        //ParSigmaCoreg->SigmaAcc.Print("SIGMAPOST");
    //        update_TjAcc(Order);
    //
    //        update_SigmaAcc();
    //
    //
    //        update_SigmaCholAcc();
    //        update_logdeterminantAcc();
    //        update_SigmaInvAcc();
    //    }
    //
    
    
    void update_SigmaProp();
    void update_SigmaCholProp();
    void update_logdeterminantProp();
    void update_SigmaInvProp();
    void update_MatricesProp()
    {
        // ParSigmaCoreg->SigmaProp.Print("SIGMAPRE");
        ParSigmaCoreg->update_allMatricesProp();
        // ParSigmaCoreg->SigmaProp.Print("SIGMAPOST");
        update_TjProp();
        update_SigmaProp();
        update_SigmaCholProp();
        update_logdeterminantProp();
        update_SigmaInvProp();
    }
    
    //    void update_MatricesProp(vector <int> *Order)
    //    {
    //        // ParSigmaCoreg->SigmaProp.Print("SIGMAPRE");
    //        ParSigmaCoreg->update_allMatricesProp();
    //        // ParSigmaCoreg->SigmaProp.Print("SIGMAPOST");
    //        update_TjProp(Order);
    //        update_SigmaProp();
    //        update_SigmaCholProp();
    //        update_logdeterminantProp();
    //        update_SigmaInvProp();
    //    }
    //
    
    
    void update_SigmaAccKC();
    
    
    void update_MatricesAccKC()
    {
        //ParSigmaCoreg->SigmaAcc.Print("SIGMAPRE");
        ParSigmaCoreg->update_allMatricesAcc();
        //ParSigmaCoreg->SigmaAcc.Print("SIGMAPOST");
        update_TjAcc();
        //TjAcc[0].Print("T1");
        //TjAcc[1].Print("T2");
        update_SigmaAccKC();
        
        
        update_SigmaCholAcc();
        update_logdeterminantAcc();
        update_SigmaInvAcc();
    }
    
    void update_SigmaPropKC();
    void update_MatricesPropKC()
    {
        // ParSigmaCoreg->SigmaProp.Print("SIGMAPRE");
        ParSigmaCoreg->update_allMatricesProp();
        // ParSigmaCoreg->SigmaProp.Print("SIGMAPOST");
        update_TjProp();
        update_SigmaPropKC();
        update_SigmaCholProp();
        update_logdeterminantProp();
        update_SigmaInvProp();
    }
    void update_MatricesPropKCNoSigmaCoreg()
    {
        //ParSigmaCoreg->update_allMatricesProp();
        update_TjProp();
        update_SigmaPropKC();
        update_SigmaCholProp();
        update_logdeterminantProp();
        update_SigmaInvProp();
    }
    
    
    void UpdateIfAcceptedNoSigmaCoreg()
    {
        //ParSigmaCoreg->UpdateIfAccepted();
        double *app;
        
        app                 = SigmaCholAcc.P;
        SigmaCholAcc.P      = SigmaCholProp.P;
        SigmaCholProp.P    = app;
        
        app                 = SigmaAcc.P;
        SigmaAcc.P         = SigmaProp.P;
        SigmaProp.P        = app;
        
        app                 = SigmaInvAcc.P;
        SigmaInvAcc.P       = SigmaInvProp.P;
        SigmaInvProp.P      = app;
        
        double app2 = logdeterminantProp;
        logdeterminantProp = logdeterminantAcc;
        logdeterminantAcc = app2;
        
        for(int k=0;k<TjAcc.size();k++)
        {
            app             = TjAcc[k].P;
            TjAcc[k].P      = TjProp[k].P;;
            TjProp[k].P     = app;
            
        }
        
        
        
        
        
    }
    void UpdateIfAccepted()
    {
        ParSigmaCoreg->UpdateIfAcceptedNoChol();
        double *app;
        
        app                 = SigmaCholAcc.P;
        SigmaCholAcc.P      = SigmaCholProp.P;
        SigmaCholProp.P    = app;
        
        app                 = SigmaAcc.P;
        SigmaAcc.P         = SigmaProp.P;
        SigmaProp.P        = app;
        
        app                 = SigmaInvAcc.P;
        SigmaInvAcc.P       = SigmaInvProp.P;
        SigmaInvProp.P      = app;
        
        double app2 = logdeterminantProp;
        logdeterminantProp = logdeterminantAcc;
        logdeterminantAcc = app2;
        
        for(int k=0;k<TjAcc.size();k++)
        {
            app             = TjAcc[k].P;
            TjAcc[k].P      = TjProp[k].P;;
            TjProp[k].P     = app;
            
        }
        
        
        
        
        
    }
    // external
    static void external_SigmaTotProp(int nobs, int dimcoreg, Matrix<double> *out, Matrix<double> *ParSigmaCoreg_Sigma, Matrix<double> * dist ,  vector<Poly_CovCorFunction*>*   covfunctions, vector <Matrix<double> > * tj);
    static void external_SigmaTotAcc(int nobs, int dimcoreg, Matrix<double> *out, Matrix<double> *ParSigmaCoreg_Sigma, Matrix<double> * dist ,  vector<Poly_CovCorFunction*>*   covfunctions, vector <Matrix<double> > * tj);
    
    static void external_SigmaTotProp(int nobs, int dimcoreg, Matrix<double> *out, Matrix<double> *ParSigmaCoreg_Sigma, Matrix<double> * dist1 , Matrix<double> * dist2 ,  vector<Poly_CovCorFunction*>*   covfunctions, vector <Matrix<double> > * tj);
    static void external_SigmaTotAcc(int nobs, int dimcoreg, Matrix<double> *out, Matrix<double> *ParSigmaCoreg_Sigma, Matrix<double> * dist1 ,Matrix<double> * dist2 ,  vector<Poly_CovCorFunction*>*   covfunctions, vector <Matrix<double> > * tj);
    
    static void external_SigmaTot_fromCoreg_to_CoregLessOne(int nobs, int dimcoreg, Matrix<double>* out, Matrix <double>* SigmaTot);
};



class Class_MatrixCoreg_Spectral: public CoregMatrix, public CoregMatrixNNGP
{
private:
    
public:
    //*** UPDATES ******/
    void update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj) override;
   // void update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj,vector <int> *Order);
    
};


class Class_MatrixCoreg_Chol: public CoregMatrix, public CoregMatrixNNGP
{
private:
    
public:
    //*** UPDATES ******/
    void update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj) override;
    //void update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj,vector <int> *Order);
};

class Class_MatrixCoreg_Ind: public CoregMatrix, public CoregMatrixNNGP
{
private:
    
public:
    //*** UPDATES ******/
    void update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj) override;
    //void update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj,vector <int> *Order);
};

//class Class_MatrixCoreg_Ind: public CoregMatrix, public CoregMatrixNNGP
//{
//private:
//    
//public:
//    //*** UPDATES ******/
//    void update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj);
//    //void update_Tj_BASE(Matrix <double>* SigmaCoreg, vector<Matrix <double> >* tj,vector <int> *Order);
//};







class Class_Gaussian
{
private:
    
public:
    int UserControlledMemory;
    int Dimension; // sarebbe meglio chiamarla dimensiona
    Vector<double> Omega;
    Vector<double> OmegaProp;
    
    Class_MultivariateNormal*   Distributions;
    CovMatrix_ToPass*           CovarianceMatrix;
    Mean_ToPass*                MeanVector;
    
    
    
    
    //COSTRUCCTORS
    Class_Gaussian(){}
    
    // DESTRUCTORS
    ~Class_Gaussian(){}
    void Destroy()
    {
        Omega.Destroy();
        CovarianceMatrix->Destroy();
        MeanVector->Destroy();
    }
    
    void add_Prop()
    {
        OmegaProp           = Vector<double>(Omega.nElem, UserControlledMemory);
        for(int i=0;i<Omega.nElem;i++)
        {
            OmegaProp.Pvec(i)[0] = Omega.Pvec(i)[0];
        }
    }
    
    
    void create_FullObject( Vector<double> *omega, Mean_ToPass*       meanvector, CovMatrix_ToPass*   covariancematrix, int usr)
    {
        UserControlledMemory        = usr;
        Omega               = Vector<double> (omega->nElem,omega->P);
        Dimension           = omega[0].nElem;
        
        MeanVector          = meanvector;
        CovarianceMatrix    = covariancematrix;
        
        
    }
    
    
    // check
    void check()
    {
        
    }
};


class Class_Gaussian_Multivariate
{
private:
    
public:
    int UserControlledMemory;
    int Nobs;
    //int DimCoreg; // della coregionalizzazion
    int Dimension;

    Vector<double>                  Omega;
    //Mean_ToPass*                    MeanVector;
    CoregMatrix*                   CovMat;

    Class_MultivariateNormal*   Distributions;
    
    Matrix <double> *Covariates;
    VectorParameters *RegCoef;
    Matrix <double> * OtherVar;
    
    
    
    //COSTRUCCTORS
    Class_Gaussian_Multivariate(){}
    
    // DESTRUCTORS
    ~Class_Gaussian_Multivariate(){}
    void Destroy()
    {

    }
    void add_OtherVar(Matrix<double> *other)
    {
        OtherVar = other;
    }
    void add_CovariatesAndRegCoefs(Matrix <double> *covariates, VectorParameters *regCoef)
    {
        Covariates = covariates;
        RegCoef = regCoef;
    }
    void create_FullObject(int nobs,  Vector<double> *omega,  int usr, CoregMatrix*                   covmat)
    {

        UserControlledMemory        = usr;
        Omega                       = Vector<double> (omega->nElem,omega->P);
        Dimension                   = omega[0].nElem;
        Nobs                        = nobs;
        
        CovMat = covmat;

//        if(Choice_Coregionalization=="Cholesky")
//        {
//            CovMat = new Class_MatrixCoreg_Chol;
//        }else{
//            if(Choice_Coregionalization=="Spectral")
//            {
//                CovMat = new Class_MatrixCoreg_Spectral;
//            }else{
//                if(Choice_Coregionalization=="Ind")
//                {
//                    error("Coregionalization not well specified in Class_Gaussian_Temp_Multvariate (IND)\n");
//                }else{
//                    error("Coregionalization not well specified in Class_Gaussian_Temp_Multvariate\n");
//                }
//            }
//            
//        }
//        CovMat->create_object(CoregSigmaMCMC,covfunc, UserControlledMemory,coords);
    }
    
    void create_FullObject(int nobs,  Vector<double> *omega, vector<Poly_CovCorFunction*>  *covfunc, int usr, Matrix <double>  *coords, string Choice_Coregionalization, Class_Parameter_PDMatrixUnivSamp       *CoregSigmaMCMC)
    {
        
        error("NON USARE; BISONGNA DEFINIRE DI FUORI  LA COVMAT");
        UserControlledMemory        = usr;
        Omega                       = Vector<double> (omega->nElem,omega->P);
        Dimension                   = omega[0].nElem;
        Nobs                        = nobs;
        
        
        if(Choice_Coregionalization=="Cholesky")
        {
            CovMat = new Class_MatrixCoreg_Chol;
        }else{
            if(Choice_Coregionalization=="Spectral")
            {
                CovMat = new Class_MatrixCoreg_Spectral;
            }else{
                if(Choice_Coregionalization=="Ind")
                {
                    error("Coregionalization not well specified in Class_Gaussian_Temp_Multvariate (IND)\n");
                }else{
                    error("Coregionalization not well specified in Class_Gaussian_Temp_Multvariate\n");
                }
            }
            
        }
        CovMat->create_object(CoregSigmaMCMC,covfunc, UserControlledMemory,coords);
    }
    
    
    void update_CovMat_Prop()
    {
        int DimCoreg    =  CovMat[0].DimCoreg;
       
        //REprintf("%i %i %i %i %i  %i\n", DimCoreg, Dimension,Nobs, CovMat[0].SigmaProp.nRows,CovMat[0].SigmaProp.nCols, CovMat[0].nTot );
        //REprintf("At1\n");
        CovMat[0].ParSigmaCoreg->update_allMatricesProp();
        //REprintf("At2\n");
        CovMat[0].update_TjProp();
        //REprintf("At3\n");
        if(CovMat[0].SpaceOrTime==1)
        {
            //REprintf("Time1\n");
            CoregMatrix::external_SigmaTotProp(Nobs, DimCoreg , &CovMat[0].SigmaProp, &CovMat[0].ParSigmaCoreg->SigmaProp, &CovMat[0].Dist ,  CovMat[0].CovFunctions, CovMat[0].TjProp);
        }else{
            //REprintf("Time2\n");
            CoregMatrix::external_SigmaTotProp(Nobs, DimCoreg , &CovMat[0].SigmaProp, &CovMat[0].ParSigmaCoreg->SigmaProp, &CovMat[0].Dist ,&CovMat[0].Dist2,  CovMat[0].CovFunctions, CovMat[0].TjProp);
        }
        //CovMat[0].Dist.Print("dist");
        //CovMat[0].SigmaProp.Print("s");
        //REprintf("At4\n");
        CovMat[0].update_SigmaCholProp();
        //REprintf("At5\n");
        CovMat[0].update_logdeterminantProp();
        //REprintf("At6\n");
        CovMat[0].update_SigmaInvProp();
        //REprintf("At7\n");
        
    }
    
    void update_CovMat_Acc()
    {
        int DimCoreg    =  CovMat[0].DimCoreg;
        
        
        CovMat[0].ParSigmaCoreg->update_allMatricesAcc();
        
       CovMat[0].update_TjAcc();

        if(CovMat[0].SpaceOrTime==1)
        {
            //printf("BB1\n");
            CoregMatrix::external_SigmaTotAcc(Nobs, DimCoreg , &CovMat[0].SigmaAcc, &CovMat[0].ParSigmaCoreg->SigmaAcc, &CovMat[0].Dist ,  CovMat[0].CovFunctions, CovMat[0].TjAcc);
            //printf("BB2\n");
        }else{
            //CoregMatrix::external_SigmaTotAcc(Nobs, DimCoreg , &CovMat[0].SigmaAcc, &CovMat[0].ParSigmaCoreg->SigmaAcc, &CovMat[0].Dist ,&CovMat[0].Dist2,  CovMat[0].CovFunctions, CovMat[0].TjAcc);
        }
        //REprintf("Ac4\n");
        CovMat[0].update_SigmaCholAcc();
        //REprintf("Ac5\n");
        CovMat[0].update_logdeterminantAcc();
        //REprintf("Ac6\n");
        CovMat[0].update_SigmaInvAcc();
        //REprintf("Ac7\n");
    }
    
    void compute_ytSigmaInvy_Acc(double *ret)
    {
        Class_Utils::external_ytSigmaInvy(&Omega, &CovMat[0].SigmaAcc,ret);
    }
    void compute_ytSigmaInvy_Prop(double *ret)
    {
        Class_Utils::external_ytSigmaInvy(&Omega, &CovMat[0].SigmaProp,ret);
    }
    
    void UpdateIfAccepted()
    {
        double *app;
        for(int k=0;k<CovMat[0].TjAcc[0].size();k++)
        {
            app                           = CovMat[0].TjAcc[0][k].P;
            CovMat[0].TjAcc[0][k].P      = CovMat[0].TjProp[0][k].P;;
            CovMat[0].TjProp[0][k].P     = app;
            
        }
        
        CovMat[0].ParSigmaCoreg->UpdateIfAcceptedNoChol();
        CovMat[0].UpdateIfAcceptedNoSigmaCoregNoTj();
    }
    
    void sample_RegCoef_NormalPrior()
    {
        const int ncov = Covariates->nCols;
        
        double retMat_P[ncov*ncov];
        Matrix<double>retMat(ncov,ncov,retMat_P);
        
        double retVec_P[ncov];
        Vector<double>retVec(ncov,retVec_P);
        
        const double Zero = 0.0;
        const int  One = 1;
        
        
        Class_MultivariateNormal::external_ParametersForFullConditioanlBeta_WithoutMolt( Covariates, &CovMat[0].SigmaInvAcc, &Omega, &retMat, &retVec,&Zero);
        for(int i=0;i<ncov;i++)
        {
            retMat.Pmat(i,i)[0] += 1.0/RegCoef[0].Parameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
            retVec.Pvec(i)[0] += RegCoef[0].Parameters[0][i].PriorParameter[0].HyperparametersAcc.vec(0)[0]/RegCoef[0].Parameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
        }
        Class_MultivariateNormal::external_finalizedRegFullConditional(&retMat, &retVec, One);
        Class_MultivariateNormal::external_SampleMultivariate(&RegCoef[0].VectorAcc,&retVec, &retMat);
        RegCoef[0].update_ParameterAcc();
    }
    void sample_RegCoef_NormalPrior_ExtraVar()
    {
        const int ncov = Covariates->nCols;
        
        double retMat_P[ncov*ncov];
        Matrix<double>retMat(ncov,ncov,retMat_P);
        
        double retVec_P[ncov];
        Vector<double>retVec(ncov,retVec_P);
        
        double OmegaApp_P[Omega.nElem];
        Vector<double>OmegaApp(Omega.nElem,OmegaApp_P);
        for(int i=0;i<Omega.nElem;i++)
        {
            OmegaApp.Pvec(i)[0] = Omega.vec(i);
            for(int j=0;j<OtherVar->nCols;j++)
            {
                OmegaApp.Pvec(i)[0] -= OtherVar->mat(i,j);
            }
        }
        
        const double Zero = 0.0;
        const int  One = 1;
        
        
        Class_MultivariateNormal::external_ParametersForFullConditioanlBeta_WithoutMolt( Covariates, &CovMat[0].SigmaInvAcc, &OmegaApp, &retMat, &retVec,&Zero);
        for(int i=0;i<ncov;i++)
        {
            retMat.Pmat(i,i)[0] += 1.0/RegCoef[0].Parameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
            retVec.Pvec(i)[0] += RegCoef[0].Parameters[0][i].PriorParameter[0].HyperparametersAcc.vec(0)[0]/RegCoef[0].Parameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
        }
        Class_MultivariateNormal::external_finalizedRegFullConditional(&retMat, &retVec, One);
        Class_MultivariateNormal::external_SampleMultivariate(&RegCoef[0].VectorAcc,&retVec, &retMat);
        RegCoef[0].update_ParameterAcc();
    }

    
};







class Class_Gaussian_NNGP_Multivariate_V2
{
private:
    
public:
    int UserControlledMemory;
    int Nobs;
    //int DimCoreg; // della coregionalizzazion
    int Dimension;
    int Msparemax;
    // sarebbe meglio chiamarla dimensiona
    Vector<double>                  Omega;
    //Mean_ToPass*                    MeanVector;
    vector<CoregMatrixNNGP*>        CovMat; // sarebbe la F
    vector<Matrix<double> >         BAcc;
    vector<Matrix<double> >         BProp;
    Vector <int> *VecEqual;
    Vector <int> ElementComp;
    
    
    Vector<double>  Mean;
    Vector<double>  MeanProp;
    Matrix<double>  *Covariates;
    VectorParameters  *RegVec;
    vector <Matrix<double> > CovariatesNeigh;
    
    Class_MultivariateNormal*   Distributions;
    
    
    vector <vector <int> > Neigh;
    vector <vector <int> > NeighRev;
    vector <vector <int> > PosNeighRev;
    
    
    
    
    //COSTRUCCTORS
    Class_Gaussian_NNGP_Multivariate_V2(){}
    
    // DESTRUCTORS
    ~Class_Gaussian_NNGP_Multivariate_V2(){}
    void Destroy()
    {
        Omega.Destroy();
        
        for(int i=0;i<CovMat.size();i++)
        {
            CovMat[i]->Destory();
        }
        
        for(int i=0;i<BAcc.size();i++)
        {
            BAcc[i].Destroy();
            BProp[i].Destroy();
        }
        //CovarianceMatrix->Destroy();
        //MeanVector->Destroy();
    }
    
    void create_FullObject(Vector <int> *EqualDist, Matrix<int> *NeighMat, int nobs,  Vector<double> *omega, vector<Poly_CovCorFunction*>  *covfunc, int usr, Matrix <double>  *coords, string Choice_Coregionalization, Class_Parameter_PDMatrixUnivSamp       *CoregSigmaMCMC)
    {
        //REprintf("Print_Gaus1_1\n");
        // in base alla dimensione delle coordinat decidono se space time o spacetime
        
        UserControlledMemory        = usr;
        Omega                       = Vector<double> (omega->nElem,omega->P);
        Dimension                   = omega[0].nElem;
        Nobs                        = nobs;
        Msparemax                   = NeighMat->nCols;
        
        VecEqual = EqualDist;
        // MeanVector                  = meanvector;
        
        //REprintf("Print_Gaus1_2\n");
        // COREGIONALIZATION TYPE
        if(Choice_Coregionalization=="Cholesky")
        {
            for(int i=0;i<Nobs;i++)
            {
                CovMat.push_back(new Class_MatrixCoreg_Chol);
            }
            //CovMat = new Class_MatrixCoreg_Chol;
        }else{
            if(Choice_Coregionalization=="Spectral")
            {
                for(int i=0;i<Nobs;i++)
                {
                    CovMat.push_back(new Class_MatrixCoreg_Spectral);
                }
            }else{
                error("Coregionalization not well specified in Class_Gaussian_TempNNGP_Multvariate\n");
            }
        }
        //REprintf("Print_Gaus1_3\n");
        for(int i=0;i<Nobs;i++)
        {
            Neigh.push_back(vector<int>());
            NeighRev.push_back(vector<int>());
            PosNeighRev.push_back(vector<int>());
            
            
        }
        //REprintf("Print_Gaus1_4\n");
        double CoordsApp[(Msparemax+1)*coords->nCols];
        Matrix <double> AppCoord(Msparemax+1,coords->nCols,CoordsApp);
        
        //REprintf("Print_Gaus1_5\n");
        int i = 0;
        int pos=0;
        for(int j=0;j<Msparemax;j++)
        {
            if(NeighMat[0].mat(i,j)>(-1))
            {
                Neigh[i].push_back(NeighMat[0].mat(i,j));
                NeighRev[NeighMat[0].mat(i,j)].push_back(i);
                PosNeighRev[NeighMat[0].mat(i,j)].push_back(pos);
                for(int t=0;t<coords->nCols;t++)
                {
                    AppCoord.Pmat(pos,t)[0] = coords->mat(NeighMat[0].mat(i,j),t);
                }
                pos ++;
            }
        }
        //REprintf("Print_Gaus1_6\n");
        for(int t=0;t<coords->nCols;t++)
        {
            AppCoord.Pmat(pos,t)[0] = coords->mat(i,t);
        }
        //CovMat[i]->create_object(min(i,Msparemax),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord);
        CovMat[i]->create_object((int)Neigh[i].size(),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord);
        BAcc.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,UserControlledMemory));
        BProp.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,UserControlledMemory));
        
        //REprintf("Print_Gaus1_7\n");
        for(i=1;i<Nobs;i++)
        {
            pos = 0;
            for(int j=0;j<Msparemax;j++)
            {
                if(NeighMat[0].mat(i,j)>(-1))
                {
                    Neigh[i].push_back(NeighMat[0].mat(i,j));
                    NeighRev[NeighMat[0].mat(i,j)].push_back(i);
                    PosNeighRev[NeighMat[0].mat(i,j)].push_back(pos);
                    for(int t=0;t<coords->nCols;t++)
                    {
                        AppCoord.Pmat(pos,t)[0] = coords->mat(NeighMat[0].mat(i,j),t);
                    }
                    pos ++;
                }
            }
            for(int t=0;t<coords->nCols;t++)
            {
                AppCoord.Pmat(pos,t)[0] = coords->mat(i,t);
            }
            
            //CovMat[i]->create_object(min(i,Msparemax),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord,CovMat[0]->TjAcc,CovMat[0]->TjProp);
            
            
            
            if(EqualDist->vec(i)<0)
            {
                // fare attenzione quando si cambi al'indirizzo accettato propostop, perchè quello che non hanno l'originale non gli viene cambiato, vale per Tj
                CovMat[i]->create_object((int)Neigh[i].size(),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord,CovMat[0]->TjAcc,CovMat[0]->TjProp);
                BAcc.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,UserControlledMemory));
                BProp.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,UserControlledMemory));
                
            }else{
                CovMat[i] = CovMat[EqualDist->vec(i)];
                BAcc.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,BAcc[EqualDist->vec(i)].P));
                BProp.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,BProp[EqualDist->vec(i)].P));
            }
            
            
        }
        
        int nComp = 0;
        for(int i=0;i<Omega.nElem;i++)
        {
            if(VecEqual->vec(i)<0)
            {
                nComp++;
            }
        }
        ElementComp = Vector<int>(nComp,1);
        nComp = 0;
        for(int i=0;i<Omega.nElem;i++)
        {
            if(VecEqual->vec(i)<0)
            {
                ElementComp.Pvec(nComp)[0] = i;
                nComp++;
            }
        }
        
    }
    void add_RegMean(Matrix<double>  *Cov, VectorParameters  *Reg)
    {
        
        Covariates = Cov;
        RegVec = Reg;
        Mean = Vector<double>(Covariates->nRows,1);
        MeanProp = Vector<double>(Covariates->nRows,1);
        compute_MeanAcc();
        compute_CovariateMatrix_neigh();
    }
    void compute_CovariateMatrix_neigh()
    {
        // SOno le covariate dei vicini di i
        //int nProcesses = CovMat[0]->SigmaAcc.nRows;
        for(int iobs=0;iobs<Nobs;iobs++)
        {
            int ncol = BAcc[iobs].nCols;
            int nrow = BAcc[iobs].nRows;
            CovariatesNeigh.push_back(Matrix<double>());
            
            CovariatesNeigh[iobs] = Matrix<double>(ncol,Covariates->nCols,1);
            
            if((ncol!=0)&(nrow!=0))
            {
                int pos = 0;
                for(int j=0;j<Neigh[iobs].size();j++)
                {
                    for(int k=0;k<nrow;k++)
                    {
                        for(int t=0;t<Covariates->nCols;t++)
                        {
                            CovariatesNeigh[iobs].Pmat(pos,t)[0] =  Covariates[0].mat(Neigh[iobs][j]*nrow+k,t);
                        }
                        pos++;
                    }
                    
                }
            }
        }
    }
    
    //VectorAcc
    void compute_MeanAcc()
    {
        compute_Mean(&Mean,&RegVec->VectorAcc);
    }
    void compute_MeanProp()
    {
        compute_Mean(&MeanProp,&RegVec->VectorProp);
    }
    void compute_Mean(Vector<double> *M,Vector<double>  *Reg)
    {
        Class_Utils::external_dgemv(Covariates, Reg, M, 0.0);
    }

    void update_BFAcc();
    void update_BFProp();
    

    void sample_RegCoefNormalPrior(double ss)
    {
        double VarBetas_P[Covariates->nCols * Covariates->nCols];
        Matrix<double> VarBetas(Covariates->nCols,Covariates->nCols,VarBetas_P);
        VarBetas.Init(0.0);
        double MeanBetas_P[Covariates->nCols];
        Vector<double> MeanBetas(Covariates->nCols,MeanBetas_P);
        
        double OmegaApp_P[Omega.nElem];
        Vector<double>OmegaApp(Omega.nElem,OmegaApp_P);
        for(int i=0;i<Omega.nElem;i++)
        {
            OmegaApp.Pvec(i)[0] = Omega.vec(i)-ss;
        }
        
        for(int i=0;i<Covariates->nCols;i++)
        {
            //RegVec[0].Parameters[0][i].PrintObject("rEg");
            VarBetas.Pmat(i,i)[0] = 1.0/RegVec[0].Parameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
            MeanBetas.Pvec(i)[0] = RegVec[0].Parameters[0][i].PriorParameter[0].HyperparametersAcc.vec(0)[0]/RegVec[0].Parameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
        }
        compute_parFullCondRegParameters( &VarBetas, &MeanBetas, OmegaApp);
        Class_MultivariateNormal::external_SampleMultivariate(&RegVec[0].VectorAcc, &MeanBetas, &VarBetas);
        RegVec[0].update_ParameterAcc();
        compute_MeanAcc();
        
        
        //MeanBetas.Print("Mean");
        
    }
    
    void sample_RegCoefNormalPrior()
    {
        double VarBetas_P[Covariates->nCols * Covariates->nCols];
        Matrix<double> VarBetas(Covariates->nCols,Covariates->nCols,VarBetas_P);
        VarBetas.Init(0.0);
        double MeanBetas_P[Covariates->nCols];
        Vector<double> MeanBetas(Covariates->nCols,MeanBetas_P);
        for(int i=0;i<Covariates->nCols;i++)
        {
            //RegVec[0].Parameters[0][i].PrintObject("rEg");
            VarBetas.Pmat(i,i)[0] = 1.0/RegVec[0].Parameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
            MeanBetas.Pvec(i)[0] = RegVec[0].Parameters[0][i].PriorParameter[0].HyperparametersAcc.vec(0)[0]/RegVec[0].Parameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
        }
        compute_parFullCondRegParameters( &VarBetas, &MeanBetas, Omega);
        Class_MultivariateNormal::external_SampleMultivariate(&RegVec[0].VectorAcc, &MeanBetas, &VarBetas);
        RegVec[0].update_ParameterAcc();
        compute_MeanAcc();
        
    
        //MeanBetas.Print("Mean");
        
    }
    void compute_parFullCondRegParameters( Matrix<double> *VarBetas, Vector<double> *MeanBetas, Vector <double> &Y)
    {
        
        //Y è il processo gaussian con media Xbeta
        int nProcesses = CovMat[0]->SigmaAcc.nRows;
        
        double BtimesY_P[nProcesses];
        Vector <double> BtimesY(nProcesses,BtimesY_P);
        
        
        double YlessBtimesY_P[nProcesses];
        Vector <double> YlessBtimesY(nProcesses,YlessBtimesY_P);
        
        double CovariateBetas_P[Covariates->nCols*nProcesses];
        Matrix <double> CovariateBetas(nProcesses,Covariates->nCols,CovariateBetas_P);
        
        //        Mean->priorParameters_forGibbs(VarBetas,MeanBetas);
        //        for(int i=0;i<Nobs;i++)
        //        {
        //            for(int k=0;k<nProcesses;k++)
        //            {
        //                Y->Pvec(nProcesses*i+k)[0] = Omega.vec(i*nProcesses+k)+Mean->MeanAcc->vec(i*nProcesses+k);
        //            }
        //        }
        
        int i_IndexEqual;
        //        for(int i=0;i<20;i++)
        //        {
        //            REprintf("\n%f %f %f \n",Covariates->mat(i,0),Covariates->mat(i,1),Covariates->mat(i,2));
        //            CovariatesNeigh[i].Print("CovNeig");
        //        }
        //        error("AA");
        for(int i=0;i<Nobs;i++)
        {
            int ncol,nrow;
            if(VecEqual->vec(i)<0)
            {
                i_IndexEqual = i;
            }else{
                i_IndexEqual = VecEqual->vec(i);
            }
            
            ncol = BAcc[i_IndexEqual].nCols;
            nrow = BAcc[i_IndexEqual].nRows;
            
            if(ncol>0)
            {
                compute_Bomega_neigh(i,  &BtimesY,&Y,i_IndexEqual);
                for(int k=0;k<nProcesses;k++)
                {
                    YlessBtimesY.Pvec(k)[0] = Y.vec(i*nProcesses+k)-BtimesY.vec(k);
                }
                Class_Utils::external_dgemm(&BAcc[i_IndexEqual], &CovariatesNeigh[i], &CovariateBetas, Class_ToLoad::Dzero);
                for(int i1=0;i1<CovariateBetas.nRows;i1++)
                {
                    for(int j1=0;j1<CovariateBetas.nCols;j1++)
                    {
                        CovariateBetas.Pmat(i1,j1)[0] = Covariates->mat(i*nProcesses+i1,0+j1)-1.0*CovariateBetas.Pmat(i1,j1)[0];
                    }
                }
            }else{
                //REprintf("else");
                for(int k=0;k<nProcesses;k++)
                {
                    YlessBtimesY.Pvec(k)[0] = Y.vec(i*nProcesses+k);
                }
                for(int i1=0;i1<CovariateBetas.nRows;i1++)
                {
                    for(int j1=0;j1<CovariateBetas.nCols;j1++)
                    {
                        CovariateBetas.Pmat(i1,j1)[0] = Covariates->mat(i*nProcesses+i1,0+j1);
                    }
                }
            }
            Class_RegMean::external_ParametersForFullConditioanlBeta_WithoutMolt(&CovariateBetas, &CovMat[i_IndexEqual]->SigmaInvAcc, &YlessBtimesY, VarBetas, MeanBetas, &Class_ToLoad::Done);
            //CovariateBetas.Print("Cov");
            //CovMat[i_IndexEqual]->SigmaInvAcc.Print("CovMat[i_IndexEqual]->SigmaInvAcc");
            //YlessBtimesY.Print("YlessBtimesY");
//            REprintf("Iter %i",i);
//

        }

        Class_MultivariateNormal::external_finalizedRegFullConditional(VarBetas, MeanBetas, 1);
//        MeanBetas->Print("MeanBetas");
//        VarBetas->Print("VarBetas");

    }
    
    
    
    double compute_logdensity_forCovParAcc_NoZeroMean()
    {
        double Y_P[Omega.nElem];
        Vector <double>Y(Omega.nElem,Y_P);
        for(int i=0;i<Omega.nElem;i++)
        {
            Y.Pvec(i)[0] = Omega.vec(i)-Mean.vec(i);
        }
        return(compute_logdensity_forCovParAcc(&Y));
        //return(compute_logdensity_forCovParAccMulti(&Y));
    }
    double compute_logdensity_forCovParProp_NoZeroMean()
    {
        double Y_P[Omega.nElem];
        Vector <double>Y(Omega.nElem,Y_P);
        for(int i=0;i<Omega.nElem;i++)
        {
            Y.Pvec(i)[0] = Omega.vec(i)-Mean.vec(i);
        }
        return(compute_logdensity_forCovParPropMulti(&Y));
    }
    
    double compute_logdensity_forCovParAcc_NoZeroMean(double ss)
    {
        double Y_P[Omega.nElem];
        Vector <double>Y(Omega.nElem,Y_P);
        for(int i=0;i<Omega.nElem;i++)
        {
            Y.Pvec(i)[0] = Omega.vec(i)-Mean.vec(i)-ss;
        }
        return(compute_logdensity_forCovParAcc(&Y));
        //return(compute_logdensity_forCovParAccMulti(&Y));
    }
    double compute_logdensity_forCovParProp_NoZeroMean(double ss)
    {
        double Y_P[Omega.nElem];
        Vector <double>Y(Omega.nElem,Y_P);
        for(int i=0;i<Omega.nElem;i++)
        {
            Y.Pvec(i)[0] = Omega.vec(i)-Mean.vec(i)-ss;
        }
        return(compute_logdensity_forCovParPropMulti(&Y));
    }
    
    
    
    
    double compute_logdensity_forCovParAcc(Vector <double> *Y)
    {
        double ret = 0.0;
        for(int i=0;i<Nobs;i++)
        {
            ret+= compute_logdensity_forCovParAcc(i,Y);
        }
        return(ret);
        
    }
    
    double compute_logdensity_InvolveObservation_i(int i,Vector <double> *Y)
    {
        // testare bene
        double ret = 0.0;
        
        ret += compute_logdensity_forCovParAcc(i,Y);
        for(int jrev2 = 0;jrev2<NeighRev[i].size() ;jrev2++)
        {
            int jrev    = NeighRev[i][jrev2];
            ret += compute_logdensity_forCovParAcc(jrev,Y);
        }
        return(ret);
        
    }
    
    
    double compute_logdensity_forCovParPropMulti(Vector <double> *Y)
    {
        // Y è il GP com media nulla  di non solo l i-esimo valore
        // questa calcola la densità di y_i, quando questa è l'osservazione, non la covariata
        double ret = 0.0;
        
        const double    Dzero          = 0.0;
        const double    Done          = 1.0;
        
        const int       Ione          = 1;
        
        
        int nrow;
        int ncol;
        
        nrow = CovMat[0]->SigmaProp.nRows;
        
        double Muapp_Pointer[nrow];
        double Omegaapp_Pointer[(Msparemax+1)*nrow];
        
        Vector <double> Muapp(nrow,Muapp_Pointer);
        Vector <double> Omegaapp((Msparemax+1)*nrow,Omegaapp_Pointer);
        
        int isame;
        for(int i=0;i<Nobs;i++)
        {
            if(VecEqual->vec(i)<0)
            {
                isame = i;
            }else{
                isame = VecEqual->vec(i);
            }
            // REprintf("Iter %i ",i);
            ncol = BProp[isame].nCols;
            //nrow = BAcc[i].nRows;
            if((ncol!=0)&(nrow!=0))
            {
                
                for(int j=0;j<Neigh[i].size();j++)
                {
                    for(int k=0;k<nrow;k++)
                    {
                        Omegaapp.Pvec(j*nrow+k)[0] = Y->vec(Neigh[i][j]*nrow+k);
                    }
                }
                
                F77_NAME(dgemv)("T",  &ncol, &nrow, &Done, BProp[isame].P,  &ncol, Omegaapp.P, &Ione, &Dzero, Muapp.P, &Ione);
                ret += Class_MultivariateNormal::external_compute_LogDensity_forCovMat(nrow, Y->Pvec(i*nrow),Muapp.P , CovMat[isame][0].SigmaInvProp.P,&CovMat[isame][0].logdeterminantProp);
                
            }else{
                for(int j=0;j<nrow;j++)
                {
                    Muapp.Pvec(j)[0] = 0.0;
                }
                ret += Class_MultivariateNormal::external_compute_LogDensity_forCovMat(nrow, Y->Pvec(i*nrow),Muapp.P , CovMat[isame][0].SigmaInvProp.P,&CovMat[isame][0].logdeterminantProp);
            }
            
        }
        
        return(ret);
    }
    double compute_logdensity_forCovParAcc(int i,Vector <double> *Y)
    {
        // Y è il GP com media nulla  di non solo l i-esimo valore
        // questa calcola la densità di y-i, quando questa è l'osservazione, non la covariata
        double ret = 0.0;
        
        const double    Dzero          = 0.0;
        const double    Done          = 1.0;
        
        const int       Ione          = 1;
        
        
        int nrow;
        int ncol;
        
        nrow = CovMat[0]->SigmaAcc.nRows;
        
        double Muapp_Pointer[nrow];
        double Omegaapp_Pointer[(Msparemax+1)*nrow];
        
        Vector <double> Muapp(nrow,Muapp_Pointer);
        Vector <double> Omegaapp((Msparemax+1)*nrow,Omegaapp_Pointer);
        
        int isame;
        //for(int i=0;i<Nobs;i++)
        //{
        if(VecEqual->vec(i)<0)
        {
            isame = i;
        }else{
            isame = VecEqual->vec(i);
        }
        //REprintf("Iter %i ",i);
        ncol = BAcc[isame].nCols;
        //nrow = BProp[i].nRows;
        if((ncol!=0)&(nrow!=0))
        {
            
            for(int j=0;j<Neigh[i].size();j++)
            {
                for(int k=0;k<nrow;k++)
                {
                    Omegaapp.Pvec(j*nrow+k)[0] = Y->vec(Neigh[i][j]*nrow+k);
                }
            }
            
            F77_NAME(dgemv)("T",  &ncol, &nrow, &Done, BAcc[isame].P,  &ncol, Omegaapp.P, &Ione, &Dzero, Muapp.P, &Ione);
            ret += Class_MultivariateNormal::external_compute_LogDensity_forCovMat(nrow,  Y->Pvec(i*nrow),Muapp.P , CovMat[isame][0].SigmaInvAcc.P,  &CovMat[isame][0].logdeterminantAcc );
            
        }else{
            for(int j=0;j<nrow;j++)
            {
                Muapp.Pvec(j)[0] = 0.0;
            }
            ret += Class_MultivariateNormal::external_compute_LogDensity_forCovMat(nrow, Y->Pvec(i*nrow),Muapp.P , CovMat[isame][0].SigmaInvAcc.P,&CovMat[isame][0].logdeterminantAcc);
            
        }
        
        
        //}
        
        return(ret);
    }
    
    void UpdateIfAccepted_CovMat()
    {
        double *app;
        for(int k=0;k<CovMat[0]->TjAcc[0].size();k++)
        {
            app                           = CovMat[0]->TjAcc[0][k].P;
            CovMat[0]->TjAcc[0][k].P      = CovMat[0]->TjProp[0][k].P;;
            CovMat[0]->TjProp[0][k].P     = app;
            
        }
        
        CovMat[0]->ParSigmaCoreg->UpdateIfAcceptedNoChol();
        // F
        int i;
        for(int iii2=0;iii2<ElementComp.nElem;iii2++)
        {
            i = ElementComp.vec(iii2);
            CovMat[i]->UpdateIfAcceptedNoSigmaCoregNoTj();
        }
        // B
        for(int iii2=0;iii2<ElementComp.nElem;iii2++)
        {
            i = ElementComp.vec(iii2);
            app                             = BAcc[i].P;
            BAcc[i].P                       = BProp[i].P;;
            BProp[i].P                      = app;
        }
    }
    
    
    void compute_Bomega_neigh(int iobs,  Vector <double> *ret,Vector <double> *OmegaPass,int i_IndexEqual)
    {
        // da i parametri prima di trasformarli in media e varianza
        int nProcesses = CovMat[0]->SigmaAcc.nRows;
        
        
        double Omegaapp_Pointer[(Msparemax)*nProcesses];
        Vector <double> Omegaapp((Msparemax)*nProcesses,Omegaapp_Pointer);
        
        
        int ncol = BAcc[i_IndexEqual].nCols;
        int nrow = BAcc[i_IndexEqual].nRows;
        if((ncol!=0)&(nrow!=0))
        {
            for(int j=0;j<Neigh[iobs].size();j++)
            {
                for(int k=0;k<nrow;k++)
                {
                    Omegaapp.Pvec(j*nrow+k)[0] = OmegaPass->vec(Neigh[iobs][j]*nrow+k);
                }
                
            }
            F77_NAME(dgemv)("T",  &ncol, &nrow, &Class_ToLoad::Done, BAcc[i_IndexEqual].P,  &ncol, Omegaapp.P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, ret->P, &Class_ToLoad::Ione);
            
        }else{
            for(int k=0;k<nProcesses;k++)
            {
                ret->Pvec(k)[0] = 0.0;
            }
        }
        
        
        
        
    }
    
    void compute_ParametersConditionalDensity_ZeroMean(int iobs,  Vector <double> *mu, Matrix <double> *var,  Vector <double> *Y, int retChol,int retInv)
    {
        if(var->nCols>1)
        {
            error("compute_ParametersConditionalDensityMulti_NoZeroMean, il codice vale solo per dimensione 1, controllar bene quando è >1");
        }
        //mu->Print("mu");
        //var->Print("var");
        compute_ParametersConditionalDensity_ZeroMean_NoMolt(iobs,  mu, var, Y);
        double VarInv_P[var->nCols*var->nCols];
        Matrix<double>VarInv(var->nCols,var->nCols,&VarInv_P[0]);
        if(retInv==1)
        {
            for(int i=0;i<var->nCols;i++)
            {
                for(int j=i;j<var->nCols;j++)
                {
                    VarInv.Pmat(i,j)[0] = var->mat(i,j);
                }
            }
        }
        //mu->Print("mu2");
        //var->Print("var2");
        Class_MultivariateNormal::external_finalizedRegFullConditional(var,mu, retChol);
        if(retInv==1)
        {
            for(int i=0;i<var->nCols;i++)
            {
                for(int j=i;j<var->nCols;j++)
                {
                    var->Pmat(i,j)[0] = VarInv.mat(i,j);
                }
            }
        }
        //mu->Print("mu3");
        //var->Print("var3");
    }
    void compute_ParametersConditionalDensity_ZeroMean_NoMolt(int iobs,  Vector <double> *mu, Matrix <double> *var,  Vector <double> *Y)
    {
        //Y ha media o
        int nProcesses = CovMat[0]->SigmaAcc.nRows;
        
        double Muapp_Pointer[nProcesses];
        Vector <double> Muapp(nProcesses,Muapp_Pointer);
        
        double Muapp2_Pointer[nProcesses];
        Vector <double> Muapp2(nProcesses,Muapp2_Pointer);
        
        double Sigmaapp_Pointer[nProcesses*nProcesses];
        Matrix <double> Sigmaapp(nProcesses,nProcesses,Sigmaapp_Pointer);
        
        double Omegaapp_Pointer[(Msparemax)*nProcesses];
        Vector <double> Omegaapp((Msparemax)*nProcesses,Omegaapp_Pointer);
        
        
        
        double OmegaappObs_Pointer[(Msparemax)*nProcesses];
        Vector <double> OmegaappObs((Msparemax)*nProcesses,OmegaappObs_Pointer);
        
        
        double Bplus_Pointer[nProcesses*nProcesses];
        Matrix <double> Bplus(nProcesses,nProcesses,Bplus_Pointer);
        //        double BplusApp_Pointer[nProcesses];
        //        Vector <double> BplusApp(nProcesses,BplusApp_Pointer);
        
        
        // double appvar;
        
        
        int i_IndexEqual;
        int j_IndexEqual;
        if(VecEqual->vec(iobs)<0)
        {
            i_IndexEqual = iobs;
        }else{
            i_IndexEqual = VecEqual->vec(iobs);
        }
        
        
        // prendo dalla sua distribuzione condizionata
        
        int ncol = BAcc[i_IndexEqual].nCols;
        int nrow = BAcc[i_IndexEqual].nRows;
        
        //REprintf("N %i %i \n",ncol,nrow);
        if( (ncol!=0)&(nrow!=0))
        {
            for(int j=0;j<Neigh[iobs].size();j++)
            {
                for(int k=0;k<nrow;k++)
                {
                    Omegaapp.Pvec(j*nrow+k)[0] = Y->vec(Neigh[iobs][j]*nrow+k);
                }
                
            }
            F77_NAME(dgemv)("T",  &ncol, &nrow, &Class_ToLoad::Done, BAcc[i_IndexEqual].P,  &ncol, Omegaapp.P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, Muapp.P, &Class_ToLoad::Ione);
            
        }else{
            for(int k=0;k<nProcesses;k++)
            {
                Muapp.Pvec(k)[0] = 0.0;
            }
        }
       // Muapp.Print("Muapp1");
        
        
        Class_Utils::external_dsymv_MatMoltX(&CovMat[i_IndexEqual]->SigmaInvAcc, &Muapp, &Muapp2);
        for(int i=0;i<CovMat[i_IndexEqual]->SigmaInvAcc.nRows;i++)
        {
            for(int j=i;j<CovMat[i_IndexEqual]->SigmaInvAcc.nCols;j++)
            {
                var->Pmat(i,j)[0] = CovMat[i_IndexEqual]->SigmaInvAcc.mat(i,j);
            }
            mu->Pvec(i)[0] = Muapp2.vec(i);
        }
        //mu->Print("Mu");
        //var->Print("Vac");
        
        
        
        // prendo da quelle in cui omega è covariata
        //        int pos;
        //        int jrev;
        for(int jrev2 = 0;jrev2<NeighRev[iobs].size() ;jrev2++)
        {
            
            int jrev    = NeighRev[iobs][jrev2];
            int pos     = PosNeighRev[iobs][jrev2];
            
            //REprintf("NEIGinv %i %i %i\n",iobs ,jrev, pos);
            
            if(VecEqual->vec(jrev)<0)
            {
                j_IndexEqual = jrev;
            }else{
                j_IndexEqual = VecEqual->vec(jrev);
            }
            
            
            for(int k=0;k<nProcesses;k++)
            {
                OmegaappObs.Pvec(k)[0] = Y->vec(jrev*nProcesses+k);
            }
            ncol = BAcc[j_IndexEqual].nCols;
            nrow = BAcc[j_IndexEqual].nRows;
            for(int j=0;j<Neigh[jrev].size();j++)
            {
                for(int k=0;k<nrow;k++)
                {
                    Omegaapp.Pvec(j*nrow+k)[0] = Y->vec(Neigh[jrev][j]*nrow+k);
                }
            }
            F77_NAME(dgemv)("T",  &ncol, &nrow, &Class_ToLoad::Done, BAcc[j_IndexEqual].P,  &ncol, Omegaapp.P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, Muapp.P, &Class_ToLoad::Ione);
            
            //BAcc[j_IndexEqual].Print("Bacc");
            //Omegaapp.Print("Omega Neig");
            //Muapp.Print("B*omega");
            
            for(int k=0;k<nProcesses;k++)
            {
                for(int kk=0;kk<nProcesses;kk++)
                {
                    Bplus.Pmat(k,kk)[0] = BAcc[j_IndexEqual].mat(k,pos*nProcesses+kk);
                }
            }
            //Bplus.Print("B[j]");
            for(int k=0;k<nProcesses;k++)
            {
                
                Muapp2.Pvec(k)[0]    = OmegaappObs.vec(k)-Muapp.vec(k);
            }
            //Muapp2.Print("Omega[j]-B*omega");
            for(int k=0;k<nProcesses;k++)
            {
                for(int kk=0;kk<nProcesses;kk++)
                {
                    Muapp2.Pvec(k)[0] += Bplus.mat(k,kk)*Y->vec(iobs*nProcesses+kk);
                }
            }
            //Muapp2.Print("Muapp2");
            Class_MultivariateNormal::external_ParametersForFullConditioanlBeta_WithoutMolt(&Bplus, &CovMat[j_IndexEqual]->SigmaInvAcc, &Muapp2, &Sigmaapp, &Muapp, 0.0);
            for(int i=0;i<CovMat[i_IndexEqual]->SigmaInvAcc.nRows;i++)
            {
                for(int j=i;j<CovMat[i_IndexEqual]->SigmaInvAcc.nCols;j++)
                {
                    var->Pmat(i,j)[0] += Sigmaapp.mat(i,j);
                }
                mu->Pvec(i)[0] += Muapp.vec(i);
            }
            //mu->Print("Mu");
            //var->Print("Vac");
            //error("s");
            
        }
        
        
        //        for(int i=0;i<CovMat[i_IndexEqual]->SigmaInvAcc.nRows;i++)
        //        {
        //            Muapp.Pvec(i)[0] = mu->Pvec(i)[0];
        //        }
        //        int info;
        //        F77_NAME(dpotrf)("L",&nProcesses, var->Pmat(0,0), &nProcesses, &info);
        //        if(info != 0)
        //        {
        //            error("Cpp error Cholesky failed - function: compute_ParametersConditionalDensityMulti\n");
        //        }
        //        F77_NAME(dpotri)("L",&nProcesses,var->Pmat(0,0), &nProcesses, &info);
        //        if(info != 0)
        //        {
        //            error("Cpp error Cholesky inverse - function: compute_ParametersConditionalDensityMulti\n");
        //        }
        //
        //        Class_Utils::external_dsymv_MatMoltX(var, &Muapp, mu);
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    /*********** UNTESTED FUNCTION*************/
    
    
    
    
    
    
    
    // compute
    
    double compute_logdensity_forCovParAccMulti_UNTESTED(Vector <double> *Y)
    {
        // Y è il GP com media nulla
        double ret = 0.0;

        const double    Dzero          = 0.0;
        const double    Done          = 1.0;

        const int       Ione          = 1;


        int nrow;
        int ncol;

        nrow = CovMat[0]->SigmaAcc.nRows;

        double Muapp_Pointer[nrow];
        double Omegaapp_Pointer[(Msparemax+1)*nrow];

        Vector <double> Muapp(nrow,Muapp_Pointer);
        Vector <double> Omegaapp((Msparemax+1)*nrow,Omegaapp_Pointer);

        int isame;
        for(int i=0;i<Nobs;i++)
        {
            if(VecEqual->vec(i)<0)
            {
                isame = i;
            }else{
                isame = VecEqual->vec(i);
            }
            //REprintf("Iter %i ",i);
            ncol = BAcc[isame].nCols;
            //nrow = BProp[i].nRows;
            if((ncol!=0)&(nrow!=0))
            {

                for(int j=0;j<Neigh[i].size();j++)
                {
                    for(int k=0;k<nrow;k++)
                    {
                        Omegaapp.Pvec(j*nrow+k)[0] = Y->vec(Neigh[i][j]*nrow+k);
                    }
                }

                F77_NAME(dgemv)("T",  &ncol, &nrow, &Done, BAcc[isame].P,  &ncol, Omegaapp.P, &Ione, &Dzero, Muapp.P, &Ione);
                ret += Class_MultivariateNormal::external_compute_LogDensity_forCovMat(nrow, Y->Pvec(i*nrow),Muapp.P , CovMat[isame][0].SigmaInvAcc.P,&CovMat[isame][0].logdeterminantAcc);

            }else{
                for(int j=0;j<nrow;j++)
                {
                    Muapp.Pvec(j)[0] = 0.0;
                }
                ret += Class_MultivariateNormal::external_compute_LogDensity_forCovMat(nrow, Y->Pvec(i*nrow),Muapp.P , CovMat[isame][0].SigmaInvAcc.P,&CovMat[isame][0].logdeterminantAcc);

            }


        }

        return(ret);
    }
    
    
    
    
    void compute_ParametersConditionalDensityMulti_NoZeroMean_UNTESTED(int iobs,Vector <double> *mu, Matrix <double> *var, int retChol, int retInv)
    {
        if(var->nCols>1)
        {
            error("compute_ParametersConditionalDensityMulti_NoZeroMean, il codice vale solo per dimensione 1, controllar bene quando è >1");
        }
        compute_ParametersConditionalDensityMulti_NoZeroMean_NoMolt_UNTESTED(iobs,mu,var);
        double VarInv_P[var->nCols*var->nCols];
        Matrix<double>VarInv(var->nCols,var->nCols,&VarInv_P[0]);
        if(retInv==1)
        {
            for(int i=0;i<var->nCols;i++)
            {
                for(int j=i;j<var->nCols;j++)
                {
                    VarInv.Pmat(i,j)[0] = var->mat(i,j);
                }
            }
        }
        Class_MultivariateNormal::external_finalizedRegFullConditional(var,mu, retChol);
        for(int i=0;i<var->nCols;i++)
        {
            //mu->Pvec(i)[0] = mu->vec(i)+Mean.vec(iobs);
            mu->Pvec(i)[0] = mu->vec(i)+Mean.vec(iobs*var->nCols+i);
        }
        if(retInv==1)
        {
            for(int i=0;i<var->nCols;i++)
            {
                for(int j=i;j<var->nCols;j++)
                {
                    var->Pmat(i,j)[0] = VarInv.mat(i,j);
                }
            }
        }
    }
    
    void compute_ParametersConditionalDensityMulti_NoZeroMean_NoMolt_UNTESTED(int iobs,Vector <double> *mu, Matrix <double> *var)
    {
        double Y_P[Omega.nElem];
        Vector <double>Y(Omega.nElem,Y_P);
        for(int i=0;i<Omega.nElem;i++)
        {
            Y.Pvec(i)[0] = Omega.vec(i)-Mean.vec(i);
        }
        compute_ParametersConditionalDensity_ZeroMean_NoMolt(iobs, mu, var,  &Y);

    }
    
  
    
    
    
    
   
    
    
     /*************************
     VESIONE M1 per logistic normal
    **************************/
     void create_FullObject_DimMinusOne(Vector <int> *EqualDist, Matrix<int> *NeighMat, int nobs,  Vector<double> *omega, vector<Poly_CovCorFunction*>  *covfunc, int usr, Matrix <double>  *coords, string Choice_Coregionalization, Class_Parameter_PDMatrixUnivSamp       *CoregSigmaMCMC)
     {
         // attenzione!!! Dovrebbe funzionare anche con cpace-time, ma va controlato bene
         UserControlledMemory        = usr;
         Omega                       = Vector<double> (omega->nElem,omega->P);
         Dimension                   = omega[0].nElem;
         Nobs                        = nobs;
         //DimCoreg            = dimK;
         //MeanVector                  = meanvector;
         Msparemax                   = NeighMat->nCols;
         
         
         
         // COREGIONALIZATION TYPE
         if(Choice_Coregionalization=="Cholesky")
         {
         for(int i=0;i<Nobs;i++)
         {
         CovMat.push_back(new Class_MatrixCoreg_Chol);
         }
         //CovMat = new Class_MatrixCoreg_Chol;
         }else{
         if(Choice_Coregionalization=="Spectral")
         {
         for(int i=0;i<Nobs;i++)
         {
         CovMat.push_back(new Class_MatrixCoreg_Spectral);
         }
         }else{
         error("Coregionalization not well specified in Class_Gaussian_TempNNGP_Multvariate\n");
         }
         }
         
         for(int i=0;i<Nobs;i++)
         {
         Neigh.push_back(vector<int>());
         NeighRev.push_back(vector<int>());
         PosNeighRev.push_back(vector<int>());
         
         
         }
         
         double CoordsApp[(Msparemax+1)*coords->nCols];
         Matrix <double> AppCoord(Msparemax+1,coords->nCols,CoordsApp);
         
         //int init;
         //int i= 0;
         //init = max(0,i-Msparemax);
         
         int i = 0;
         int pos=0;
         for(int j=0;j<Msparemax;j++)
         {
             if(NeighMat[0].mat(i,j)>(-1))
             {
                 Neigh[i].push_back(NeighMat[0].mat(i,j));
                 NeighRev[NeighMat[0].mat(i,j)].push_back(i);
                 PosNeighRev[NeighMat[0].mat(i,j)].push_back(pos);
                 for(int t=0;t<coords->nCols;t++)
                 {
                  AppCoord.Pmat(pos,t)[0] = coords->mat(NeighMat[0].mat(i,j),t);
                 }
                 pos ++;
             }
         }
         for(int t=0;t<coords->nCols;t++)
         {
             AppCoord.Pmat(pos,t)[0] = coords->mat(i,t);
         }
         //CovMat[i]->create_objectSpaceOrTimeKC(min(i,Msparemax),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord);
         //CovMat[i]->create_objectSpaceOrTimeKC((int)Neigh[i].size(),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord);
         CovMat[i]->create_object_DimMinusOne((int)Neigh[i].size(),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord);
         
         BAcc.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,UserControlledMemory));
         BProp.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,UserControlledMemory));
         
         
         for(i=1;i<Nobs;i++)
         {
             pos = 0;
             for(int j=0;j<Msparemax;j++)
             {
                 if(NeighMat[0].mat(i,j)>(-1))
                 {
                     Neigh[i].push_back(NeighMat[0].mat(i,j));
                     NeighRev[NeighMat[0].mat(i,j)].push_back(i);
                     PosNeighRev[NeighMat[0].mat(i,j)].push_back(pos);
                     for(int t=0;t<coords->nCols;t++)
                     {
                         AppCoord.Pmat(pos,t)[0] = coords->mat(NeighMat[0].mat(i,j),t);
                     }
                    pos ++;
                 }
             }
             for(int t=0;t<coords->nCols;t++)
             {
              AppCoord.Pmat(pos,t)[0] = coords->mat(i,t);
             }
             //CovMat[i]->create_objectSpaceOrTimeKC(min(i,Msparemax),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord,CovMat[0]->TjAcc,CovMat[0]->TjProp);
             
             if(EqualDist->vec(i)<0)
             {
             //CovMat[i]->create_objectSpaceOrTimeKC((int)Neigh[i].size(),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord,CovMat[0]->TjAcc,CovMat[0]->TjProp);
             
                 CovMat[i]->create_object_DimMinusOne((int)Neigh[i].size(),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord,CovMat[0]->TjAcc,CovMat[0]->TjProp);
             
             
             BAcc.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,UserControlledMemory));
             BProp.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,UserControlledMemory));
             }else{
             CovMat[i] = CovMat[EqualDist->vec(i)];
             BAcc.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,BAcc[EqualDist->vec(i)].P));
             BProp.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,BProp[EqualDist->vec(i)].P));
             }
         
         
         }
    }
    void update_BFAcc_DimMinusOne(Vector <int> *Element);
    void update_BFProp_DimMinusOne(Vector <int> *Element);
    
    
    
    
};
class Class_Gaussian_NNGP_Multivariate
{
    // USARE LE V2
private:
    
public:
    int UserControlledMemory;
    int Nobs;
    //int DimCoreg; // della coregionalizzazion
    int Dimension;
    int Msparemax;
    // sarebbe meglio chiamarla dimensiona
    Vector<double>                  Omega;
    //Mean_ToPass*                    MeanVector;
    vector<CoregMatrixNNGP*>        CovMat; // sarebbe la F
    vector<Matrix<double> >         BAcc;
    vector<Matrix<double> >         BProp;
    
    Vector<double>  Mean;
    Vector<double>  MeanProp;
    Matrix<double>  *Covariates;
    VectorParameters  *RegVec;
    
    Class_MultivariateNormal*   Distributions;
    
    
    vector <vector <int> > Neigh;
    vector <vector <int> > NeighRev;
    vector <vector <int> > PosNeighRev;
    
    
    
    
    //COSTRUCCTORS
    Class_Gaussian_NNGP_Multivariate(){}
    
    // DESTRUCTORS
    ~Class_Gaussian_NNGP_Multivariate(){}
    void Destroy()
    {
        Omega.Destroy();
        
        for(int i=0;i<CovMat.size();i++)
        {
            CovMat[i]->Destory();
        }
        
        for(int i=0;i<BAcc.size();i++)
        {
            BAcc[i].Destroy();
            BProp[i].Destroy();
        }
        //CovarianceMatrix->Destroy();
        //MeanVector->Destroy();
    }
    void add_RegMean(Matrix<double>  *Cov, VectorParameters  *Reg)
    {
        
        Covariates = Cov;
        RegVec = Reg;
        Mean = Vector<double>(Covariates->nRows,1);
        MeanProp = Vector<double>(Covariates->nRows,1);
        compute_MeanAcc();
    }

//VectorAcc
    void compute_MeanAcc()
    {
        compute_Mean(&Mean,&RegVec->VectorAcc);
    }
    void compute_MeanProp()
    {
        compute_Mean(&MeanProp,&RegVec->VectorProp);
    }
    void compute_Mean(Vector<double> *M,Vector<double>  *Reg)
    {
        Class_Utils::external_dgemv(Covariates, Reg, M, 0.0);
    }
    void sample_MeanNormalPriorReg()
    {
        
    }

    void create_FullObject_DimMinusOne(Vector <int> *EqualDist, Matrix<int> *NeighMat, int nobs,  Vector<double> *omega, vector<Poly_CovCorFunction*>  *covfunc, int usr, Matrix <double>  *coords, string Choice_Coregionalization, Class_Parameter_PDMatrixUnivSamp       *CoregSigmaMCMC)
    {
        // attenzione!!! Dovrebbe funzionare anche con cpace-time, ma va controlato bene
        UserControlledMemory        = usr;
        Omega                       = Vector<double> (omega->nElem,omega->P);
        Dimension                   = omega[0].nElem;
        Nobs                        = nobs;
        //DimCoreg            = dimK;
        //MeanVector                  = meanvector;
        Msparemax                   = NeighMat->nCols;
        
        
        
        // COREGIONALIZATION TYPE
        if(Choice_Coregionalization=="Cholesky")
        {
            for(int i=0;i<Nobs;i++)
            {
                CovMat.push_back(new Class_MatrixCoreg_Chol);
            }
            //CovMat = new Class_MatrixCoreg_Chol;
        }else{
            if(Choice_Coregionalization=="Spectral")
            {
                for(int i=0;i<Nobs;i++)
                {
                    CovMat.push_back(new Class_MatrixCoreg_Spectral);
                }
            }else{
                error("Coregionalization not well specified in Class_Gaussian_TempNNGP_Multvariate\n");
            }
        }
        
        for(int i=0;i<Nobs;i++)
        {
            Neigh.push_back(vector<int>());
            NeighRev.push_back(vector<int>());
            PosNeighRev.push_back(vector<int>());
            
            
        }
        
        double CoordsApp[(Msparemax+1)*coords->nCols];
        Matrix <double> AppCoord(Msparemax+1,coords->nCols,CoordsApp);
        
        //int init;
        //int i= 0;
        //init = max(0,i-Msparemax);
        
        int i = 0;
        int pos=0;
        for(int j=0;j<Msparemax;j++)
        {
            if(NeighMat[0].mat(i,j)>(-1))
            {
                Neigh[i].push_back(NeighMat[0].mat(i,j));
                NeighRev[NeighMat[0].mat(i,j)].push_back(i);
                PosNeighRev[NeighMat[0].mat(i,j)].push_back(pos);
                for(int t=0;t<coords->nCols;t++)
                {
                    AppCoord.Pmat(pos,t)[0] = coords->mat(NeighMat[0].mat(i,j),t);
                }
                pos ++;
            }
        }
        for(int t=0;t<coords->nCols;t++)
        {
            AppCoord.Pmat(pos,t)[0] = coords->mat(i,t);
        }
        //CovMat[i]->create_objectSpaceOrTimeKC(min(i,Msparemax),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord);
        //CovMat[i]->create_objectSpaceOrTimeKC((int)Neigh[i].size(),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord);
        CovMat[i]->create_object_DimMinusOne((int)Neigh[i].size(),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord);
        
        BAcc.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,UserControlledMemory));
        BProp.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,UserControlledMemory));
        
        
        for(i=1;i<Nobs;i++)
        {
            pos = 0;
            for(int j=0;j<Msparemax;j++)
            {
                if(NeighMat[0].mat(i,j)>(-1))
                {
                    Neigh[i].push_back(NeighMat[0].mat(i,j));
                    NeighRev[NeighMat[0].mat(i,j)].push_back(i);
                    PosNeighRev[NeighMat[0].mat(i,j)].push_back(pos);
                    for(int t=0;t<coords->nCols;t++)
                    {
                        AppCoord.Pmat(pos,t)[0] = coords->mat(NeighMat[0].mat(i,j),t);
                    }
                    pos ++;
                }
            }
            for(int t=0;t<coords->nCols;t++)
            {
                AppCoord.Pmat(pos,t)[0] = coords->mat(i,t);
            }
            //CovMat[i]->create_objectSpaceOrTimeKC(min(i,Msparemax),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord,CovMat[0]->TjAcc,CovMat[0]->TjProp);
            
            if(EqualDist->vec(i)<0)
            {
                //CovMat[i]->create_objectSpaceOrTimeKC((int)Neigh[i].size(),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord,CovMat[0]->TjAcc,CovMat[0]->TjProp);
                
                CovMat[i]->create_object_DimMinusOne((int)Neigh[i].size(),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord,CovMat[0]->TjAcc,CovMat[0]->TjProp);
                
                
                BAcc.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,UserControlledMemory));
                BProp.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,UserControlledMemory));
            }else{
                CovMat[i] = CovMat[EqualDist->vec(i)];
                BAcc.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,BAcc[EqualDist->vec(i)].P));
                BProp.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,BProp[EqualDist->vec(i)].P));
            }
            
            
        }
    }
    
    
   
    void create_FullObject(Vector <int> *EqualDist, Matrix<int> *NeighMat, int nobs,  Vector<double> *omega, vector<Poly_CovCorFunction*>  *covfunc, int usr, Matrix <double>  *coords, string Choice_Coregionalization, Class_Parameter_PDMatrixUnivSamp       *CoregSigmaMCMC)
    {
        //REprintf("Print_Gaus1_1\n");
        // in base alla dimensione delle coordinat decidono se space time o spacetime
        UserControlledMemory        = usr;
        Omega                       = Vector<double> (omega->nElem,omega->P);
        Dimension                   = omega[0].nElem;
        Nobs                        = nobs;
        Msparemax                   = NeighMat->nCols;
       // MeanVector                  = meanvector;
        
        //REprintf("Print_Gaus1_2\n");
        // COREGIONALIZATION TYPE
        if(Choice_Coregionalization=="Cholesky")
        {
            for(int i=0;i<Nobs;i++)
            {
                CovMat.push_back(new Class_MatrixCoreg_Chol);
            }
            //CovMat = new Class_MatrixCoreg_Chol;
        }else{
            if(Choice_Coregionalization=="Spectral")
            {
                for(int i=0;i<Nobs;i++)
                {
                    CovMat.push_back(new Class_MatrixCoreg_Spectral);
                }
            }else{
                error("Coregionalization not well specified in Class_Gaussian_TempNNGP_Multvariate\n");
            }
        }
        //REprintf("Print_Gaus1_3\n");
        for(int i=0;i<Nobs;i++)
        {
            Neigh.push_back(vector<int>());
            NeighRev.push_back(vector<int>());
            PosNeighRev.push_back(vector<int>());
            
            
        }
        //REprintf("Print_Gaus1_4\n");
        double CoordsApp[(Msparemax+1)*coords->nCols];
        Matrix <double> AppCoord(Msparemax+1,coords->nCols,CoordsApp);
        
        //REprintf("Print_Gaus1_5\n");
        int i = 0;
        int pos=0;
        for(int j=0;j<Msparemax;j++)
        {
            if(NeighMat[0].mat(i,j)>(-1))
            {
                Neigh[i].push_back(NeighMat[0].mat(i,j));
                NeighRev[NeighMat[0].mat(i,j)].push_back(i);
                PosNeighRev[NeighMat[0].mat(i,j)].push_back(pos);
                for(int t=0;t<coords->nCols;t++)
                {
                    AppCoord.Pmat(pos,t)[0] = coords->mat(NeighMat[0].mat(i,j),t);
                }
                pos ++;
            }
        }
        //REprintf("Print_Gaus1_6\n");
        for(int t=0;t<coords->nCols;t++)
        {
            AppCoord.Pmat(pos,t)[0] = coords->mat(i,t);
        }
        //CovMat[i]->create_object(min(i,Msparemax),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord);
        CovMat[i]->create_object((int)Neigh[i].size(),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord);
        BAcc.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,UserControlledMemory));
        BProp.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,UserControlledMemory));
        
        //REprintf("Print_Gaus1_7\n");
        for(i=1;i<Nobs;i++)
        {
            pos = 0;
            for(int j=0;j<Msparemax;j++)
            {
                if(NeighMat[0].mat(i,j)>(-1))
                {
                    Neigh[i].push_back(NeighMat[0].mat(i,j));
                    NeighRev[NeighMat[0].mat(i,j)].push_back(i);
                    PosNeighRev[NeighMat[0].mat(i,j)].push_back(pos);
                    for(int t=0;t<coords->nCols;t++)
                    {
                        AppCoord.Pmat(pos,t)[0] = coords->mat(NeighMat[0].mat(i,j),t);
                    }
                    pos ++;
                }
            }
            for(int t=0;t<coords->nCols;t++)
            {
                AppCoord.Pmat(pos,t)[0] = coords->mat(i,t);
            }
            
            //CovMat[i]->create_object(min(i,Msparemax),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord,CovMat[0]->TjAcc,CovMat[0]->TjProp);
            
            
            
            if(EqualDist->vec(i)<0)
            {
                // fare attenzione quando si cambi al'indirizzo accettato propostop, perchè quello che non hanno l'originale non gli viene cambiato, vale per Tj
                CovMat[i]->create_object((int)Neigh[i].size(),CoregSigmaMCMC,covfunc, UserControlledMemory,&AppCoord,CovMat[0]->TjAcc,CovMat[0]->TjProp);
                BAcc.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,UserControlledMemory));
                BProp.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,UserControlledMemory));
                
            }else{
                CovMat[i] = CovMat[EqualDist->vec(i)];
                BAcc.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,BAcc[EqualDist->vec(i)].P));
                BProp.push_back(Matrix<double>(CovMat[i]->SigmaInvAcc.nRows,(int)Neigh[i].size()*CovMat[i]->SigmaInvAcc.nRows,BProp[EqualDist->vec(i)].P));
            }
            
            
        }
        
        //REprintf("Print_Gaus1_8\n");
        
    }
    
    

    
    
    void update_BFAcc_DimMinusOne(Vector <int> *Element);
    void update_BFProp_DimMinusOne(Vector <int> *Element);
    
    void update_BFAcc(Vector <int> *Element);
    void update_BFProp(Vector <int> *Element);

    
    
    
    // compute
    double compute_logdensity_forCovParAcc(Vector <int> *EqualDist)
    {
        double ret = 0.0;
        
        const double    Dzero          = 0.0;
        const double    Done          = 1.0;
        
        const int       Ione          = 1;
        
        
        int nrow;
        int ncol;
        
        nrow = CovMat[0]->SigmaAcc.nRows;
        
        double Muapp_Pointer[nrow];
        double Omegaapp_Pointer[(Msparemax+1)*nrow];
        
        Vector <double> Muapp(nrow,Muapp_Pointer);
        Vector <double> Omegaapp((Msparemax+1)*nrow,Omegaapp_Pointer);
        
        int isame;
        for(int i=0;i<Nobs;i++)
        {
            if(EqualDist->vec(i)<0)
            {
                isame = i;
            }else{
                isame = EqualDist->vec(i);
            }
            //REprintf("Iter %i ",i);
            ncol = BAcc[isame].nCols;
            //nrow = BProp[i].nRows;
            if((ncol!=0)&(nrow!=0))
            {
                
                for(int j=0;j<Neigh[i].size();j++)
                {
                    for(int k=0;k<nrow;k++)
                    {
                        Omegaapp.Pvec(j*nrow+k)[0] = Omega.vec(Neigh[i][j]*nrow+k);
                    }
                }
                
                F77_NAME(dgemv)("T",  &ncol, &nrow, &Done, BAcc[isame].P,  &ncol, Omegaapp.P, &Ione, &Dzero, Muapp.P, &Ione);
                ret += Class_MultivariateNormal::external_compute_LogDensity_forCovMat(nrow, Omega.Pvec(i*nrow),Muapp.P , CovMat[isame][0].SigmaInvAcc.P,&CovMat[isame][0].logdeterminantAcc);
                
            }else{
                for(int j=0;j<nrow;j++)
                {
                    Muapp.Pvec(j)[0] = 0.0;
                }
                ret += Class_MultivariateNormal::external_compute_LogDensity_forCovMat(nrow, Omega.Pvec(i*nrow),Muapp.P , CovMat[isame][0].SigmaInvAcc.P,&CovMat[isame][0].logdeterminantAcc);
                
            }
            
            
        }
        
        return(ret);
    }
    double compute_logdensity_forCovParProp(Vector <int> *EqualDist)
    {
        double ret = 0.0;
        
        const double    Dzero          = 0.0;
        const double    Done          = 1.0;
        
        const int       Ione          = 1;
        
        
        int nrow;
        int ncol;
        
        nrow = CovMat[0]->SigmaProp.nRows;
        
        double Muapp_Pointer[nrow];
        double Omegaapp_Pointer[(Msparemax+1)*nrow];
        
        Vector <double> Muapp(nrow,Muapp_Pointer);
        Vector <double> Omegaapp((Msparemax+1)*nrow,Omegaapp_Pointer);
        
        int isame;
        for(int i=0;i<Nobs;i++)
        {
            if(EqualDist->vec(i)<0)
            {
                isame = i;
            }else{
                isame = EqualDist->vec(i);
            }
            // REprintf("Iter %i ",i);
            ncol = BProp[isame].nCols;
            //nrow = BAcc[i].nRows;
            if((ncol!=0)&(nrow!=0))
            {
                
                for(int j=0;j<Neigh[i].size();j++)
                {
                    for(int k=0;k<nrow;k++)
                    {
                        Omegaapp.Pvec(j*nrow+k)[0] = Omega.vec(Neigh[i][j]*nrow+k);
                    }
                }
                
                F77_NAME(dgemv)("T",  &ncol, &nrow, &Done, BProp[isame].P,  &ncol, Omegaapp.P, &Ione, &Dzero, Muapp.P, &Ione);
                ret += Class_MultivariateNormal::external_compute_LogDensity_forCovMat(nrow, Omega.Pvec(i*nrow),Muapp.P , CovMat[isame][0].SigmaInvProp.P,&CovMat[isame][0].logdeterminantProp);
                
            }else{
                for(int j=0;j<nrow;j++)
                {
                    Muapp.Pvec(j)[0] = 0.0;
                }
                ret += Class_MultivariateNormal::external_compute_LogDensity_forCovMat(nrow, Omega.Pvec(i*nrow),Muapp.P , CovMat[isame][0].SigmaInvProp.P,&CovMat[isame][0].logdeterminantProp);
            }
            
            // REprintf(" %f\n",ret);
        }
        
        return(ret);
    }
    
    
    
//    void compute_logdensity_forBetaReg(Vector <int> *EqualDist,  Matrix <double> *Covariates, Vector <double> *MeanBeta, Matrix <double> *VarBeta)
//    {
//        
//        
//    }
    
    
    
//    void UpdateIfAccepted()
//    {
//        double *app;
//        for(int k=0;k<CovMat[0]->TjAcc[0].size();k++)
//        {
//            app                           = CovMat[0]->TjAcc[0][k].P;
//            CovMat[0]->TjAcc[0][k].P      = CovMat[0]->TjProp[0][k].P;;
//            CovMat[0]->TjProp[0][k].P     = app;
//            
//        }
//        
//        CovMat[0]->ParSigmaCoreg->UpdateIfAccepted();
//        // F
//        for(int i=0;i<Nobs;i++)
//        {
//            CovMat[i]->UpdateIfAcceptedNoSigmaCoregNoTj();
//        }
//        // B
//        for(int i=0;i<Nobs;i++)
//        {
//            app                             = BAcc[i].P;
//            BAcc[i].P                       = BProp[i].P;;
//            BProp[i].P                      = app;
//        }
//    }
    void UpdateIfAccepted(Vector<int> *Element)
    {
        double *app;
        for(int k=0;k<CovMat[0]->TjAcc[0].size();k++)
        {
            app                           = CovMat[0]->TjAcc[0][k].P;
            CovMat[0]->TjAcc[0][k].P      = CovMat[0]->TjProp[0][k].P;;
            CovMat[0]->TjProp[0][k].P     = app;
            
        }
        
        CovMat[0]->ParSigmaCoreg->UpdateIfAcceptedNoChol();
        // F
        int i;
        for(int iii2=0;iii2<Element->nElem;iii2++)
        {
            i = Element->vec(iii2);
            CovMat[i]->UpdateIfAcceptedNoSigmaCoregNoTj();
        }
        // B
        for(int iii2=0;iii2<Element->nElem;iii2++)
        {
            i = Element->vec(iii2);
            app                             = BAcc[i].P;
            BAcc[i].P                       = BProp[i].P;;
            BProp[i].P                      = app;
        }
    }
    
    
    void compute_ParametersConditionalDensityMulti(int iobs,  Vector <double> *mu, Matrix <double> *var, Vector<int> *iEqual)
    {
        // TEST livello medio - FUNZIONA
        // in un modello con k processi e un tot numero di ossrrvazioni NNGP, calcola la distribuzione condizionata
        // Omega ha mu=0
        int nProcesses = CovMat[0]->SigmaAcc.nRows;
        
        double Muapp_Pointer[nProcesses];
        Vector <double> Muapp(nProcesses,Muapp_Pointer);
        
        double Muapp2_Pointer[nProcesses];
        Vector <double> Muapp2(nProcesses,Muapp2_Pointer);
        
        double Sigmaapp_Pointer[nProcesses*nProcesses];
        Matrix <double> Sigmaapp(nProcesses,nProcesses,Sigmaapp_Pointer);
        
        double Omegaapp_Pointer[(Msparemax)*nProcesses];
        Vector <double> Omegaapp((Msparemax)*nProcesses,Omegaapp_Pointer);
        
        
        
        double OmegaappObs_Pointer[(Msparemax)*nProcesses];
        Vector <double> OmegaappObs((Msparemax)*nProcesses,OmegaappObs_Pointer);
        
        
        double Bplus_Pointer[nProcesses*nProcesses];
        Matrix <double> Bplus(nProcesses,nProcesses,Bplus_Pointer);
        //        double BplusApp_Pointer[nProcesses];
        //        Vector <double> BplusApp(nProcesses,BplusApp_Pointer);
        
        
        // double appvar;
        
        
        int i_IndexEqual;
        int j_IndexEqual;
        if(iEqual->vec(iobs)<0)
        {
            i_IndexEqual = iobs;
        }else{
            i_IndexEqual = iEqual->vec(iobs);
        }
        
        
        // prendo dalla sua distribuzione condizionata
        
        int ncol = BAcc[i_IndexEqual].nCols;
        int nrow = BAcc[i_IndexEqual].nRows;
        //REprintf("Neigh:\n");
        if((ncol!=0)&(nrow!=0))
        {
            for(int j=0;j<Neigh[iobs].size();j++)
            {
                for(int k=0;k<nrow;k++)
                {
                    Omegaapp.Pvec(j*nrow+k)[0] = Omega.vec(Neigh[iobs][j]*nrow+k);
                }
                
            }
            F77_NAME(dgemv)("T",  &ncol, &nrow, &Class_ToLoad::Done, BAcc[i_IndexEqual].P,  &ncol, Omegaapp.P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, Muapp.P, &Class_ToLoad::Ione);
            
        }else{
            for(int k=0;k<nProcesses;k++)
            {
                Muapp.Pvec(k)[0] = 0.0;
            }
        }
        
        
        
        Class_Utils::external_dsymv_MatMoltX(&CovMat[i_IndexEqual]->SigmaInvAcc, &Muapp, &Muapp2);
        for(int i=0;i<CovMat[i_IndexEqual]->SigmaInvAcc.nRows;i++)
        {
            for(int j=i;j<CovMat[i_IndexEqual]->SigmaInvAcc.nCols;j++)
            {
                var->Pmat(i,j)[0] = CovMat[i_IndexEqual]->SigmaInvAcc.mat(i,j);
            }
            mu->Pvec(i)[0] = Muapp2.vec(i);
        }
        
        
        
        // prendo da quelle in cui omega è covariata
//        int pos;
//        int jrev;
        for(int jrev2 = 0;jrev2<NeighRev[iobs].size() ;jrev2++)
        {
            int jrev    = NeighRev[iobs][jrev2];
            int pos     = PosNeighRev[iobs][jrev2];
            
            if(iEqual->vec(jrev)<0)
            {
                j_IndexEqual = jrev;
            }else{
                j_IndexEqual = iEqual->vec(jrev);
            }
            
            
            for(int k=0;k<nProcesses;k++)
            {
                OmegaappObs.Pvec(k)[0] = Omega.vec(jrev*nProcesses+k);
            }
            ncol = BAcc[j_IndexEqual].nCols;
            nrow = BAcc[j_IndexEqual].nRows;
            for(int j=0;j<Neigh[jrev].size();j++)
            {
                for(int k=0;k<nrow;k++)
                {
                    Omegaapp.Pvec(j*nrow+k)[0] = Omega.vec(Neigh[jrev][j]*nrow+k);
                }
            }
            F77_NAME(dgemv)("T",  &ncol, &nrow, &Class_ToLoad::Done, BAcc[j_IndexEqual].P,  &ncol, Omegaapp.P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, Muapp.P, &Class_ToLoad::Ione);
            
            
            for(int k=0;k<nProcesses;k++)
            {
                for(int kk=0;kk<nProcesses;kk++)
                {
                    Bplus.Pmat(k,kk)[0] = BAcc[j_IndexEqual].mat(k,pos*nProcesses+kk);
                }
            }
            for(int k=0;k<nProcesses;k++)
            {
                
                Muapp2.Pvec(k)[0]    = OmegaappObs.vec(k)-Muapp.vec(k);
            }
            for(int k=0;k<nProcesses;k++)
            {
                for(int kk=0;kk<nProcesses;kk++)
                {
                    Muapp2.Pvec(k)[0] += Bplus.mat(k,kk)*Omega.vec(iobs*nProcesses+kk);
                }
            }
            
            
            Class_RegMean::external_ParametersForFullConditioanlBeta_WithoutMolt(&Bplus, &CovMat[j_IndexEqual]->SigmaInvAcc, &Muapp2, &Sigmaapp, &Muapp);
            for(int i=0;i<CovMat[i_IndexEqual]->SigmaInvAcc.nRows;i++)
            {
                for(int j=i;j<CovMat[i_IndexEqual]->SigmaInvAcc.nCols;j++)
                {
                    var->Pmat(i,j)[0] += Sigmaapp.mat(i,j);
                }
                mu->Pvec(i)[0] += Muapp.vec(i);
            }
            
        }
        
        for(int i=0;i<CovMat[i_IndexEqual]->SigmaInvAcc.nRows;i++)
        {
            Muapp.Pvec(i)[0] = mu->Pvec(i)[0];
        }
        int info;
        F77_NAME(dpotrf)("L",&nProcesses, var->Pmat(0,0), &nProcesses, &info);
        if(info != 0)
        {
            error("Cpp error Cholesky failed - function: compute_ParametersConditionalDensityMulti\n");
        }
        F77_NAME(dpotri)("L",&nProcesses,var->Pmat(0,0), &nProcesses, &info);
        if(info != 0)
        {
            error("Cpp error Cholesky inverse - function: compute_ParametersConditionalDensityMulti\n");
        }
        
        Class_Utils::external_dsymv_MatMoltX(var, &Muapp, mu);
        
        
        
    }
    
    
    void compute_ParametersConditionalDensityMulti(int iobs,  Vector <double> *mu, Matrix <double> *var, Vector<int> *iEqual, Vector <double> *Xbeta)
    {
        // TEST livello medio - FUNZIONA
        // in un modello con k processi e un tot numero di ossrrvazioni NNGP, calcola la distribuzione condizionata
        // Omega ha mu=Xbeta
        int nProcesses = CovMat[0]->SigmaAcc.nRows;
        
        double Muapp_Pointer[nProcesses];
        Vector <double> Muapp(nProcesses,Muapp_Pointer);
        
        double Muapp2_Pointer[nProcesses];
        Vector <double> Muapp2(nProcesses,Muapp2_Pointer);
        
        double Sigmaapp_Pointer[nProcesses*nProcesses];
        Matrix <double> Sigmaapp(nProcesses,nProcesses,Sigmaapp_Pointer);
        
        double Omegaapp_Pointer[(Msparemax)*nProcesses];
        Vector <double> Omegaapp((Msparemax)*nProcesses,Omegaapp_Pointer);
        
        
        
        double OmegaappObs_Pointer[(Msparemax)*nProcesses];
        Vector <double> OmegaappObs((Msparemax)*nProcesses,OmegaappObs_Pointer);
        
        
        double Bplus_Pointer[nProcesses*nProcesses];
        Matrix <double> Bplus(nProcesses,nProcesses,Bplus_Pointer);
        //        double BplusApp_Pointer[nProcesses];
        //        Vector <double> BplusApp(nProcesses,BplusApp_Pointer);
        
        
        // double appvar;
        
        
        int i_IndexEqual;
        int j_IndexEqual;
        if(iEqual->vec(iobs)<0)
        {
            i_IndexEqual = iobs;
        }else{
            i_IndexEqual = iEqual->vec(iobs);
        }
        
        
        // prendo dalla sua distribuzione condizionata
        
        int ncol = BAcc[i_IndexEqual].nCols;
        int nrow = BAcc[i_IndexEqual].nRows;
        //REprintf("Neigh:\n");
        if((ncol!=0)&(nrow!=0))
        {
            for(int j=0;j<Neigh[iobs].size();j++)
            {
                for(int k=0;k<nrow;k++)
                {
                    Omegaapp.Pvec(j*nrow+k)[0] = Omega.vec(Neigh[iobs][j]*nrow+k)-Xbeta->vec(Neigh[iobs][j]*nrow+k);
                }                
            }
            F77_NAME(dgemv)("T",  &ncol, &nrow, &Class_ToLoad::Done, BAcc[i_IndexEqual].P,  &ncol, Omegaapp.P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, Muapp.P, &Class_ToLoad::Ione);
            
        }else{
            for(int k=0;k<nProcesses;k++)
            {
                Muapp.Pvec(k)[0] = 0.0;
            }
        }
        for(int k=0;k<nProcesses;k++)
        {
            Muapp.Pvec(k)[0] += Xbeta->vec(iobs*nProcesses+k);
        }
        
        
//        REprintf("Vicini di %i: ",iobs);
//        for(int j=0;j<Neigh[iobs].size();j++)
//        {
//            REprintf("%i ",Neigh[iobs][j]);
//        }
        
        
        
        Class_Utils::external_dsymv_MatMoltX(&CovMat[i_IndexEqual]->SigmaInvAcc, &Muapp, &Muapp2);
        for(int i=0;i<CovMat[i_IndexEqual]->SigmaInvAcc.nRows;i++)
        {
            for(int j=i;j<CovMat[i_IndexEqual]->SigmaInvAcc.nCols;j++)
            {
                var->Pmat(i,j)[0] = CovMat[i_IndexEqual]->SigmaInvAcc.mat(i,j);
            }
            mu->Pvec(i)[0] = Muapp2.vec(i);
        }
        //mu->Print("Mu1");
        
        
        // prendo da quelle in cui omega è covariata
//        int pos;
//        int jrev;
        for(int jrev2 = 0;jrev2<NeighRev[iobs].size() ;jrev2++)
        {
            int jrev    = NeighRev[iobs][jrev2];
            int pos     = PosNeighRev[iobs][jrev2];
            
            if(iEqual->vec(jrev)<0)
            {
                j_IndexEqual = jrev;
            }else{
                j_IndexEqual = iEqual->vec(jrev);
            }
            
            
            for(int k=0;k<nProcesses;k++)
            {
                OmegaappObs.Pvec(k)[0] = Omega.vec(jrev*nProcesses+k)-Xbeta->vec(jrev*nProcesses+k);
            }
            ncol = BAcc[j_IndexEqual].nCols;
            nrow = BAcc[j_IndexEqual].nRows;
            
            //BAcc[j_IndexEqual].Print("B");
            
            //REprintf("\nOM");
            for(int j=0;j<Neigh[jrev].size();j++)
            {
                for(int k=0;k<nrow;k++)
                {
                    Omegaapp.Pvec(j*nrow+k)[0] = Omega.vec(Neigh[jrev][j]*nrow+k)-Xbeta->vec(Neigh[jrev][j]*nrow+k);
                    //REprintf("%f %i \n",Omegaapp.Pvec(j*nrow+k)[0],Neigh[jrev][j]);
                }
            }
            
//            REprintf("Vicini di %i: ",jrev);
//            for(int j=0;j<Neigh[iobs].size();j++)
//            {
//                REprintf("%i ",Neigh[jrev][j]);
//            }
            
            
            F77_NAME(dgemv)("T",  &ncol, &nrow, &Class_ToLoad::Done, BAcc[j_IndexEqual].P,  &ncol, Omegaapp.P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, Muapp.P, &Class_ToLoad::Ione);
            //Muapp.Print("MUAPP");
            
            for(int k=0;k<nProcesses;k++)
            {
                for(int kk=0;kk<nProcesses;kk++)
                {
                    Bplus.Pmat(k,kk)[0] = BAcc[j_IndexEqual].mat(k,pos*nProcesses+kk);
                }
            }
            for(int k=0;k<nProcesses;k++)
            {
                
                Muapp2.Pvec(k)[0]    = OmegaappObs.vec(k)-Muapp.vec(k);
            }
            for(int k=0;k<nProcesses;k++)
            {
                for(int kk=0;kk<nProcesses;kk++)
                {
                    Muapp2.Pvec(k)[0] += Bplus.mat(k,kk)*(Omega.vec(iobs*nProcesses+kk));
                }
            }
            
            //Muapp2.Print("MUAPP2");
            Class_RegMean::external_ParametersForFullConditioanlBeta_WithoutMolt(&Bplus, &CovMat[j_IndexEqual]->SigmaInvAcc, &Muapp2, &Sigmaapp, &Muapp);
            for(int i=0;i<CovMat[i_IndexEqual]->SigmaInvAcc.nRows;i++)
            {
                for(int j=i;j<CovMat[i_IndexEqual]->SigmaInvAcc.nCols;j++)
                {
                    var->Pmat(i,j)[0] += Sigmaapp.mat(i,j);
                }
                mu->Pvec(i)[0] += Muapp.vec(i);
            }
            //mu->Print("Mu2");
        }
        
        for(int i=0;i<CovMat[i_IndexEqual]->SigmaInvAcc.nRows;i++)
        {
            Muapp.Pvec(i)[0] = mu->Pvec(i)[0];
        }
        int info;
        F77_NAME(dpotrf)("L",&nProcesses, var->Pmat(0,0), &nProcesses, &info);
        if(info != 0)
        {
            error("Cpp error Cholesky failed - function: compute_ParametersConditionalDensityMulti\n");
        }
        F77_NAME(dpotri)("L",&nProcesses,var->Pmat(0,0), &nProcesses, &info);
        if(info != 0)
        {
            error("Cpp error Cholesky inverse - function: compute_ParametersConditionalDensityMulti\n");
        }
        
        Class_Utils::external_dsymv_MatMoltX(var, &Muapp, mu);
        //mu->Print("Mu3");
        
        
    }
    
    
    
    void compute_ParametersConditionalDensityMulti_NoMolt(int iobs,  Vector <double> *mu, Matrix <double> *var, Vector<int> *iEqual)
    {
        // TEST livello medio - FUNZIONA
        // in un modello con k processi e un tot numero di ossrrvazioni NNGP, calcola la distribuzione condizionata
        // Omega ha mu=0
    
        int nProcesses = CovMat[0]->SigmaAcc.nRows;
        
        double Muapp_Pointer[nProcesses];
        Vector <double> Muapp(nProcesses,Muapp_Pointer);
        
        double Muapp2_Pointer[nProcesses];
        Vector <double> Muapp2(nProcesses,Muapp2_Pointer);
        
        double Sigmaapp_Pointer[nProcesses*nProcesses];
        Matrix <double> Sigmaapp(nProcesses,nProcesses,Sigmaapp_Pointer);
        
        double Omegaapp_Pointer[(Msparemax)*nProcesses];
        Vector <double> Omegaapp((Msparemax)*nProcesses,Omegaapp_Pointer);
        
        
        
        double OmegaappObs_Pointer[(Msparemax)*nProcesses];
        Vector <double> OmegaappObs((Msparemax)*nProcesses,OmegaappObs_Pointer);
        
        
        double Bplus_Pointer[nProcesses*nProcesses];
        Matrix <double> Bplus(nProcesses,nProcesses,Bplus_Pointer);
        //        double BplusApp_Pointer[nProcesses];
        //        Vector <double> BplusApp(nProcesses,BplusApp_Pointer);
        
        
        // double appvar;
        
        
        int i_IndexEqual;
        int j_IndexEqual;
        if(iEqual->vec(iobs)<0)
        {
            i_IndexEqual = iobs;
        }else{
            i_IndexEqual = iEqual->vec(iobs);
        }
        
        
        // prendo dalla sua distribuzione condizionata
        
        int ncol = BAcc[i_IndexEqual].nCols;
        int nrow = BAcc[i_IndexEqual].nRows;
        //REprintf("Neigh:\n");
        if((ncol!=0)&(nrow!=0))
        {
            for(int j=0;j<Neigh[iobs].size();j++)
            {
                for(int k=0;k<nrow;k++)
                {
                    Omegaapp.Pvec(j*nrow+k)[0] = Omega.vec(Neigh[iobs][j]*nrow+k);
                }
                
            }
            F77_NAME(dgemv)("T",  &ncol, &nrow, &Class_ToLoad::Done, BAcc[i_IndexEqual].P,  &ncol, Omegaapp.P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, Muapp.P, &Class_ToLoad::Ione);
            
        }else{
            for(int k=0;k<nProcesses;k++)
            {
                Muapp.Pvec(k)[0] = 0.0;
            }
        }
        
        
        
        Class_Utils::external_dsymv_MatMoltX(&CovMat[i_IndexEqual]->SigmaInvAcc, &Muapp, &Muapp2);
        for(int i=0;i<CovMat[i_IndexEqual]->SigmaInvAcc.nRows;i++)
        {
            for(int j=i;j<CovMat[i_IndexEqual]->SigmaInvAcc.nCols;j++)
            {
                var->Pmat(i,j)[0] = CovMat[i_IndexEqual]->SigmaInvAcc.mat(i,j);
            }
            mu->Pvec(i)[0] = Muapp2.vec(i);
        }
        
        
        
        // prendo da quelle in cui omega è covariata
//        int pos;
//        int jrev;
        for(int jrev2 = 0;jrev2<NeighRev[iobs].size() ;jrev2++)
        {
            int jrev    = NeighRev[iobs][jrev2];
            int pos     = PosNeighRev[iobs][jrev2];
            
            if(iEqual->vec(jrev)<0)
            {
                j_IndexEqual = jrev;
            }else{
                j_IndexEqual = iEqual->vec(jrev);
            }
            
            
            for(int k=0;k<nProcesses;k++)
            {
                OmegaappObs.Pvec(k)[0] = Omega.vec(jrev*nProcesses+k);
            }
            ncol = BAcc[j_IndexEqual].nCols;
            nrow = BAcc[j_IndexEqual].nRows;
            for(int j=0;j<Neigh[jrev].size();j++)
            {
                for(int k=0;k<nrow;k++)
                {
                    Omegaapp.Pvec(j*nrow+k)[0] = Omega.vec(Neigh[jrev][j]*nrow+k);
                }
            }
            F77_NAME(dgemv)("T",  &ncol, &nrow, &Class_ToLoad::Done, BAcc[j_IndexEqual].P,  &ncol, Omegaapp.P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, Muapp.P, &Class_ToLoad::Ione);
            
        
            
            for(int k=0;k<nProcesses;k++)
            {
                for(int kk=0;kk<nProcesses;kk++)
                {
                    Bplus.Pmat(k,kk)[0] = BAcc[j_IndexEqual].mat(k,pos*nProcesses+kk);
                }
            }
            
            for(int k=0;k<nProcesses;k++)
            {
                
                Muapp2.Pvec(k)[0]    = OmegaappObs.vec(k)-Muapp.vec(k);
            }
            
            for(int k=0;k<nProcesses;k++)
            {
                for(int kk=0;kk<nProcesses;kk++)
                {
                    Muapp2.Pvec(k)[0] += Bplus.mat(k,kk)*Omega.vec(iobs*nProcesses+kk);
                }
            }
            
            
            Class_RegMean::external_ParametersForFullConditioanlBeta_WithoutMolt(&Bplus, &CovMat[j_IndexEqual]->SigmaInvAcc, &Muapp2, &Sigmaapp, &Muapp);
            for(int i=0;i<CovMat[i_IndexEqual]->SigmaInvAcc.nRows;i++)
            {
                for(int j=i;j<CovMat[i_IndexEqual]->SigmaInvAcc.nCols;j++)
                {
                    var->Pmat(i,j)[0] += Sigmaapp.mat(i,j);
                }
                mu->Pvec(i)[0] += Muapp.vec(i);
            }
            
        }
        
        
        
    }

    
    //
//    void compute_ParametersConditionalDensity(int iobs, int kproc, double *mu, double *var)
//    {
//        
//        int nProcesses = CovMat[0]->SigmaAcc.nRows;
//        
//        double Muapp_Pointer[nProcesses];
//        double OmegaappObs_Pointer[(Msparemax)*nProcesses];
//        
//        Vector <double> Muapp(nProcesses,Muapp_Pointer);
//        Vector <double> OmegaappObs((Msparemax)*nProcesses,OmegaappObs_Pointer);
//        
//        double Omegaapp_Pointer[(Msparemax)*nProcesses];
//        Vector <double> Omegaapp((Msparemax)*nProcesses,Omegaapp_Pointer);
//        
//        
//        double Bplus_Pointer[nProcesses];
//        Vector <double> Bplus(nProcesses,Bplus_Pointer);
//        double BplusApp_Pointer[nProcesses];
//        Vector <double> BplusApp(nProcesses,BplusApp_Pointer);
//        
//        
//        // double appvar;
//        
//        mu[0]      = 0.0;
//        var[0]     = 0.0;
//        
//        //        REprintf("\n");
//        //        REprintf("\n");
//        //        REprintf("iobs = %i k=%i\n",iobs+1,kproc);
//        // prendo dalla sua distribuzione condizionata
//        for(int k=0;k<nProcesses;k++)
//        {
//            OmegaappObs.Pvec(k)[0] = Omega.vec(iobs*nProcesses+k);
//        }
//        int ncol = BAcc[iobs].nCols;
//        int nrow = BAcc[iobs].nRows;
//        //REprintf("Neigh:\n");
//        if((ncol!=0)&(nrow!=0))
//        {
//            for(int j=0;j<Neigh[iobs].size();j++)
//            {
//                for(int k=0;k<nrow;k++)
//                {
//                    Omegaapp.Pvec(j*nrow+k)[0] = Omega.vec(Neigh[iobs][j]*nrow+k);
//                    // REprintf(",Neigh[iobs][j]=%i k=%i omega=%f \n",Neigh[iobs][j],k, Omegaapp.Pvec(j*nrow+k)[0]);
//                }
//                
//            }
//            //BAcc[iobs].Print("B");
//            F77_NAME(dgemv)("T",  &ncol, &nrow, &Class_ToLoad::Done, BAcc[iobs].P,  &ncol, Omegaapp.P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, Muapp.P, &Class_ToLoad::Ione);
//            
//            //            REprintf("media:\n");
//            //            for(int k=0;k<nProcesses;k++)
//            //            {
//            //                REprintf("%f \n",Muapp.Pvec(k)[0]);
//            //            }
//            
//        }else{
//            for(int k=0;k<nProcesses;k++)
//            {
//                Muapp.Pvec(k)[0] = 0.0;
//            }
//        }
//        
//        
//        
//        
//        Class_MultivariateNormal::external_computeConditioanlMeanAndVariance_uni(kproc, mu,  var, &CovMat[iobs]->SigmaInvAcc, &Muapp, &OmegaappObs);
//        mu[0]   = mu[0]/var[0];
//        var[0]  = 1.0/var[0];
//        
//        
//        // prendo da quelle in cui omega è covariata
//        int pos;
//        int pos2;
//        int jrev;
//        for(int jrev2 = 0;jrev2<NeighRev[iobs].size() ;jrev2++)
//        {
//            jrev    = NeighRev[iobs][jrev2];
//            pos     = PosNeighRev[iobs][jrev2];
//            pos2    = pos*nProcesses+kproc;
//            for(int k=0;k<nProcesses;k++)
//            {
//                OmegaappObs.Pvec(k)[0] = Omega.vec(jrev*nProcesses+k);
//            }
//            ncol = BAcc[jrev].nCols;
//            nrow = BAcc[jrev].nRows;
//            for(int j=0;j<Neigh[jrev].size();j++)
//            {
//                for(int k=0;k<nrow;k++)
//                {
//                    Omegaapp.Pvec(j*nrow+k)[0] = Omega.vec(Neigh[jrev][j]*nrow+k);
//                }
//            }
//            F77_NAME(dgemv)("T",  &ncol, &nrow, &Class_ToLoad::Done, BAcc[jrev].P,  &ncol, Omegaapp.P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, Muapp.P, &Class_ToLoad::Ione);
//            
//            for(int k=0;k<nProcesses;k++)
//            {
//                Bplus.Pvec(k)[0]    = BAcc[jrev].mat(k,pos2);
//                Muapp.Pvec(k)[0]    = OmegaappObs.vec(k)- (Muapp.Pvec(k)[0]-Bplus.Pvec(k)[0]*Omega.vec(iobs*nProcesses+kproc));
//            }
//            
//            Class_MultivariateNormal::external_dsymv_MatMoltX(&CovMat[jrev]->SigmaInvAcc, &Bplus, &BplusApp);
//            
//            var[0]  += F77_NAME(ddot)(&nProcesses,BplusApp.P, &Class_ToLoad::Ione, Bplus.P, &Class_ToLoad::Ione);
//            mu[0]   += F77_NAME(ddot)(&nProcesses,BplusApp.P, &Class_ToLoad::Ione, Muapp.P, &Class_ToLoad::Ione);
//            //REprintf("var %f mean %f\n",F77_NAME(ddot)(&nProcesses,BplusApp.P, &Class_ToLoad::Ione, Bplus.P, &Class_ToLoad::Ione),F77_NAME(ddot)(&nProcesses,BplusApp.P, &Class_ToLoad::Ione, Muapp.P, &Class_ToLoad::Ione));
//        }
//        
//        var[0]      = 1.0/var[0];
//        mu[0]       = var[0]*mu[0];
//    }
    
    
    
//    void compute_ParametersConditionalDensityMulti(int iobs,  Vector <double> *mu, Matrix <double> *var)
//    {
//        // TEST livello medio - FUNZIONA
//        // in un modello con k processi e un tot numero di ossrrvazioni NNGP, calcola la distribuzione condizionata
//        // Omega ha mu=0
//        int nProcesses = CovMat[0]->SigmaAcc.nRows;
//        
//        double Muapp_Pointer[nProcesses];
//        Vector <double> Muapp(nProcesses,Muapp_Pointer);
//        
//        double Muapp2_Pointer[nProcesses];
//        Vector <double> Muapp2(nProcesses,Muapp2_Pointer);
//        
//        double Sigmaapp_Pointer[nProcesses*nProcesses];
//        Matrix <double> Sigmaapp(nProcesses,nProcesses,Sigmaapp_Pointer);
//        
//        double Omegaapp_Pointer[(Msparemax)*nProcesses];
//        Vector <double> Omegaapp((Msparemax)*nProcesses,Omegaapp_Pointer);
//        
//        
//        
//        double OmegaappObs_Pointer[(Msparemax)*nProcesses];
//        Vector <double> OmegaappObs((Msparemax)*nProcesses,OmegaappObs_Pointer);
//        
//        
//        double Bplus_Pointer[nProcesses*nProcesses];
//        Matrix <double> Bplus(nProcesses,nProcesses,Bplus_Pointer);
//        //        double BplusApp_Pointer[nProcesses];
//        //        Vector <double> BplusApp(nProcesses,BplusApp_Pointer);
//        
//        
//        // double appvar;
//        
//        
//        
//        
//        
//        // prendo dalla sua distribuzione condizionata
//        
//        int ncol = BAcc[iobs].nCols;
//        int nrow = BAcc[iobs].nRows;
//        //REprintf("Neigh:\n");
//        if((ncol!=0)&(nrow!=0))
//        {
//            for(int j=0;j<Neigh[iobs].size();j++)
//            {
//                for(int k=0;k<nrow;k++)
//                {
//                    Omegaapp.Pvec(j*nrow+k)[0] = Omega.vec(Neigh[iobs][j]*nrow+k);
//                }
//                
//            }
//            F77_NAME(dgemv)("T",  &ncol, &nrow, &Class_ToLoad::Done, BAcc[iobs].P,  &ncol, Omegaapp.P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, Muapp.P, &Class_ToLoad::Ione);
//            
//        }else{
//            for(int k=0;k<nProcesses;k++)
//            {
//                Muapp.Pvec(k)[0] = 0.0;
//            }
//        }
//        
//        
//        
//        Class_MultivariateNormal::external_dsymv_MatMoltX(&CovMat[iobs]->SigmaInvAcc, &Muapp, &Muapp2);
//        for(int i=0;i<CovMat[iobs]->SigmaInvAcc.nRows;i++)
//        {
//            for(int j=i;j<CovMat[iobs]->SigmaInvAcc.nCols;j++)
//            {
//                var->Pmat(i,j)[0] = CovMat[iobs]->SigmaInvAcc.mat(i,j);
//            }
//            mu->Pvec(i)[0] = Muapp2.vec(i);
//        }
//        
//        
//        
//        // prendo da quelle in cui omega è covariata
//        int pos;
//        int jrev;
//        for(int jrev2 = 0;jrev2<NeighRev[iobs].size() ;jrev2++)
//        {
//            jrev    = NeighRev[iobs][jrev2];
//            pos     = PosNeighRev[iobs][jrev2];
//            //pos2    = pos*nProcesses+kproc;
//            for(int k=0;k<nProcesses;k++)
//            {
//                OmegaappObs.Pvec(k)[0] = Omega.vec(jrev*nProcesses+k);
//            }
//            ncol = BAcc[jrev].nCols;
//            nrow = BAcc[jrev].nRows;
//            for(int j=0;j<Neigh[jrev].size();j++)
//            {
//                for(int k=0;k<nrow;k++)
//                {
//                    Omegaapp.Pvec(j*nrow+k)[0] = Omega.vec(Neigh[jrev][j]*nrow+k);
//                }
//            }
//            F77_NAME(dgemv)("T",  &ncol, &nrow, &Class_ToLoad::Done, BAcc[jrev].P,  &ncol, Omegaapp.P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, Muapp.P, &Class_ToLoad::Ione);
//            
//            
//            for(int k=0;k<nProcesses;k++)
//            {
//                for(int kk=0;kk<nProcesses;kk++)
//                {
//                    Bplus.Pmat(k,kk)[0] = BAcc[jrev].mat(k,pos*nProcesses+kk);
//                }
//            }
//            for(int k=0;k<nProcesses;k++)
//            {
//                
//                Muapp2.Pvec(k)[0]    = OmegaappObs.vec(k)-Muapp.vec(k);
//            }
//            for(int k=0;k<nProcesses;k++)
//            {
//                for(int kk=0;kk<nProcesses;kk++)
//                {
//                    Muapp2.Pvec(k)[0] += Bplus.mat(k,kk)*Omega.vec(iobs*nProcesses+kk);
//                }
//            }
//            
//            
//            Class_RegMean::external_ParametersForFullConditioanlBeta_WithoutMolt(&Bplus, &CovMat[jrev]->SigmaInvAcc, &Muapp2, &Sigmaapp, &Muapp);
//            for(int i=0;i<CovMat[iobs]->SigmaInvAcc.nRows;i++)
//            {
//                for(int j=i;j<CovMat[iobs]->SigmaInvAcc.nCols;j++)
//                {
//                    var->Pmat(i,j)[0] += Sigmaapp.mat(i,j);
//                }
//                mu->Pvec(i)[0] += Muapp.vec(i);
//            }
//            
//        }
//        
//        for(int i=0;i<CovMat[iobs]->SigmaInvAcc.nRows;i++)
//        {
//            Muapp.Pvec(i)[0] = mu->Pvec(i)[0];
//        }
//        int info;
//        F77_NAME(dpotrf)("L",&nProcesses, var->Pmat(0,0), &nProcesses, &info);
//        if(info != 0)
//        {
//            error("Cpp error Cholesky failed - function: compute_ParametersConditionalDensityMulti\n");
//        }
//        F77_NAME(dpotri)("L",&nProcesses,var->Pmat(0,0), &nProcesses, &info);
//        if(info != 0)
//        {
//            error("Cpp error Cholesky inverse - function: compute_ParametersConditionalDensityMulti\n");
//        }
//        
//        Class_MultivariateNormal::external_dsymv_MatMoltX(var, &Muapp, mu);
//        
//        
//        
//    }
    
    
   
    
    
    
    
//    void compute_ParametersConditionalDensityMulti_NoMolt(int iobs,  Vector <double> *mu, Matrix <double> *var)
//    {
//        // da i parametri prima di trasformarli in media e varianza
//        int nProcesses = CovMat[0]->SigmaAcc.nRows;
//        
//        double Muapp_Pointer[nProcesses];
//        Vector <double> Muapp(nProcesses,Muapp_Pointer);
//        
//        double Muapp2_Pointer[nProcesses];
//        Vector <double> Muapp2(nProcesses,Muapp2_Pointer);
//        
//        double Sigmaapp_Pointer[nProcesses*nProcesses];
//        Matrix <double> Sigmaapp(nProcesses,nProcesses,Sigmaapp_Pointer);
//        
//        double Omegaapp_Pointer[(Msparemax)*nProcesses];
//        Vector <double> Omegaapp((Msparemax)*nProcesses,Omegaapp_Pointer);
//        
//        
//        
//        double OmegaappObs_Pointer[(Msparemax)*nProcesses];
//        Vector <double> OmegaappObs((Msparemax)*nProcesses,OmegaappObs_Pointer);
//        
//        
//        double Bplus_Pointer[nProcesses*nProcesses];
//        Matrix <double> Bplus(nProcesses,nProcesses,Bplus_Pointer);
//        //        double BplusApp_Pointer[nProcesses];
//        //        Vector <double> BplusApp(nProcesses,BplusApp_Pointer);
//        
//        
//        // double appvar;
//        
//        
//        
//        
//        
//        // prendo dalla sua distribuzione condizionata
//        
//        int ncol = BAcc[iobs].nCols;
//        int nrow = BAcc[iobs].nRows;
//        //REprintf("Neigh:\n");
//        if((ncol!=0)&(nrow!=0))
//        {
//            for(int j=0;j<Neigh[iobs].size();j++)
//            {
//                for(int k=0;k<nrow;k++)
//                {
//                    Omegaapp.Pvec(j*nrow+k)[0] = Omega.vec(Neigh[iobs][j]*nrow+k);
//                }
//                
//            }
//            F77_NAME(dgemv)("T",  &ncol, &nrow, &Class_ToLoad::Done, BAcc[iobs].P,  &ncol, Omegaapp.P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, Muapp.P, &Class_ToLoad::Ione);
//            
//        }else{
//            for(int k=0;k<nProcesses;k++)
//            {
//                Muapp.Pvec(k)[0] = 0.0;
//            }
//        }
//        
//        
//        
//        Class_MultivariateNormal::external_dsymv_MatMoltX(&CovMat[iobs]->SigmaInvAcc, &Muapp, &Muapp2);
//        for(int i=0;i<CovMat[iobs]->SigmaInvAcc.nRows;i++)
//        {
//            for(int j=i;j<CovMat[iobs]->SigmaInvAcc.nCols;j++)
//            {
//                var->Pmat(i,j)[0] = CovMat[iobs]->SigmaInvAcc.mat(i,j);
//            }
//            mu->Pvec(i)[0] = Muapp2.vec(i);
//        }
//        
//        
//        
//        // prendo da quelle in cui omega è covariata
//        int pos;
//        int jrev;
//        for(int jrev2 = 0;jrev2<NeighRev[iobs].size() ;jrev2++)
//        {
//            jrev    = NeighRev[iobs][jrev2];
//            pos     = PosNeighRev[iobs][jrev2];
//            //pos2    = pos*nProcesses+kproc;
//            for(int k=0;k<nProcesses;k++)
//            {
//                OmegaappObs.Pvec(k)[0] = Omega.vec(jrev*nProcesses+k);
//            }
//            ncol = BAcc[jrev].nCols;
//            nrow = BAcc[jrev].nRows;
//            for(int j=0;j<Neigh[jrev].size();j++)
//            {
//                for(int k=0;k<nrow;k++)
//                {
//                    Omegaapp.Pvec(j*nrow+k)[0] = Omega.vec(Neigh[jrev][j]*nrow+k);
//                }
//            }
//            F77_NAME(dgemv)("T",  &ncol, &nrow, &Class_ToLoad::Done, BAcc[jrev].P,  &ncol, Omegaapp.P, &Class_ToLoad::Ione, &Class_ToLoad::Done, Muapp.P, &Class_ToLoad::Ione);
//            
//            
//            for(int k=0;k<nProcesses;k++)
//            {
//                for(int kk=0;kk<nProcesses;kk++)
//                {
//                    Bplus.Pmat(k,kk)[0] = BAcc[jrev].mat(k,pos*nProcesses+kk);
//                }
//            }
//            for(int k=0;k<nProcesses;k++)
//            {
//                
//                Muapp2.Pvec(k)[0]    = OmegaappObs.vec(k)-Muapp.vec(k);
//            }
//            for(int k=0;k<nProcesses;k++)
//            {
//                for(int kk=0;kk<nProcesses;kk++)
//                {
//                    Muapp2.Pvec(k)[0] += Bplus.mat(k,kk)*Omega.vec(iobs*nProcesses+kk);
//                }
//            }
//            
//            
//            Class_RegMean::external_ParametersForFullConditioanlBeta_WithoutMolt(&Bplus, &CovMat[jrev]->SigmaInvAcc, &Muapp2, &Sigmaapp, &Muapp);
//            for(int i=0;i<CovMat[iobs]->SigmaInvAcc.nRows;i++)
//            {
//                for(int j=i;j<CovMat[iobs]->SigmaInvAcc.nCols;j++)
//                {
//                    var->Pmat(i,j)[0] += Sigmaapp.mat(i,j);
//                }
//                mu->Pvec(i)[0] += Muapp.vec(i);
//            }
//            
//        }
//        
//
//        
//    }
    
    void compute_CovariateMatrix_neigh(Matrix <double> *Cov, vector <Matrix<double> > *ret, int usr)
    {
        // SOno le covariate dei vicini di i
        //int nProcesses = CovMat[0]->SigmaAcc.nRows;
        
        
        
        

        for(int iobs=0;iobs<Nobs;iobs++)
        {
            int ncol = BAcc[iobs].nCols;
            int nrow = BAcc[iobs].nRows;
            ret->push_back(Matrix<double>());
            
            ret[0][iobs] = Matrix<double>(ncol,Cov->nCols,usr);
            
            if((ncol!=0)&(nrow!=0))
            {
                int pos = 0;
                for(int j=0;j<Neigh[iobs].size();j++)
                {
                    for(int k=0;k<nrow;k++)
                    {
                        for(int t=0;t<Cov->nCols;t++)
                        {
                            ret[0][iobs].Pmat(pos,t)[0] =  Cov[0].mat(Neigh[iobs][j]*nrow+k,t);
                        }
                        pos++;
                    }
                    
                }
            }
        }
    }
    
    void compute_Bomega_neigh(int iobs,  Vector <double> *ret,Vector <double> *OmegaPass,int i_IndexEqual)
    {
        // da i parametri prima di trasformarli in media e varianza
        int nProcesses = CovMat[0]->SigmaAcc.nRows;
        
        
        double Omegaapp_Pointer[(Msparemax)*nProcesses];
        Vector <double> Omegaapp((Msparemax)*nProcesses,Omegaapp_Pointer);
        
        
        int ncol = BAcc[i_IndexEqual].nCols;
        int nrow = BAcc[i_IndexEqual].nRows;
        if((ncol!=0)&(nrow!=0))
        {
            for(int j=0;j<Neigh[iobs].size();j++)
            {
                for(int k=0;k<nrow;k++)
                {
                    Omegaapp.Pvec(j*nrow+k)[0] = OmegaPass->vec(Neigh[iobs][j]*nrow+k);
                }
                
            }
            F77_NAME(dgemv)("T",  &ncol, &nrow, &Class_ToLoad::Done, BAcc[i_IndexEqual].P,  &ncol, Omegaapp.P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, ret->P, &Class_ToLoad::Ione);
            
        }else{
            for(int k=0;k<nProcesses;k++)
            {
                ret->Pvec(k)[0] = 0.0;
            }
        }
        
        
        
        
    }
    
    
    void compute_parFullCondRegParameters(Matrix <double> * Covariates, vector<Matrix<double> > *CovNNGP, Matrix<double> *VarBetas, Vector<double> *MeanBetas, Class_RegMean *Mean, Vector <double> * Y,Vector<int> *iEqual, int ReturnChol)
    {

        // We assume that Omega has zero mean
        int nProcesses = CovMat[0]->SigmaAcc.nRows;
        
        
        
        double BtimesY_P[nProcesses];
        Vector <double> BtimesY(nProcesses,BtimesY_P);
        
        
        double YlessBtimesY_P[nProcesses];
        Vector <double> YlessBtimesY(nProcesses,YlessBtimesY_P);
        
        double CovariateBetas_P[Covariates->nCols*nProcesses];
        Matrix <double> CovariateBetas(nProcesses,Covariates->nCols,CovariateBetas_P);
        
        Mean->priorParameters_forGibbs(VarBetas,MeanBetas);
        for(int i=0;i<Nobs;i++)
        {
            for(int k=0;k<nProcesses;k++)
            {
                Y->Pvec(nProcesses*i+k)[0] = Omega.vec(i*nProcesses+k)+Mean->MeanAcc->vec(i*nProcesses+k);
                //omegaSTARBetas.Pvec(nProcesses*i+k)[0] = Omega.vec(i*nProcesses+k);
            }
        }
       // omegaSTARBetas.Print("OMEGA");
        
        
        int i_IndexEqual;
        
        for(int i=0;i<Nobs;i++)
        {
            int ncol,nrow;
            if(iEqual->vec(i)<0)
            {
                i_IndexEqual = i;
            }else{
                i_IndexEqual = iEqual->vec(i);
            }
        
            
            
            ncol = BAcc[i_IndexEqual].nCols;
            nrow = BAcc[i_IndexEqual].nRows;
            
            if(ncol>0)
            {
                compute_Bomega_neigh(i,  &BtimesY,Y,i_IndexEqual);
                for(int k=0;k<nProcesses;k++)
                {
                    YlessBtimesY.Pvec(k)[0] = Y->vec(i*nProcesses+k)-BtimesY.vec(k);
                }
                

                Class_Utils::external_dgemm(&BAcc[i_IndexEqual], &CovNNGP[0][i], &CovariateBetas, Class_ToLoad::Dzero);
                for(int i1=0;i1<CovariateBetas.nRows;i1++)
                {
                    for(int j1=0;j1<CovariateBetas.nCols;j1++)
                    {
                        CovariateBetas.Pmat(i1,j1)[0] = Covariates->mat(i*nProcesses+i1,0+j1)-1.0*CovariateBetas.Pmat(i1,j1)[0];
                    }
                }
            }else{
                for(int k=0;k<nProcesses;k++)
                {
                    YlessBtimesY.Pvec(k)[0] = Y->vec(i*nProcesses+k);
                }
                
                for(int i1=0;i1<CovariateBetas.nRows;i1++)
                {
                    for(int j1=0;j1<CovariateBetas.nCols;j1++)
                    {
                        CovariateBetas.Pmat(i1,j1)[0] = Covariates->mat(i*nProcesses+i1,0+j1);
                    }
                }

                
            }
            
            Class_RegMean::external_ParametersForFullConditioanlBeta_WithoutMolt(&CovariateBetas, &CovMat[i_IndexEqual]->SigmaInvAcc, &YlessBtimesY, VarBetas, MeanBetas, &Class_ToLoad::Done);

        }
        
 
        Class_MultivariateNormal::external_finalizedRegFullConditional(VarBetas, MeanBetas, ReturnChol);
  

        
    }
    
 
    

};

// Si potrebbe aggiungere qualcosa che fa si che matrici di distanze, B etc che sono in comune tra i processi lo sia anche in termini di memoria
class Class_Multi_Gaussian_NNGP_Multivariate
{
private:
    
public:
    int UserControlledMemory;
    int nProcMulti; // How many NNGP are there
    Vector<int> dimProcMulti; // the dimension of each NNGP
    Vector<int> seq_dimProcMulti; // if the first NNGP has dimensio 3 and the second 2, then we have 0,0,0,1,1
    Matrix<int> startend_dimProcMulti; // The first row is (0,3), the second (3,5)
    
    vector< Class_Gaussian_NNGP_Multivariate > NNGPs;
    
    
    //COSTRUCCTORS
    Class_Multi_Gaussian_NNGP_Multivariate(){}
    
    // DESTRUCTORS
    ~Class_Multi_Gaussian_NNGP_Multivariate(){}
    void Destroy()
    {
        dimProcMulti.Destroy();
        seq_dimProcMulti.Destroy();
        startend_dimProcMulti.Destroy();
        for(int i=0;i<NNGPs.size();i++)
        {
            NNGPs[i].Destroy();
        }
    }
    
    
    void RunBeforeAddGPs()
    {
        nProcMulti = 0;
    }
    void AddAndCreate_FullObjectNNGP(Vector <int> *EqualDist, Matrix<int> *NeighMat, int nobs,  Vector<double> *omega, vector<Poly_CovCorFunction*>  *covfunc, int usr, Matrix <double>  *coords, string Choice_Coregionalization, Class_Parameter_PDMatrixUnivSamp       *CoregSigmaMCMC)
    {
        UserControlledMemory = usr;
        
        NNGPs.push_back(Class_Gaussian_NNGP_Multivariate());
        NNGPs[nProcMulti].create_FullObject(EqualDist, NeighMat, nobs, omega, covfunc,  usr, coords,  Choice_Coregionalization,CoregSigmaMCMC);
        nProcMulti++;
    }
    void finalizeNNGPs()
    {
        int sum = 0;
        dimProcMulti                            = Vector<int>(nProcMulti,UserControlledMemory );
        startend_dimProcMulti                   = Matrix<int>(nProcMulti,2,UserControlledMemory );
        
        
        for(int i=0;i<nProcMulti;i++)
        {
            
            dimProcMulti.Pvec(i)[0] = NNGPs[i].CovMat[0]->SigmaInvAcc.nRows;
            sum += dimProcMulti.Pvec(i)[0];
        }
        
        startend_dimProcMulti.Pmat(0,0)[0]      = 0;
        startend_dimProcMulti.Pmat(0,1)[0]      = dimProcMulti.vec(0);
        
        for(int i=1;i<nProcMulti;i++)
        {
            startend_dimProcMulti.Pmat(i,0)[0] = startend_dimProcMulti.mat(i-1,1);
            startend_dimProcMulti.Pmat(i,1)[0] = startend_dimProcMulti.mat(i,0)+dimProcMulti.Pvec(i)[0];
        }
        
        seq_dimProcMulti        = Vector<int>(sum,UserControlledMemory);
        int h = 0;
        for(int i=0;i<nProcMulti;i++)
        {
            for(int j=startend_dimProcMulti.mat(i,0);j<startend_dimProcMulti.mat(i,1);j++)
            {
                seq_dimProcMulti.Pvec(h)[0] = i;
                h++;
            }
        }
    }
    
};





#endif
