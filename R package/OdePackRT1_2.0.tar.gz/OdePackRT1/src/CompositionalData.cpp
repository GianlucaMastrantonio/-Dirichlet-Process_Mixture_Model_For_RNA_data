
#include <iostream>
#include <list>
#include <vector>
#include <string>
#include "MatricesAndVectors.h"
#include "CompositionalData.h"
//#include "F_Utils.h"
using std::cout; using std::endl;
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>


//
//double a(int n, double x)
//
//{
//    double TRUNC = 0.64;
//    double K = (n + 0.5) * M_PI;
//    
//    double y = 0;
//    
//    if (x > TRUNC) {
//        
//        y = K * exp( -0.5 * K*K * x );
//        
//    }
//    
//    else if (x > 0) {
//        
//        double expnt = -1.5 * (log(0.5 * M_PI)  + log(x)) + log(K) - 2.0 * (n+0.5)*(n+0.5) / x;
//        
//        y = exp(expnt);
//        
//        // y = pow(0.5 * M_PI * x, -1.5) * K * exp( -2.0 * (n+0.5)*(n+0.5) / x);
//        
//        // ^- unstable for small x?
//        
//    }
//    
//    return y;
//    
//}
//
//double rtigauss(double Z)
//
//{
//    
//    Z = fabs(Z);
//    
//    double t = 0.64;
//    
//    double X = t + 1.0;
//    
//    if (1/t > Z) { // mu > t
//        
//        double alpha = 0.0;
//        
//        while (runif(0.0,1.0) > alpha) {
//            
//            // X = t + 1.0;
//            
//            // while (X > t)
//            
//            //     X = 1.0 / r.gamma_rate(0.5, 0.5);
//            
//            // Slightly faster to use truncated normal.
//            
//            double E1 = rexp(1.0); double E2 = rexp(1.0);
//            
//            while ( E1*E1 > 2 * E2 / t) {
//                
//                E1 = rexp(1.0); E2 = rexp(1.0);
//                
//            }
//            
//            X = 1 + E1 * t;
//            
//            X = t / (X * X);
//            
//            alpha = exp(-0.5 * Z*Z * X);
//            
//        }
//        
//    }
//    
//    else {
//        
//        double mu = 1.0 / Z;
//        
//        while (X > t) {
//            
//            double Y = rnorm(0.0,1.0); Y *= Y;
//            
//            double half_mu = 0.5 * mu;
//            
//            double mu_Y    = mu  * Y;
//            
//            X = mu + half_mu * mu_Y - half_mu * sqrt(4 * mu_Y + mu_Y * mu_Y);
//            
//            if (runif(0.0,1.0) > mu / (mu + X))
//                
//                X = mu*mu / X;
//            
//        }
//        
//    }
//    
//    return X;
//    
//}
//
//
//
//double mass_texpon(double Z)
//
//{
//    
//    double t = 0.64;
//    
//    
//    
//    double fz = 0.125 * M_PI*M_PI + 0.5 * Z*Z;
//    
//    double b = sqrt(1.0 / t) * (t * Z - 1);
//    
//    double a = sqrt(1.0 / t) * (t * Z + 1) * -1.0;
//    
//    
//    
//    double x0 = log(fz) + fz * t;
//    
//    double xb = x0 - Z + pnorm(b, 0.0,1.0,1,1);
//    
//    double xa = x0 + Z + pnorm(a, 0.0,1.0,1,1);
//    
//    
//    
//    double qdivp = 4 / M_PI * ( exp(xb) + exp(xa) );
//    
//    
//    
//    return 1.0 / (1.0 + qdivp);
//    
//}
//
//
//
//double rPolyaGamma1z(double Z)
//{
//    
//    // Change the parameter.
//    
//    Z = fabs(Z) * 0.5;
//    
//    
//    double TRUNC = 0.64;
//    // Now sample 0.25 * J^*(1, Z := Z/2).
//    
//    double fz = 0.125 * M_PI*M_PI + 0.5 * Z*Z; // K
//    
//    // ... Problems with large Z?  Try using q_over_p.
//    
//    // double p  = 0.5 * M_PI * exp(-1.0 * fz * __TRUNC) / fz;
//    
//    // double q  = 2 * exp(-1.0 * Z) * pigauss(__TRUNC, Z);
//    
//    
//    
//    double X = 0.0;
//    
//    double S = 1.0;
//    
//    double Y = 0.0;
//    
//    // int iter = 0; If you want to keep track of iterations.
//    
//    
//    
//    while (true) {
//        
//        
//        
//        // if (r.unif() < p/(p+q))
//        
//        if ( runif(0.0,1.0) < mass_texpon(Z) )
//            
//            X = TRUNC + rexp(1) / fz;
//        
//        else
//            
//            X = rtigauss(Z);
//        
//        
//        
//        S = a(0, X);
//        
//        Y = runif(0.0,1.0) * S;
//        
//        int n = 0;
//        
//        bool go = true;
//        
//        
//        
//        // Cap the number of iterations?
//        
//        while (go) {
//            
//            
//            
//            // Break infinite loop.  Put first so it always checks n==0.
//            
//#ifdef USE_R
//            
//            if (n % 1000 == 0) R_CheckUserInterrupt();
//            
//#endif
//            
//            
//            
//            ++n;
//            
//            if (n%2==1) {
//                
//                S = S - a(n, X);
//                
//                if ( Y<=S ) return 0.25 * X;
//                
//            }
//            
//            else {
//                
//                S = S + a(n, X);
//                
//                if ( Y>S ) go = false;
//                
//            }
//        }
//    }
//    
//}
//
///*******************************
// LogisticNormalProcess
// *********************************/
//
//double LogisticNormalProcess::external_rPolyaGamma(int b,double z)
//{
//    
////    double ret = 0;
////
////    for(int k=0;k<20;k++)
////    {
////        ret += rgamma(1,1)/(  pow(k+1-0.5,2.0) );
////    }
////    return(ret/(2*M_PI*M_PI));
//    
//    
//    int i;
//    double ret = rPolyaGamma1z(z);
//    for(i=1;i<b;i++)
//    {
//        ret += rPolyaGamma1z(z);
//    }
//    return(ret);
//}
//
///*******************************
// LogisticNormalProcessNNGP
// *********************************/
//
//static double external_rPolyaGamma(int b, double z)
//{
//    return(LogisticNormalProcess::external_rPolyaGamma(b,z));
//};


