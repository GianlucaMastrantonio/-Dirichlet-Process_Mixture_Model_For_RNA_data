#ifndef CompositionalData_H
#define CompositionalData_H



using std::cout; using std::endl;
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>
#include "Functions.h"
#include "DensityPriorParam.h"
#include <vector>
#include <string>








class Probs_ToPass
{
private:
    
public:
    int dim1; // nrow
    int dim2; //ncol
    int UserControlledMemory;
    
    string TypeProb;
    
    vector< Vector <double>* >      ProbsAcc;
    vector< Vector <double>* >      ProbsProp;
    
    
    // COSTRUCTORS
    Probs_ToPass(){};
    
    // DESTRUCTORS
    ~Probs_ToPass(){}
    void Destroy()
    {
        for(int i=0;i<ProbsAcc.size();i++)
        {
            ProbsAcc[i][0].Destroy();
        }
        for(int i=0;i<ProbsProp.size();i++)
        {
            ProbsProp[i][0].Destroy();
        }
        
    }
};



/********************************************
Change Point
 ********************************************/

class ChangePointDP: public Probs_ToPass
{
private:
    
public:
    //int UserControlledMemory;
    //Vector <int> n_st;
    VectorParameters *StickProbs;
    VectorParameters *NonStickProbs;
    
    vector< Vector <double>* >      NonStickProbsAcc;
    vector< Vector <double>* >      NonStickProbsProp;
    //VectorParameters *ProbVec;
    // COSTRUCTORS
    ChangePointDP(){};
    
    // DESTRUCTORS
    ~ChangePointDP(){};
    
    void create_FullObject(int kmax,  int usr,VectorParameters *prob)
    {
        
        TypeProb = "ChangePoint";
        //Rprintf("cCC1 \n");
        UserControlledMemory    = usr;
        dim1                    = 1;
        dim2                    = kmax;
        StickProbs                 = prob;
        
        ProbsAcc.push_back(new Vector<double>(dim2,UserControlledMemory));
        ProbsAcc[0]->Init(0.0);
        
        ProbsProp.push_back(new Vector<double>(dim2,UserControlledMemory));
        ProbsProp[0]->Init(0.0);
        
        NonStickProbsAcc.push_back(new Vector<double>(dim2,UserControlledMemory));
        NonStickProbsAcc[0]->Init(2.0);
        
        NonStickProbsProp.push_back(new Vector<double>(dim2,UserControlledMemory));
        NonStickProbsProp[0]->Init(2.0);
        
        for(int i=0;i<dim2;i++)
        {
            ProbsAcc[0]->Pvec(i)[0]     = StickProbs->VectorAcc.vec(i);
            ProbsProp[0]->Pvec(i)[0]    = StickProbs->VectorAcc.vec(i);
        }
        
        
    }
    void add_NonStick(VectorParameters *prob)
    {
        NonStickProbs = prob;
        update_ProbAccNonStick();
        
    }
  
    void update_ProbAcc()
    {
        for(int i=0;i<dim2;i++)
        {
            ProbsAcc[0]->Pvec(i)[0]     = StickProbs->VectorAcc.vec(i);
            //ProbsProp[0]->Pvec(i)[0]    = ProbVec->VectorAcc.vec(i);
        }
        
    }
    void update_ProbAccNonStick()
    {
        for(int i=0;i<dim2;i++)
        {
            NonStickProbsAcc[0]->Pvec(i)[0]     = NonStickProbs->VectorAcc.vec(i);
            //ProbsProp[0]->Pvec(i)[0]    = ProbVec->VectorAcc.vec(i);
        }
        
    }
    
};



class MixtureDP: public Probs_ToPass
{
private:
    
public:
    //int UserControlledMemory;
    //Vector <int> n_st;
    VectorParameters *ProbVec;
    
    // COSTRUCTORS
    MixtureDP(){};
    
    // DESTRUCTORS
    ~MixtureDP(){};
    
    void create_FullObject(int kmax,  int usr,VectorParameters *prob)
    {
        TypeProb = "Mixture";
        //Rprintf("cCC1 \n");
        UserControlledMemory    = usr;
        dim1                    = 1;
        dim2                    = kmax;
        ProbVec                 = prob;
        
        ProbsAcc.push_back(new Vector<double>(dim2,UserControlledMemory));
        ProbsAcc[0]->Init(0.0);
        
        ProbsProp.push_back(new Vector<double>(dim2,UserControlledMemory));
        ProbsProp[0]->Init(0.0);
        
        for(int i=0;i<dim2;i++)
        {
            ProbsAcc[0]->Pvec(i)[0]     = ProbVec->VectorAcc.vec(i);
            ProbsProp[0]->Pvec(i)[0]    = ProbVec->VectorAcc.vec(i);
        }

        
    }
    
    void update_ProbAcc()
    {
        for(int i=0;i<dim2;i++)
        {
            ProbsAcc[0]->Pvec(i)[0]     = ProbVec->VectorAcc.vec(i);
            //ProbsProp[0]->Pvec(i)[0]    = ProbVec->VectorAcc.vec(i);
        }
        
    }
    
};





//
//class  Categorial
//{
//private:
//
//public:
//
//    int UserControlledMemory;
//    int nVectors;
//    int Zmax;
//
//    Vector<int> Zeta;
//
//    Probs_ToPass*  Probs;
//
//
//
//    // COSTRUCTORS
//    Categorial(){}
//
//    // DESTRUCTOR
//    ~Categorial(){}
//    void Destroy()
//    {
//        Probs->Destroy();
//        Zeta.Destroy();
//    }
//
//
//    void create_FullObject(Probs_ToPass*  probs,  Vector<int> *zeta,int usr)
//    {
//        UserControlledMemory        = usr;
//        Probs                       = probs;
//        nVectors                    = Probs->nVectors;
//        Zmax                        = Probs->DimensionProb;
//        Zeta                        = Vector<int>(zeta->nElem,zeta->P);
//
//    }
//
//
//
//};
//




class  ClusterIndex_TONOTUSEANYMORE
{
private:
    
public:
    
    int UserControlledMemory;
    int lengthVector;
    int Kmax;
    
    Vector<int> Zeta;
    Vector<int> NObsInClust;
    
    Vector<int> EmptyC;
    Vector<int> NonEmptyC;
    int nNonEmpty;
    int nEmpty;
    
    Probs_ToPass*  Probs;
    
    //void (*update_EmptyAndNonEmptyClusters)(void);
    
    
    int test1()
    {
        return(10);
    }
    
    // COSTRUCTORS
    ClusterIndex_TONOTUSEANYMORE(){}
    
    // DESTRUCTOR
    ~ClusterIndex_TONOTUSEANYMORE(){}

    
    
//    void create_FullObject(Probs_ToPass*  probs,  Vector<int> *zeta,int usr)
//    {
//        UserControlledMemory        = usr;
//        Probs                       = probs;
//        nVectors                    = Probs->nVectors;
//        Zmax                        = Probs->DimensionProb;
//        Zeta                        = Vector<int>(zeta->nElem,zeta->P);
//
//    }
   
    
    void create_FullObject(Probs_ToPass*  probs,  Vector<int> *zeta, int usr)
    {
        // per chang epoint
        UserControlledMemory        = usr;
        Probs                       = probs;
        lengthVector                = zeta->nElem;
        Kmax                        = probs[0].ProbsAcc[0][0].nElem;
        Zeta                        = Vector<int>(zeta->nElem,zeta->P);
        
        //REprintf("%i %i %i \n",lengthVector,Kmax,UserControlledMemory);
       // Zeta.Print("Zeta");
        
        NObsInClust                 = Vector<int>(Kmax,UserControlledMemory);
        EmptyC                      = Vector<int>(Kmax,UserControlledMemory);
        NonEmptyC                   = Vector<int>(Kmax,UserControlledMemory);
        
       
        update_EmptyAndNonEmptyClusters();
        
        //NObsInClust.Print("s");
        //EmptyC.Print("s");
        //NonEmptyC.Print("s");
        
    }
    
    void update_EmptyAndNonEmptyClusters()
    {
        
        NObsInClust.Init(0);
        EmptyC.Init(0);
        NonEmptyC.Init(0);
        
        nNonEmpty                   = 0;
        nEmpty                      = 0;
        
        int k,i;
        for(i=0;i<lengthVector;i++)
        {
            k = Zeta.vec(i);
            NObsInClust.Pvec(k)[0]++;
        }
        for(k=0;k<Kmax;k++)
        {
            if(NObsInClust.Pvec(k)[0]==0)
            {
                EmptyC.Pvec(nEmpty)[0] = k;
                nEmpty++;
            }
        }
        
        k = 0;
        NonEmptyC.Pvec(0)[0] = Zeta.vec(0);
        nNonEmpty++;
        k++;
        //REprintf("%i ",lengthVector,k)
        for(i=1;i<lengthVector;i++)
        {
            if(Zeta.vec(i)!=Zeta.vec(i-1))
            {
                NonEmptyC.Pvec(k)[0] = Zeta.vec(i);
                k++;
                nNonEmpty++;
            }
        }
        
        
    }
    
    
    void samplePi(MixtureDP *mixDP)
    {
        //double app1;
        double app2;
        int k,i;
        double par1_P[Kmax];
        Vector<double> par1(Kmax, par1_P);
        
        double par2_P[Kmax];
        Vector<double> par2(Kmax, par2_P);
        
        int Order_P[Kmax];
        Vector<int> Order(Kmax, Order_P);
        
        
        app2  = lengthVector+mixDP->ProbVec->PriorParameters[0][0][0].HyperparametersAcc.vec(0)[0];
        for(i=0;i<nNonEmpty;i++)
        {
            k = NonEmptyC.vec(i);
            Order.Pvec(i)[0] = k;
            par1.Pvec(k)[0] = 1.0+NObsInClust.vec(k);
            app2 -= NObsInClust.vec(k);
            par2.Pvec(k)[0] =   app2;
            
        }
        for(i=0;i<nEmpty;i++)
        {
            k = EmptyC.vec(i);
            Order.Pvec(nNonEmpty+i)[0] = k;
            par1.Pvec(k)[0] = 1.0;
            par2.Pvec(k)[0] =   mixDP->ProbVec->PriorParameters[0][0][0].HyperparametersAcc.vec(0)[0];
            
        }

        
        Class_Dirichlet::external_SampleDirichlet_Stick(&par1,&par2,  &mixDP->ProbVec->VectorAcc, &Order);
        mixDP->ProbVec->update_ParameterAcc();
        mixDP->update_ProbAcc();
        
    }
//    void samplePi(ChangePointDP *mixDP)
//    {
//        double app1;
//        double app2;
//        double par1;
//        double par2;
//        int k,i;
//
//        par2  = 1.0+mixDP->StickProbs->PriorParameters[0][0][0].HyperparametersAcc.vec(0)[0];
//        for(i=0;i<nNonEmpty-1;i++)
//        {
//            k       = NonEmptyC.vec(i);
//            par1    = NObsInClust.vec(k);
//            mixDP->StickProbs->VectorAcc.Pvec(k)[0] = rbeta(par1,par2);
//        }
//        par2  = mixDP->StickProbs->PriorParameters[0][0][0].HyperparametersAcc.vec(0)[0];
//        i = nNonEmpty;
//        k       = NonEmptyC.vec(i);
//        par1    = NObsInClust.vec(k)-1;
//        mixDP->StickProbs->VectorAcc.Pvec(k)[0] = rbeta(par1,par2);
//        par1    = 1.0;
//        for(i=0;i<nEmpty;i++)
//        {
//            k = EmptyC.vec(i);
//            mixDP->StickProbs->VectorAcc.Pvec(k)[0] = rbeta(par1,par2);
//        }
//        mixDP->StickProbs->update_ParameterAcc();
//        mixDP->update_ProbAcc();
//
//    }
    
    void samplePi(ChangePointDP *mixDP)
    {

        double par1;
        double par2;
        int k,i;


        for(i=0;i<nNonEmpty;i++)
        {
            k       = NonEmptyC.vec(i);
            par1    = NObsInClust.vec(k);
            if(k==Zeta.vec(Zeta.nElem-1))
            {
                par2  = mixDP->StickProbs->PriorParameters[0][0][0].HyperparametersAcc.vec(0)[0];
            }else{
                par2  = 1.0+mixDP->StickProbs->PriorParameters[0][0][0].HyperparametersAcc.vec(0)[0];
            }
            mixDP->StickProbs->VectorAcc.Pvec(k)[0] = rbeta(par1,par2);
        }

        par1    = 1.0;
        par2  = mixDP->StickProbs->PriorParameters[0][0][0].HyperparametersAcc.vec(0)[0];
        for(i=0;i<nEmpty;i++)
        {
            k = EmptyC.vec(i);
            mixDP->StickProbs->VectorAcc.Pvec(k)[0] = rbeta(par1,par2);
        }
        mixDP->StickProbs->update_ParameterAcc();
        mixDP->update_ProbAcc();

    }
 
};



typedef ClusterIndex_TONOTUSEANYMORE ClusterIndex;




class  ClusterIndex_V2
{
private:
    
public:
    
    int UserControlledMemory;
    int lengthVector;
    int Kmax;
    
    Vector<int> Zeta;
    Vector<int> NObsInClust;
    
    Vector<int> EmptyC;
    Vector<int> NonEmptyC;
    int nNonEmpty;
    int nEmpty;
    
    Probs_ToPass*  Probs;
    
    /*pointer function*/
    void (ClusterIndex_V2::*update_EmptyAndNonEmptyClusters_P)();
    void update_EmptyAndNonEmptyClusters()
    {
        (this->*update_EmptyAndNonEmptyClusters_P)();
    }
    

    
    // COSTRUCTORS
    ClusterIndex_V2(){}
    
    // DESTRUCTOR
    ~ClusterIndex_V2(){}
    
    
    
    //    void create_FullObject(Probs_ToPass*  probs,  Vector<int> *zeta,int usr)
    //    {
    //        UserControlledMemory        = usr;
    //        Probs                       = probs;
    //        nVectors                    = Probs->nVectors;
    //        Zmax                        = Probs->DimensionProb;
    //        Zeta                        = Vector<int>(zeta->nElem,zeta->P);
    //
    //    }
    
    
    void create_FullObject(Probs_ToPass*  probs,  Vector<int> *zeta, int usr)
    {
        //test = &ClusterIndex::test1;
        // per chang epoint
        UserControlledMemory        = usr;
        Probs                       = probs;
        lengthVector                = zeta->nElem;
        Kmax                        = probs[0].ProbsAcc[0][0].nElem;
        Zeta                        = Vector<int>(zeta->nElem,zeta->P);
        
        REprintf("%i %i %i \n",lengthVector,Kmax,UserControlledMemory);
        // Zeta.Print("Zeta");
        
        NObsInClust                 = Vector<int>(Kmax,UserControlledMemory);
        EmptyC                      = Vector<int>(Kmax,UserControlledMemory);
        NonEmptyC                   = Vector<int>(Kmax,UserControlledMemory);
        
        //REprintf("DDDD %i \n",(this->*test)());
        if(probs->TypeProb=="ChangePoint")
        {
            update_EmptyAndNonEmptyClusters_P = &::ClusterIndex_V2::update_EmptyAndNonEmptyClusters_CP;
        }else{
            if(probs->TypeProb=="Mixture")
            {
                update_EmptyAndNonEmptyClusters_P = &::ClusterIndex_V2::update_EmptyAndNonEmptyClusters_Mixture;
            }else{
                error("\n\n\n update_EmptyAndNonEmptyClusters  camb\n\n\n");
            }
        }
        update_EmptyAndNonEmptyClusters();
        
    }
    
    void update_EmptyAndNonEmptyClusters_Mixture()
    {
        
        NObsInClust.Init(0);
        EmptyC.Init(0);
        NonEmptyC.Init(0);
        
        nNonEmpty                   = 0;
        nEmpty                      = 0;
        
        int k,i;
        for(i=0;i<lengthVector;i++)
        {
            k = Zeta.vec(i);
            NObsInClust.Pvec(k)[0]++;
        }
        for(k=0;k<Kmax;k++)
        {
            if(NObsInClust.Pvec(k)[0]==0)
            {
                EmptyC.Pvec(nEmpty)[0] = k;
                nEmpty++;
            }
        }
        
        k = 0;
        for(int k1=0;k1<NObsInClust.nElem;k1++)
        {
            if(NObsInClust.vec(k1)>0)
            {
                NonEmptyC.Pvec(k)[0] = k1;
                nNonEmpty++;
                k++;
            }
        }
    }
    
    void update_EmptyAndNonEmptyClusters_CP()
    {
        
        NObsInClust.Init(0);
        EmptyC.Init(0);
        NonEmptyC.Init(0);
        
        nNonEmpty                   = 0;
        nEmpty                      = 0;
        
        int k,i;
        for(i=0;i<lengthVector;i++)
        {
            k = Zeta.vec(i);
            NObsInClust.Pvec(k)[0]++;
        }
        for(k=0;k<Kmax;k++)
        {
            if(NObsInClust.Pvec(k)[0]==0)
            {
                EmptyC.Pvec(nEmpty)[0] = k;
                nEmpty++;
            }
        }
        
        k = 0;
        NonEmptyC.Pvec(0)[0] = Zeta.vec(0);
        nNonEmpty++;
        k++;
        //REprintf("%i ",lengthVector,k)
        for(i=1;i<lengthVector;i++)
        {
            if(Zeta.vec(i)!=Zeta.vec(i-1))
            {
                NonEmptyC.Pvec(k)[0] = Zeta.vec(i);
                k++;
                nNonEmpty++;
            }
        }
        
        
    }
    
    void samplePi_FixedK(MixtureDP *mixDP)
    {
        //double app1;
        double app2;
        int k,i;
        double par1_P[Kmax];
        Vector<double> par1(Kmax, par1_P);
        
        double par2_P[Kmax];
        Vector<double> par2(Kmax, par2_P);
        
        int Order_P[Kmax];
        Vector<int> Order(Kmax, Order_P);
        
        double hyper = mixDP->ProbVec->PriorParameters[0][0][0].HyperparametersAcc.vec(0)[0];
        
		 //REprintf("Hyper=%f\n",mixDP->ProbVec->PriorParameters[0][0][0].HyperparametersAcc.vec(0)[0]);
        app2  = lengthVector+Kmax*hyper;
        for(i=0;i<nNonEmpty;i++)
        {
            k = NonEmptyC.vec(i);
            Order.Pvec(i)[0] = k;
            par1.Pvec(k)[0] = NObsInClust.vec(k)+hyper;
            app2 -= NObsInClust.vec(k)+hyper;
            par2.Pvec(k)[0] =   app2;
			  //REprintf("%f %f \n",  par1.Pvec(k)[0],par2.Pvec(k)[0] );
            
        }
        for(i=0;i<nEmpty;i++)
        {
            k = EmptyC.vec(i);
            Order.Pvec(nNonEmpty+i)[0] = k;
            par1.Pvec(k)[0] = hyper;
            app2 -= hyper;
            par2.Pvec(k)[0] =   app2;
			  //REprintf("%f %f \n",  par1.Pvec(k)[0],par2.Pvec(k)[0] );
//            par1.Pvec(k)[0] = 1.0;
//            par2.Pvec(k)[0] =   mixDP->ProbVec->PriorParameters[0][0][0].HyperparametersAcc.vec(0)[0];
            
        }
       
//		 for(int i=0;i<Kmax;i++)
//		 {
//			 REprintf("%f %f %f \n",par1.vec(i), par2.vec(i),mixDP->ProbVec->VectorAcc.vec(i));
//		 }
        Class_Dirichlet::external_SampleDirichlet_Stick(&par1,&par2,  &mixDP->ProbVec->VectorAcc, &Order);
        mixDP->ProbVec->update_ParameterAcc();
        mixDP->update_ProbAcc();
		  
        
    }
    
    void samplePi(MixtureDP *mixDP)
    {
        //double app1;
        double app2;
        int k,i;
        double par1_P[Kmax];
        Vector<double> par1(Kmax, par1_P);
        
        double par2_P[Kmax];
        Vector<double> par2(Kmax, par2_P);
        
        int Order_P[Kmax];
        Vector<int> Order(Kmax, Order_P);
        
        
        app2  = lengthVector+mixDP->ProbVec->PriorParameters[0][0][0].HyperparametersAcc.vec(0)[0];
        for(i=0;i<nNonEmpty;i++)
        {
            k = NonEmptyC.vec(i);
            Order.Pvec(i)[0] = k;
            par1.Pvec(k)[0] = 1.0+NObsInClust.vec(k);
            app2 -= NObsInClust.vec(k);
            par2.Pvec(k)[0] =   app2;
            
        }
        for(i=0;i<nEmpty;i++)
        {
            k = EmptyC.vec(i);
            Order.Pvec(nNonEmpty+i)[0] = k;
            par1.Pvec(k)[0] = 1.0;
            par2.Pvec(k)[0] =   mixDP->ProbVec->PriorParameters[0][0][0].HyperparametersAcc.vec(0)[0];
            
        }
        
        
        Class_Dirichlet::external_SampleDirichlet_Stick(&par1,&par2,  &mixDP->ProbVec->VectorAcc, &Order);
        mixDP->ProbVec->update_ParameterAcc();
        mixDP->update_ProbAcc();
        
    }
    //    void samplePi(ChangePointDP *mixDP)
    //    {
    //        double app1;
    //        double app2;
    //        double par1;
    //        double par2;
    //        int k,i;
    //
    //        par2  = 1.0+mixDP->StickProbs->PriorParameters[0][0][0].HyperparametersAcc.vec(0)[0];
    //        for(i=0;i<nNonEmpty-1;i++)
    //        {
    //            k       = NonEmptyC.vec(i);
    //            par1    = NObsInClust.vec(k);
    //            mixDP->StickProbs->VectorAcc.Pvec(k)[0] = rbeta(par1,par2);
    //        }
    //        par2  = mixDP->StickProbs->PriorParameters[0][0][0].HyperparametersAcc.vec(0)[0];
    //        i = nNonEmpty;
    //        k       = NonEmptyC.vec(i);
    //        par1    = NObsInClust.vec(k)-1;
    //        mixDP->StickProbs->VectorAcc.Pvec(k)[0] = rbeta(par1,par2);
    //        par1    = 1.0;
    //        for(i=0;i<nEmpty;i++)
    //        {
    //            k = EmptyC.vec(i);
    //            mixDP->StickProbs->VectorAcc.Pvec(k)[0] = rbeta(par1,par2);
    //        }
    //        mixDP->StickProbs->update_ParameterAcc();
    //        mixDP->update_ProbAcc();
    //
    //    }
    
    void samplePi(ChangePointDP *mixDP)
    {
        
        double par1;
        double par2;
        int k,i;
        
        
        for(i=0;i<nNonEmpty;i++)
        {
            k       = NonEmptyC.vec(i);
            par1    = NObsInClust.vec(k);
            if(k==Zeta.vec(Zeta.nElem-1))
            {
                par2  = mixDP->StickProbs->PriorParameters[0][0][0].HyperparametersAcc.vec(0)[0];
            }else{
                par2  = 1.0+mixDP->StickProbs->PriorParameters[0][0][0].HyperparametersAcc.vec(0)[0];
            }
            mixDP->StickProbs->VectorAcc.Pvec(k)[0] = rbeta(par1,par2);
        }
        
        par1    = 1.0;
        par2  = mixDP->StickProbs->PriorParameters[0][0][0].HyperparametersAcc.vec(0)[0];
        for(i=0;i<nEmpty;i++)
        {
            k = EmptyC.vec(i);
            mixDP->StickProbs->VectorAcc.Pvec(k)[0] = rbeta(par1,par2);
        }
        mixDP->StickProbs->update_ParameterAcc();
        mixDP->update_ProbAcc();
        
    }
    
};



#endif
