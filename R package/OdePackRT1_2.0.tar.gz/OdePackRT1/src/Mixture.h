#ifndef Mixture_H
#define Mixture_H


#include <iostream>
#include <list>
#include <vector>
#include "DensityPriorParam.h"
#include "CompositionalData.h"
#include "Gaussian.h"
using namespace std;
#include <vector>
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>
#include <time.h>

#ifdef _OPENMP
#include <omp.h>
#endif


#pragma mark Mixture V3
class Class_Mixture_V3
{
private:
    
    
public:
    // STUFF
    int nObs;
    int nVars;
    int Kmax;
    
    int UserControlledMemory;
    
    // MEMBERS
    Matrix <double>         Y;
    //Matrix <double>         YProp;
    //Matrix <double>         YTransformed;
    ClusterIndex_V2            *Clusters;
    Poly_Density             *Likelihood;
	//Matrix<double> LatentVariables;
	//Matrix<double> LatentVariablesProp;
    
    vector<Class_Parameter_PDMatrixUnivSamp >   *CovMat;
    vector<VectorParameters>                    *VectorParam;
    Matrix<double>                              *Covariates;
    
    vector <ParametersContainer>                Container;
    
    // CONSTRUCTORS
    Class_Mixture_V3(){};
    
    //DESTRUCTORS
    ~Class_Mixture_V3(){};
    

	
	void create_fullObject( Matrix<double>* y, ClusterIndex_V2* clust, Poly_Density *like, int usr )
	{
		 UserControlledMemory    = usr;
		 
		 Kmax     = clust->Kmax;
		 Y           = Matrix<double>(y->nRows,y->nCols, y->P);
		 nObs        = Y.nRows;
		 nVars       = Y.nCols;
		 
		 Likelihood  = like;
		 Clusters    = clust;
		 
		 for(int k=0;k<Kmax;k++)
		 {
			  Container.push_back(ParametersContainer());
		 }
		 
		 SampParGIBBS_OnlyOcc_P = &::Class_Mixture_V3::SampParGIBBS_OnlyOcc_VOID;
		// SampParGIBBS_P = &::Class_Mixture_V3::SampParGIBBS_VOID;
		// SampParMETROPOLIS_P = &::Class_Mixture_V3::SampParMETROPOLIS_VOID;
		 SampFromPrior_P = &::Class_Mixture_V3::SampFromPrior_VOID;
		 ComputeDensityPrior_P = &::Class_Mixture_V3::ComputeDensityPrior_VOID;
	}
	
	/**  CAMPIONAMENTO DA PRIOR */
	void (Class_Mixture_V3::*SampFromPrior_P)(int k);
	void SampFromPrior_VOID(int k)
	{
		 error("SampFromPrior_P() not set");
	}
	void SampFromPrior(int k)
	{
		 return((this->*SampFromPrior_P)(k));
	}
	// Multivariate normal
	void set_SampFromPrior_MultiNormal_NIW()
	{
		 SampFromPrior_P = &::Class_Mixture_V3::sample_SampFromPrior_MultiNormal_NIW;
	}
	void sample_SampFromPrior_MultiNormal_NIW(int k)
	{
		 sample_FromPrior_MultiNormLike_Reg_NormalPrior(k);  
		 sample_FromPrior_MultiNormLikeReg_Sigma_InverseWishart(k);
	}
	// IWP
	void set_SampFromPrior_IWPreg_General()
	{
		SampFromPrior_P = &::Class_Mixture_V3::sample_SampFromPrior_IWPreg_General;
	}
	void sample_SampFromPrior_IWPreg_General(int k)
	{
		sample_FromPrior_MultiNormLike_Reg_NormalPrior(k);
		for(int j=0;j<Y.nCols;j++)
		{
			//Container[k].Params[0][0][j].sample(); //mu
			Container[k].Params[1][0][j].sample();// sigma
			Container[k].Params[2][0][j].sample(); // delta			
		}
	}
	
	/**  Densità prior */
	void (Class_Mixture_V3::*ComputeDensityPrior_P)(int k, double *ret);
	void ComputeDensityPrior_VOID(int k, double *ret)
	{
		 error("ComputeDensityPrior_P() not set");
	}
	void ComputeDensityPrior(int k, double *ret)
	{
		 return((this->*ComputeDensityPrior_P)(k,ret));
	}
	void set_ComputeDensityPrior_IWP_General()
	{
		 ComputeDensityPrior_P = &::Class_Mixture_V3::ComputeDensityPrior_IWP_General;
	}
	void ComputeDensityPrior_IWP_General(int k, double *ret)
	{
		ret[0] = 0.0;
		for(int i=0;i<VectorParam[0][k].PriorParameters[0].size();i++)
		{
			double mean = VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0];
			double sd = pow(VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0],0.5);
			double obs = VectorParam[0][k].VectorAcc.vec(i);
			ret[0]+= dnorm(obs,mean,sd,1);
		}
		for(int j=0;j<Y.nCols;j++)
		{
			//Container[k].Params[0][0][j].compute_logDensityAcc(); //mu
			Container[k].Params[1][0][j].compute_logDensityAcc();// sigma
			Container[k].Params[2][0][j].compute_logDensityAcc(); // delta			
		}
		
	}
	
	void set_ComputeDensityPrior_MultiNormal_NIW()
	{
		 ComputeDensityPrior_P = &::Class_Mixture_V3::ComputeDensityPrior_MultiNormal_NIW;
	}
	void ComputeDensityPrior_MultiNormal_NIW(int k, double *ret)
	{
		double retapp;
		Matrix <double> *Sigma = &Container[k].PDmat[0].SigmaAcc;
		Matrix <double> *SigmaInv = &Container[k].PDmat[0].SigmaAccInv;
		double logdet = Container[k].PDmat[0].logdetAcc;
		Matrix <double> *Psi = &CovMat[0][k].PriorParameter->PsiAcc[0];
		double nu = nVars-1+ CovMat[0][k].PriorParameter->nuAcc[0];
		
		Class_InverseWishart::compute_logdensity_noNorm( &retapp ,Sigma[0], SigmaInv[0], logdet, Psi[0],nu);
		ret[0] = retapp;
		
		
		
		for(int i=0;i<Sigma->nRows;i++)
		{
			double mean = VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0];
			double sd = pow(VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0],0.5);
			double obs = VectorParam[0][k].VectorAcc.vec(i);
			ret[0]+= dnorm(obs,mean,sd,1);
		}
	}
	
	
	/**  Posteriori dei parametri per i soli occupati **/
	void (Class_Mixture_V3::*SampParGIBBS_OnlyOcc_P)();
	void SampParGIBBS_OnlyOcc_VOID()
	{
		 error("SampParGIBBS_OnlyOcc_P() not set");
	}
	void SampParGIBBS_OnlyOcc()
	{
		 return((this->*SampParGIBBS_OnlyOcc_P)());
	}
	void (Class_Mixture_V3::*SampParMETROPOLIS_OnlyOcc_P)(vector< Poly_Adapt* > * Adapt);
	void SampParMETROPOLIS_OnlyOcc_VOID(vector< Poly_Adapt* > * Adapt)
	{
		error("SampParMETROPOLIS_OnlyOcc_P() not set");
	}
	void SampParMETROPOLIS_OnlyOcc(vector< Poly_Adapt* > * Adapt)
	{
		 return((this->*SampParMETROPOLIS_OnlyOcc_P)(Adapt));
	}
	
	
	// Multivariate Normal
	void set_SampParGIBBS_MultiNormal_OnlyOcc()
	{
		 SampParGIBBS_OnlyOcc_P = &::Class_Mixture_V3::sample_LikeParam_MultiNormLike_GIBBS_OnlyOcc;
	}
	void sample_LikeParam_MultiNormLike_GIBBS_OnlyOcc()
	{
		 sample_LikeParam_MultiNormLike_Reg_NormalPrior_OnlyOcc();  
		 sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_OnlyOcc();
	}
	
	// Multivariate Trajectory
	void set_SampParGIBBS_MultiNormalTraj_OnlyOcc()
	{
		 SampParGIBBS_OnlyOcc_P = &::Class_Mixture_V3::sample_LikeParam_MultiNormTrajLike_GIBBS_OnlyOcc;
	}
	void sample_LikeParam_MultiNormTrajLike_GIBBS_OnlyOcc()
	{
		 sample_LikeParam_MultiNormTrajLike_Reg_NormalPrior_OnlyOcc();  
		 sample_LikeParam_MultiNormTrajLikeReg_Sigma_InverseWishart_OnlyOcc();
	}
	
	// IWP
	
	
	void set_SampParMETROPOLIS_InvariantWrappedPoissonReg_OnlyOcc()
	{
		 SampParMETROPOLIS_OnlyOcc_P = &::Class_Mixture_V3::sample_LikeParam_InvariantWrappedPoissonRegLike_METROPOLIS_OnlyOcc;
	}
	void sample_LikeParam_InvariantWrappedPoissonRegLike_METROPOLIS_OnlyOcc(vector< Poly_Adapt* > * Adapt)
	{

		 sample_LikeParam_IWPREG_withLink_GeneralPrior_OnlyOcc(Adapt);
		 //REprintf("b");
		 sample_delta_InvariantWrapperPoisson_OnlyOcc();
		 
	}
	
	
	void sample_delta_InvariantWrapperPoisson_OnlyOcc()
	{
		double MH[Kmax];
		for(int k=0;k<Kmax;k++)
		{
			MH[k] = 0.0;
		}
		
		
		double parProp_P[Likelihood->nParameters*Kmax];
		double parAcc_P[Likelihood->nParameters*Kmax];
		vector<double*> parProp;
		vector<double*> parAcc;
		
		for(int k=0;k<Kmax;k++)
		{
			parProp.push_back(&parProp_P[k*Likelihood->nParameters]);
			parAcc.push_back(&parAcc_P[k*Likelihood->nParameters]);
		}
		
		double mucirc;
		double sigma2;
		double delta;
		double Npoints;
		double approx;
		int Npar = Likelihood->nParameters/Likelihood->dimObs;
		
		int jsamp = (int)floor(runif(0.0,1.0*Y.nCols));
		for(int k1=0;k1<Clusters->nNonEmpty;k1++)
		{
			int k = Clusters->NonEmptyC.vec(k1);
			int gg;
			gg = 0;
			for(int j=0;j<Y.nCols;j++)
			{
				//link = hyper[i*nparUni+0];
				mucirc = Container[k].Params[0][0][j].ParameterAcc;
				sigma2 = Container[k].Params[1][0][j].ParameterAcc;
				delta = Container[k].Params[2][0][j].ParameterAcc;
				Npoints = Container[k].Params[3][0][j].ParameterAcc;
				approx = Container[k].Params[4][0][j].ParameterAcc;
				
				parProp[k][gg] = 0.0;
				parAcc[k][gg] = 0.0;
				gg++;
				
				parProp[k][gg] = mucirc;
				parAcc[k][gg]  = mucirc;
				gg++;
				
				parProp[k][gg] = sigma2;
				parAcc[k][gg]  = sigma2;
				gg++;
				

				
				if(j==jsamp)
				{
					parProp[k][gg] = 1.0;
					parAcc[k][gg] = -1.0;
				}else{
					parProp[k][gg] = Container[k].Params[2][0][j].ParameterAcc;
					parAcc[k][gg]  = Container[k].Params[2][0][j].ParameterAcc;
				}
				gg++;
				
				parProp[k][gg] = Npoints;
				parAcc[k][gg]  = Npoints;
				gg++;
				
				parProp[k][gg] = approx;
				parAcc[k][gg]  = approx;
				gg++;
				
			}
		}
		
		
		
		for(int i=0;i<nObs;i++)
		{
			//Vector<double> Omega(nVars,Y.Pmat(obs,0));
			
			int k       = Clusters->Zeta.vec(i);
			
			
			double XbetaAccNum_P[nVars];
			Vector<double>XbetaAccNum (nVars,XbetaAccNum_P);
			
			
			double XbetaAccFact_P[nVars];
			Vector<double>XbetaAccFact (nVars,XbetaAccFact_P);
			
			
			
			Class_InvariantWrappedPoissonReg::compute_XbetaFactNum(&XbetaAccFact, nVars,i, Covariates, &VectorParam[0][k].VectorAcc, Container[k].IndexFact);
			
			
			Class_InvariantWrappedPoissonReg::compute_XbetaFactNum(&XbetaAccNum, nVars,i, Covariates, &VectorParam[0][k].VectorAcc, Container[k].IndexNumb);
			
			
			for(int j=0;j<Y.nCols;j++)
			{
				parAcc[k][j*Npar] = Likelihood->linkFunction(XbetaAccNum.Pvec(j));
				parProp[k][j*Npar] = Likelihood->linkFunction(XbetaAccNum.Pvec(j));
				
				
				
				parAcc[k][j*Npar+1] = Class_Utils::ModOp(XbetaAccFact.vec(j),2*M_PI);
				parProp[k][j*Npar+1] =Class_Utils::ModOp(XbetaAccFact.vec(j),2*M_PI);
				
				
			}
			
			
			
			
			if(Container[0].NAposTOTlongRev[0][i].nElem==Y.nCols)
			{
				//REprintf("\n%i %i All\n",i,k);
				for(int j=0;j<Y.nCols;j++)
				{
					MH[k] += Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parProp[k]);
					MH[k] -= Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parAcc[k]);
				}

				
			}else{
				if(Container[0].NAposTOTlongRev[0][i].nElem!=0)
				{
					int nvarA = Container[0].NAposTOTlongRev[0][i].nElem;
					
					for(int h=0;h<nvarA;h++)
					{
						int j = Container[0].NAposTOTlongRev[0][i].vec(h);
						
						MH[k] += Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parProp[k]);
						MH[k] -= Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parAcc[k]);
						
					}
					
				}
			}

		}
		for(int k1=0;k1<Clusters->nNonEmpty;k1++)
		{
			int k = Clusters->NonEmptyC.vec(k1);
			double alphaRatio = min(1.0,exp(MH[k]));
			//REprintf("MH %i %f\n",k,MH[k]);
			if(runif(0.0,1.0)<alphaRatio)
			{
				for(int j=0;j<Y.nCols;j++)
				{
					Container[k].Params[2][0][j].ParameterAcc = parProp[k][j*6+3];
					Container[k].Params[2][0][j].ParameterProp = parProp[k][j*6+3];
				}
			}else{
				for(int j=0;j<Y.nCols;j++)
				{
					Container[k].Params[2][0][j].ParameterAcc = parAcc[k][j*6+3];
					Container[k].Params[2][0][j].ParameterProp = parAcc[k][j*6+3];
				}
			}
			
			
			
		}
		//error("");
		
	}
	
	
	
	void sample_LikeParam_IWPREG_withLink_GeneralPrior_OnlyOcc(vector< Poly_Adapt* > * Adapt)
	{
		// multivariate obs are independent
		
		int Npar = Likelihood->nParameters/Likelihood->dimObs;
		
		double MH[Kmax];
		for(int k1=0;k1<Clusters->nNonEmpty;k1++)
		{
			int k = Clusters->NonEmptyC.vec(k1);
			
			MH[k] = 0.0;
			Adapt[0][k]->compute_TransFromAcc();
			Adapt[0][k]->Samp();
			
			Container[k].VectorCont[0].update_VectorProp();
			
			MH[k] = Adapt[0][k]->get_logDensityParameterWithLogJacobian_DiffPropAcc();
			
			
			
		}
		
		
		
		double parProp_P[Likelihood->nParameters*Kmax];
		double parAcc_P[Likelihood->nParameters*Kmax];
		vector<double*> parProp;
		vector<double*> parAcc;
		for(int k=0;k<Kmax;k++)
		{
			parProp.push_back(&parProp_P[k*Likelihood->nParameters]);
			parAcc.push_back(&parAcc_P[k*Likelihood->nParameters]);
		}
		
		//REprintf("T11\n");
		
		
		for(int k1=0;k1<Clusters->nNonEmpty;k1++)
		{
			int k = Clusters->NonEmptyC.vec(k1);
			
			//REprintf("k=%i, %i",k,Likelihood->nParameters);
			int gg;
			gg = 0;
			for(int j=0;j<Y.nCols;j++)
			{
				//REprintf("j=%i",j);
				parProp[k][gg] = 0.0;
				gg++;
				for(int np=0;np<Npar-1;np++)
				{
					//REprintf("np=%i",np);
					parProp[k][gg] = Container[k].Params[np][0][j].ParameterProp;
					gg++;
				}
			}
			gg = 0;
			for(int j=0;j<Y.nCols;j++)
			{
				//REprintf("j=%i",j);
				parAcc[k][gg] = 0.0;
				gg++;
				for(int np=0;np<Npar-1;np++)
				{
					parAcc[k][gg] = Container[k].Params[np][0][j].ParameterAcc;
					gg++;
				}
			}
			
		}
		

		for(int i=0;i<nObs;i++)
		{
			//REprintf("%i=i\n",i);
			//Vector<double> Omega(nVars,Y.Pmat(obs,0));
			
			int k       = Clusters->Zeta.vec(i);
			
			
			
			double XbetaAccNum_P[nVars];
			Vector<double>XbetaAccNum (nVars,XbetaAccNum_P);
			double XbetaPropNum_P[nVars];
			Vector<double>XbetaPropNum (nVars,XbetaPropNum_P);
			
			double XbetaAccFact_P[nVars];
			Vector<double>XbetaAccFact (nVars,XbetaAccFact_P);
			double XbetaPropFact_P[nVars];
			Vector<double>XbetaPropFact (nVars,XbetaPropFact_P);
			
			//REprintf("M1\n");
			Class_InvariantWrappedPoissonReg::compute_XbetaFactNum(&XbetaAccFact, nVars,i, Covariates, &VectorParam[0][k].VectorAcc, Container[k].IndexFact);
			Class_InvariantWrappedPoissonReg::compute_XbetaFactNum(&XbetaPropFact, nVars,i, Covariates, &VectorParam[0][k].VectorProp, Container[k].IndexFact);
			//REprintf("M2\n");
			Class_InvariantWrappedPoissonReg::compute_XbetaFactNum(&XbetaAccNum, nVars,i, Covariates, &VectorParam[0][k].VectorAcc, Container[k].IndexNumb);
			Class_InvariantWrappedPoissonReg::compute_XbetaFactNum(&XbetaPropNum, nVars,i, Covariates, &VectorParam[0][k].VectorProp, Container[k].IndexNumb);
			
			
			
			for(int j=0;j<Y.nCols;j++)
			{
				parAcc[k][j*Npar] = Likelihood->linkFunction(XbetaAccNum.Pvec(j));
				parProp[k][j*Npar] = Likelihood->linkFunction(XbetaPropNum.Pvec(j));
				
				parAcc[k][j*Npar+1] =  Class_Utils::ModOp(XbetaAccFact.vec(j),2*M_PI)  ;
				parProp[k][j*Npar+1] = Class_Utils::ModOp(XbetaPropFact.vec(j),2*M_PI);
			}
			
			if(Container[0].NAposTOTlongRev[0][i].nElem==Y.nCols)
			{
				for(int j=0;j<Y.nCols;j++)
				{
					//REprintf("ASD %i\n",j);
					MH[k] += Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parProp[k]);
					MH[k] -= Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parAcc[k]);
					
					//                    REprintf("ParAcc %f %f %f \n",XbetaAccNum.vec(j), Likelihood->linkFunction(XbetaAccNum.Pvec(j)),Container[k].Cov[0].mat(i*3+0,0));
					//                    REprintf("ParProp %f %f %f \n",XbetaPropNum.vec(j), Likelihood->linkFunction(XbetaPropNum.Pvec(j)),Container[k].Cov[0].mat(i*3+0,0));
					//                    for(int hhh=0;hhh<6;hhh++)
					//                    {
					//                        REprintf("%f %f  \n",parAcc[k][hhh], parProp[k][hhh]);
					//                    }
					//                    REprintf("\n");
				}
				
			}else{
				if(Container[0].NAposTOTlongRev[0][i].nElem!=0)
				{
					int nvarA = Container[0].NAposTOTlongRev[0][i].nElem;
					
					for(int h=0;h<nvarA;h++)
					{
						int j = Container[0].NAposTOTlongRev[0][i].vec(h);
						
						MH[k] += Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parProp[k]);
						MH[k] -= Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parAcc[k]);
						
					}
					
				}
			}
			
		}
		//error("");
		for(int k1=0;k1<Clusters->nNonEmpty;k1++)
		{
			int k = Clusters->NonEmptyC.vec(k1);
			//REprintf("%i %f \n", k, MH[k]);
			//REprintf("%i\n",k);
			//Adapt[0][k]->PrintObject("Adapt pre\n");
			double alphaRatio = min(1.0,exp(MH[k]));
			//REprintf("Acc %f %f",alphaRatio,MH[k]);
			if(runif(0.0,1.0)<alphaRatio)
			{
				Adapt[0][k]->UpdateIfAccepted();
				Container[k].VectorCont[0].update_VectorAcc();
			}
			Adapt[0][k]->PostSamp(alphaRatio);

			
		}

		
	}
	

    
	
//	void compute_BivNormRotated_NormalTrajectory()
//	{
//		 // Ricordarsi che prima bisogna creare Ytrasformed
//		 
//		 // the locations
//		 double Loc_P[nVars];
//		 Vector <double> Loc(nVars,Loc_P);
//		 
//		 double PrevLoc_P[nVars];
//		 Vector <double> PrevLoc(nVars,PrevLoc_P);
//		 
//		 double PrevPrevLoc_P[nVars];
//		 Vector <double> PrevPrevLoc(nVars,PrevPrevLoc_P);
//		 
//		 double RotAngle;
//		 double R_P[4];
//		 Matrix <double> R(2,2,R_P);
//		 
//		 int t;
//		 double ret_P[2];
//		 Vector<double> ret(2,ret_P);
//		 double retapp_P[2];
//		 Vector<double> retapp(2,retapp_P);
//		 
//		 
//		 
//		 t = 0;
//		 ret.P           = YTransformed.Pmat(t,0);
//		 PrevLoc.P       = Y.Pmat(t,0);
//		 Loc.P           = Y.Pmat(t+1,0);
//		 RotAngle        = LatentVariables.Pvec(0)[0];
//		 Class_NormalTrajectory::external_compute_RotationMatrix(RotAngle, &R);
//		 Class_NormalTrajectory::external_compute_BivNormRotated(&ret, &R, &retapp, &PrevLoc,  &Loc);
//		 
//		 for(t=1;t<nObs-1;t++)
//		 {
//			  ret.P               = YTransformed.Pmat(t,0);
//			  PrevPrevLoc.P       = Y.Pmat(t-1,0);
//			  PrevLoc.P           = Y.Pmat(t,0);
//			  Loc.P               = Y.Pmat(t+1,0);
//			  
//			  
//			  RotAngle = atan2(PrevLoc.vec(1)-PrevPrevLoc.vec(1),PrevLoc.vec(0)-PrevPrevLoc.vec(0));
//			  Class_NormalTrajectory::external_compute_RotationMatrix(RotAngle, &R);
//			  Class_NormalTrajectory::external_compute_BivNormRotated(&ret, &R, &retapp, &PrevLoc,  &Loc);
//		 }
//		 t = nObs-1;
//		 ret.P               = YTransformed.Pmat(t,0);
//		 PrevPrevLoc.P       = Y.Pmat(t-1,0);
//		 PrevLoc.P           = Y.Pmat(t,0);
//		 Loc.P               = LatentVariables.Pvec(1);
//		 
//		 RotAngle = atan2(PrevLoc.vec(1)-PrevPrevLoc.vec(1),PrevLoc.vec(0)-PrevPrevLoc.vec(0));
//		 Class_NormalTrajectory::external_compute_RotationMatrix(RotAngle, &R);
//		 Class_NormalTrajectory::external_compute_BivNormRotated(&ret, &R, &retapp, &PrevLoc,  &Loc);
//		 
//		 
//	}
	
	
    /*****   ADD ****/

//	void add_LatentVariables(int nr, int nc)
//	{
//		 LatentVariables             = Matrix<double>(nr,nc, 0);
//		 LatentVariablesProp         = Matrix<double>(nr,nc, 0);
//	}
//	void add_YTransformed()
//	{
//		 YTransformed                = Matrix<double>(Y.nRows,Y.nCols,UserControlledMemory);
//	};
	
    void add_Varmat_for_MultiNormal( vector<Class_Parameter_PDMatrixUnivSamp >   *covmat)
    {
        CovMat  = covmat;
        
        for(int k=0;k<Kmax;k++)
        {
            Container[k].PDmat  = &covmat[0][k];
        }
        
    }
    
    void add_RegCoefVarmat(vector<VectorParameters> *regCoef, vector<Class_Parameter_PDMatrixUnivSamp >   *covmat, Matrix<double> *Covar)
    {
        VectorParam = regCoef;
        CovMat  = covmat;
        Covariates = Covar;
        
        for(int k=0;k<Kmax;k++)
        {
            Container[k].VectorCont = &regCoef[0][k];
            Container[k].PDmat  = &covmat[0][k];
            Container[k].Cov    = &Covar[0];
        }
        
    }
    void add_RegCoef(vector<VectorParameters> *regCoef, Matrix<double> *Covar)
    {
        VectorParam = regCoef;
        Covariates = Covar;
        
        for(int k=0;k<Kmax;k++)
        {
            Container[k].VectorCont = &regCoef[0][k];
            Container[k].Cov    = &Covar[0];
        }
        
    }
    
    void add_IndexFactNum(Vector<int>*FactIndex, Vector<int>*NumbIndex)
    {

        for(int k=0;k<Kmax;k++)
        {
            Container[k].IndexFact = FactIndex;
            Container[k].IndexNumb = NumbIndex;
        }
        
    }
    void add_Parameter(vector<vector<Class_Parameter> > *Par)
    {
        for(int k=0;k<Kmax;k++)
        {
            Container[k].Params.push_back(&Par[0][k]);
        }
    }
    void add_MissinObject(vector<Vector <int> > *NAposTOT_a, vector<Vector <int> > *NAposTOTlongRev_a,Vector<int> *IndexNA_a )
    {
        for(int k=0;k<Kmax;k++)
        {
            Container[k].NAposTOT          = NAposTOT_a;
            Container[k].NAposTOTlongRev   = NAposTOTlongRev_a;
            Container[k].IndexNA           = IndexNA_a;
        }
    }

    
    void add_RegVarmat_for_MultiNormal_Type_Clima(vector<VectorParameters> *regCoef, vector<Class_Parameter_PDMatrixUnivSamp >   *covmat, Matrix<double> *Covar, Vector <int> *TypeLike)
    {
        VectorParam = regCoef;
        CovMat  = covmat;
        Covariates = Covar;
        
        for(int k=0;k<Kmax;k++)
        {
            Container[k].VectorCont = &regCoef[0][k];
            Container[k].PDmat  = &covmat[0][k];
            Container[k].Cov    = &Covar[0];
            Container[k].TypeLike    = &TypeLike[0];
        }
        
    }
    void add_RegVarmat_for_MultiNormal_Type_ClimaSeason(vector<VectorParameters> *regCoef, vector<Class_Parameter_PDMatrixUnivSamp >   *covmat, Matrix<double> *Covar, Vector <int> *TypeLike,vector<Class_Gaussian_Multivariate> *GP)
    {
        VectorParam = regCoef;
        CovMat  = covmat;
        Covariates = Covar;
        
        for(int k=0;k<Kmax;k++)
        {
            Container[k].VectorCont = &regCoef[0][k];
            Container[k].PDmat  = &covmat[0][k];
            Container[k].Cov    = &Covar[0];
            Container[k].TypeLike    = &TypeLike[0];
            //Container[k].GPVec    = &GP[0];
            for(int j=0;j<GP->size(); j++)
            {
                Container[k].GPVec.push_back(&GP[0][j].Omega);
            }
        }
        
        
        
    }
    
	/*******SAMPLE NA *****/
    void sampleNA()
    {
		 //REprintf("NA");
        //#pragma omp parallel for default(none) 
        for(int  j=0;j<Container[0].IndexNA->nElem;j++)
        {
			  //REprintf("%i \n",j);
            int obs     = Container[0].IndexNA->vec(j);
            int k       = Clusters->Zeta.vec(obs);
            
            double omega_P[nVars];
            Vector <double> omega(nVars,omega_P);
            omega.P = Y.Pmat(obs,0);
            //REprintf("%i %i %i \n", j,obs,k);
            Likelihood->sample_SubsetOrAll(&Container[0].NAposTOT[0][j],obs, Container[k], &omega);
        }
    }
    
    
    
    void sampleNA_uni( vector< Vector<int> > *VectorNA)
    {
        int obs;
        for(int i=0;i<nVars;i++)
        {
            //Rprintf("i= %i",i);
            for(int  j=0;j<VectorNA[0][i].nElem;j++)
            {
                obs     = VectorNA[0][i].vec(j);
                int k       = Clusters->Zeta.vec(obs);
                
                double omega_P[nVars];
                Vector <double> omega(nVars,omega_P);
                omega.P = Y.Pmat(obs,0);
                
                Likelihood->sample_uni(i, obs, Container[k], &omega);
            }
        }
    }
    void sampleNA_multi(Vector<int>  *VectorNA)
    {
        for(int  j=0;j<VectorNA[0].nElem;j++)
        {
            int obs     = VectorNA[0].vec(j);
            int k       = Clusters->Zeta.vec(obs);
            
            double omega_P[nVars];
            Vector <double> omega(nVars,omega_P);
            omega.P = Y.Pmat(obs,0);
            
            Likelihood->sample_Multi(obs,Container[k], &omega);
        }
    }
    
    
    void sampleNA_MultiNormLikeRegUni( vector< Vector<int> > *VectorNA)
    {
        //error("Da Testare");
        int obs;
        for(int i=0;i<nVars;i++)
        {
            //Rprintf("i= %i",i);
            for(int  j=0;j<VectorNA[0][i].nElem;j++)
            {
                //Rprintf("j= %i\n",j);
                obs     = VectorNA[0][i].vec(j);
                //Rprintf("VectorNA[0][i].vec(j)= %i\n",VectorNA[0][i].vec(j));
                sampleNA_MultiNormLikeRegUni( obs, i);
            }
        }
    }
    void sampleNA_MultiNormLikeRegUni( int obs, int nvar)
    {
        
        // da testare
        double omega_P[nVars];
        Vector <double> omega(nVars,omega_P);
        
        double muA;
        double varA;
        
        muA     = 0.0;
        varA    = 0.0;
        
        //int obs;
        int k;
        int i;
        int j;
        int h;
        i = nvar;
        
        //obs     = VectorNA[0][i].vec(j);
        k       = Clusters->Zeta.vec(obs);
        double Xbeta_P[nVars];
        Vector<double>Xbeta (nVars,Xbeta_P);
        
        for(h=0;h<nVars;h++)
        {
            Xbeta.Pvec(h)[0] = 0.0;
            for(j = 0; j<Covariates->nCols;j++)
            {
                Xbeta.Pvec(h)[0] += Covariates[0].mat(nVars*obs+h,j)*VectorParam[0][k].VectorAcc.vec(j);
            }
        }
        
        omega.P = Y.Pmat(obs,0);
        Class_MultivariateNormal::external_computeConditioanlMeanAndVariance_uni(i,  &muA,  &varA, &CovMat[0][k].SigmaAccInv, &Xbeta, &omega);
        
        Y.Pmat(obs,i)[0] = rnorm(muA, pow(varA,0.5));
    }
    
    void sampleNA_MultiNormLikeRegAll( Vector<int>  *VectorNA)
    {
        //error("Da Testare");
        
        for(int  j=0;j<VectorNA[0].nElem;j++)
        {
            int obs     = VectorNA[0].vec(j);
            sampleNA_MultiNormLikeRegAll( obs);
        }
    }
    void sampleNA_MultiNormLikeRegAll( int obs)
    {
        // DA FARE UN CHECK -  non so se funziona
        
        //        double muA;
        //        double varA;
        //
        //        muA     = 0.0;
        //        varA    = 0.0;
        
        //int obs;
        int k;
        //int i;
        int j;
        int h;
        
        
        
        Vector<double> Omega(nVars,Y.Pmat(obs,0));
        
        k       = Clusters->Zeta.vec(obs);
        double Xbeta_P[nVars];
        Vector<double>Xbeta (nVars,Xbeta_P);
        
        for(h=0;h<nVars;h++)
        {
            Xbeta.Pvec(h)[0] = 0.0;
            for(j = 0; j<Covariates->nCols;j++)
            {
                Xbeta.Pvec(h)[0] += Covariates[0].mat(nVars*obs+h,j)*VectorParam[0][k].VectorAcc.vec(j);
            }
        }
        Class_MultivariateNormal::external_SampleMultivariate(&Omega, &Xbeta, &CovMat[0][k].SigmaCholAcc);
        
        
        
    }
    
    
    
	/**** sample aprameters ***/
	void sample_FromPrior_MultiNormLike_Reg_NormalPrior(int k)
	{
		int dimCov = Covariates->nCols;
		for(int j=0;j<dimCov;j++)
		{
			VectorParam[0][k].VectorAcc.Pvec(j)[0] = rnorm(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(0)[0],pow(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(1)[0],0.5));
		}
		VectorParam[0][k].update_ParameterAcc();
		 
	}
	
	void sample_LikeParam_MultiNormTrajLike_Reg_NormalPrior_OnlyOcc()
	{
		 //sample_LikeParam_MultiNormLike_Reg_NormalPrior_OnlyOcc(&YTransformed);
	}
	
	void sample_LikeParam_MultiNormLike_Reg_NormalPrior_OnlyOcc()
	{
		 
		 sample_LikeParam_MultiNormLike_Reg_NormalPrior_OnlyOcc(&Y);
		 
	}
	
	void sample_LikeParam_MultiNormLike_Reg_NormalPrior_OnlyOcc(Matrix <double> * Data)
	{
		
//		string NAMEdir = "/work/gmastrantonio/ODE/lancio/";
//		#ifdef _OPENMP
//		string appNamedir = (NAMEdir+to_string(omp_get_thread_num())+"Media.txt");
//		#else
//		string appNamedir = (NAMEdir+to_string(0)+".txt");
//		#endif
//		FILE * (file);
//		time_t my_time = time(NULL);
		 int k,i,j;
		 
		 const double SumPar = 1.0;
		 int dimCov = Covariates->nCols;
		 
		double CovApp_P[nVars*dimCov];
		 Matrix <double> CovApp(nVars,dimCov,Covariates[0].Pmat(0,0));
		 Vector <double> YApp(nVars,Data[0].Pmat(0,0));
		 
		 
		 double MeanPar_P[dimCov*Kmax];
		 double CovPar_P[dimCov*dimCov*Kmax];
		 vector <Vector<double> > MeanPar;
		 vector <Matrix<double> > CovPar;
		 
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time)); 
//		fprintf(file, "A1\n \n");
//		fclose (file);
		 for(k=0;k< Kmax;k++)
		 {
			  MeanPar.push_back(Vector<double>(dimCov,&MeanPar_P[k*dimCov]));
			  CovPar.push_back(Matrix<double>(dimCov,dimCov,&CovPar_P[k*dimCov*dimCov]));
		 }

		 for(i=0;i< Clusters->nNonEmpty;i++)
		 {
			  k = Clusters->NonEmptyC.vec(i);
			  MeanPar[k].Init(0.0);
			  CovPar[k].Init(0.0);
			  
		 }
//		 file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time)); 
//		fprintf(file, "A2\n \n");
//		fclose (file);
		 for(j=0;j< Clusters->nNonEmpty;j++)
		 {
			  k = Clusters->NonEmptyC.vec(j);
			  // prior hyperparameters
			  for(i=0;i<dimCov;i++)
			  {					
					CovPar[k].Pmat(i,i)[0]   = 1.0/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
					MeanPar[k].Pvec(i)[0]  = VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
			  }
			  
		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time)); 
//		fprintf(file, "A3\n \n");
//		fclose (file);
		 for(i=0;i<nObs;i++)
		 {
			
			  k           = Clusters->Zeta.vec(i);
			  CovApp.P = Covariates[0].Pmat(i*nVars,0);
			  YApp.P = Data[0].Pmat(i,0);
			 Class_MultivariateNormal::external_ParametersForFullConditioanlBeta_WithoutMolt(&CovApp,  &CovMat[0][k].SigmaAccInv, &YApp, &CovPar[k], &MeanPar[k], &SumPar); 
		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time)); 
//		fprintf(file, "A4\n \n");
//		fclose (file);
		 for(i=0;i< Clusters->nNonEmpty;i++)
		 {
			  k = Clusters->NonEmptyC.vec(i);
			  Class_MultivariateNormal::external_finalizedRegFullConditional(&CovPar[k],&MeanPar[k], 1);
			  Class_MultivariateNormal::external_SampleMultivariate(&VectorParam[0][k].VectorAcc, &MeanPar[k], &CovPar[k]);
			  VectorParam[0][k].update_ParameterAcc();
		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time)); 
//		fprintf(file, "A5\n \n");
//		fclose (file);

	}
	
	
//	void sample_LikeParam_MultiNormLike_Reg_NormalPrior_OnlyOcc(Matrix <double> * Data)
//	{
//		
//		//string NAMEdir = "/Users/gianlucamastrantonio/Dropbox (Politecnico di Torino Staff)/lavori/ode/TESTOUT/";
//		string NAMEdir = "/work/gmastrantonio/ODE/lancio/";
//
//		#ifdef _OPENMP
//		string appNamedir = (NAMEdir+to_string(omp_get_thread_num())+"Media.txt");
//		#else
//		string appNamedir = (NAMEdir+to_string(0)+".txt");
//		#endif
//		FILE * (file);
//		time_t my_time = time(NULL);
//		
//		
//	 
//		 int k,i,j;
//		 
//		 const double SumPar = 1.0;
//		 int dimCov = Covariates->nCols;
//		 
//		double CovApp_P[nVars*dimCov];
//		 Matrix <double> CovApp(nVars,dimCov,Covariates[0].Pmat(0,0));
//		//double YApp_P[nVars];
//		 Vector <double> YApp(nVars,Data[0].Pmat(0,0));
//		 
//		 
//		 double MeanPar_P[dimCov*Kmax];
//		 double CovPar_P[dimCov*dimCov*Kmax];
//		 vector <Vector<double> > MeanPar;
//		 vector <Matrix<double> > CovPar;
//		 
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time)); 
//		fprintf(file, "A1\n \n");
//		fclose (file);
//		 //Rprintf("A1_1 %i %i  %i %i %i\n",Kmax, nObs, Covariates->nRows,dimCov, Clusters->nNonEmpty );
//		 for(k=0;k< Kmax;k++)
//		 {
//			  MeanPar.push_back(Vector<double>(dimCov,&MeanPar_P[k*dimCov]));
//			  CovPar.push_back(Matrix<double>(dimCov,dimCov,&CovPar_P[k*dimCov*dimCov]));
//		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		 fprintf(file, "A2\n \n");
//		fclose (file);
//		 for(i=0;i< Clusters->nNonEmpty;i++)
//		 {
//			  //REprintf("dj=%i k=%i \n",i,Clusters->NonEmptyC.vec(i));
//			  k = Clusters->NonEmptyC.vec(i);
//			  //Rprintf("A1_3\n");
//			  MeanPar[k].Init(0.0);
//			  CovPar[k].Init(0.0);
//			  
//		 }
//		 
//		 //Rprintf("A5\n");
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		fprintf(file, "A3\n \n");
//		fclose (file);
//		 for(j=0;j< Clusters->nNonEmpty;j++)
//		 {
//			  //REprintf("j=%i k=%i \n",j,Clusters->NonEmptyC.vec(j));
//			  k = Clusters->NonEmptyC.vec(j);
//			  // prior hyperparameters
//			  for(i=0;i<dimCov;i++)
//			  {
//					//REprintf("%i %f %f\n",i,VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0],VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]);
//					
//					CovPar[k].Pmat(i,i)[0]   = 1.0/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
//					MeanPar[k].Pvec(i)[0]  = VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
//			  }
//			  
//		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		 fprintf(file, "A4 \n");
//		fclose (file);
//		 //Rprintf("A6\n");
//		//REprintf("A6e\n");
//		 for(i=0;i<nObs;i++)
//		 {
//			 //REprintf("i=%i",i);
//			  k           = Clusters->Zeta.vec(i);
//			 //REprintf("AA %i mmm\n",k);
//			  CovApp.P = Covariates[0].Pmat(i*nVars,0);
//			  YApp.P = Data[0].Pmat(i,0);
//			  // molto poco performante
//	  Class_MultivariateNormal::external_ParametersForFullConditioanlBeta_WithoutMolt(&CovApp,  &CovMat[0][k].SigmaAccInv, &YApp, &CovPar[k], &MeanPar[k], &SumPar);
//			  
//			  
//		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		fprintf(file, "A5 \n");
//		fclose (file);
//		 for(i=0;i< Clusters->nNonEmpty;i++)
//		 {
//			  k = Clusters->NonEmptyC.vec(i);
//			  //CovPar[k].Print("Cov2");
//			  //MeanPar[k].Print("Mean2");
//			  //Rprintf("%i %i\n",Clusters->nNonEmpty,Clusters->NonEmptyC.vec(i));
//			  Class_MultivariateNormal::external_finalizedRegFullConditional(&CovPar[k],&MeanPar[k], 1);
//			  
//			  Class_MultivariateNormal::external_SampleMultivariate(&VectorParam[0][k].VectorAcc, &MeanPar[k], &CovPar[k]);
//			  VectorParam[0][k].update_ParameterAcc();
//		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		fprintf(file, "A6 \n");
//		fclose (file);
//
//		 
//	}
	
    
    
	
	void sample_FromPrior_MultiNormLikeReg_Sigma_InverseWishart(int k)
	{
		Class_InverseWishart::sampleInvWishartPsiDiag(nVars,&CovMat[0][k].SigmaAcc,&CovMat[0][k].SigmaAccInv, &CovMat[0][k].PriorParameter->PsiAcc[0], CovMat[0][k].PriorParameter->nuAcc[0]);
		CovMat[0][k].compute_InvAccAndChol();

	}
	void sample_LikeParam_MultiNormTrajLikeReg_Sigma_InverseWishart_OnlyOcc()
	{
		 //sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_OnlyOcc(&YTransformed);
	}
	void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_OnlyOcc()
	{
		 sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_OnlyOcc(&Y);
	}
	
	 void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_OnlyOcc(Matrix <double> * Data)
	 {
		 
//		 string NAMEdir = "/work/gmastrantonio/ODE/lancio/";
//		#ifdef _OPENMP
//		string appNamedir = (NAMEdir+to_string(omp_get_thread_num())+"Var.txt");
//		#else
//		string appNamedir = (NAMEdir+to_string(0)+".txt");
//		#endif
//		FILE * (file);
//		time_t my_time = time(NULL);
		  
		  
		 double appMeanPar_P[nVars];
		 Vector<double> appMeanPar(nVars,&appMeanPar_P[0]);
		 
		  
		  double nu_P[Kmax];
		  Vector<double> nu(Kmax,&nu_P[0]);
		  
		  
//		  file = fopen(appNamedir.c_str(),"wt");
//		  fprintf(file,"%s", ctime(&my_time)); 
//		  fprintf(file, "A1\n \n");
//		  fclose (file);
		 
		  double Xbeta_P[nVars];
		  Vector<double>Xbeta (nVars,&Xbeta_P[0]);

		 double CovPar_P[nVars*nVars*Kmax];
		 vector <Matrix<double> *> CovPar;
		  for(int k=0;k< Kmax;k++)
		  {
				CovPar.push_back(new Matrix<double>(nVars,nVars,&CovPar_P[k*nVars*nVars]));
		  }
//REprintf("D2 \n");
		  for(int i=0;i< Clusters->nNonEmpty;i++)
		  {
				int k = Clusters->NonEmptyC.vec(i);
				CovPar[k][0].Init(0.0);
	
		  }
		 
//		  file = fopen(appNamedir.c_str(),"wt");
//		  fprintf(file,"%s", ctime(&my_time)); 
//		  fprintf(file, "A2\n \n");
//		  fclose (file);
		 
//REprintf("D3 \n");
		  for(int i=0;i< Clusters->nNonEmpty;i++)
		  {
				int k = Clusters->NonEmptyC.vec(i);
				nu.Pvec(k)[0] = CovMat[0][k].PriorParameter->nuAcc[0]+Clusters->NObsInClust.vec(k);
				
				CovPar[k][0].Init(0.0);
				for(int h=0;h<nVars;h++)
				{
					 for(int j=0;j<nVars;j++)
					 {
						  CovPar[k][0].Pmat(h,j)[0] = CovMat[0][k].PriorParameter->PsiAcc[0].Pmat(h,j)[0];
					 }
					 
				}
				
		  }
		  
//		 file = fopen(appNamedir.c_str(),"wt");
//		  fprintf(file,"%s", ctime(&my_time)); 
//		  fprintf(file, "A3\n \n");
//		  fclose (file);
		 
//REprintf("D4 \n");
		  for(int i=0;i<nObs;i++)
		  {
				// likelihood contribution
				int k           = Clusters->Zeta.vec(i);
			  Vector <double> omega(nVars,Data->Pmat(i,0));
				
				for(int h=0;h<nVars;h++)
				{
					 Xbeta.Pvec(h)[0] = 0.0;
					 for(int j = 0; j<Covariates->nCols;j++)
					 {
						  Xbeta.Pvec(h)[0] += Covariates[0].mat(nVars*i+h,j)*VectorParam[0][k].VectorAcc.vec(j);
					 }
				}
				
				for(int j=0;j<nVars;j++)
				{
					 for(int h=j;h<nVars;h++)
					 {
						  CovPar[k][0].Pmat(j,h)[0] += (omega.vec(j)-Xbeta.vec(j))*(omega.vec(h)-Xbeta.vec(h));
					 }
				}
		  }
		  
//		 file = fopen(appNamedir.c_str(),"wt");
//		  fprintf(file,"%s", ctime(&my_time)); 
//		  fprintf(file, "A4\n \n");
//		  fclose (file);
		 
//REprintf("D5 \n");
		  for(int i=0;i< Clusters->nNonEmpty;i++)
		  {
				
				int k = Clusters->NonEmptyC.vec(i);
				Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc, &CovMat[0][k].SigmaAccInv, &CovPar[k][0], nu.Pvec(k)[0]);
				
				CovMat[0][k].compute_InvAccAndChol();
		  }
		  
//		 file = fopen(appNamedir.c_str(),"wt");
//		  fprintf(file,"%s", ctime(&my_time)); 
//		  fprintf(file, "A5\n \n");
//		  fclose (file);
		 
//REprintf("D6 \n");
	 }
//	void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_OnlyOcc(Matrix <double> * Data)
//		{
//			
//			
//			//string NAMEdir = "/Users/gianlucamastrantonio/Dropbox (Politecnico di Torino Staff)/lavori/ode/TESTOUT/";
//		  string NAMEdir = "/work/gmastrantonio/ODE/lancio/";
//		  #ifdef _OPENMP
//		  string appNamedir = (NAMEdir+to_string(omp_get_thread_num())+"Var.txt");
//		  #else
//		  string appNamedir = (NAMEdir+to_string(0)+".txt");
//		  #endif
//		  FILE * (file);
//		  time_t my_time = time(NULL);
//			
//			 int k,i,j,h;
//			 int K = Kmax;
//			 
//			 
//			double appMeanPar_P[nVars];
//			Vector<double> appMeanPar(nVars,&appMeanPar_P[0]);
//			
//			 
//			 double nu_P[K];
//			 Vector<double> nu(K,&nu_P[0]);
//			 
//			 
//			 
//			 double omega_P[nVars];
//			 Vector <double> omega(nVars,&omega_P[0]);
//			 
//			 double Xbeta_P[nVars];
//			 Vector<double>Xbeta (nVars,&Xbeta_P[0]);
//			
//			file = fopen(appNamedir.c_str(),"wt");
//		  fprintf(file,"%s", ctime(&my_time));
//			fprintf(file, "A1 \n");
//		  fclose (file);
//			
//			
//			double CovPar_P[nVars*nVars*K];
//			vector <Matrix<double> *> CovPar;
//			 for(k=0;k< Kmax;k++)
//			 {
//				  CovPar.push_back(new Matrix<double>(nVars,nVars,&CovPar_P[k*nVars*nVars]));
//			 }
//			 for(i=0;i< Clusters->nNonEmpty;i++)
//			 {
//				  k = Clusters->NonEmptyC.vec(i);
//				  CovPar[k][0].Init(0.0);
//				  
//				  //nclust[k] = 0.0;
//			 }
//		  file = fopen(appNamedir.c_str(),"wt");
//		  fprintf(file,"%s", ctime(&my_time));
//			fprintf(file, "A2 \n");
//		  fclose (file);
//			 //Rprintf("S2\n");
//			 for(i=0;i< Clusters->nNonEmpty;i++)
//			 {
//				  k = Clusters->NonEmptyC.vec(i);
//				  nu.Pvec(k)[0] = nVars-1+ CovMat[0][k].PriorParameter->nuAcc[0]+Clusters->NObsInClust.vec(k);
//				  
//				  CovPar[k][0].Init(0.0);
//				  for(h=0;h<nVars;h++)
//				  {
//						for(j=0;j<nVars;j++)
//						{
//							 CovPar[k][0].Pmat(h,j)[0] = CovMat[0][k].PriorParameter->PsiAcc[0].Pmat(h,j)[0];
//						}
//						
//				  }
//				  
//			 }
//		  file = fopen(appNamedir.c_str(),"wt");
//		  fprintf(file,"%s", ctime(&my_time));
//		  fprintf(file, "A3 \n");
//		  fclose (file);
//			 //Rprintf("S3\n");
//			 for(i=0;i<nObs;i++)
//			 {
//				  // likelihood contribution
//				  k           = Clusters->Zeta.vec(i);
//				  omega.P     = Data->Pmat(i,0);
//				  
//				  for(h=0;h<nVars;h++)
//				  {
//						Xbeta.Pvec(h)[0] = 0.0;
//						for(j = 0; j<Covariates->nCols;j++)
//						{
//							 Xbeta.Pvec(h)[0] += Covariates[0].mat(nVars*i+h,j)*VectorParam[0][k].VectorAcc.vec(j);
//						}
//				  }
//				  
//				  for(j=0;j<nVars;j++)
//				  {
//						for(h=j;h<nVars;h++)
//						{
//							 CovPar[k][0].Pmat(j,h)[0] += (omega.vec(j)-Xbeta.vec(j))*(omega.vec(h)-Xbeta.vec(h));
//						}
//				  }
//			 }
//		  file = fopen(appNamedir.c_str(),"wt");
//		  fprintf(file,"%s", ctime(&my_time));
//			fprintf(file, "A4 \n");
//		  fclose (file);
//			 //Rprintf("%i\n ", Clusters->nNonEmpty);
//			 //        for(i=0;i< Clusters->nNonEmpty;i++)
//			 //        {
//			 //            Rprintf("%i  ", Clusters->NonEmptyC.vec(i));
//			 //        }
//			 //Rprintf("S4\n");
//			 for(i=0;i< Clusters->nNonEmpty;i++)
//			 {
//				  
//				  k = Clusters->NonEmptyC.vec(i);
//				  Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc, &CovMat[0][k].SigmaAccInv, &CovPar[k][0], nu.Pvec(k)[0]);
//				  
//				  CovMat[0][k].compute_InvAccAndChol();
//			 }
//	//		file = fopen(appNamedir.c_str(),"wt");
//		  fprintf(file,"%s", ctime(&my_time));
//		  fprintf(file, "A5 \n");
//		  fclose (file);
//			 
//			 
//
//		}
  
    
    /***SAMP MIXTURE */
    
//    void samp_stMixtureDP_FixedK()
//    {
//        samp_stMixtureDP_CheckLastElementNocheck();
//        Clusters->update_EmptyAndNonEmptyClusters();
//    }
//    void samp_stMixtureDP_CheckLastElement()
//    {
//        samp_stMixtureDP_CheckLastElementNocheck();
//        if(Clusters->nNonEmpty>=(Kmax))
//        {
//            //Rprintf("error: Kmax occupied regimes -  approximation is not valid\n");
//        }
//        Clusters->update_EmptyAndNonEmptyClusters();
//    }
//	
//	
//	void samp_stMixtureDP_CheckLastElement(Class_Parameter *DPpar)
//	{
//		 samp_stMixtureDP_CheckLastElementNocheck(DPpar);
//		 if(Clusters->nNonEmpty>=(Kmax))
//		 {
//			  //Rprintf("error: Kmax occupied regimes -  approximation is not valid\n");
//		 }
//		 Clusters->update_EmptyAndNonEmptyClusters();
//	}
//	void samp_stMixtureDP_CheckLastElementNocheck(Class_Parameter *DPpar)
//	 {
//		  //double u;
//		  
//		  vector< vector <int> > AppSamp;
//		  //double sum;
//		  int i,k;
//		  double ret_P[Kmax];
//		  Vector<double> ret(Kmax,ret_P);
//		 
//		 int veck_P[Kmax];
//		 Vector<int> veck(Kmax,veck_P);
//		 int vecNonk_P[Kmax];
//		 Vector<int> vecNonk(Kmax,vecNonk_P);
//		  
//		  
//		 int Noccupied = Clusters->nNonEmpty; 
//		 int N_Nonoccupied; 
//		  Vector<double> ObsY(nVars,Y.Pmat(0,0));
//		 
//		 //Clusters->NObsInClust.Print("nObs");
//		  for(i=0;i<nObs;i++)
//		  {
//			  //REprintf("Obs %i Occ %i\n",i, Noccupied);
//			  ObsY.P = Y.Pmat(i,0);
//			  int doUpdate = 1;
//			  int kobs = Clusters->Zeta.vec(i);
//			  Clusters->NObsInClust.Pvec(kobs)[0]--;
//			  if(Clusters->NObsInClust.vec(kobs)==0)
//			  {
//				  Noccupied--;
//				  if(runif(0.0,1.0)< (1.0*Noccupied-1.0)/(1.0*Noccupied))
//				  {
//					  doUpdate = 0;
//					  Noccupied++;
//					  Clusters->NObsInClust.Pvec(kobs)[0]++;
//				  }
//				 
//			  }
//			  if(doUpdate!=0)
//			  {
//				  if(Noccupied==Kmax)
//				  {
//					  ret.nElem = Kmax;
//					  for(int k=0;k<Kmax;k++)
//					  {
//							Likelihood->computeLogDensityForLike_WithoutNA(ret.Pvec(k),&ObsY, &Container[k], i);
//							ret.Pvec(k)[0] += log(Clusters->NObsInClust.vec(k));
//					  }
//					  Clusters->Zeta.Pvec(i)[0] = Class_Utils::sample_DiscreteVar(ret.P, Kmax);
//					  Clusters->NObsInClust.Pvec(Clusters->Zeta.vec(i))[0]++;
//					
//				  }else{
//					  ret.nElem = Noccupied+1;
//					  N_Nonoccupied = Kmax-Noccupied;
//					  int hh = 0;
//					  int gg = 0;
//					  for(int k=0;k<Kmax;k++)
//					  {
//						  if(Clusters->NObsInClust.vec(k)>0)
//						  {
//							  Likelihood->computeLogDensityForLike_WithoutNA(ret.Pvec(hh),&ObsY, &Container[k], i);
//							  ret.Pvec(hh)[0] += log(Clusters->NObsInClust.vec(k));
//							  veck.Pvec(hh)[0] = k;
//							  hh++;
//						  }else{
//							  vecNonk.Pvec(gg)[0] = k;
//							  gg++;
//						  }            
//					  }
//					  k = vecNonk.vec(Class_Utils::sample_DiscreteVarEqualProb(N_Nonoccupied));
//
//					  Likelihood->computeLogDensityForLike_WithoutNA(ret.Pvec(hh),&ObsY, &Container[k], i);
//
//					  ret.Pvec(hh)[0] += log(DPpar->ParameterAcc)-log( 1.0*(Noccupied+1) );
//					  
//					  veck.Pvec(hh)[0] = k;
//					  
//					  Clusters->Zeta.Pvec(i)[0] = veck.vec(Class_Utils::sample_DiscreteVar(ret.P, ret.nElem));
//					  
//					  Clusters->NObsInClust.Pvec(Clusters->Zeta.vec(i))[0]++;
//					  
//					  if(Clusters->NObsInClust.Pvec(Clusters->Zeta.vec(i))[0]==1)
//					  {
//						  Noccupied++;
//					  }
//					  
//				  }
//			  }
//			      
//		  }
//		 //REprintf("END\n");
//	 }
//	
//	
	void samp_stMixtureDP_CheckLastElement_Metropolis(Class_Parameter *DPpar)
	{
		 samp_stMixtureDP_CheckLastElementNocheck_Metropolis(DPpar);
		 if(Clusters->nNonEmpty>=(Kmax))
		 {
			  //Rprintf("error: Kmax occupied regimes -  approximation is not valid\n");
		 }
		 Clusters->update_EmptyAndNonEmptyClusters();
	}
	void samp_stMixtureDP_CheckLastElementNocheck_Metropolis(Class_Parameter *DPpar)
	 {
		  //double u;
		 //REprintf("C1\n");
		 int Noccupied = Clusters->nNonEmpty; 
		 int N_Nonoccupied; 
		 
		 for(int i=0;i<nObs;i++)
		 {
			 //REprintf("C2\n");
			 Vector<double> ObsY(nVars,Y.Pmat(i,0));
			 
			 int vecNonk_P[Kmax];
			 Vector<int> vecNonk(Kmax,vecNonk_P);
			 
			 double MH = 0.0;
			 double ret;
			 int kacc  = Clusters->Zeta.vec(i);
			 int kprop;
			 
			 Clusters->NObsInClust.Pvec(kacc)[0]--;
			 if(Clusters->NObsInClust.vec(kacc)==0)
			 {
				 Noccupied--;
			 }
			 //REprintf("C3\n");
			 int AppS = 0;
			 if(Noccupied==Kmax)
			 {
				 AppS  = 1;
			 }else{
				 if(runif(0.0, 1.0*(nObs-1)+DPpar->ParameterAcc )<1.0*(nObs-1))
				 {
					 AppS  = 1;
				 }else{
					 AppS  = 0;
				 }
			 }
			 if(AppS==1)
			 {
				 //REprintf("C122\n");
				 int kpropapp = Class_Utils::sample_DiscreteVarEqualProb(nObs-1);
				 if(kpropapp<i)
				 {
					 kprop = Clusters->Zeta.vec(kpropapp);
				 }else{
					 kprop = Clusters->Zeta.vec(kpropapp+1);
				 }
			 }else{
				 //REprintf("C133\n");
				 N_Nonoccupied = Kmax-Noccupied;
				 int gg = 0;
				 for(int k=0;k<Kmax;k++)
				 {
					 if(Clusters->NObsInClust.vec(k)==0)
					 {
						 vecNonk.Pvec(gg)[0] = k;
						 gg++;
					 }
				 }
				 kprop = vecNonk.vec(Class_Utils::sample_DiscreteVarEqualProb(N_Nonoccupied));
				 //REprintf("%i %i\n",kprop,N_Nonoccupied );
				 #pragma omp critical (SampleFromPriorIW)
				 {
					 SampFromPrior(kprop);
				 }
			 }
			 //REprintf("C4\n");
			 Likelihood->computeLogDensityForLike_WithoutNA(&ret,&ObsY, &Container[kprop], i);
			 MH += ret;
			 Likelihood->computeLogDensityForLike_WithoutNA(&ret,&ObsY, &Container[kacc], i);
			 MH += -1.0*ret;
			 //REprintf("C5\n");
			 if(runif(0.0,1.0)<exp(MH))
			 {
				 Clusters->Zeta.Pvec(i)[0] = kprop;
			 }
			 //REprintf("C6\n");
			 Clusters->NObsInClust.Pvec(Clusters->Zeta.Pvec(i)[0])[0]++;
			 if(Clusters->NObsInClust.Pvec(Clusters->Zeta.Pvec(i)[0])[0]==1)
			 {
				 Noccupied++;
			 }
			 //REprintf("C7\n");
		 }		 
	 }
	
	
	void samp_stMixtureDP_CheckLastElement_Metropolis_Type2(Class_Parameter *DPpar)
	{
		 samp_stMixtureDP_CheckLastElementNocheck_Metropolis_Type2(DPpar);
		 if(Clusters->nNonEmpty>=(Kmax))
		 {
			  //Rprintf("error: Kmax occupied regimes -  approximation is not valid\n");
		 }
		 Clusters->update_EmptyAndNonEmptyClusters();
	}
	void samp_stMixtureDP_CheckLastElementNocheck_Metropolis_Type2(Class_Parameter *DPpar)
	 {
		  //double u;
		 //REprintf("C1_T2\n");
		 int Noccupied = Clusters->nNonEmpty; 
		 int N_Nonoccupied; 
		 
		 for(int i=0;i<nObs;i++)
		 {
			 //REprintf("C2 %i\n",i);
			 Vector<double> ObsY(nVars,Y.Pmat(i,0));
			 
			 int vecNonk_P[Kmax];
			 Vector<int> vecNonk(Kmax,vecNonk_P);
			 
			 double MH = 0.0;
			 double ret;
			 int kacc  = Clusters->Zeta.vec(i);
			 int kprop;
			 int AppS = 0;
			 Clusters->NObsInClust.Pvec(kacc)[0]--;
			 if(Clusters->NObsInClust.vec(kacc)==0)
			 {
				 //Singleton
				 MH = 0.0;
				 Noccupied--;
				 
				 //REprintf("C122\n");
				 int kpropapp = Class_Utils::sample_DiscreteVarEqualProb(nObs-1);
				 if(kpropapp<i)
				 {
					 kprop = Clusters->Zeta.vec(kpropapp);
				 }else{
					 kprop = Clusters->Zeta.vec(kpropapp+1);
				 }
				 
				 MH = log(1.0*(nObs-1))-log(DPpar->ParameterAcc);
				 
			 }else{
				 // no Singleton
				 MH = 0.0;
				 kprop = 0;
				 if(Noccupied!=Kmax)
				 {
					 AppS = 1;
					 N_Nonoccupied = Kmax-Noccupied;
					 int gg = 0;
					 for(int k=0;k<Kmax;k++)
					 {
						 if(Clusters->NObsInClust.vec(k)==0)
						 {
							 vecNonk.Pvec(gg)[0] = k;
							 gg++;
						 }
					 }
					 kprop = vecNonk.vec(Class_Utils::sample_DiscreteVarEqualProb(N_Nonoccupied));
					 //REprintf("%i %i\n",kprop,N_Nonoccupied );
					 #pragma omp critical (SampleFromPriorIW)
					 {
						 SampFromPrior(kprop);
					 }
					 MH = log(DPpar->ParameterAcc)-log(1.0*(nObs-1));
				 }
				 
			 }
			 if(AppS==0)
			 {
				 Likelihood->computeLogDensityForLike_WithoutNA(&ret,&ObsY, &Container[kprop], i);
				 MH += ret;
				 Likelihood->computeLogDensityForLike_WithoutNA(&ret,&ObsY, &Container[kacc], i);
				 MH += -1.0*ret;
				 //REprintf("C5\n");
				 if(runif(0.0,1.0)<exp(MH))
				 {
					 Clusters->Zeta.Pvec(i)[0] = kprop;
				 }
			 }else{
				 Clusters->Zeta.Pvec(i)[0] = kacc;
			 }

			 //REprintf("C6\n");
			 Clusters->NObsInClust.Pvec(Clusters->Zeta.Pvec(i)[0])[0]++;
			 if(Clusters->NObsInClust.Pvec(Clusters->Zeta.Pvec(i)[0])[0]==1)
			 {
				 Noccupied++;
			 }
			 
		 }	
		 
		 
		 //REprintf("C2_T2\n");
		 Clusters->update_EmptyAndNonEmptyClusters();
		 //REprintf("C3_T2\n");
		 for(int i=0;i<nObs;i++)
		 {
			 Vector<double> ObsY(nVars,Y.Pmat(i,0));
			 //double MH = 0.0;
			 int samp;
			 double ret;
			 int kacc  = Clusters->Zeta.vec(i);
			 
			 double Prob_P[Clusters->nNonEmpty];
			 Vector <double> Prob(Clusters->nNonEmpty,&Prob_P[0]);
			 
			 
			 if(Clusters->NObsInClust.Pvec(kacc)[0]>1)
			 {
				 Clusters->NObsInClust.Pvec(kacc)[0]--;
				 for(int k1=0;k1<Clusters->nNonEmpty;k1++)
				 {
					 int k = Clusters->NonEmptyC.vec(k1);
					 Likelihood->computeLogDensityForLike_WithoutNA(&ret,&ObsY, &Container[k], i);
					 Prob.Pvec(k1)[0] = log(1.0*Clusters->NObsInClust.vec(k))+ret;
				 }
				 samp = Class_Utils::sample_DiscreteVar(Prob.P, Clusters->nNonEmpty);
				 
				 Clusters->Zeta.Pvec(i)[0] = Clusters->NonEmptyC.vec(samp);
				 Clusters->NObsInClust.Pvec(Clusters->Zeta.Pvec(i)[0])[0]++;
			 }
		 }
		 //REprintf("C4_T2\n");
		 
	 }
	
 
	void samp_stMixtureDP_CheckLastElement_MergeSplit(Class_Parameter *DPpar)
	{
		samp_stMixtureDP_CheckLastElementNocheck_MergeSplit(DPpar);
		if(Clusters->nNonEmpty>=(Kmax))
		{
			 //Rprintf("error: Kmax occupied regimes -  approximation is not valid\n");
		}
		Clusters->update_EmptyAndNonEmptyClusters();
	}
	void samp_stMixtureDP_CheckLastElementNocheck_MergeSplit(Class_Parameter *DPpar)
	{
		//REprintf("M1\n");
		double LIKEmerge;
		double LIKEsplit;
		
		double Qmerge = 0.0;
		double Qsplit = 0.0;
		
		int doMerge;
		
		int nOccupied = Clusters->nNonEmpty;
		if(nOccupied==Kmax)
		{
			doMerge = 1;
			Qmerge = 0.0;
			Qsplit = -log(2.0);
		}else{
			if(nOccupied==1)
			{
				doMerge = 0;
				Qmerge = -log(2.0);
				Qsplit = 0.0;
				
			}else{
				if(runif(0.0,1.0)<0.5)
				{
					doMerge = 1;
				}else{
					doMerge = 0;
				}
				if((nOccupied==2)||(doMerge==1))
				{
					Qmerge = -log(2.0);
					Qsplit = 0.0;
				}
				if((nOccupied==(Kmax-1))||(doMerge==0))
				{
					Qmerge = 0.0;
					Qsplit = -log(2.0);
				}
			}
		}
		//REprintf("M2\n");
		if(doMerge==1)
		{
			//REprintf("M3\n");
			int ObsInk_P[nObs];
			Vector<int>ObsInk(1,&ObsInk_P[0]);
			ObsInk.nElem = 0;
			double appret;
			int k1app = Class_Utils::sample_DiscreteVarEqualProb(nOccupied);
			int k2app = Class_Utils::sample_DiscreteVarEqualProb(nOccupied-1);
			if(k2app>=k1app)
			{
				k2app++;
			}
			int k1 = Clusters->NonEmptyC.vec(k1app);
			int k2 = Clusters->NonEmptyC.vec(k2app);
			int k; 
			int n1 = Clusters->NObsInClust.vec(k1);
			int n2 = Clusters->NObsInClust.vec(k2);
			LIKEmerge = 0.0;
			//ComputeDensityPrior(k2,&LIKEsplit);
			LIKEsplit = 0.0;
			LIKEsplit += log(DPpar->ParameterAcc);
			
			//REprintf("M4\n");
			for(int i=0;i<nObs;i++)
			{
				Vector <double> ObsY(nVars,Y.Pmat(i,0));
				k = Clusters->Zeta.vec(i);
				if((k==k1)||(k==k2))
				{
					Likelihood->computeLogDensityForLike_WithoutNA(&appret,&ObsY, &Container[k], i);
					LIKEsplit+= appret;
					
					Likelihood->computeLogDensityForLike_WithoutNA(&appret,&ObsY, &Container[k1], i);
					LIKEmerge+= appret;
					
					ObsInk.nElem++;
					ObsInk.Pvec(ObsInk.nElem-1)[0] = i;
				}
			}
			LIKEsplit += lgammafn(1.0*n1)+ lgammafn(1.0*n2);
			LIKEmerge += lgammafn(1.0*(n1+n2));
			
			Qmerge += -log(1.0*nOccupied)-log(1.0*nOccupied-1.0);
			Qsplit += -log(1.0*nOccupied-1.0)-1.0*(n1+n2)*log(2.0);
			
			//ObsInk.Print("ObsInk");
			//REprintf("M4\n");
			
			if(runif(0.0,1.0)<exp(LIKEmerge+Qsplit-LIKEsplit-Qmerge))
			{
				// do merge
				for(int i=0;i<ObsInk.nElem;i++)
				{
					Clusters->Zeta.Pvec(ObsInk.vec(i))[0] = k1;
				}
			}
			
		}
		if(doMerge==0)
		{
			//REprintf("M5\n");
			// split
			double appret;
			int k1app = Class_Utils::sample_DiscreteVarEqualProb(nOccupied);
			int k1 = Clusters->NonEmptyC.vec(k1app);
			int k2 = Clusters->EmptyC.vec(0);
			int k; 
			int n = Clusters->NObsInClust.vec(k1);
			
			LIKEmerge = 0.0;
			
			#pragma omp critical (SampleFromPriorIW)
			{
				SampFromPrior(k2);
			}
			//ComputeDensityPrior(k2,&LIKEsplit);
			LIKEsplit = 0.0;
			LIKEsplit += log(DPpar->ParameterAcc);
			
			//int ObsInk1_P[nObs];
			//Vector<int>ObsInk1(0,&ObsInk1_P[0]);
			int ObsInk2_P[nObs];
			Vector<int>ObsInk2(1,&ObsInk2_P[0]);
			ObsInk2.nElem  = 0;
			//REprintf("M6\n");
			for(int i=0;i<nObs;i++)
			{
				Vector <double> ObsY(nVars,Y.Pmat(i,0));
				k = Clusters->Zeta.vec(i);
				if(k==k1)
				{
					if(runif(0.0,1.0)<0.5)
					{
						Likelihood->computeLogDensityForLike_WithoutNA(&appret,&ObsY, &Container[k1], i);
						LIKEsplit+= appret;
						//ObsInk1.nElem++;
						//ObsInk1.Pvec(ObsInk1.nElem-1)[0] = i;
					}else{
						Likelihood->computeLogDensityForLike_WithoutNA(&appret,&ObsY, &Container[k2], i);
						LIKEsplit+= appret;
						ObsInk2.nElem++;
						ObsInk2.Pvec(ObsInk2.nElem-1)[0] = i;
					}
					Likelihood->computeLogDensityForLike_WithoutNA(&appret,&ObsY, &Container[k1], i);
					LIKEmerge+= appret;
				}
				
			}
			LIKEsplit += lgammafn(1.0*ObsInk2.nElem)+ lgammafn(1.0*(n-ObsInk2.nElem));
			LIKEmerge += lgammafn(1.0*n);
			
			Qmerge += -log(1.0*nOccupied)+1.0-log(1.0*nOccupied);
			Qsplit += -log(1.0*nOccupied)-1.0*(n)*log(2.0);
			//REprintf("M7\n");
			if(runif(0.0,1.0)<exp(LIKEsplit+Qmerge-LIKEmerge-Qsplit))
			{
				// do split
				for(int i=0;i<ObsInk2.nElem;i++)
				{
					Clusters->Zeta.Pvec(ObsInk2.vec(i))[0] = k2;
				}
			}
			//REprintf("M8\n");
		}
		//REprintf("END\n");
	}
  
};
#pragma mark Mixture V2
class Class_Mixture_V2
{
private:
    
    
public:
    // STUFF
    int nObs;
    int nVars;
    int Kmax;
    
    int UserControlledMemory;
    
    // MEMBERS
    Matrix <double>         Y;
    //Matrix <double>         YProp;
    //Matrix <double>         YTransformed;
    ClusterIndex_V2            *Clusters;
    Poly_Density             *Likelihood;
    
    
    vector<Class_Parameter_PDMatrixUnivSamp >   *CovMat;
    vector<VectorParameters>                    *VectorParam;
    Matrix<double>                              *Covariates;
    
    vector <ParametersContainer>                Container;
    
    // CONSTRUCTORS
    Class_Mixture_V2(){};
    
    //DESTRUCTORS
    ~Class_Mixture_V2(){};
    
	
	/**  CAMPIONAMENTO DA PRIOR */
	void (Class_Mixture_V2::*SampFromPrior_P)(int k);
	void SampFromPrior_VOID(int k)
	{
		 error("SampFromPrior_P() not set");
	}
	void SampFromPrior(int k)
	{
		 return((this->*SampFromPrior_P)(k));
	}
	void set_SampFromPrior_MultiNormal_NIW()
	{
		 SampFromPrior_P = &::Class_Mixture_V2::sample_SampFromPrior_MultiNormal_NIW;
	}
	void sample_SampFromPrior_MultiNormal_NIW(int k)
	{
		 sample_FromPrior_MultiNormLike_Reg_NormalPrior(k);  
		 sample_FromPrior_MultiNormLikeReg_Sigma_InverseWishart(k);
	}
	
	/**  Densità prior */
	void (Class_Mixture_V2::*ComputeDensityPrior_P)(int k, double *ret);
	void ComputeDensityPrior_VOID(int k, double *ret)
	{
		 error("ComputeDensityPrior_P() not set");
	}
	void ComputeDensityPrior(int k, double *ret)
	{
		 return((this->*ComputeDensityPrior_P)(k,ret));
	}
	void set_ComputeDensityPrior_MultiNormal_NIW()
	{
		 ComputeDensityPrior_P = &::Class_Mixture_V2::sample_ComputeDensityPrior_MultiNormal_NIW;
	}
	void sample_ComputeDensityPrior_MultiNormal_NIW(int k, double *ret)
	{
		double retapp;
		Matrix <double> *Sigma = &Container[k].PDmat[0].SigmaAcc;
		Matrix <double> *SigmaInv = &Container[k].PDmat[0].SigmaAccInv;
		double logdet = Container[k].PDmat[0].logdetAcc;
		Matrix <double> *Psi = &CovMat[0][k].PriorParameter->PsiAcc[0];
		double nu = nVars-1+ CovMat[0][k].PriorParameter->nuAcc[0];
		
		Class_InverseWishart::compute_logdensity_noNorm( &retapp ,Sigma[0], SigmaInv[0], logdet, Psi[0],nu);
		ret[0] = retapp;
		
		
	}
	
	
	
	/**  Posteriori dei parametri */
    void (Class_Mixture_V2::*SampParGIBBS_P)();
    void SampParGIBBS_VOID()
    {
        error("SampParGIBBS_P() not set");
    }
    void (Class_Mixture_V2::*SampParMETROPOLIS_P)(vector< Poly_Adapt* > * Adapt);
    void SampParMETROPOLIS_VOID(vector< Poly_Adapt* > * Adapt)
    {
        error("SampParMETROPOLIS_P() not set");
    }
    
    void SampParGIBBS()
    {
        return((this->*SampParGIBBS_P)());
    }
    void SampParMETROPOLIS(vector< Poly_Adapt* > * Adapt)
    {
        return((this->*SampParMETROPOLIS_P)(Adapt));
    }
    
    void set_SampParGIBBS_MultiNormal()
    {
        SampParGIBBS_P = &::Class_Mixture_V2::sample_LikeParam_MultiNormLike_GIBBS;
    }
    void sample_LikeParam_MultiNormLike_GIBBS()
    {
        sample_LikeParam_MultiNormLike_Reg_NormalPrior();  
        sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart();
    }
	
	void set_SampParMETROPOLIS_PoissonReg()
	{
		 SampParMETROPOLIS_P = &::Class_Mixture_V2::sample_LikeParam_PoissonRegLike_METROPOLIS;
	}
	void sample_LikeParam_PoissonRegLike_METROPOLIS(vector< Poly_Adapt* > * Adapt)
	{
		 sample_LikeParam_REG_withLink_GeneralPrior(Adapt);
	}
	
	void set_SampParMETROPOLIS_InvariantWrappedPoissonReg()
	{
		 SampParMETROPOLIS_P = &::Class_Mixture_V2::sample_LikeParam_InvariantWrappedPoissonRegLike_METROPOLIS;
	}
	void sample_LikeParam_InvariantWrappedPoissonRegLike_METROPOLIS(vector< Poly_Adapt* > * Adapt)
	{
		 //REprintf("A");
		
		 sample_LikeParam_IWPREG_withLink_GeneralPrior(Adapt);
		 //REprintf("b");
		 sample_delta_InvariantWrapperPoisson();
		 
	}
	
	/**  Posteriori dei parametri per i soli occupati **/
	void (Class_Mixture_V2::*SampParGIBBS_OnlyOcc_P)();
	void SampParGIBBS_OnlyOcc_VOID()
	{
		 error("SampParGIBBS_OnlyOcc_P() not set");
	}
	void SampParGIBBS_OnlyOcc()
	{
		 return((this->*SampParGIBBS_OnlyOcc_P)());
	}
	void set_SampParGIBBS_MultiNormal_OnlyOcc()
	{
		 SampParGIBBS_OnlyOcc_P = &::Class_Mixture_V2::sample_LikeParam_MultiNormLike_GIBBS_OnlyOcc;
	}
	void sample_LikeParam_MultiNormLike_GIBBS_OnlyOcc()
	{
		 sample_LikeParam_MultiNormLike_Reg_NormalPrior_OnlyOcc();  
		 sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_OnlyOcc();
	}
	
	
//	
//	void SampParMETROPOLIS(vector< Poly_Adapt* > * Adapt)
//	{
//		 return((this->*SampParMETROPOLIS_P)(Adapt));
//	}
//	
//	void set_SampParGIBBS_MultiNormal()
//	{
//		 SampParGIBBS_P = &::Class_Mixture_V2::sample_LikeParam_MultiNormLike_GIBBS;
//	}
//	void sample_LikeParam_MultiNormLike_GIBBS()
//	{
//		 sample_LikeParam_MultiNormLike_Reg_NormalPrior();  
//		 sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart();
//	}
  
  
  /**  Posteriori dei parametri per i soli occupati - BIG VAR **/
  void set_SampParGIBBS_MultiNormal_BIGNVAR()
  {
      SampParGIBBS_P = &::Class_Mixture_V2::sample_LikeParam_MultiNormLike_GIBBS_BIGNVAR;
  }
  void sample_LikeParam_MultiNormLike_GIBBS_BIGNVAR()
  {
      sample_LikeParam_MultiNormLike_Reg_NormalPrior_BIGNVAR();
      sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_BIGNVAR();
    
    if(runif(0.0,1.0)<0.5)
    {
      if(runif(0.0,1.0)<0.5)
      {
        sample_LikeParam_MultiNormLike_Reg_NormalPrior_ONLYEMPTY_BIGNVAR();
      }else{
        sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_ONLYEMPTY_BIGNVAR();
      }
      
    }else{
      sample_LikeParam_MultiNormLike_Reg_NormalPrior_ONLYFIRSTEMPTY();
      sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_ONLYFIRSTEMPTY();
    }
      
      
  }
    
    
    /*   CODICI  */
    
    void sample_delta_InvariantWrapperPoisson()
    {
        double MH[Kmax];
        for(int k=0;k<Kmax;k++)
        {
            MH[k] = 0.0;
        }
 
        
        double parProp_P[Likelihood->nParameters*Kmax];
        double parAcc_P[Likelihood->nParameters*Kmax];
        vector<double*> parProp;
        vector<double*> parAcc;
        
        for(int k=0;k<Kmax;k++)
        {
            parProp.push_back(&parProp_P[k*Likelihood->nParameters]);
            parAcc.push_back(&parAcc_P[k*Likelihood->nParameters]);
        }
        
        double mucirc;
        double sigma2;
        double delta;
        double Npoints;
        double approx;
        int Npar = Likelihood->nParameters/Likelihood->dimObs;
        
        int jsamp = (int)floor(runif(0.0,1.0*Y.nCols));
        for(int k=0;k<Kmax;k++)
        {
            int gg;
            gg = 0;
            for(int j=0;j<Y.nCols;j++)
            {
                //link = hyper[i*nparUni+0];
                mucirc = Container[k].Params[0][0][j].ParameterAcc;
                sigma2 = Container[k].Params[1][0][j].ParameterAcc;
                delta = Container[k].Params[2][0][j].ParameterAcc;
                Npoints = Container[k].Params[3][0][j].ParameterAcc;
                approx = Container[k].Params[4][0][j].ParameterAcc;
                
                parProp[k][gg] = 0.0;
                parAcc[k][gg] = 0.0;
                gg++;
                
                parProp[k][gg] = mucirc;
                parAcc[k][gg]  = mucirc;
                gg++;
                
                parProp[k][gg] = sigma2;
                parAcc[k][gg]  = sigma2;
                gg++;
                
//                if(runif(0.0,1.0)>0.5)
//                {
//                    parProp[k][gg] = 1.0;
//                    parAcc[k][gg] = -1.0;
//
//                    MH[k] += log( (Container[k].Params[2][0][j].PriorParameter->HyperparametersAcc.vec(1)[0])/(1.0-Container[k].Params[2][0][j].PriorParameter->HyperparametersAcc.vec(1)[0]) );
//                }else{
//                    parProp[k][gg] = -1.0;
//                    parAcc[k][gg] = 1.0;
//
//                    MH[k] += log( (1.0-Container[k].Params[2][0][j].PriorParameter->HyperparametersAcc.vec(1)[0])/(Container[k].Params[2][0][j].PriorParameter->HyperparametersAcc.vec(1)[0]) );
//                }
//                gg++;
                
                if(j==jsamp)
                {
                    parProp[k][gg] = 1.0;
                    parAcc[k][gg] = -1.0;
                }else{
                    parProp[k][gg] = Container[k].Params[2][0][j].ParameterAcc;
                    parAcc[k][gg]  = Container[k].Params[2][0][j].ParameterAcc;
                }
                gg++;
                
                parProp[k][gg] = Npoints;
                parAcc[k][gg]  = Npoints;
                gg++;
                
                parProp[k][gg] = approx;
                parAcc[k][gg]  = approx;
                gg++;
                
            }
        }
        
        
        
        for(int i=0;i<nObs;i++)
        {
            //Vector<double> Omega(nVars,Y.Pmat(obs,0));
            
            int k       = Clusters->Zeta.vec(i);
            
            
            double XbetaAccNum_P[nVars];
            Vector<double>XbetaAccNum (nVars,XbetaAccNum_P);
          
            
            double XbetaAccFact_P[nVars];
            Vector<double>XbetaAccFact (nVars,XbetaAccFact_P);
            
            
            
            Class_InvariantWrappedPoissonReg::compute_XbetaFactNum(&XbetaAccFact, nVars,i, Covariates, &VectorParam[0][k].VectorAcc, Container[k].IndexFact);
            
            
            Class_InvariantWrappedPoissonReg::compute_XbetaFactNum(&XbetaAccNum, nVars,i, Covariates, &VectorParam[0][k].VectorAcc, Container[k].IndexNumb);
           
            
            for(int j=0;j<Y.nCols;j++)
            {
                parAcc[k][j*Npar] = Likelihood->linkFunction(XbetaAccNum.Pvec(j));
                parProp[k][j*Npar] = Likelihood->linkFunction(XbetaAccNum.Pvec(j));
                
                
                
                parAcc[k][j*Npar+1] = Class_Utils::ModOp(XbetaAccFact.vec(j),2*M_PI);
                parProp[k][j*Npar+1] =Class_Utils::ModOp(XbetaAccFact.vec(j),2*M_PI);
                
                
            }
            
            
            
            
            if(Container[0].NAposTOTlongRev[0][i].nElem==Y.nCols)
            {
                //REprintf("\n%i %i All\n",i,k);
                for(int j=0;j<Y.nCols;j++)
                {
                    MH[k] += Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parProp[k]);
                    MH[k] -= Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parAcc[k]);
                }
//                for(int j=0;j<Y.nCols;j++)
//                {
//                    double comp =Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parProp[k]);
//                    REprintf("l %f l2 %f s %f  d %f %f %f %f\n",parProp[k][j*6+0],parProp[k][j*6+1],parProp[k][j*6+2],parProp[k][j*6+3],parProp[k][j*6+4],parProp[k][j*6+5],comp);
//
//                    comp =Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parAcc[k]);
//                    REprintf("l %f l2 %f s2 %f  d %f %f %f %f\n",parAcc[k][j*6+0],parAcc[k][j*6+1],parAcc[k][j*6+2],parAcc[k][j*6+3],parAcc[k][j*6+4],parAcc[k][j*6+5],comp);
//                }
                
                
            }else{
                if(Container[0].NAposTOTlongRev[0][i].nElem!=0)
                {
                    int nvarA = Container[0].NAposTOTlongRev[0][i].nElem;
                    
                    for(int h=0;h<nvarA;h++)
                    {
                        int j = Container[0].NAposTOTlongRev[0][i].vec(h);
                        
                        MH[k] += Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parProp[k]);
                        MH[k] -= Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parAcc[k]);
                        
                    }
                    
                }
            }
            //REprintf("obs %i %f %f %f\n",i,MH[0],MH[1],MH[2]);
//            if(i==2)
//            {
//                error("63");
//            }
        }
        for(int k=0;k<Kmax;k++)
        {
            double alphaRatio = min(1.0,exp(MH[k]));
            //REprintf("MH %i %f\n",k,MH[k]);
            if(runif(0.0,1.0)<alphaRatio)
            {
                for(int j=0;j<Y.nCols;j++)
                {
                    Container[k].Params[2][0][j].ParameterAcc = parProp[k][j*6+3];
                    Container[k].Params[2][0][j].ParameterProp = parProp[k][j*6+3];
                }
            }else{
                for(int j=0;j<Y.nCols;j++)
                {
                    Container[k].Params[2][0][j].ParameterAcc = parAcc[k][j*6+3];
                    Container[k].Params[2][0][j].ParameterProp = parAcc[k][j*6+3];
                }
            }
            
            

        }
        //error("");
        
    }
    
//    void sample_LikeParam_REG_withLink_InvarianteWrappedPoisson_GeneralPrior(vector< Poly_Adapt* > * Adapt)
//    {
//        // multivariate obs are independent
//
//        int Npar = Likelihood->nParameters/Likelihood->dimObs;
//
//        double MH[Kmax];
//        for(int k=0;k<Kmax;k++)
//        {
//            MH[k] = 0.0;
//            Adapt[0][k]->Samp();
//
//            Container[k].VectorCont[0].update_VectorProp();
//
//            MH[k] = Adapt[0][k]->get_logDensityParameterWithLogJacobian_DiffPropAcc();
//
//
//        }
//        //        for(int k=0;k<Kmax;k++)
//        //        {
//        //            for(int j = 0; j<Covariates->nCols;j++)
//        //            {
//        //                REprintf("Param pre %f %f %f %f \n",Container[k].VectorCont[0].Parameters[0][j].ParameterAcc,Container[k].VectorCont[0].VectorAcc.vec(j),Container[k].VectorCont[0].Parameters[0][j].ParameterProp,Container[k].VectorCont[0].VectorProp.vec(j));
//        //            }
//        //        }
//
//        double parProp_P[Likelihood->nParameters*Kmax];
//        double parAcc_P[Likelihood->nParameters*Kmax];
//        vector<double*> parProp;
//        vector<double*> parAcc;
//        //REprintf("T1\n");
//        for(int k=0;k<Kmax;k++)
//        {
//            parProp.push_back(&parProp_P[k*Likelihood->nParameters]);
//            parAcc.push_back(&parAcc_P[k*Likelihood->nParameters]);
//        }
//
//        //REprintf("T11\n");
//
//
//        for(int k=0;k<Kmax;k++)
//        {
//            //REprintf("k=%i, %i",k,Likelihood->nParameters);
//            int gg;
//            gg = 0;
//            for(int j=0;j<Y.nCols;j++)
//            {
//                // REprintf("j=%i",j);
//                parProp[k][gg] = 0.0;
//                gg++;
//                for(int np=0;np<Npar-1;np++)
//                {
//                    //REprintf("np=%i",np);
//                    parProp[k][gg] = Container[k].Params[np][0][j].ParameterProp;
//                    gg++;
//                }
//            }
//            gg = 0;
//            for(int j=0;j<Y.nCols;j++)
//            {
//                parAcc[k][gg] = 0.0;
//                gg++;
//                for(int np=0;np<Npar-1;np++)
//                {
//                    parAcc[k][gg] = Container[k].Params[np][0][j].ParameterAcc;
//                    gg++;
//                }
//            }
//        }
//
//
//
//        for(int i=0;i<nObs;i++)
//        {
//            //REprintf("%i=i\n",i);
//            //Vector<double> Omega(nVars,Y.Pmat(obs,0));
//
//            int k       = Clusters->Zeta.vec(i);
//            double XbetaAcc_P[nVars];
//            Vector<double>XbetaAcc (nVars,XbetaAcc_P);
//            double XbetaProp_P[nVars];
//            Vector<double>XbetaProp (nVars,XbetaProp_P);
//
//            for(int h=0;h<nVars;h++)
//            {
//                XbetaAcc.Pvec(h)[0] = 0.0;
//                for(int j = 0; j<Covariates->nCols;j++)
//                {
//                    XbetaAcc.Pvec(h)[0] += Covariates[0].mat(nVars*i+h,j)*VectorParam[0][k].VectorAcc.vec(j);
//                }
//            }
//            for(int h=0;h<nVars;h++)
//            {
//                XbetaProp.Pvec(h)[0] = 0.0;
//                for(int j = 0; j<Covariates->nCols;j++)
//                {
//                    XbetaProp.Pvec(h)[0] += Covariates[0].mat(nVars*i+h,j)*VectorParam[0][k].VectorProp.vec(j);
//                }
//            }
//
//            for(int j=0;j<Y.nCols;j++)
//            {
//                // aggiungo il link
//                parAcc[k][j*Npar] = Likelihood->linkFunction(XbetaAcc.Pvec(j));
//                parProp[k][j*Npar] = Likelihood->linkFunction(XbetaProp.Pvec(j));
//
//                // cambio lambda
//
//                // calcolo xi accettato
//                double linkAcc      = parAcc[k][j*Npar+0];
//                double muAcc        = parAcc[k][j*Npar+1];
//                double sigma2Acc    = parAcc[k][j*Npar+2];
//                double deltaAcc     = parAcc[k][j*Npar+3];
//                double Napp         = parAcc[k][j*Npar+4];
//
//                double linkProp      = parProp[k][j*Npar+0];
//                double muProp        = parProp[k][j*Npar+1];
//                //double sigma2Prop    = parProp[k][j*Npar+2];
//                //double deltaProp     = parProp[k][j*Npar+3];
//
//                double lambdaAcc    = Class_InvariantWrappedPoissonReg::lambda_from_var(sigma2Acc, Napp);
//
//                double xiAcc = Class_InvariantWrappedPoissonReg::xi_from_mean(lambdaAcc, deltaAcc, muAcc,linkAcc, Napp);
//
//                double lambdaProp = Class_InvariantWrappedPoissonReg::lambda_from_xi(xiAcc, deltaAcc, muProp,linkProp, Napp);
//
//                parProp[k][j*Npar+2] = Class_InvariantWrappedPoissonReg::sigma2_from_lambda(lambdaProp, Napp);
//            }
//
//
//            if(Container[0].NAposTOTlongRev[0][i].nElem==Y.nCols)
//            {
//                for(int j=0;j<Y.nCols;j++)
//                {
//                    MH[k] += Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parProp[k]);
//                    MH[k] -= Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parAcc[k]);
//                }
//
//            }else{
//                if(Container[0].NAposTOTlongRev[0][i].nElem!=0)
//                {
//                    int nvarA = Container[0].NAposTOTlongRev[0][i].nElem;
//
//                    for(int h=0;h<nvarA;h++)
//                    {
//                        int j = Container[0].NAposTOTlongRev[0][i].vec(h);
//
//                        MH[k] += Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parProp[k]);
//                        MH[k] -= Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parAcc[k]);
//
//                    }
//
//                }
//            }
//        }
//
//        for(int k=0;k<Kmax;k++)
//        {
//            //REprintf("%i %f \n", k, MH[k]);
//            //REprintf("%i\n",k);
//            //Adapt[0][k]->PrintObject("Adapt pre\n");
//            double alphaRatio = min(1.0,exp(MH[k]));
//            //REprintf("Acc %f %f",alphaRatio,MH[k]);
//            if(runif(0.0,1.0)<alphaRatio)
//            {
//                Adapt[0][k]->UpdateIfAccepted();
//                Container[k].VectorCont[0].update_VectorAcc();
//            }
//            Adapt[0][k]->PostSamp(alphaRatio);
//
//            //Adapt[0][k]->PrintObject("Adapt post\n");
//
//        }
//        //error("");
//        //        for(int k=0;k<Kmax;k++)
//        //        {
//        //            for(int j = 0; j<Covariates->nCols;j++)
//        //            {
//        //                REprintf("Param %f %f %f %f \n",Container[k].VectorCont[0].Parameters[0][j].ParameterAcc,Container[k].VectorCont[0].VectorAcc.vec(j),Container[k].VectorCont[0].Parameters[0][j].ParameterProp,Container[k].VectorCont[0].VectorProp.vec(j));
//        //            }
//        //        }
//
//        //error("stop");
//
//    }
//
    void sample_LikeParam_REG_withLink_GeneralPrior(vector< Poly_Adapt* > * Adapt)
    {
        // multivariate obs are independent
        
        int Npar = Likelihood->nParameters/Likelihood->dimObs;
        
        double MH[Kmax];
        for(int k=0;k<Kmax;k++)
        {
            MH[k] = 0.0;
            Adapt[0][k]->Samp();
            
            Container[k].VectorCont[0].update_VectorProp();
            
            MH[k] = Adapt[0][k]->get_logDensityParameterWithLogJacobian_DiffPropAcc();
            
            
        }
        //        for(int k=0;k<Kmax;k++)
        //        {
        //            for(int j = 0; j<Covariates->nCols;j++)
        //            {
        //                REprintf("Param pre %f %f %f %f \n",Container[k].VectorCont[0].Parameters[0][j].ParameterAcc,Container[k].VectorCont[0].VectorAcc.vec(j),Container[k].VectorCont[0].Parameters[0][j].ParameterProp,Container[k].VectorCont[0].VectorProp.vec(j));
        //            }
        //        }
        
        double parProp_P[Likelihood->nParameters*Kmax];
        double parAcc_P[Likelihood->nParameters*Kmax];
        vector<double*> parProp;
        vector<double*> parAcc;
        //REprintf("T1\n");
        for(int k=0;k<Kmax;k++)
        {
            parProp.push_back(&parProp_P[k*Likelihood->nParameters]);
            parAcc.push_back(&parAcc_P[k*Likelihood->nParameters]);
        }
        
        //REprintf("T11\n");
        
        
        for(int k=0;k<Kmax;k++)
        {
            //REprintf("k=%i, %i",k,Likelihood->nParameters);
            int gg;
            gg = 0;
            for(int j=0;j<Y.nCols;j++)
            {
                // REprintf("j=%i",j);
                parProp[k][gg] = 0.0;
                gg++;
                for(int np=0;np<Npar-1;np++)
                {
                    //REprintf("np=%i",np);
                    parProp[k][gg] = Container[k].Params[np][0][j].ParameterProp;
                    gg++;
                }
            }
            gg = 0;
            for(int j=0;j<Y.nCols;j++)
            {
                parAcc[k][gg] = 0.0;
                gg++;
                for(int np=0;np<Npar-1;np++)
                {
                    parAcc[k][gg] = Container[k].Params[np][0][j].ParameterAcc;
                    gg++;
                }
            }
        }
        
        
        
        for(int i=0;i<nObs;i++)
        {
            //REprintf("%i=i\n",i);
            //Vector<double> Omega(nVars,Y.Pmat(obs,0));
            
            int k       = Clusters->Zeta.vec(i);
            double XbetaAcc_P[nVars];
            Vector<double>XbetaAcc (nVars,XbetaAcc_P);
            double XbetaProp_P[nVars];
            Vector<double>XbetaProp (nVars,XbetaProp_P);
            
            for(int h=0;h<nVars;h++)
            {
                XbetaAcc.Pvec(h)[0] = 0.0;
                for(int j = 0; j<Covariates->nCols;j++)
                {
                    XbetaAcc.Pvec(h)[0] += Covariates[0].mat(nVars*i+h,j)*VectorParam[0][k].VectorAcc.vec(j);
                }
            }
            for(int h=0;h<nVars;h++)
            {
                XbetaProp.Pvec(h)[0] = 0.0;
                for(int j = 0; j<Covariates->nCols;j++)
                {
                    XbetaProp.Pvec(h)[0] += Covariates[0].mat(nVars*i+h,j)*VectorParam[0][k].VectorProp.vec(j);
                }
            }
            for(int j=0;j<Y.nCols;j++)
            {
                parAcc[k][j*Npar] = Likelihood->linkFunction(XbetaAcc.Pvec(j));
                parProp[k][j*Npar] = Likelihood->linkFunction(XbetaProp.Pvec(j));
            }
            
            if(Container[0].NAposTOTlongRev[0][i].nElem==Y.nCols)
            {
                for(int j=0;j<Y.nCols;j++)
                {
                    MH[k] += Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parProp[k]);
                    MH[k] -= Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parAcc[k]);
                }
                
            }else{
                if(Container[0].NAposTOTlongRev[0][i].nElem!=0)
                {
                    int nvarA = Container[0].NAposTOTlongRev[0][i].nElem;
                    
                    for(int h=0;h<nvarA;h++)
                    {
                        int j = Container[0].NAposTOTlongRev[0][i].vec(h);
                        
                        MH[k] += Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parProp[k]);
                        MH[k] -= Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parAcc[k]);
                        
                    }
                    
                }
            }
        }
        
        for(int k=0;k<Kmax;k++)
        {
            //REprintf("%i %f \n", k, MH[k]);
            //REprintf("%i\n",k);
            //Adapt[0][k]->PrintObject("Adapt pre\n");
            double alphaRatio = min(1.0,exp(MH[k]));
            //REprintf("Acc %f %f",alphaRatio,MH[k]);
            if(runif(0.0,1.0)<alphaRatio)
            {
                Adapt[0][k]->UpdateIfAccepted();
                Container[k].VectorCont[0].update_VectorAcc();
            }
            Adapt[0][k]->PostSamp(alphaRatio);
            
            //Adapt[0][k]->PrintObject("Adapt post\n");
            
        }
        //error("");
        //        for(int k=0;k<Kmax;k++)
        //        {
        //            for(int j = 0; j<Covariates->nCols;j++)
        //            {
        //                REprintf("Param %f %f %f %f \n",Container[k].VectorCont[0].Parameters[0][j].ParameterAcc,Container[k].VectorCont[0].VectorAcc.vec(j),Container[k].VectorCont[0].Parameters[0][j].ParameterProp,Container[k].VectorCont[0].VectorProp.vec(j));
        //            }
        //        }
        
        //error("stop");
        
    }
    void sample_LikeParam_IWPREG_withLink_GeneralPrior(vector< Poly_Adapt* > * Adapt)
    {
        // multivariate obs are independent
        
        int Npar = Likelihood->nParameters/Likelihood->dimObs;
        
        double MH[Kmax];
        for(int k=0;k<Kmax;k++)
        {
            MH[k] = 0.0;
            Adapt[0][k]->Samp();
            
            Container[k].VectorCont[0].update_VectorProp();
            
            MH[k] = Adapt[0][k]->get_logDensityParameterWithLogJacobian_DiffPropAcc();
            
            
            
        }
        
//        for(int k=0;k<Kmax;k++)
//        {
//            for(int j = 0; j<Covariates->nCols;j++)
//            {
//                REprintf("Param pre %f %f %f %f \n",Container[k].VectorCont[0].Parameters[0][j].ParameterAcc,Container[k].VectorCont[0].VectorAcc.vec(j),Container[k].VectorCont[0].Parameters[0][j].ParameterProp,Container[k].VectorCont[0].VectorProp.vec(j));
//            }
//        }
        
        double parProp_P[Likelihood->nParameters*Kmax];
        double parAcc_P[Likelihood->nParameters*Kmax];
        vector<double*> parProp;
        vector<double*> parAcc;
        for(int k=0;k<Kmax;k++)
        {
            parProp.push_back(&parProp_P[k*Likelihood->nParameters]);
            parAcc.push_back(&parAcc_P[k*Likelihood->nParameters]);
        }
        
        //REprintf("T11\n");
        
       
        for(int k=0;k<Kmax;k++)
        {
            
            //REprintf("k=%i, %i",k,Likelihood->nParameters);
            int gg;
             gg = 0;
            for(int j=0;j<Y.nCols;j++)
            {
                //REprintf("j=%i",j);
                parProp[k][gg] = 0.0;
                gg++;
                for(int np=0;np<Npar-1;np++)
                {
                    //REprintf("np=%i",np);
                    parProp[k][gg] = Container[k].Params[np][0][j].ParameterProp;
                    gg++;
                }
            }
            gg = 0;
            for(int j=0;j<Y.nCols;j++)
            {
                //REprintf("j=%i",j);
                parAcc[k][gg] = 0.0;
                gg++;
                for(int np=0;np<Npar-1;np++)
                {
                    parAcc[k][gg] = Container[k].Params[np][0][j].ParameterAcc;
                    gg++;
                }
            }
            
        }
        
//         REprintf("Jac %f %f %f \n Par\n",MH[0],MH[1],MH[2]);
//        // Primo Gruppo, per tutte le variabili
//        int k = 1;
//        REprintf("betaAcc=c(); sigma2Acc = c(); deltaAcc=c()\n");
//        for(int jvar=0;jvar<3;jvar++)
//        {
//            REprintf("betaAcc[%i]=%f; sigma2Acc[%i]=%f; deltaAcc[%i]=%f \n", jvar+1,VectorParam[0][k].VectorAcc.vec(jvar),jvar+1,parAcc[k][jvar*6+2],jvar+1,parAcc[k][jvar*6+3] );
//            REprintf("betaProp[%i]=%f; sigma2Prop[%i]=%f; deltaProp[%i]=%f \n", jvar+1,VectorParam[0][k].VectorProp.vec(jvar),jvar+1,parProp[k][jvar*6+2],jvar+1,parProp[k][jvar*6+3] );
//
//
//            //REprintf("ASAS\n");
//        }
//         REprintf("Jac %f %f %f \n",MH[0],MH[1],MH[2]);
//
        
        for(int i=0;i<nObs;i++)
        {
            //REprintf("%i=i\n",i);
            //Vector<double> Omega(nVars,Y.Pmat(obs,0));
            
            int k       = Clusters->Zeta.vec(i);
            
            
            
            double XbetaAccNum_P[nVars];
            Vector<double>XbetaAccNum (nVars,XbetaAccNum_P);
            double XbetaPropNum_P[nVars];
            Vector<double>XbetaPropNum (nVars,XbetaPropNum_P);
            
            double XbetaAccFact_P[nVars];
            Vector<double>XbetaAccFact (nVars,XbetaAccFact_P);
            double XbetaPropFact_P[nVars];
            Vector<double>XbetaPropFact (nVars,XbetaPropFact_P);
            
            //REprintf("M1\n");
            Class_InvariantWrappedPoissonReg::compute_XbetaFactNum(&XbetaAccFact, nVars,i, Covariates, &VectorParam[0][k].VectorAcc, Container[k].IndexFact);
            Class_InvariantWrappedPoissonReg::compute_XbetaFactNum(&XbetaPropFact, nVars,i, Covariates, &VectorParam[0][k].VectorProp, Container[k].IndexFact);
            //REprintf("M2\n");
            Class_InvariantWrappedPoissonReg::compute_XbetaFactNum(&XbetaAccNum, nVars,i, Covariates, &VectorParam[0][k].VectorAcc, Container[k].IndexNumb);
            Class_InvariantWrappedPoissonReg::compute_XbetaFactNum(&XbetaPropNum, nVars,i, Covariates, &VectorParam[0][k].VectorProp, Container[k].IndexNumb);
            
         
            
            for(int j=0;j<Y.nCols;j++)
            {
                parAcc[k][j*Npar] = Likelihood->linkFunction(XbetaAccNum.Pvec(j));
                parProp[k][j*Npar] = Likelihood->linkFunction(XbetaPropNum.Pvec(j));
                
                parAcc[k][j*Npar+1] =  Class_Utils::ModOp(XbetaAccFact.vec(j),2*M_PI)  ;
                parProp[k][j*Npar+1] = Class_Utils::ModOp(XbetaPropFact.vec(j),2*M_PI);
            }
            
            if(Container[0].NAposTOTlongRev[0][i].nElem==Y.nCols)
            {
                for(int j=0;j<Y.nCols;j++)
                {
                    //REprintf("ASD %i\n",j);
                    MH[k] += Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parProp[k]);
                    MH[k] -= Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parAcc[k]);
                    
//                    REprintf("ParAcc %f %f %f \n",XbetaAccNum.vec(j), Likelihood->linkFunction(XbetaAccNum.Pvec(j)),Container[k].Cov[0].mat(i*3+0,0));
//                    REprintf("ParProp %f %f %f \n",XbetaPropNum.vec(j), Likelihood->linkFunction(XbetaPropNum.Pvec(j)),Container[k].Cov[0].mat(i*3+0,0));
//                    for(int hhh=0;hhh<6;hhh++)
//                    {
//                        REprintf("%f %f  \n",parAcc[k][hhh], parProp[k][hhh]);
//                    }
//                    REprintf("\n");
                }
                
            }else{
                if(Container[0].NAposTOTlongRev[0][i].nElem!=0)
                {
                    int nvarA = Container[0].NAposTOTlongRev[0][i].nElem;
                    
                    for(int h=0;h<nvarA;h++)
                    {
                        int j = Container[0].NAposTOTlongRev[0][i].vec(h);
                        
                        MH[k] += Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parProp[k]);
                        MH[k] -= Likelihood->compute_LogDensityUni(j,Y.Pmat(i,0),parAcc[k]);
                        
                    }
                    
                }
            }
//            REprintf("\n\nMH i=%i %f %f %f \n",i,MH[0],MH[1],MH[2]);
//            REprintf("LikeProp k=%i %f %f %f  \n",k,Likelihood->compute_LogDensityUni(0,Y.Pmat(i,0),parProp[k]),Likelihood->compute_LogDensityUni(1,Y.Pmat(i,0),parProp[k]),Likelihood->compute_LogDensityUni(2,Y.Pmat(i,0),parProp[k]));
//
//            REprintf("LikeAcc k=%i %f  %f %f \n \n",k,Likelihood->compute_LogDensityUni(0,Y.Pmat(i,0),parAcc[k]),Likelihood->compute_LogDensityUni(1,Y.Pmat(i,0),parAcc[k]),
//                     Likelihood->compute_LogDensityUni(2,Y.Pmat(i,0),parAcc[k]));
//            if(i==1)
//            {
//                error("");
//            }
        }
        //error("");
        for(int k=0;k<Kmax;k++)
        {
            //REprintf("%i %f \n", k, MH[k]);
            //REprintf("%i\n",k);
            //Adapt[0][k]->PrintObject("Adapt pre\n");
            double alphaRatio = min(1.0,exp(MH[k]));
            //REprintf("Acc %f %f",alphaRatio,MH[k]);
            if(runif(0.0,1.0)<alphaRatio)
            {
                Adapt[0][k]->UpdateIfAccepted();
                Container[k].VectorCont[0].update_VectorAcc();
            }
            Adapt[0][k]->PostSamp(alphaRatio);
            
            //Adapt[0][k]->PrintObject("Adapt post\n");
            
        }
        //error("");
//        for(int k=0;k<Kmax;k++)
//        {
//            for(int j = 0; j<Covariates->nCols;j++)
//            {
//                REprintf("Param %f %f %f %f \n",Container[k].VectorCont[0].Parameters[0][j].ParameterAcc,Container[k].VectorCont[0].VectorAcc.vec(j),Container[k].VectorCont[0].Parameters[0][j].ParameterProp,Container[k].VectorCont[0].VectorProp.vec(j));
//            }
//        }
        
        //error("stop");
        
    }
    
    void create_fullObject( Matrix<double>* y, ClusterIndex_V2* clust, Poly_Density *like, int usr )
    {
        UserControlledMemory    = usr;
        
        Kmax     = clust->Kmax;
        Y           = Matrix<double>(y->nRows,y->nCols, y->P);
        nObs        = Y.nRows;
        nVars       = Y.nCols;
        
        Likelihood  = like;
        Clusters    = clust;
        
        for(int k=0;k<Kmax;k++)
        {
            Container.push_back(ParametersContainer());
        }
        
		  SampParGIBBS_OnlyOcc_P = &::Class_Mixture_V2::SampParGIBBS_OnlyOcc_VOID;
        SampParGIBBS_P = &::Class_Mixture_V2::SampParGIBBS_VOID;
        SampParMETROPOLIS_P = &::Class_Mixture_V2::SampParMETROPOLIS_VOID;
		  SampFromPrior_P = &::Class_Mixture_V2::SampFromPrior_VOID;
		  ComputeDensityPrior_P = &::Class_Mixture_V2::ComputeDensityPrior_VOID;
    }
    void add_Varmat_for_MultiNormal( vector<Class_Parameter_PDMatrixUnivSamp >   *covmat)
    {
        CovMat  = covmat;
        
        for(int k=0;k<Kmax;k++)
        {
            Container[k].PDmat  = &covmat[0][k];
        }
        
    }
    
    void add_RegCoefVarmat(vector<VectorParameters> *regCoef, vector<Class_Parameter_PDMatrixUnivSamp >   *covmat, Matrix<double> *Covar)
    {
        VectorParam = regCoef;
        CovMat  = covmat;
        Covariates = Covar;
        
        for(int k=0;k<Kmax;k++)
        {
            Container[k].VectorCont = &regCoef[0][k];
            Container[k].PDmat  = &covmat[0][k];
            Container[k].Cov    = &Covar[0];
        }
        
    }
    void add_RegCoef(vector<VectorParameters> *regCoef, Matrix<double> *Covar)
    {
        VectorParam = regCoef;
        Covariates = Covar;
        
        for(int k=0;k<Kmax;k++)
        {
            Container[k].VectorCont = &regCoef[0][k];
            Container[k].Cov    = &Covar[0];
        }
        
    }
    
    void add_IndexFactNum(Vector<int>*FactIndex, Vector<int>*NumbIndex)
    {

        for(int k=0;k<Kmax;k++)
        {
            Container[k].IndexFact = FactIndex;
            Container[k].IndexNumb = NumbIndex;
        }
        
    }
    void add_Parameter(vector<vector<Class_Parameter> > *Par)
    {
        for(int k=0;k<Kmax;k++)
        {
            Container[k].Params.push_back(&Par[0][k]);
        }
    }
    void add_MissinObject(vector<Vector <int> > *NAposTOT_a, vector<Vector <int> > *NAposTOTlongRev_a,Vector<int> *IndexNA_a )
    {
        for(int k=0;k<Kmax;k++)
        {
            Container[k].NAposTOT          = NAposTOT_a;
            Container[k].NAposTOTlongRev   = NAposTOTlongRev_a;
            Container[k].IndexNA           = IndexNA_a;
        }
    }

    
    void add_RegVarmat_for_MultiNormal_Type_Clima(vector<VectorParameters> *regCoef, vector<Class_Parameter_PDMatrixUnivSamp >   *covmat, Matrix<double> *Covar, Vector <int> *TypeLike)
    {
        VectorParam = regCoef;
        CovMat  = covmat;
        Covariates = Covar;
        
        for(int k=0;k<Kmax;k++)
        {
            Container[k].VectorCont = &regCoef[0][k];
            Container[k].PDmat  = &covmat[0][k];
            Container[k].Cov    = &Covar[0];
            Container[k].TypeLike    = &TypeLike[0];
        }
        
    }
    void add_RegVarmat_for_MultiNormal_Type_ClimaSeason(vector<VectorParameters> *regCoef, vector<Class_Parameter_PDMatrixUnivSamp >   *covmat, Matrix<double> *Covar, Vector <int> *TypeLike,vector<Class_Gaussian_Multivariate> *GP)
    {
        VectorParam = regCoef;
        CovMat  = covmat;
        Covariates = Covar;
        
        for(int k=0;k<Kmax;k++)
        {
            Container[k].VectorCont = &regCoef[0][k];
            Container[k].PDmat  = &covmat[0][k];
            Container[k].Cov    = &Covar[0];
            Container[k].TypeLike    = &TypeLike[0];
            //Container[k].GPVec    = &GP[0];
            for(int j=0;j<GP->size(); j++)
            {
                Container[k].GPVec.push_back(&GP[0][j].Omega);
            }
        }
        
        
        
    }
    
    void sampleNA()
    {
        #pragma omp parallel for default(none) 
        for(int  j=0;j<Container[0].IndexNA->nElem;j++)
        {
            int obs     = Container[0].IndexNA->vec(j);
            int k       = Clusters->Zeta.vec(obs);
            
            double omega_P[nVars];
            Vector <double> omega(nVars,omega_P);
            omega.P = Y.Pmat(obs,0);
            //REprintf("%i %i %i \n", j,obs,k);
            Likelihood->sample_SubsetOrAll(&Container[0].NAposTOT[0][j],obs, Container[k], &omega);
        }
    }
    
    
    
    void sampleNA_uni( vector< Vector<int> > *VectorNA)
    {
        int obs;
        for(int i=0;i<nVars;i++)
        {
            //Rprintf("i= %i",i);
            for(int  j=0;j<VectorNA[0][i].nElem;j++)
            {
                obs     = VectorNA[0][i].vec(j);
                int k       = Clusters->Zeta.vec(obs);
                
                double omega_P[nVars];
                Vector <double> omega(nVars,omega_P);
                omega.P = Y.Pmat(obs,0);
                
                Likelihood->sample_uni(i, obs, Container[k], &omega);
            }
        }
    }
    void sampleNA_multi(Vector<int>  *VectorNA)
    {
        for(int  j=0;j<VectorNA[0].nElem;j++)
        {
            int obs     = VectorNA[0].vec(j);
            int k       = Clusters->Zeta.vec(obs);
            
            double omega_P[nVars];
            Vector <double> omega(nVars,omega_P);
            omega.P = Y.Pmat(obs,0);
            
            Likelihood->sample_Multi(obs,Container[k], &omega);
        }
    }
    
    
    void sampleNA_MultiNormLikeRegUni( vector< Vector<int> > *VectorNA)
    {
        //error("Da Testare");
        int obs;
        for(int i=0;i<nVars;i++)
        {
            //Rprintf("i= %i",i);
            for(int  j=0;j<VectorNA[0][i].nElem;j++)
            {
                //Rprintf("j= %i\n",j);
                obs     = VectorNA[0][i].vec(j);
                //Rprintf("VectorNA[0][i].vec(j)= %i\n",VectorNA[0][i].vec(j));
                sampleNA_MultiNormLikeRegUni( obs, i);
            }
        }
    }
    void sampleNA_MultiNormLikeRegUni( int obs, int nvar)
    {
        
        // da testare
        double omega_P[nVars];
        Vector <double> omega(nVars,omega_P);
        
        double muA;
        double varA;
        
        muA     = 0.0;
        varA    = 0.0;
        
        //int obs;
        int k;
        int i;
        int j;
        int h;
        i = nvar;
        
        //obs     = VectorNA[0][i].vec(j);
        k       = Clusters->Zeta.vec(obs);
        double Xbeta_P[nVars];
        Vector<double>Xbeta (nVars,Xbeta_P);
        
        for(h=0;h<nVars;h++)
        {
            Xbeta.Pvec(h)[0] = 0.0;
            for(j = 0; j<Covariates->nCols;j++)
            {
                Xbeta.Pvec(h)[0] += Covariates[0].mat(nVars*obs+h,j)*VectorParam[0][k].VectorAcc.vec(j);
            }
        }
        
        omega.P = Y.Pmat(obs,0);
        Class_MultivariateNormal::external_computeConditioanlMeanAndVariance_uni(i,  &muA,  &varA, &CovMat[0][k].SigmaAccInv, &Xbeta, &omega);
        
        Y.Pmat(obs,i)[0] = rnorm(muA, pow(varA,0.5));
    }
    
    void sampleNA_MultiNormLikeRegAll( Vector<int>  *VectorNA)
    {
        //error("Da Testare");
        
        for(int  j=0;j<VectorNA[0].nElem;j++)
        {
            int obs     = VectorNA[0].vec(j);
            sampleNA_MultiNormLikeRegAll( obs);
        }
    }
    void sampleNA_MultiNormLikeRegAll( int obs)
    {
        // DA FARE UN CHECK -  non so se funziona
        
        //        double muA;
        //        double varA;
        //
        //        muA     = 0.0;
        //        varA    = 0.0;
        
        //int obs;
        int k;
        //int i;
        int j;
        int h;
        
        
        
        Vector<double> Omega(nVars,Y.Pmat(obs,0));
        
        k       = Clusters->Zeta.vec(obs);
        double Xbeta_P[nVars];
        Vector<double>Xbeta (nVars,Xbeta_P);
        
        for(h=0;h<nVars;h++)
        {
            Xbeta.Pvec(h)[0] = 0.0;
            for(j = 0; j<Covariates->nCols;j++)
            {
                Xbeta.Pvec(h)[0] += Covariates[0].mat(nVars*obs+h,j)*VectorParam[0][k].VectorAcc.vec(j);
            }
        }
        Class_MultivariateNormal::external_SampleMultivariate(&Omega, &Xbeta, &CovMat[0][k].SigmaCholAcc);
        
        
        
    }
    
    
    

	void sample_FromPrior_MultiNormLike_Reg_NormalPrior(int k)
	{
		int dimCov = Covariates->nCols;
		for(int j=0;j<dimCov;j++)
		{
			VectorParam[0][k].VectorAcc.Pvec(j)[0] = rnorm(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(0)[0],pow(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(1)[0],0.5));
		}
		VectorParam[0][k].update_ParameterAcc();
		 
	}
	
	void sample_LikeParam_MultiNormLike_Reg_NormalPrior_OnlyOcc()
	{
		 
		 sample_LikeParam_MultiNormLike_Reg_NormalPrior_OnlyOcc(&Y);
		 
	}
	
	void sample_LikeParam_MultiNormLike_Reg_NormalPrior_OnlyOcc(Matrix <double> * Data)
	{
		
		//string NAMEdir = "/Users/gianlucamastrantonio/Dropbox (Politecnico di Torino Staff)/lavori/ode/TESTOUT/";
//		string NAMEdir = "/work/gmastrantonio/ODE/lancio/";
//
//		#ifdef _OPENMP
//		string appNamedir = (NAMEdir+to_string(omp_get_thread_num())+"Media.txt");
//		#else
//		string appNamedir = (NAMEdir+to_string(0)+".txt");
//		#endif
//		FILE * (file);
//		time_t my_time = time(NULL);
//		
		
	 
		 int k,i,j;
		 
		 const double SumPar = 1.0;
		 int dimCov = Covariates->nCols;
		 
		double CovApp_P[nVars*dimCov];
		 Matrix <double> CovApp(nVars,dimCov,Covariates[0].Pmat(0,0));
		//double YApp_P[nVars];
		 Vector <double> YApp(nVars,Data[0].Pmat(0,0));
		 
		 
		 double MeanPar_P[dimCov*Kmax];
		 double CovPar_P[dimCov*dimCov*Kmax];
		 vector <Vector<double> > MeanPar;
		 vector <Matrix<double> > CovPar;
		 
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time)); 
//		fprintf(file, "A1\n \n");
//		fclose (file);
		 //Rprintf("A1_1 %i %i  %i %i %i\n",Kmax, nObs, Covariates->nRows,dimCov, Clusters->nNonEmpty );
		 for(k=0;k< Kmax;k++)
		 {
			  MeanPar.push_back(Vector<double>(dimCov,&MeanPar_P[k*dimCov]));
			  CovPar.push_back(Matrix<double>(dimCov,dimCov,&CovPar_P[k*dimCov*dimCov]));
		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		 fprintf(file, "A2\n \n");
//		fclose (file);
		 for(i=0;i< Clusters->nNonEmpty;i++)
		 {
			  //REprintf("dj=%i k=%i \n",i,Clusters->NonEmptyC.vec(i));
			  k = Clusters->NonEmptyC.vec(i);
			  //Rprintf("A1_3\n");
			  MeanPar[k].Init(0.0);
			  CovPar[k].Init(0.0);
			  
		 }
		 
		 //Rprintf("A5\n");
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		fprintf(file, "A3\n \n");
//		fclose (file);
		 for(j=0;j< Clusters->nNonEmpty;j++)
		 {
			  //REprintf("j=%i k=%i \n",j,Clusters->NonEmptyC.vec(j));
			  k = Clusters->NonEmptyC.vec(j);
			  // prior hyperparameters
			  for(i=0;i<dimCov;i++)
			  {
					//REprintf("%i %f %f\n",i,VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0],VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]);
					
					CovPar[k].Pmat(i,i)[0]   = 1.0/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
					MeanPar[k].Pvec(i)[0]  = VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
			  }
			  
		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		 fprintf(file, "A4 \n");
//		fclose (file);
		 //Rprintf("A6\n");
		//REprintf("A6e\n");
		 for(i=0;i<nObs;i++)
		 {
			 //REprintf("i=%i",i);
			  k           = Clusters->Zeta.vec(i);
			 //REprintf("AA %i mmm\n",k);
			  CovApp.P = Covariates[0].Pmat(i*nVars,0);
			  YApp.P = Data[0].Pmat(i,0);
			  // molto poco performante
	  Class_MultivariateNormal::external_ParametersForFullConditioanlBeta_WithoutMolt(&CovApp,  &CovMat[0][k].SigmaAccInv, &YApp, &CovPar[k], &MeanPar[k], &SumPar);
			  
			  
		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		fprintf(file, "A5 \n");
//		fclose (file);
		 for(i=0;i< Clusters->nNonEmpty;i++)
		 {
			  k = Clusters->NonEmptyC.vec(i);
			  //CovPar[k].Print("Cov2");
			  //MeanPar[k].Print("Mean2");
			  //Rprintf("%i %i\n",Clusters->nNonEmpty,Clusters->NonEmptyC.vec(i));
			  Class_MultivariateNormal::external_finalizedRegFullConditional(&CovPar[k],&MeanPar[k], 1);
			  
			  Class_MultivariateNormal::external_SampleMultivariate(&VectorParam[0][k].VectorAcc, &MeanPar[k], &CovPar[k]);
			  VectorParam[0][k].update_ParameterAcc();
		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		fprintf(file, "A6 \n");
//		fclose (file);
//		 for(i=0;i< Clusters->nEmpty;i++)
//		 {
//			  //Rprintf("A10 %i\n",i);
//			  k = Clusters->EmptyC.vec(i);
//			  //Rprintf("%i ",k );
//			  for(j=0;j<dimCov;j++)
//			  {
//					VectorParam[0][k].VectorAcc.Pvec(j)[0] = rnorm(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(0)[0],pow(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(1)[0],0.5));
//			  }
//			  
//			  VectorParam[0][k].update_ParameterAcc();
//		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		fprintf(file, "Fine \n");
//		fclose (file);
		 
	}
	
	
    void sample_LikeParam_MultiNormLike_Reg_NormalPrior()
    {
        
        sample_LikeParam_MultiNormLike_Reg_NormalPrior(&Y);
        
    }
  void sample_LikeParam_MultiNormLike_Reg_NormalPrior_BIGNVAR()
  { 
    sample_LikeParam_MultiNormLike_Reg_NormalPrior_ONLYNONEMPTY(&Y);   //CHECHHERE
  } 
    
//	 void sample_LikeParam_MultiNormLike_Reg_NormalPrior(Matrix <double> * Data)
//	 {
//
//	  
//		  int k,i,j;
//		  
//		  const double SumPar = 1.0;
//		  int dimCov = Covariates->nCols;
//		  
//		 double CovApp_P[nVars*dimCov];
//		  Matrix <double> CovApp(nVars,dimCov,Covariates[0].Pmat(0,0));
//		 //double YApp_P[nVars];
//		  Vector <double> YApp(nVars,Data[0].Pmat(0,0));
//		  
//		  
//		  double MeanPar_P[dimCov*Kmax];
//		  double CovPar_P[dimCov*dimCov*Kmax];
//		  vector <Vector<double> > MeanPar;
//		  vector <Matrix<double> > CovPar;
//		  
//		 
//		  for(k=0;k< Kmax;k++)
//		  {
//				MeanPar.push_back(Vector<double>(dimCov,&MeanPar_P[k*dimCov]));
//				CovPar.push_back(Matrix<double>(dimCov,dimCov,&CovPar_P[k*dimCov*dimCov]));
//		  }
//		 
//		  for(i=0;i< Clusters->nNonEmpty;i++)
//		  {
//				//REprintf("dj=%i k=%i \n",i,Clusters->NonEmptyC.vec(i));
//				k = Clusters->NonEmptyC.vec(i);
//				//Rprintf("A1_3\n");
//				MeanPar[k].Init(0.0);
//				CovPar[k].Init(0.0);
//				
//		  }
//		  
//		  //Rprintf("A5\n");
//		 
//		  for(j=0;j< Clusters->nNonEmpty;j++)
//		  {
//				//REprintf("j=%i k=%i \n",j,Clusters->NonEmptyC.vec(j));
//				k = Clusters->NonEmptyC.vec(j);
//				// prior hyperparameters
//				for(i=0;i<dimCov;i++)
//				{
//					 //REprintf("%i %f %f\n",i,VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0],VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]);
//					 
//					 CovPar[k].Pmat(i,i)[0]   = 1.0/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
//					 MeanPar[k].Pvec(i)[0]  = VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
//				}
//				
//		  }
//		 
//		  //Rprintf("A6\n");
//		 //REprintf("A6e\n");
//		  for(i=0;i<nObs;i++)
//		  {
//			  //REprintf("i=%i",i);
//				k           = Clusters->Zeta.vec(i);
//			  //REprintf("AA %i mmm\n",k);
//				CovApp.P = Covariates[0].Pmat(i*nVars,0);
//				YApp.P = Data[0].Pmat(i,0);
//				// molto poco performante
//		Class_MultivariateNormal::external_ParametersForFullConditioanlBeta_WithoutMolt(&CovApp,  &CovMat[0][k].SigmaAccInv, &YApp, &CovPar[k], &MeanPar[k], &SumPar);
//				
//				
//		  }
//		 
//		  for(i=0;i< Clusters->nNonEmpty;i++)
//		  {
//				k = Clusters->NonEmptyC.vec(i);
//				//CovPar[k].Print("Cov2");
//				//MeanPar[k].Print("Mean2");
//				//Rprintf("%i %i\n",Clusters->nNonEmpty,Clusters->NonEmptyC.vec(i));
//				Class_MultivariateNormal::external_finalizedRegFullConditional(&CovPar[k],&MeanPar[k], 1);
//				
//				Class_MultivariateNormal::external_SampleMultivariate(&VectorParam[0][k].VectorAcc, &MeanPar[k], &CovPar[k]);
//				VectorParam[0][k].update_ParameterAcc();
//		  }
//		 
//		  for(i=0;i< Clusters->nEmpty;i++)
//		  {
//				//Rprintf("A10 %i\n",i);
//				k = Clusters->EmptyC.vec(i);
//				//Rprintf("%i ",k );
//				for(j=0;j<dimCov;j++)
//				{
//					 VectorParam[0][k].VectorAcc.Pvec(j)[0] = rnorm(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(0)[0],pow(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(1)[0],0.5));
//				}
//				
//				VectorParam[0][k].update_ParameterAcc();
//		  }
//		 
//		  
//	 }
	
	
	void sample_LikeParam_MultiNormLike_Reg_NormalPrior(Matrix <double> * Data)
	{
		
		//string NAMEdir = "/Users/gianlucamastrantonio/Dropbox (Politecnico di Torino Staff)/lavori/ode/TESTOUT/";
//		string NAMEdir = "/work/gmastrantonio/ODE/lancio/";
//
//		#ifdef _OPENMP
//		string appNamedir = (NAMEdir+to_string(omp_get_thread_num())+"Media.txt");
//		#else
//		string appNamedir = (NAMEdir+to_string(0)+".txt");
//		#endif
//		FILE * (file);
//		time_t my_time = time(NULL);
//		
		
	 
		 int k,i,j;
		 
		 const double SumPar = 1.0;
		 int dimCov = Covariates->nCols;
		 
		double CovApp_P[nVars*dimCov];
		 Matrix <double> CovApp(nVars,dimCov,Covariates[0].Pmat(0,0));
		//double YApp_P[nVars];
		 Vector <double> YApp(nVars,Data[0].Pmat(0,0));
		 
		 
		 double MeanPar_P[dimCov*Kmax];
		 double CovPar_P[dimCov*dimCov*Kmax];
		 vector <Vector<double> > MeanPar;
		 vector <Matrix<double> > CovPar;
		 
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time)); 
//		fprintf(file, "A1\n \n");
//		fclose (file);
		 //Rprintf("A1_1 %i %i  %i %i %i\n",Kmax, nObs, Covariates->nRows,dimCov, Clusters->nNonEmpty );
		 for(k=0;k< Kmax;k++)
		 {
			  MeanPar.push_back(Vector<double>(dimCov,&MeanPar_P[k*dimCov]));
			  CovPar.push_back(Matrix<double>(dimCov,dimCov,&CovPar_P[k*dimCov*dimCov]));
		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		 fprintf(file, "A2\n \n");
//		fclose (file);
		 for(i=0;i< Clusters->nNonEmpty;i++)
		 {
			  //REprintf("dj=%i k=%i \n",i,Clusters->NonEmptyC.vec(i));
			  k = Clusters->NonEmptyC.vec(i);
			  //Rprintf("A1_3\n");
			  MeanPar[k].Init(0.0);
			  CovPar[k].Init(0.0);
			  
		 }
		 
		 //Rprintf("A5\n");
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		fprintf(file, "A3\n \n");
//		fclose (file);
		 for(j=0;j< Clusters->nNonEmpty;j++)
		 {
			  //REprintf("j=%i k=%i \n",j,Clusters->NonEmptyC.vec(j));
			  k = Clusters->NonEmptyC.vec(j);
			  // prior hyperparameters
			  for(i=0;i<dimCov;i++)
			  {
					//REprintf("%i %f %f\n",i,VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0],VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]);
					
					CovPar[k].Pmat(i,i)[0]   = 1.0/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
					MeanPar[k].Pvec(i)[0]  = VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
			  }
			  
		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		 fprintf(file, "A4 \n");
//		fclose (file);
		 //Rprintf("A6\n");
		//REprintf("A6e\n");
		 for(i=0;i<nObs;i++)
		 {
			 //REprintf("i=%i",i);
			  k           = Clusters->Zeta.vec(i);
			 //REprintf("AA %i mmm\n",k);
			  CovApp.P = Covariates[0].Pmat(i*nVars,0);
			  YApp.P = Data[0].Pmat(i,0);
			  // molto poco performante
	  Class_MultivariateNormal::external_ParametersForFullConditioanlBeta_WithoutMolt(&CovApp,  &CovMat[0][k].SigmaAccInv, &YApp, &CovPar[k], &MeanPar[k], &SumPar);
			  
			  
		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		fprintf(file, "A5 \n");
//		fclose (file);
		 for(i=0;i< Clusters->nNonEmpty;i++)
		 {
			  k = Clusters->NonEmptyC.vec(i);
			  //CovPar[k].Print("Cov2");
			  //MeanPar[k].Print("Mean2");
			  //Rprintf("%i %i\n",Clusters->nNonEmpty,Clusters->NonEmptyC.vec(i));
			  Class_MultivariateNormal::external_finalizedRegFullConditional(&CovPar[k],&MeanPar[k], 1);
			  
			  Class_MultivariateNormal::external_SampleMultivariate(&VectorParam[0][k].VectorAcc, &MeanPar[k], &CovPar[k]);
			  VectorParam[0][k].update_ParameterAcc();
		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		fprintf(file, "A6 \n");
//		fclose (file);
		 for(i=0;i< Clusters->nEmpty;i++)
		 {
			  //Rprintf("A10 %i\n",i);
			  k = Clusters->EmptyC.vec(i);
			  //Rprintf("%i ",k );
			  for(j=0;j<dimCov;j++)
			  {
					VectorParam[0][k].VectorAcc.Pvec(j)[0] = rnorm(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(0)[0],pow(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(1)[0],0.5));
			  }
			  
			  VectorParam[0][k].update_ParameterAcc();
		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		fprintf(file, "Fine \n");
//		fclose (file);
		 
	}
	
  void sample_LikeParam_MultiNormLike_Reg_NormalPrior_ONLYNONEMPTY(Matrix <double> * Data)
  {
      Timing T1;
      Timing T2;
      Timing T3;
      Timing T4;
      Timing T5;
      Timing T6;
      int k,i,j;
      
      const double SumPar = 1.0;
      int dimCov = Covariates->nCols;
      
      
      Matrix <double> CovApp(nVars,dimCov,0);
      Vector <double> YApp(nVars,0);
      
      //Rprintf("A1\n");
      double MeanPar_P[dimCov*Kmax];
      double CovPar_P[dimCov*dimCov*Kmax];
      vector <Vector<double> > MeanPar;
      vector <Matrix<double> > CovPar;
      
      //Rprintf("A1_1 %i %i  %i %i %i\n",Kmax, nObs, Covariates->nRows,dimCov, Clusters->nNonEmpty );
      for(k=0;k< Kmax;k++)
      {
          MeanPar.push_back(Vector<double>(dimCov,&MeanPar_P[k*dimCov]));
          CovPar.push_back(Matrix<double>(dimCov,dimCov,&CovPar_P[k*dimCov*dimCov]));
      }
      //Rprintf("A1_2\n");
      for(i=0;i< Clusters->nNonEmpty;i++)
      {
          //REprintf("dj=%i k=%i \n",i,Clusters->NonEmptyC.vec(i));
          k = Clusters->NonEmptyC.vec(i);
          //Rprintf("A1_3\n");
          MeanPar[k].Init(0.0);
          CovPar[k].Init(0.0);
          
      }
      
      //Rprintf("A5\n");
      for(j=0;j< Clusters->nNonEmpty;j++)
      {
          //REprintf("j=%i k=%i \n",j,Clusters->NonEmptyC.vec(j));
          k = Clusters->NonEmptyC.vec(j);
          // prior hyperparameters
          for(i=0;i<dimCov;i++)
          {
              //REprintf("%i %f %f\n",i,VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0],VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]);
              
              CovPar[k].Pmat(i,i)[0]   = 1.0/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
              MeanPar[k].Pvec(i)[0]  = VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
          }
          
      }
      
      //Rprintf("A6\n");
      for(i=0;i<nObs;i++)
      {
          //
          
          //
          // likelihood contribution
          k           = Clusters->Zeta.vec(i);
          
          CovApp.P = Covariates[0].Pmat(i*nVars,0);
          YApp.P = Data[0].Pmat(i,0);
          // molto poco performante
          Class_MultivariateNormal::external_ParametersForFullConditioanlBeta_WithoutMolt(&CovApp,&CovMat[0][k].SigmaAccInv, &YApp, &CovPar[k], &MeanPar[k], &SumPar);
          
          
      }
      //Rprintf("A7\n");
      for(i=0;i< Clusters->nNonEmpty;i++)
      {
          k = Clusters->NonEmptyC.vec(i);
          //CovPar[k].Print("Cov2");
          //MeanPar[k].Print("Mean2");
          //Rprintf("%i %i\n",Clusters->nNonEmpty,Clusters->NonEmptyC.vec(i));
          Class_MultivariateNormal::external_finalizedRegFullConditional(&CovPar[k],&MeanPar[k], 1);
          
          Class_MultivariateNormal::external_SampleMultivariate(&VectorParam[0][k].VectorAcc, &MeanPar[k], &CovPar[k]);
          VectorParam[0][k].update_ParameterAcc();
      }
      
      
  }
  void sample_LikeParam_MultiNormLike_Reg_NormalPrior_ONLYEMPTY()
  {
      Timing T1;
      Timing T2;
      Timing T3;
      Timing T4;
      Timing T5;
      Timing T6;
      int k,i,j;
      

      int dimCov = Covariates->nCols;
      
      
      Matrix <double> CovApp(nVars,dimCov,0);
      Vector <double> YApp(nVars,0);
      
      
      vector <Vector<double> > MeanPar;
      vector <Matrix<double> > CovPar;
      
      
      for(i=0;i< Clusters->nEmpty;i++)
      {
          //Rprintf("A10 %i\n",i);
          k = Clusters->EmptyC.vec(i);
          //Rprintf("%i ",k );
          for(j=0;j<dimCov;j++)
          {
              VectorParam[0][k].VectorAcc.Pvec(j)[0] = rnorm(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(0)[0],pow(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(1)[0],0.5));
          }
          
          VectorParam[0][k].update_ParameterAcc();
      }
      
  }
  void sample_LikeParam_MultiNormLike_Reg_NormalPrior_ONLYFIRSTEMPTY()
  {
      Timing T1;
      Timing T2;
      Timing T3;
      Timing T4;
      Timing T5;
      Timing T6;
      int k,i,j;
      

      int dimCov = Covariates->nCols;
      
      
      Matrix <double> CovApp(nVars,dimCov,0);
      Vector <double> YApp(nVars,0);
      
      
      vector <Vector<double> > MeanPar;
      vector <Matrix<double> > CovPar;
      
      
      for(i=0;i< 1;i++)
      {
          //Rprintf("A10 %i\n",i);
          k = Clusters->EmptyC.vec(i);
          //Rprintf("%i ",k );
          for(j=0;j<dimCov;j++)
          {
              VectorParam[0][k].VectorAcc.Pvec(j)[0] = rnorm(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(0)[0],pow(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(1)[0],0.5));
          }
          
          VectorParam[0][k].update_ParameterAcc();
      }
      
  }
  void sample_LikeParam_MultiNormLike_Reg_NormalPrior_ONLYEMPTY_BIGNVAR()
  {
      Timing T1;
      Timing T2;
      Timing T3;
      Timing T4;
      Timing T5;
      Timing T6;
      int k,i,j;
      

      int dimCov = Covariates->nCols;
      
      
      Matrix <double> CovApp(nVars,dimCov,0);
      Vector <double> YApp(nVars,0);
      
      
      vector <Vector<double> > MeanPar;
      vector <Matrix<double> > CovPar;
      
      
      int kc = Clusters->NonEmptyC.vec((int)floor(runif(0.0,Clusters->nNonEmpty)));
      k = Clusters->EmptyC.vec(0);  
      for(j=0;j<dimCov;j++)
      {
        VectorParam[0][k].VectorAcc.Pvec(j)[0] = VectorParam[0][kc].VectorAcc.Pvec(j)[0];
      }
    
      j = (int)floor(runif(0.0,dimCov));
      VectorParam[0][k].VectorAcc.Pvec(j)[0] = rnorm(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(0)[0],pow(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(1)[0],0.5));
      
      
      VectorParam[0][k].update_ParameterAcc();
      
  }
    void sample_LikeParam_GIBBS()
    {
        
    }
    void sample_LikeParam_MultiNormLike_Reg_NormalPrior_TODELETE()
    {
        
        sample_LikeParam_MultiNormLike_Reg_NormalPrior_TODELETE(&Y);
        
    }
    
    void sample_LikeParam_MultiNormLike_Reg_NormalPrior_TODELETE(Matrix <double> * Data)
    {
        Timing T1;
        Timing T2;
        Timing T3;
        Timing T4;
        Timing T5;
        Timing T6;
        int k,i,j;
        
        const double SumPar = 1.0;
        int dimCov = Covariates->nCols;
        
        
        Matrix <double> CovApp(nVars,dimCov,0);
        Vector <double> YApp(nVars,0);
        
        //Rprintf("A1\n");
        double MeanPar_P[dimCov*Kmax];
        double CovPar_P[dimCov*dimCov*Kmax];
        vector <Vector<double> > MeanPar;
        vector <Matrix<double> > CovPar;
        
        //Rprintf("A1_1 %i %i  %i %i %i\n",Kmax, nObs, Covariates->nRows,dimCov, Clusters->nNonEmpty );
        for(k=0;k< Kmax;k++)
        {
            MeanPar.push_back(Vector<double>(dimCov,&MeanPar_P[k*dimCov]));
            CovPar.push_back(Matrix<double>(dimCov,dimCov,&CovPar_P[k*dimCov*dimCov]));
        }
        //Rprintf("A1_2\n");
        for(i=0;i< Clusters->nNonEmpty;i++)
        {
            //REprintf("dj=%i k=%i \n",i,Clusters->NonEmptyC.vec(i));
            k = Clusters->NonEmptyC.vec(i);
            //Rprintf("A1_3\n");
            MeanPar[k].Init(0.0);
            CovPar[k].Init(0.0);
        }
        
        //Rprintf("A5\n");
        for(j=0;j< Clusters->nNonEmpty;j++)
        {
            //REprintf("j=%i k=%i \n",j,Clusters->NonEmptyC.vec(j));
            k = Clusters->NonEmptyC.vec(j);
            // prior hyperparameters
            for(i=0;i<dimCov;i++)
            {
                //REprintf("%i %f %f\n",i,VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0],VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]);
                
                CovPar[k].Pmat(i,i)[0]   = 1.0/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
                MeanPar[k].Pvec(i)[0]  = VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
            }
            
        }
        
        //Rprintf("A6\n");
        for(i=0;i<nObs;i++)
        {
            //
            
            //
            // likelihood contribution
            k           = Clusters->Zeta.vec(i);
            
            CovApp.P = Covariates[0].Pmat(i*nVars,0);
            YApp.P = Y.Pmat(i,0);
            // molto poco performante
            Class_MultivariateNormal::external_ParametersForFullConditioanlBeta_WithoutMolt(&CovApp,&CovMat[0][k].SigmaAccInv, &YApp, &CovPar[k], &MeanPar[k], &SumPar);
            
            
        }
        //Rprintf("A7\n");
        for(i=0;i< Clusters->nNonEmpty;i++)
        {
            k = Clusters->NonEmptyC.vec(i);
            //CovPar[k].Print("Cov2");
            //MeanPar[k].Print("Mean2");
            //Rprintf("%i %i\n",Clusters->nNonEmpty,Clusters->NonEmptyC.vec(i));
            Class_MultivariateNormal::external_finalizedRegFullConditional(&CovPar[k],&MeanPar[k], 1);
            
            Class_MultivariateNormal::external_SampleMultivariate(&VectorParam[0][k].VectorAcc, &MeanPar[k], &CovPar[k]);
            VectorParam[0][k].update_ParameterAcc();
        }
        //Rprintf("A8\n");
        for(i=0;i< Clusters->nEmpty;i++)
        {
            //Rprintf("A10 %i\n",i);
            k = Clusters->EmptyC.vec(i);
            //Rprintf("%i ",k );
            for(j=0;j<dimCov;j++)
            {
                VectorParam[0][k].VectorAcc.Pvec(j)[0] = rnorm(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(0)[0],pow(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(1)[0],0.5));
            }
            
            VectorParam[0][k].update_ParameterAcc();
        }
        
    }
    
    
    void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishartZeroMean()
    {
        sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishartZeroMean(&Y);
    }
    void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishartZeroMean(Matrix <double> * Data)
    {
        int k,i,j,h;
        int K = Kmax;
        //int Kapp;
        
        //int nclust[K];
        double appMeanPar_P[nVars];
        //        double MeanPar_P[nVars*K];
        double CovPar_P[nVars*nVars*K];
        double nu_P[K];
        
        Vector<double> appMeanPar(nVars,appMeanPar_P);
        Vector<double> nu(K,nu_P);
        //        vector <Vector<double> > MeanPar;
        vector <Matrix<double> > CovPar;
        
        double omega_P[nVars];
        Vector <double> omega(nVars,omega_P);
        
        //        double Xbeta_P[nVars];
        //        Vector<double>Xbeta (nVars,Xbeta_P);
        
        
        //Rprintf("S1\n");
        for(k=0;k< Kmax;k++)
        {
            CovPar.push_back(Matrix<double>(nVars,nVars,CovPar_P[k*nVars*nVars]));
        }
        for(i=0;i< Clusters->nNonEmpty;i++)
        {
            k = Clusters->NonEmptyC.vec(i);
            CovPar[k].Init(0.0);
            
            //nclust[k] = 0.0;
        }
        
        //Rprintf("S2\n");
        for(i=0;i< Clusters->nNonEmpty;i++)
        {
            k = Clusters->NonEmptyC.vec(i);
            nu.Pvec(k)[0] =  CovMat[0][k].PriorParameter->nuAcc[0]+Clusters->NObsInClust.vec(k);
            
            CovPar[k].Init(0.0);
            for(h=0;h<nVars;h++)
            {
                for(j=0;j<nVars;j++)
                {
                    CovPar[k].Pmat(h,j)[0] = CovMat[0][k].PriorParameter->PsiAcc[0].Pmat(h,j)[0];
                }
                
            }
            
        }
        //Rprintf("S3\n");
        for(i=0;i<nObs;i++)
        {
            // likelihood contribution
            k           = Clusters->Zeta.vec(i);
            omega.P     = Data->Pmat(i,0);
            
            //            for(h=0;h<nVars;h++)
            //            {
            //                Xbeta.Pvec(h)[0] = 0.0;
            //                for(j = 0; j<Covariates->nCols;j++)
            //                {
            //                    Xbeta.Pvec(h)[0] += Covariates[0].mat(nVars*i+h,j)*VectorParam[0][k].VectorAcc.vec(j);
            //                }
            //            }
            
            //            for(j=0;j<nVars;j++)
            //            {
            //                for(h=j;h<nVars;h++)
            //                {
            //                    CovPar[k].Pmat(j,h)[0] += (omega.vec(j)-Xbeta.vec(j))*(omega.vec(h)-Xbeta.vec(h));
            //                }
            //            }
            for(j=0;j<nVars;j++)
            {
                for(h=j;h<nVars;h++)
                {
                    CovPar[k].Pmat(j,h)[0] += omega.vec(j)*omega.vec(h);
                }
            }
        }
        
        
        for(i=0;i< Clusters->nNonEmpty;i++)
        {
            
            k = Clusters->NonEmptyC.vec(i);
            Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc, &CovMat[0][k].SigmaAccInv, &CovPar[k], nu.Pvec(k)[0]);
            
            CovMat[0][k].compute_InvAccAndChol();
        }
        //Rprintf("S5\n");
        for(i=0;i< Clusters->nEmpty;i++)
        {
            // Rprintf("S1 %i\n",i);
            k = Clusters->EmptyC.vec(i);
            //Rprintf("S1 %i %f\n",k,CovMat[0][k].PriorParameter->nuAcc[0]);
            
            //CovMat[0][k].PriorParameter->PsiAcc->Print("Psi");
            Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc,&CovMat[0][k].SigmaAccInv, &CovMat[0][k].PriorParameter->PsiAcc[0], CovMat[0][k].PriorParameter->nuAcc[0]);
            //Rprintf("S11\n");
            CovMat[0][k].compute_InvAccAndChol();
            //Rprintf("S12\n");
        }
        // Rprintf("S6\n");
        
        
        
    }
    
	
	void sample_FromPrior_MultiNormLikeReg_Sigma_InverseWishart(int k)
	{
		Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc,&CovMat[0][k].SigmaAccInv, &CovMat[0][k].PriorParameter->PsiAcc[0], CovMat[0][k].PriorParameter->nuAcc[0]);
		CovMat[0][k].compute_InvAccAndChol();
	}
	void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_OnlyOcc()
	{
		 sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_OnlyOcc(&Y);
	}
	
	 void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_OnlyOcc(Matrix <double> * Data)
	 {
		 
		 
		 //string NAMEdir = "/Users/gianlucamastrantonio/Dropbox (Politecnico di Torino Staff)/lavori/ode/TESTOUT/";
 //		string NAMEdir = "/work/gmastrantonio/ODE/lancio/";
 //		#ifdef _OPENMP
 //		string appNamedir = (NAMEdir+to_string(omp_get_thread_num())+"Var.txt");
 //		#else
 //		string appNamedir = (NAMEdir+to_string(0)+".txt");
 //		#endif
 //		FILE * (file);
 //		time_t my_time = time(NULL);
		 
		  int k,i,j,h;
		  int K = Kmax;
		  
		  //int Kapp;
		  
		  //int nclust[K];
		  double appMeanPar_P[nVars];
		  //        double MeanPar_P[nVars*K];
		  double CovPar_P[nVars*nVars*K];
		  double nu_P[K];
		  
		  Vector<double> appMeanPar(nVars,appMeanPar_P);
		  Vector<double> nu(K,nu_P);
		  //        vector <Vector<double> > MeanPar;
		  vector <Matrix<double> > CovPar;
		  
		  //double omega_P[nVars];
		  Vector <double> omega(nVars,Data->Pmat(0,0));
		  
		  double Xbeta_P[nVars];
		  Vector<double>Xbeta (nVars,Xbeta_P);
 //		 file = fopen(appNamedir.c_str(),"wt");
 //		fprintf(file,"%s", ctime(&my_time));
 //		 fprintf(file, "A1 \n");
 //		fclose (file);
		  //Rprintf("S1\n");
		  for(k=0;k< Kmax;k++)
		  {
				CovPar.push_back(Matrix<double>(nVars,nVars,&CovPar_P[k*nVars*nVars]));
		  }
		  for(i=0;i< Clusters->nNonEmpty;i++)
		  {
				k = Clusters->NonEmptyC.vec(i);
				CovPar[k].Init(0.0);
				
				//nclust[k] = 0.0;
		  }
 //		file = fopen(appNamedir.c_str(),"wt");
 //		fprintf(file,"%s", ctime(&my_time));
 //		 fprintf(file, "A2 \n");
 //		fclose (file);
		  //Rprintf("S2\n");
		  for(i=0;i< Clusters->nNonEmpty;i++)
		  {
				k = Clusters->NonEmptyC.vec(i);
				nu.Pvec(k)[0] = CovMat[0][k].PriorParameter->nuAcc[0]+Clusters->NObsInClust.vec(k);
				
				CovPar[k].Init(0.0);
				for(h=0;h<nVars;h++)
				{
					 for(j=0;j<nVars;j++)
					 {
						  CovPar[k].Pmat(h,j)[0] = CovMat[0][k].PriorParameter->PsiAcc[0].Pmat(h,j)[0];
					 }
					 
				}
				
		  }
 //		file = fopen(appNamedir.c_str(),"wt");
 //		fprintf(file,"%s", ctime(&my_time));
 //		fprintf(file, "A3 \n");
 //		fclose (file);
		  //Rprintf("S3\n");
		  for(i=0;i<nObs;i++)
		  {
				// likelihood contribution
				k           = Clusters->Zeta.vec(i);
				omega.P     = Data->Pmat(i,0);
				
				for(h=0;h<nVars;h++)
				{
					 Xbeta.Pvec(h)[0] = 0.0;
					 for(j = 0; j<Covariates->nCols;j++)
					 {
						  Xbeta.Pvec(h)[0] += Covariates[0].mat(nVars*i+h,j)*VectorParam[0][k].VectorAcc.vec(j);
					 }
				}
				
				for(j=0;j<nVars;j++)
				{
					 for(h=j;h<nVars;h++)
					 {
						  CovPar[k].Pmat(j,h)[0] += (omega.vec(j)-Xbeta.vec(j))*(omega.vec(h)-Xbeta.vec(h));
					 }
				}
		  }
 //		file = fopen(appNamedir.c_str(),"wt");
 //		fprintf(file,"%s", ctime(&my_time));
 //		 fprintf(file, "A4 \n");
 //		fclose (file);
		  //Rprintf("%i\n ", Clusters->nNonEmpty);
		  //        for(i=0;i< Clusters->nNonEmpty;i++)
		  //        {
		  //            Rprintf("%i  ", Clusters->NonEmptyC.vec(i));
		  //        }
		  //Rprintf("S4\n");
		  for(i=0;i< Clusters->nNonEmpty;i++)
		  {
				
				k = Clusters->NonEmptyC.vec(i);
				Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc, &CovMat[0][k].SigmaAccInv, &CovPar[k], nu.Pvec(k)[0]);
				
				CovMat[0][k].compute_InvAccAndChol();
		  }
 //		file = fopen(appNamedir.c_str(),"wt");
 //		fprintf(file,"%s", ctime(&my_time));
 //		fprintf(file, "A5 \n");
 //		fclose (file);
		  //Rprintf("S5\n");
//		  for(i=0;i< Clusters->nEmpty;i++)
//		  {
//				// Rprintf("S1 %i\n",i);
//				k = Clusters->EmptyC.vec(i);
//				//Rprintf("S1 %i %f\n",k,CovMat[0][k].PriorParameter->nuAcc[0]);
//				
//				//CovMat[0][k].PriorParameter->PsiAcc->Print("Psi");
//				Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc,&CovMat[0][k].SigmaAccInv, &CovMat[0][k].PriorParameter->PsiAcc[0], CovMat[0][k].PriorParameter->nuAcc[0]);
//				//Rprintf("S11\n");
//				CovMat[0][k].compute_InvAccAndChol();
//				//Rprintf("S12\n");
//		  }
 //		 file = fopen(appNamedir.c_str(),"wt");
 //		fprintf(file,"%s", ctime(&my_time));
 //		 fprintf(file, "FINE \n");
 //		 fclose (file);
		  

	 }
    void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart()
    {
        sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart(&Y);
    }
  
  void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_BIGNVAR()
  {
      sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_ONLYNONEMPTY(&Y);
  }
    
//	 void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart(Matrix <double> * Data)
//	 {
//
//		 
//		  int k,i,j,h;
//		  int K = Kmax;
//		  
//		  //int Kapp;
//		  
//		  //int nclust[K];
//		  double appMeanPar_P[nVars];
//		  //        double MeanPar_P[nVars*K];
//		  double CovPar_P[nVars*nVars*K];
//		  double nu_P[K];
//		  
//		  Vector<double> appMeanPar(nVars,appMeanPar_P);
//		  Vector<double> nu(K,nu_P);
//		  //        vector <Vector<double> > MeanPar;
//		  vector <Matrix<double> > CovPar;
//		  
//		  //double omega_P[nVars];
//		  Vector <double> omega(nVars,Data->Pmat(0,0));
//		  
//		  double Xbeta_P[nVars];
//		  Vector<double>Xbeta (nVars,Xbeta_P);
//		  
//		  //Rprintf("S1\n");
//		  for(k=0;k< Kmax;k++)
//		  {
//				CovPar.push_back(Matrix<double>(nVars,nVars,&CovPar_P[k*nVars*nVars]));
//		  }
//		  for(i=0;i< Clusters->nNonEmpty;i++)
//		  {
//				k = Clusters->NonEmptyC.vec(i);
//				CovPar[k].Init(0.0);
//				
//				//nclust[k] = 0.0;
//		  }
//		 
//		  for(i=0;i< Clusters->nNonEmpty;i++)
//		  {
//				k = Clusters->NonEmptyC.vec(i);
//				nu.Pvec(k)[0] = K-1+ CovMat[0][k].PriorParameter->nuAcc[0]+Clusters->NObsInClust.vec(k);
//				
//				CovPar[k].Init(0.0);
//				for(h=0;h<nVars;h++)
//				{
//					 for(j=0;j<nVars;j++)
//					 {
//						  CovPar[k].Pmat(h,j)[0] = CovMat[0][k].PriorParameter->PsiAcc[0].Pmat(h,j)[0];
//					 }
//					 
//				}
//				
//		  }
//		 
//		  for(i=0;i<nObs;i++)
//		  {
//				// likelihood contribution
//				k           = Clusters->Zeta.vec(i);
//				omega.P     = Data->Pmat(i,0);
//				
//				for(h=0;h<nVars;h++)
//				{
//					 Xbeta.Pvec(h)[0] = 0.0;
//					 for(j = 0; j<Covariates->nCols;j++)
//					 {
//						  Xbeta.Pvec(h)[0] += Covariates[0].mat(nVars*i+h,j)*VectorParam[0][k].VectorAcc.vec(j);
//					 }
//				}
//				
//				for(j=0;j<nVars;j++)
//				{
//					 for(h=j;h<nVars;h++)
//					 {
//						  CovPar[k].Pmat(j,h)[0] += (omega.vec(j)-Xbeta.vec(j))*(omega.vec(h)-Xbeta.vec(h));
//					 }
//				}
//		  }
//		 
//		  for(i=0;i< Clusters->nNonEmpty;i++)
//		  {
//				
//				k = Clusters->NonEmptyC.vec(i);
//				Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc, &CovMat[0][k].SigmaAccInv, &CovPar[k], nu.Pvec(k)[0]);
//				
//				CovMat[0][k].compute_InvAccAndChol();
//		  }
//		 
//		 
//		  for(i=0;i< Clusters->nEmpty;i++)
//		  {
//				// Rprintf("S1 %i\n",i);
//				k = Clusters->EmptyC.vec(i);
//				//Rprintf("S1 %i %f\n",k,CovMat[0][k].PriorParameter->nuAcc[0]);
//				
//				//CovMat[0][k].PriorParameter->PsiAcc->Print("Psi");
//				Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc,&CovMat[0][k].SigmaAccInv, &CovMat[0][k].PriorParameter->PsiAcc[0], CovMat[0][k].PriorParameter->nuAcc[0]);
//				//Rprintf("S11\n");
//				CovMat[0][k].compute_InvAccAndChol();
//				//Rprintf("S12\n");
//		  }
//		  
//		  
//
//	 }
	
	void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart(Matrix <double> * Data)
	{
		
		
		//string NAMEdir = "/Users/gianlucamastrantonio/Dropbox (Politecnico di Torino Staff)/lavori/ode/TESTOUT/";
//		string NAMEdir = "/work/gmastrantonio/ODE/lancio/";
//		#ifdef _OPENMP
//		string appNamedir = (NAMEdir+to_string(omp_get_thread_num())+"Var.txt");
//		#else
//		string appNamedir = (NAMEdir+to_string(0)+".txt");
//		#endif
//		FILE * (file);
//		time_t my_time = time(NULL);
		
		 int k,i,j,h;
		 int K = Kmax;
		 
		 //int Kapp;
		 
		 //int nclust[K];
		 double appMeanPar_P[nVars];
		 //        double MeanPar_P[nVars*K];
		 double CovPar_P[nVars*nVars*K];
		 double nu_P[K];
		 
		 Vector<double> appMeanPar(nVars,appMeanPar_P);
		 Vector<double> nu(K,nu_P);
		 //        vector <Vector<double> > MeanPar;
		 vector <Matrix<double> > CovPar;
		 
		 //double omega_P[nVars];
		 Vector <double> omega(nVars,Data->Pmat(0,0));
		 
		 double Xbeta_P[nVars];
		 Vector<double>Xbeta (nVars,Xbeta_P);
//		 file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		 fprintf(file, "A1 \n");
//		fclose (file);
		 //Rprintf("S1\n");
		 for(k=0;k< Kmax;k++)
		 {
			  CovPar.push_back(Matrix<double>(nVars,nVars,&CovPar_P[k*nVars*nVars]));
		 }
		 for(i=0;i< Clusters->nNonEmpty;i++)
		 {
			  k = Clusters->NonEmptyC.vec(i);
			  CovPar[k].Init(0.0);
			  
			  //nclust[k] = 0.0;
		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		 fprintf(file, "A2 \n");
//		fclose (file);
		 //Rprintf("S2\n");
		 for(i=0;i< Clusters->nNonEmpty;i++)
		 {
			  k = Clusters->NonEmptyC.vec(i);
			  nu.Pvec(k)[0] = CovMat[0][k].PriorParameter->nuAcc[0]+Clusters->NObsInClust.vec(k);
			  
			  CovPar[k].Init(0.0);
			  for(h=0;h<nVars;h++)
			  {
					for(j=0;j<nVars;j++)
					{
						 CovPar[k].Pmat(h,j)[0] = CovMat[0][k].PriorParameter->PsiAcc[0].Pmat(h,j)[0];
					}
					
			  }
			  
		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		fprintf(file, "A3 \n");
//		fclose (file);
		 //Rprintf("S3\n");
		 for(i=0;i<nObs;i++)
		 {
			  // likelihood contribution
			  k           = Clusters->Zeta.vec(i);
			  omega.P     = Data->Pmat(i,0);
			  
			  for(h=0;h<nVars;h++)
			  {
					Xbeta.Pvec(h)[0] = 0.0;
					for(j = 0; j<Covariates->nCols;j++)
					{
						 Xbeta.Pvec(h)[0] += Covariates[0].mat(nVars*i+h,j)*VectorParam[0][k].VectorAcc.vec(j);
					}
			  }
			  
			  for(j=0;j<nVars;j++)
			  {
					for(h=j;h<nVars;h++)
					{
						 CovPar[k].Pmat(j,h)[0] += (omega.vec(j)-Xbeta.vec(j))*(omega.vec(h)-Xbeta.vec(h));
					}
			  }
		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		 fprintf(file, "A4 \n");
//		fclose (file);
		 //Rprintf("%i\n ", Clusters->nNonEmpty);
		 //        for(i=0;i< Clusters->nNonEmpty;i++)
		 //        {
		 //            Rprintf("%i  ", Clusters->NonEmptyC.vec(i));
		 //        }
		 //Rprintf("S4\n");
		 for(i=0;i< Clusters->nNonEmpty;i++)
		 {
			  
			  k = Clusters->NonEmptyC.vec(i);
			  Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc, &CovMat[0][k].SigmaAccInv, &CovPar[k], nu.Pvec(k)[0]);
			  
			  CovMat[0][k].compute_InvAccAndChol();
		 }
//		file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		fprintf(file, "A5 \n");
//		fclose (file);
		 //Rprintf("S5\n");
		 for(i=0;i< Clusters->nEmpty;i++)
		 {
			  // Rprintf("S1 %i\n",i);
			  k = Clusters->EmptyC.vec(i);
			  //Rprintf("S1 %i %f\n",k,CovMat[0][k].PriorParameter->nuAcc[0]);
			  
			  //CovMat[0][k].PriorParameter->PsiAcc->Print("Psi");
			  Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc,&CovMat[0][k].SigmaAccInv, &CovMat[0][k].PriorParameter->PsiAcc[0], CovMat[0][k].PriorParameter->nuAcc[0]);
			  //Rprintf("S11\n");
			  CovMat[0][k].compute_InvAccAndChol();
			  //Rprintf("S12\n");
		 }
//		 file = fopen(appNamedir.c_str(),"wt");
//		fprintf(file,"%s", ctime(&my_time));
//		 fprintf(file, "FINE \n");
//		 fclose (file);
		 

	}
  
  void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_ONLYNONEMPTY(Matrix <double> * Data)
  {
      int k,i,j,h;
      int K = Kmax;
      
      //int Kapp;
      
      //int nclust[K];
      double appMeanPar_P[nVars];
      //        double MeanPar_P[nVars*K];
      double CovPar_P[nVars*nVars*K];
      double nu_P[K];
      
      Vector<double> appMeanPar(nVars,appMeanPar_P);
      Vector<double> nu(K,nu_P);
      //        vector <Vector<double> > MeanPar;
      vector <Matrix<double> > CovPar;
      
      double omega_P[nVars];
      Vector <double> omega(nVars,omega_P);
      
      double Xbeta_P[nVars];
      Vector<double>Xbeta (nVars,Xbeta_P);
      
      
      //Rprintf("S1\n");
      for(k=0;k< Kmax;k++)
      {
          CovPar.push_back(Matrix<double>(nVars,nVars,&CovPar_P[k*nVars*nVars]));
      }
      for(i=0;i< Clusters->nNonEmpty;i++)
      {
          k = Clusters->NonEmptyC.vec(i);
          CovPar[k].Init(0.0);
          
          //nclust[k] = 0.0;
      }
      
      //Rprintf("S2\n");
      for(i=0;i< Clusters->nNonEmpty;i++)
      {
          k = Clusters->NonEmptyC.vec(i);
          nu.Pvec(k)[0] = CovMat[0][k].PriorParameter->nuAcc[0]+Clusters->NObsInClust.vec(k);
          
          CovPar[k].Init(0.0);
          for(h=0;h<nVars;h++)
          {
              for(j=0;j<nVars;j++)
              {
                  CovPar[k].Pmat(h,j)[0] = CovMat[0][k].PriorParameter->PsiAcc[0].Pmat(h,j)[0];
              }
              
          }
          
      }
      //Rprintf("S3\n");
      for(i=0;i<nObs;i++)
      {
          // likelihood contribution
          k           = Clusters->Zeta.vec(i);
          omega.P     = Data->Pmat(i,0);
          
          for(h=0;h<nVars;h++)
          {
              Xbeta.Pvec(h)[0] = 0.0;
              for(j = 0; j<Covariates->nCols;j++)
              {
                  Xbeta.Pvec(h)[0] += Covariates[0].mat(nVars*i+h,j)*VectorParam[0][k].VectorAcc.vec(j);
              }
          }
          
          for(j=0;j<nVars;j++)
          {
              for(h=j;h<nVars;h++)
              {
                  CovPar[k].Pmat(j,h)[0] += (omega.vec(j)-Xbeta.vec(j))*(omega.vec(h)-Xbeta.vec(h));
              }
          }
      }
      
      //Rprintf("%i\n ", Clusters->nNonEmpty);
      //        for(i=0;i< Clusters->nNonEmpty;i++)
      //        {
      //            Rprintf("%i  ", Clusters->NonEmptyC.vec(i));
      //        }
      //Rprintf("S4\n");
      for(i=0;i< Clusters->nNonEmpty;i++)
      {
          
          k = Clusters->NonEmptyC.vec(i);
          Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc, &CovMat[0][k].SigmaAccInv, &CovPar[k], nu.Pvec(k)[0]);
          
          CovMat[0][k].compute_InvAccAndChol();
      }
      //Rprintf("S5\n");
//      for(i=0;i< Clusters->nEmpty;i++)
//      {
//          // Rprintf("S1 %i\n",i);
//          k = Clusters->EmptyC.vec(i);
//          //Rprintf("S1 %i %f\n",k,CovMat[0][k].PriorParameter->nuAcc[0]);
//          
//          //CovMat[0][k].PriorParameter->PsiAcc->Print("Psi");
//          Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc,&CovMat[0][k].SigmaAccInv, &CovMat[0][k].PriorParameter->PsiAcc[0], CovMat[0][k].PriorParameter->nuAcc[0]);
//          //Rprintf("S11\n");
//          CovMat[0][k].compute_InvAccAndChol();
//          //Rprintf("S12\n");
//      }
      // Rprintf("S6\n");
      
      
      
  }
  void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_ONLYEMPTY()
  {
      int k,i,j,h;
      int K = Kmax;
      
      //int Kapp;
      
      //int nclust[K];
      double appMeanPar_P[nVars];
      //        double MeanPar_P[nVars*K];
      double CovPar_P[nVars*nVars*K];
      double nu_P[K];
      
      Vector<double> appMeanPar(nVars,appMeanPar_P);
      Vector<double> nu(K,nu_P);
      //        vector <Vector<double> > MeanPar;
      vector <Matrix<double> > CovPar;
      
      double omega_P[nVars];
      Vector <double> omega(nVars,omega_P);
      
      double Xbeta_P[nVars];
      Vector<double>Xbeta (nVars,Xbeta_P);
      
      
      
      for(i=0;i< Clusters->nEmpty;i++)
      {
          k = Clusters->EmptyC.vec(i);
          //Rprintf("S1 %i %f\n",k,CovMat[0][k].PriorParameter->nuAcc[0]);
          
          //CovMat[0][k].PriorParameter->PsiAcc->Print("Psi");
          Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc,&CovMat[0][k].SigmaAccInv, &CovMat[0][k].PriorParameter->PsiAcc[0], CovMat[0][k].PriorParameter->nuAcc[0]);
          //Rprintf("S11\n");
          CovMat[0][k].compute_InvAccAndChol();
      }
      // Rprintf("S6\n");
      
      
      
  }
  void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_ONLYFIRSTEMPTY()
  {
      int k,i,j,h;
      int K = Kmax;
      
      //int Kapp;
      
      //int nclust[K];
      double appMeanPar_P[nVars];
      //        double MeanPar_P[nVars*K];
      double CovPar_P[nVars*nVars*K];
      double nu_P[K];
      
      Vector<double> appMeanPar(nVars,appMeanPar_P);
      Vector<double> nu(K,nu_P);
      //        vector <Vector<double> > MeanPar;
      vector <Matrix<double> > CovPar;
      
      double omega_P[nVars];
      Vector <double> omega(nVars,omega_P);
      
      double Xbeta_P[nVars];
      Vector<double>Xbeta (nVars,Xbeta_P);
      
      
      
      for(i=0;i< 1;i++)
      {
          k = Clusters->EmptyC.vec(i);
          //Rprintf("S1 %i %f\n",k,CovMat[0][k].PriorParameter->nuAcc[0]);
          
          //CovMat[0][k].PriorParameter->PsiAcc->Print("Psi");
          Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc,&CovMat[0][k].SigmaAccInv, &CovMat[0][k].PriorParameter->PsiAcc[0], CovMat[0][k].PriorParameter->nuAcc[0]);
          //Rprintf("S11\n");
          CovMat[0][k].compute_InvAccAndChol();
      }
      // Rprintf("S6\n");
      
      
      
  }
  
  void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_ONLYEMPTY_BIGNVAR()
  {
      int k,i,j,h;
      int K = Kmax;
      
      //int Kapp;
      
      //int nclust[K];
      double appMeanPar_P[nVars];
      //        double MeanPar_P[nVars*K];
      double CovPar_P[nVars*nVars*K];
      double nu_P[K];
      
      Vector<double> appMeanPar(nVars,appMeanPar_P);
      Vector<double> nu(K,nu_P);
      //        vector <Vector<double> > MeanPar;
      vector <Matrix<double> > CovPar;
      
      double omega_P[nVars];
      Vector <double> omega(nVars,omega_P);
      
      double Xbeta_P[nVars];
      Vector<double>Xbeta (nVars,Xbeta_P);
      
      
      
    
    int kc = Clusters->NonEmptyC.vec((int)floor(runif(0.0,Clusters->nNonEmpty)));
    k = Clusters->EmptyC.vec(0);  
    for(j=0;j<nVars;j++)
    {
      for(int j2=0;j2<nVars;j2++)
      {
        CovMat[0][k].SigmaAcc.Pmat(j,j2)[0] = CovMat[0][kc].SigmaAcc.Pmat(j,j2)[0];
      }
    }
  
    j = (int)floor(runif(0.0,nVars));
    double sigmasave = pow(CovMat[0][k].SigmaAcc.Pmat(j,j)[0],0.5);
    double sigmaacc = pow(1.0/rgamma(2.0/CovMat[0][k].PriorParameter->nuAcc[0],   CovMat[0][k].PriorParameter->PsiAcc[0].mat(j,j)/2.0) ,0.5);
    
    for(int j2=0;j2<j;j2++)
    {
      CovMat[0][k].SigmaAcc.Pmat(j2,j)[0] =  CovMat[0][k].SigmaAcc.Pmat(j2,j)[0]*sigmaacc/sigmasave;
      CovMat[0][k].SigmaAcc.Pmat(j,j2)[0] =  CovMat[0][k].SigmaAcc.Pmat(j,j2)[0]*sigmaacc/sigmasave;
    }
    for(int j2=j+1;j2<nVars;j2++)
    {
      CovMat[0][k].SigmaAcc.Pmat(j2,j)[0] =  CovMat[0][k].SigmaAcc.Pmat(j2,j)[0]*sigmaacc/sigmasave;
      CovMat[0][k].SigmaAcc.Pmat(j,j2)[0] =  CovMat[0][k].SigmaAcc.Pmat(j,j2)[0]*sigmaacc/sigmasave;
    }
    CovMat[0][k].SigmaAcc.Pmat(j,j)[0] = pow(sigmaacc,2.0);
    CovMat[0][k].compute_InvAccAndChol();
    
  }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    //    void sample_LikeParam_MultiNormLike_Reg_NormalPrior_Marginal(int k)
    //    {
    //
    //        sample_LikeParam_MultiNormLike_Reg_NormalPrior_Marginal(&Y,k);
    //
    //    }
    
    void sample_LikeParam_MultiNormLike_Reg_NormalPrior_Marginal(int k)
    {
        
        int j;
        //const double SumPar = 1.0;
        int dimCov = Covariates->nCols;
        
        
        Matrix <double> CovApp(nVars,dimCov,0);
        Vector <double> YApp(nVars,0);
        
        //Rprintf("A1\n");
        //        double MeanPar_P[dimCov*Clusters->nNonEmpty];
        //        double CovPar_P[dimCov*dimCov*Clusters->nNonEmpty];
        //        vector <Vector<double> > MeanPar;
        //        vector <Matrix<double> > CovPar;
        
        
        //Rprintf("%i ",k );
        for(j=0;j<dimCov;j++)
        {
            VectorParam[0][k].VectorAcc.Pvec(j)[0] = rnorm(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(0)[0],pow(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(1)[0],0.5));
        }
        
        VectorParam[0][k].update_ParameterAcc();
        
        //
        //        //        T1.compute_start();
        //        //Rprintf("A1\n");
        //        for(k=0;k< Kmax;k++)
        //        {
        //            MeanPar.push_back(Vector<double>(dimCov,MeanPar_P[k*dimCov]));
        //            CovPar.push_back(Matrix<double>(dimCov,dimCov,CovPar_P[k*dimCov*dimCov]));
        //        }
        //        for(i=0;i< Clusters->nNonEmpty;i++)
        //        {
        //            k = Clusters->NonEmptyC.vec(i);
        //            MeanPar[k].Init(0.0);
        //            CovPar[k].Init(0.0);
        //
        //        }
        //
        //        //Rprintf("A5\n");
        //        for(j=0;j< Clusters->nNonEmpty;j++)
        //        {
        //            k = Clusters->NonEmptyC.vec(j);
        //            // prior hyperparameters
        //            for(i=0;i<dimCov;i++)
        //            {
        //                CovPar[k].Pmat(i,i)[0]   = 1.0/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
        //                MeanPar[k].Pvec(i)[0]  = VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
        //            }
        //            //CovPar[k].Print("Cov");
        //            //MeanPar[k].Print("Mean");
        //        }
        //
        //        //        T3.compute_end();
        //        //        T4.compute_start();
        //        //Rprintf("A8\n");
        //        //Covariates[0].Print("Covariates");
        //        for(i=0;i<nObs;i++)
        //        {
        //            // likelihood contribution
        //            k           = Clusters->Zeta.vec(i);
        //
        //            CovApp.P = Covariates[0].Pmat(i*nVars,0);
        //            YApp.P = Y.Pmat(i,0);
        //            // molto poco performante
        //            Class_MultivariateNormal::external_ParametersForFullConditioanlBeta_WithoutMolt(&CovApp,&CovMat[0][k].SigmaAccInv, &YApp, &CovPar[k], &MeanPar[k], &SumPar);
        //
        //
        //        }
        //        //        T4.compute_end();
        //        //        T5.compute_start();
        //        //Rprintf("A9\n");
        //        for(i=0;i< Clusters->nNonEmpty;i++)
        //        {
        //            k = Clusters->NonEmptyC.vec(i);
        //            //CovPar[k].Print("Cov2");
        //            //MeanPar[k].Print("Mean2");
        //            //Rprintf("%i %i\n",Clusters->nNonEmpty,Clusters->NonEmptyC.vec(i));
        //            Class_MultivariateNormal::external_finalizedRegFullConditional(&CovPar[k],&MeanPar[k], 1);
        //
        //            Class_MultivariateNormal::external_SampleMultivariate(&VectorParam[0][k].VectorAcc, &MeanPar[k], &CovPar[k]);
        //            VectorParam[0][k].update_ParameterAcc();
        //        }
        //        //        T5.compute_end();
        //        //        T6.compute_start();
        //        //Rprintf("A10\n");
        //        for(i=0;i< Clusters->nEmpty;i++)
        //        {
        //            //Rprintf("A10 %i\n",i);
        //
        //        }
    }
    
    
    
    //    void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_Marginal()
    //    {
    //        sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_Marginal(&Y);
    //    }
    
    void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_Marginal(int k)
    {
        //int i,j,h;
        //int K = Kmax;
        
        //int Kapp;
        
        //        //int nclust[K];
        //        double appMeanPar_P[nVars];
        //        //        double MeanPar_P[nVars*K];
        //        double CovPar_P[nVars*nVars*K];
        //        double nu_P[K];
        //
        //        Vector<double> appMeanPar(nVars,appMeanPar_P);
        //        Vector<double> nu(K,nu_P);
        //        //        vector <Vector<double> > MeanPar;
        //        vector <Matrix<double> > CovPar;
        //
        //        double omega_P[nVars];
        //        Vector <double> omega(nVars,omega_P);
        //
        //        double Xbeta_P[nVars];
        //        Vector<double>Xbeta (nVars,Xbeta_P);
        
        Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc,&CovMat[0][k].SigmaAccInv, &CovMat[0][k].PriorParameter->PsiAcc[0], CovMat[0][k].PriorParameter->nuAcc[0]);
        //Rprintf("S11\n");
        CovMat[0][k].compute_InvAccAndChol();
        
        //        //Rprintf("S1\n");
        //        for(k=0;k< Kmax;k++)
        //        {
        //            CovPar.push_back(Matrix<double>(nVars,nVars,CovPar_P[k*nVars*nVars]));
        //        }
        //        for(i=0;i< Clusters->nNonEmpty;i++)
        //        {
        //            k = Clusters->NonEmptyC.vec(i);
        //            CovPar[k].Init(0.0);
        //
        //            //nclust[k] = 0.0;
        //        }
        //
        //        //Rprintf("S2\n");
        //        for(i=0;i< Clusters->nNonEmpty;i++)
        //        {
        //            k = Clusters->NonEmptyC.vec(i);
        //            nu.Pvec(k)[0] = K-1+ CovMat[0][k].PriorParameter->nuAcc[0]+Clusters->NObsInClust.vec(k);
        //
        //            CovPar[k].Init(0.0);
        //            for(h=0;h<nVars;h++)
        //            {
        //                for(j=0;j<nVars;j++)
        //                {
        //                    CovPar[k].Pmat(h,j)[0] = CovMat[0][k].PriorParameter->PsiAcc[0].Pmat(h,j)[0];
        //                }
        //
        //            }
        //
        //        }
        //        //Rprintf("S3\n");
        //        for(i=0;i<nObs;i++)
        //        {
        //            // likelihood contribution
        //            k           = Clusters->Zeta.vec(i);
        //            omega.P     = Data->Pmat(i,0);
        //
        //            for(h=0;h<nVars;h++)
        //            {
        //                Xbeta.Pvec(h)[0] = 0.0;
        //                for(j = 0; j<Covariates->nCols;j++)
        //                {
        //                    Xbeta.Pvec(h)[0] += Covariates[0].mat(nVars*i+h,j)*VectorParam[0][k].VectorAcc.vec(j);
        //                }
        //            }
        //
        //            for(j=0;j<nVars;j++)
        //            {
        //                for(h=j;h<nVars;h++)
        //                {
        //                    CovPar[k].Pmat(j,h)[0] += (omega.vec(j)-Xbeta.vec(j))*(omega.vec(h)-Xbeta.vec(h));
        //                }
        //            }
        //        }
        //
        //        //Rprintf("%i\n ", Clusters->nNonEmpty);
        //        //        for(i=0;i< Clusters->nNonEmpty;i++)
        //        //        {
        //        //            Rprintf("%i  ", Clusters->NonEmptyC.vec(i));
        //        //        }
        //        //Rprintf("S4\n");
        //        for(i=0;i< Clusters->nNonEmpty;i++)
        //        {
        //
        //            k = Clusters->NonEmptyC.vec(i);
        //            Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc, &CovMat[0][k].SigmaAccInv, &CovPar[k], nu.Pvec(k)[0]);
        //
        //            CovMat[0][k].compute_InvAccAndChol();
        //        }
        //        //Rprintf("S5\n");
        //        for(i=0;i< Clusters->nEmpty;i++)
        //        {
        //            // Rprintf("S1 %i\n",i);
        //            k = Clusters->EmptyC.vec(i);
        //            //Rprintf("S1 %i %f\n",k,CovMat[0][k].PriorParameter->nuAcc[0]);
        //
        //            //CovMat[0][k].PriorParameter->PsiAcc->Print("Psi");
        //            Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc,&CovMat[0][k].SigmaAccInv, &CovMat[0][k].PriorParameter->PsiAcc[0], CovMat[0][k].PriorParameter->nuAcc[0]);
        //            //Rprintf("S11\n");
        //            CovMat[0][k].compute_InvAccAndChol();
        //            //Rprintf("S12\n");
        //        }
        // Rprintf("S6\n");
        
        
        
    }
    
    void samp_stMixtureDP_FixedK()
    {
        samp_stMixtureDP_CheckLastElementNocheck();
        Clusters->update_EmptyAndNonEmptyClusters();
    }
    void samp_stMixtureDP_CheckLastElement()
    {
        samp_stMixtureDP_CheckLastElementNocheck();
        if(Clusters->nNonEmpty>=(Kmax))
        {
            //Rprintf("error: Kmax occupied regimes -  approximation is not valid\n");
        }
        Clusters->update_EmptyAndNonEmptyClusters();
    }
	
	
	void samp_stMixtureDP_CheckLastElement(Class_Parameter *DPpar)
	{
		 samp_stMixtureDP_CheckLastElementNocheck(DPpar);
		 if(Clusters->nNonEmpty>=(Kmax))
		 {
			  //Rprintf("error: Kmax occupied regimes -  approximation is not valid\n");
		 }
		 Clusters->update_EmptyAndNonEmptyClusters();
	}
	void samp_stMixtureDP_CheckLastElementNocheck(Class_Parameter *DPpar)
	 {
		  //double u;
		  
		  vector< vector <int> > AppSamp;
		  //double sum;
		  int i,k;
		  double ret_P[Kmax];
		  Vector<double> ret(Kmax,ret_P);
		 
		 int veck_P[Kmax];
		 Vector<int> veck(Kmax,veck_P);
		 int vecNonk_P[Kmax];
		 Vector<int> vecNonk(Kmax,vecNonk_P);
		  
		  
		 int Noccupied = Clusters->nNonEmpty; 
		 int N_Nonoccupied; 
		  Vector<double> ObsY(nVars,Y.Pmat(0,0));
		 
		 //Clusters->NObsInClust.Print("nObs");
		  for(i=0;i<nObs;i++)
		  {
			  //REprintf("Obs %i Occ %i\n",i, Noccupied);
			  ObsY.P = Y.Pmat(i,0);
			  int doUpdate = 1;
			  int kobs = Clusters->Zeta.vec(i);
			  Clusters->NObsInClust.Pvec(kobs)[0]--;
			  if(Clusters->NObsInClust.vec(kobs)==0)
			  {
				  Noccupied--;
				  if(runif(0.0,1.0)< (1.0*Noccupied-1.0)/(1.0*Noccupied))
				  {
					  doUpdate = 0;
					  Noccupied++;
					  Clusters->NObsInClust.Pvec(kobs)[0]++;
				  }
				 
			  }
			  if(doUpdate!=0)
			  {
				  if(Noccupied==Kmax)
				  {
					  ret.nElem = Kmax;
					  for(int k=0;k<Kmax;k++)
					  {
							Likelihood->computeLogDensityForLike_WithoutNA(ret.Pvec(k),&ObsY, &Container[k], i);
							ret.Pvec(k)[0] += log(Clusters->NObsInClust.vec(k));
					  }
					  Clusters->Zeta.Pvec(i)[0] = Class_Utils::sample_DiscreteVar(ret.P, Kmax);
					  Clusters->NObsInClust.Pvec(Clusters->Zeta.vec(i))[0]++;
					
				  }else{
					  ret.nElem = Noccupied+1;
					  N_Nonoccupied = Kmax-Noccupied;
					  int hh = 0;
					  int gg = 0;
					  for(int k=0;k<Kmax;k++)
					  {
						  if(Clusters->NObsInClust.vec(k)>0)
						  {
							  Likelihood->computeLogDensityForLike_WithoutNA(ret.Pvec(hh),&ObsY, &Container[k], i);
							  ret.Pvec(hh)[0] += log(Clusters->NObsInClust.vec(k));
							  veck.Pvec(hh)[0] = k;
							  hh++;
						  }else{
							  vecNonk.Pvec(gg)[0] = k;
							  gg++;
						  }            
					  }
					  k = vecNonk.vec(Class_Utils::sample_DiscreteVarEqualProb(N_Nonoccupied));

					  Likelihood->computeLogDensityForLike_WithoutNA(ret.Pvec(hh),&ObsY, &Container[k], i);

					  ret.Pvec(hh)[0] += log(DPpar->ParameterAcc)-log( 1.0*(Noccupied+1) );
					  
					  veck.Pvec(hh)[0] = k;
					  
					  Clusters->Zeta.Pvec(i)[0] = veck.vec(Class_Utils::sample_DiscreteVar(ret.P, ret.nElem));
					  
					  Clusters->NObsInClust.Pvec(Clusters->Zeta.vec(i))[0]++;
					  
					  if(Clusters->NObsInClust.Pvec(Clusters->Zeta.vec(i))[0]==1)
					  {
						  Noccupied++;
					  }
					  
				  }
			  }
			      
		  }
		 //REprintf("END\n");
	 }
	
	
	void samp_stMixtureDP_CheckLastElement_Metropolis(Class_Parameter *DPpar)
	{
		 samp_stMixtureDP_CheckLastElementNocheck_Metropolis(DPpar);
		 if(Clusters->nNonEmpty>=(Kmax))
		 {
			  //Rprintf("error: Kmax occupied regimes -  approximation is not valid\n");
		 }
		 Clusters->update_EmptyAndNonEmptyClusters();
	}
	void samp_stMixtureDP_CheckLastElementNocheck_Metropolis(Class_Parameter *DPpar)
	 {
		  //double u;
		  
		 int Noccupied = Clusters->nNonEmpty; 
		 int N_Nonoccupied; 
		 
		 for(int i=0;i<nObs;i++)
		 {
			 Vector<double> ObsY(nVars,Y.Pmat(i,0));
			 
			 int vecNonk_P[Kmax];
			 Vector<int> vecNonk(Kmax,vecNonk_P);
			 
			 double MH = 0.0;
			 double ret;
			 int kacc  = Clusters->Zeta.vec(i);
			 int kprop;
			 
			 Clusters->NObsInClust.Pvec(kacc)[0]--;
			 if(Clusters->NObsInClust.vec(kacc)==0)
			 {
				 Noccupied--;
			 }
			 
			 int AppS = 0;
			 if(Noccupied==Kmax)
			 {
				 AppS  = 1;
			 }else{
				 if(runif(0.0, 1.0*(nObs-1)+DPpar->ParameterAcc )<1.0*(nObs-1))
				 {
					 AppS  = 1;
				 }else{
					 AppS  = 0;
				 }
			 }
			 if(AppS==1)
			 {
				 int kpropapp = Class_Utils::sample_DiscreteVarEqualProb(nObs-1);
				 if(kpropapp<i)
				 {
					 kprop = Clusters->Zeta.vec(kpropapp);
				 }else{
					 kprop = Clusters->Zeta.vec(kpropapp+1);
				 }
			 }else{
				 N_Nonoccupied = Kmax-Noccupied;
				 int gg = 0;
				 for(int k=0;k<Kmax;k++)
				 {
					 if(Clusters->NObsInClust.vec(k)==0)
					 {
						 vecNonk.Pvec(gg)[0] = k;
						 gg++;
					 }
				 }
				 kprop = vecNonk.vec(Class_Utils::sample_DiscreteVarEqualProb(N_Nonoccupied));
				 
				 
			 }
			 SampFromPrior(kprop);
			 Likelihood->computeLogDensityForLike_WithoutNA(&ret,&ObsY, &Container[kprop], i);
			 MH += ret;
			 Likelihood->computeLogDensityForLike_WithoutNA(&ret,&ObsY, &Container[kacc], i);
			 MH += -1.0*ret;
			 
			 if(runif(0.0,1.0)<exp(MH))
			 {
				 Clusters->Zeta.Pvec(i)[0] = kprop;
			 }
			 Clusters->NObsInClust.Pvec(Clusters->Zeta.Pvec(i)[0])[0]++;
			 if(Clusters->NObsInClust.Pvec(Clusters->Zeta.Pvec(i)[0])[0]==1)
			 {
				 Noccupied++;
			 }
		 }		 
	 }
	
	
	
	
	void samp_stMixtureDP_CheckLastElement_TEST(Class_Parameter *DPpar)
	{
		 samp_stMixtureDP_CheckLastElementNocheck_TEST(DPpar);
		 if(Clusters->nNonEmpty>=(Kmax))
		 {
			  Rprintf("error: Kmax occupied regimes -  approximation is not valid\n");
		 }
		 Clusters->update_EmptyAndNonEmptyClusters();
	}
	void samp_stMixtureDP_CheckLastElementNocheck_TEST(Class_Parameter *DPpar)
	 {
		  //double u;
		  
		  vector< vector <int> > AppSamp;
		  //double sum;
		  int i,k;
		  double ret_P[Kmax];
		  Vector<double> ret(Kmax,ret_P);
		 
		 int veck_P[Kmax];
		 Vector<int> veck(Kmax,veck_P);
		 int vecNonk_P[Kmax];
		 Vector<int> vecNonk(Kmax,vecNonk_P);
		  
		  
		 int Noccupied = Clusters->nNonEmpty; 
		 int N_Nonoccupied; 
		  Vector<double> ObsY(nVars,Y.Pmat(0,0));
		 
		 Y.Print("Y");
		  Clusters->NObsInClust.Print("nObs");
		  for(i=0;i<nObs;i++)
		  {
			  REprintf("Obs %i Occ %i\n",i, Noccupied);
			  ObsY.P = Y.Pmat(i,0);
			  ObsY.Print("ObsY");
			  int kobs = Clusters->Zeta.vec(i);
			  Clusters->NObsInClust.Pvec(kobs)[0]--;
			  if(Clusters->NObsInClust.vec(kobs)==0)
			  {
				  Noccupied--;
			  }
			  if(Noccupied==Kmax)
			  {
				  ret.nElem = Kmax;
				  veck.nElem = Kmax;
				  for(int k=0;k<Kmax;k++)
				  {
					  
						Likelihood->computeLogDensityForLike_WithoutNA(ret.Pvec(k),&ObsY, &Container[k], i);
						ret.Pvec(k)[0] += log(Clusters->NObsInClust.vec(k));
					  REprintf("%i  %f %f %f %i %f \n",k,ObsY.vec(0), Container[k].VectorCont->VectorAcc.vec(0),Container[k].PDmat[0].SigmaAcc.mat(0,0) ,Clusters->NObsInClust.vec(k),ret.Pvec(k)[0] );
				  }
				  Clusters->Zeta.Pvec(i)[0] = Class_Utils::sample_DiscreteVar(ret.P, Kmax);
				  Clusters->NObsInClust.Pvec(Clusters->Zeta.vec(i))[0]++;
				
			  }else{
				  ret.nElem = Noccupied+1;
				  veck.nElem = Noccupied+1;
				  N_Nonoccupied = Kmax-Noccupied;
				  int hh = 0;
				  int gg = 0;
				  for(int k=0;k<Kmax;k++)
				  {
					  if(Clusters->NObsInClust.vec(k)>0)
					  {
						  Likelihood->computeLogDensityForLike_WithoutNA(ret.Pvec(hh),&ObsY, &Container[k], i);
						  ret.Pvec(hh)[0] += log(Clusters->NObsInClust.vec(k));
						  REprintf("%i  %f %f %f %i %f \n",k,ObsY.vec(0), Container[k].VectorCont->VectorAcc.vec(0),Container[k].PDmat[0].SigmaAcc.mat(0,0) ,Clusters->NObsInClust.vec(k),ret.Pvec(hh)[0] );
						 
						  veck.Pvec(hh)[0] = k;
						  hh++;
					  }else{
						  vecNonk.Pvec(gg)[0] = k;
						  gg++;
					  }
				  }
				  k = vecNonk.vec(Class_Utils::sample_DiscreteVarEqualProb(N_Nonoccupied));

				  Likelihood->computeLogDensityForLike_WithoutNA(ret.Pvec(hh),&ObsY, &Container[k], i);

				  ret.Pvec(hh)[0] += log(DPpar->ParameterAcc);
				  
				  REprintf("%i  %f %f %f %i %f \n",k,ObsY.vec(0), Container[k].VectorCont->VectorAcc.vec(0),Container[k].PDmat[0].SigmaAcc.mat(0,0) ,Clusters->NObsInClust.vec(k),ret.Pvec(hh)[0] );
				  veck.Pvec(hh)[0] = k;
				  
				  
				  
				  Clusters->Zeta.Pvec(i)[0] = veck.vec(Class_Utils::sample_DiscreteVar(ret.P, ret.nElem));
				  
				  Clusters->NObsInClust.Pvec(Clusters->Zeta.vec(i))[0]++;
				  
				  if(Clusters->NObsInClust.Pvec(Clusters->Zeta.vec(i))[0]==1)
				  {
					  Noccupied++;
				  }
				  
			  }
			  veck.Print("vec");
			  ret.Print("ret");
			  REprintf("Acc = %i\n",Clusters->Zeta.Pvec(i)[0]);
			  
		  }
		 //REprintf("END\n");
	 }
	
//	void samp_stMixtureDP_CheckLastElement_TODELETE()
//	{
//		 samp_stMixtureDP_CheckLastElementNocheck_TODELETE();
//		 if(Clusters->nNonEmpty>=(Kmax))
//		 {
//			  Rprintf("error: Kmax occupied regimes -  approximation is not valid\n");
//		 }
//		 Clusters->update_EmptyAndNonEmptyClusters();
//	}
//	void samp_stMixtureDP_CheckLastElementNocheck_TODELETE()
//	{
//		 //double u;
//		 
//		 vector< vector <int> > AppSamp;
//		 //double sum;
//		 int i,k;
//		 double ret_P[Kmax];
//		 Vector<double> ret(Kmax,ret_P);
//		 
//		 
//		 
//		 Vector<double> ObsY(nVars,Y.Pmat(0,0));
//		 for(i=0;i<nObs;i++)
//		 {
//			 ObsY.P = Y.Pmat(i,0);
//			 //ObsY.Print("Obs");
//			  //REprintf("\n");
//			  for(int k=0;k<Kmax;k++)
//			  {
//					
//				  //Container[k].VectorCont[0].VectorAcc.Print("Mean");
//				  //Container[k].PDmat[0].SigmaAcc.Print("S");
//				  
//				  //Container[k].VectorCont[0].VectorAcc.Print();
//				  
//				  
//					Likelihood->computeLogDensityForLike_WithoutNA(ret.Pvec(k),&ObsY, &Container[k], i);
//				  //REprintf("%f %f",Clusters->Probs->ProbsAcc[0]->vec(k),ret.Pvec(k));
//					
//					ret.Pvec(k)[0] += log(Clusters->Probs->ProbsAcc[0]->vec(k));
//					
//			  }
//			  //
//			  
//			  Clusters->Zeta.Pvec(i)[0] = Class_Utils::sample_DiscreteVar(ret.P, Kmax);
//			// ret.Print("Prob");
//			 //REprintf("z=%i \n",Clusters->Zeta.Pvec(i)[0]);
//		 }
//		 
//		
//		//error("");
//		 
//	}
//	
    void samp_stMixtureDP_MergeTwoRegimes()
    {
        error("usare quello on il parametro");
        int k1 = 0;
        int k2 = 0;
        int k = 0;
        
        int ksamp;
        
        double prob[3];
        double *probMerge11 = &prob[0]
        ;
        double *probMerge22 =  &prob[1];
        double *probNoMerge =  &prob[2];
        double u;
        
        u = floor(runif(0.0,Clusters->nNonEmpty));
        k1 = Clusters->NonEmptyC.vec((int)u);
        
        u = floor(runif(0.0,Clusters->nNonEmpty));
        k2 = Clusters->NonEmptyC.vec((int)u);
        
        double app;
        int samp;
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
      
        probNoMerge[0] = 0.0;
        probMerge11[0] = 0.0;
        probMerge22[0] = 0.0;
        for(int i=0;i<nObs;i++)
        {
            k = Clusters->Zeta.vec(i);
            if((k==k1)||(k==k2))
            {
                ObsY.P = Y.Pmat(i,0);
                
                Likelihood->computeLogDensityForLike_WithoutNA(&app,&ObsY, &Container[k], i);
                //probNoMerge[0] += app+log(Clusters->Probs->ProbsAcc[0]->vec(k));
              probNoMerge[0] += app;
                
                Likelihood->computeLogDensityForLike_WithoutNA(&app,&ObsY, &Container[k1], i);
                //probMerge11[0] += app+log(Clusters->Probs->ProbsAcc[0]->vec(k1));
              probMerge11[0] += app; 
              
                Likelihood->computeLogDensityForLike_WithoutNA(&app,&ObsY, &Container[k2], i);
                //probMerge22[0] += app+log(Clusters->Probs->ProbsAcc[0]->vec(k2));
              probMerge22[0] += app;
            }
        }
      probNoMerge[0] += log(Clusters->NObsInClust.vec(k1))+log(Clusters->NObsInClust.vec(k2));
      probMerge11[0] += log(Clusters->NObsInClust.vec(k1)+ Clusters->NObsInClust.vec(k2));
      probMerge22[0] += log(Clusters->NObsInClust.vec(k1)+ Clusters->NObsInClust.vec(k2));
      samp = Class_Utils::sample_DiscreteVar(prob,3 );
      //REprintf("%f %f %f %i %i %i\n",prob[0],prob[1],prob[2],samp, k1,k2);
        if(samp==0)
        {
            for(int i=0;i<nObs;i++)
            {
                k = Clusters->Zeta.vec(i);
                if(k==k2)
                {
                    Clusters->Zeta.Pvec(i)[0] = k1;
                }
            }
        }
        if(samp==1)
        {
            for(int i=0;i<nObs;i++)
            {
                k = Clusters->Zeta.vec(i);
                if(k==k1)
                {
                    Clusters->Zeta.Pvec(i)[0] = k2;
                }
            }
        }
        if(samp==2)
        {
            
        }
        Clusters->update_EmptyAndNonEmptyClusters();
    }
  
	void samp_stMixtureDP_MergeTwoRegimes(Class_Parameter *DPpar)
	{
		 
		 int k1 = 0;
		 int k2 = 0;
		 int k = 0;
		 
		 int ksamp;
		 
		 double prob[3];
		 double *probMerge11 = &prob[0]
		 ;
		 double *probMerge22 =  &prob[1];
		 double *probNoMerge =  &prob[2];
		 double u;
		 
		 u = floor(runif(0.0,Clusters->nNonEmpty));
		 k1 = Clusters->NonEmptyC.vec((int)u);
		 
		 u = floor(runif(0.0,Clusters->nNonEmpty));
		 k2 = Clusters->NonEmptyC.vec((int)u);
		 
		 double app;
		 int samp;
		 
		 Vector<double> ObsY(nVars,Y.Pmat(0,0));
	  
		 probNoMerge[0] = 0.0;
		 probMerge11[0] = 0.0;
		 probMerge22[0] = 0.0;
		 for(int i=0;i<nObs;i++)
		 {
			  k = Clusters->Zeta.vec(i);
			  if((k==k1)||(k==k2))
			  {
					ObsY.P = Y.Pmat(i,0);
					
					Likelihood->computeLogDensityForLike_WithoutNA(&app,&ObsY, &Container[k], i);
					//probNoMerge[0] += app+log(Clusters->Probs->ProbsAcc[0]->vec(k));
				 probNoMerge[0] += app;
					
					Likelihood->computeLogDensityForLike_WithoutNA(&app,&ObsY, &Container[k1], i);
					//probMerge11[0] += app+log(Clusters->Probs->ProbsAcc[0]->vec(k1));
				 probMerge11[0] += app; 
				 
					Likelihood->computeLogDensityForLike_WithoutNA(&app,&ObsY, &Container[k2], i);
					//probMerge22[0] += app+log(Clusters->Probs->ProbsAcc[0]->vec(k2));
				 probMerge22[0] += app;
			  }
		 }
	  probNoMerge[0] += lgammafn(Clusters->NObsInClust.vec(k1))+ lgammafn(Clusters->NObsInClust.vec(k2))+log(DPpar->ParameterAcc);
	  probMerge11[0] += lgammafn(Clusters->NObsInClust.vec(k1)+ Clusters->NObsInClust.vec(k2));
	  probMerge22[0] += lgammafn(Clusters->NObsInClust.vec(k1)+ Clusters->NObsInClust.vec(k2));
	  samp = Class_Utils::sample_DiscreteVar(prob,3 );
	  //REprintf("%f %f %f %i %i %i\n",prob[0],prob[1],prob[2],samp, k1,k2);
		 if(samp==0)
		 {
			  for(int i=0;i<nObs;i++)
			  {
					k = Clusters->Zeta.vec(i);
					if(k==k2)
					{
						 Clusters->Zeta.Pvec(i)[0] = k1;
					}
			  }
		 }
		 if(samp==1)
		 {
			  for(int i=0;i<nObs;i++)
			  {
					k = Clusters->Zeta.vec(i);
					if(k==k1)
					{
						 Clusters->Zeta.Pvec(i)[0] = k2;
					}
			  }
		 }
		 if(samp==2)
		 {
			  
		 }
		 Clusters->update_EmptyAndNonEmptyClusters();
	}
  
  
  void samp_stMixtureDP_SplitTwoRegimes()
  {
	  error("sbagliato, usare l'altro");
    //REprintf("Split");
      int k1 = 0;
      int k2 = 0;
      int k = 0;
      
      
      double prob[3] = {0.0};
      double *probSplit12 = &prob[0];
      double *probSplit21 =  &prob[1];
      double *probNoSplit =  &prob[2];
      double u;
      if(Clusters->nEmpty>0)
      {
        
        
        
        u = floor(runif(0.0,Clusters->nNonEmpty));
        k1 = Clusters->NonEmptyC.vec((int)u);
        
        k2 = Clusters->EmptyC.vec(0);
        
        
        int nk1 = 0;
        int nk2 = 0;
        int Indexk1_P[Clusters->NObsInClust.vec(k1)];
        Vector<int>Indexk1(Clusters->NObsInClust.vec(k1),Indexk1_P);
        int Indexk2_P[Clusters->NObsInClust.vec(k1)];
        Vector<int>Indexk2(Clusters->NObsInClust.vec(k1),Indexk2_P);
        
        double app;
        int samp;
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
      
        probSplit12[0] = 0.0;
        probSplit21[0] = 0.0;
        probNoSplit[0] = 0.0;
        double probu = runif(0.0,1.0);
        for(int i=0;i<nObs;i++)
        {
            k = Clusters->Zeta.vec(i);
            if(k==k1)
            {
              ObsY.P = Y.Pmat(i,0);  
              
              Likelihood->computeLogDensityForLike_WithoutNA(&app,&ObsY, &Container[k], i);
              probNoSplit[0] += app;
             // REprintf("%i %f ",i, app);
              if(runif(0.0,1.0)<probu)
              {
                Likelihood->computeLogDensityForLike_WithoutNA(&app,&ObsY, &Container[k1], i);
                probSplit12[0] += app;
               // REprintf("%f ", app);
                
                
                Indexk2.Pvec(nk2)[0] = i;
                nk2++;
                Likelihood->computeLogDensityForLike_WithoutNA(&app,&ObsY, &Container[k2], i);
                probSplit21[0] += app;
               // REprintf("%f ", app);
              }else{
                Indexk1.Pvec(nk1)[0] = i;
                nk1++;
                Likelihood->computeLogDensityForLike_WithoutNA(&app,&ObsY, &Container[k2], i);
                probSplit12[0] += app;
               // REprintf("%f ", app);
                
                Likelihood->computeLogDensityForLike_WithoutNA(&app,&ObsY, &Container[k1], i);
                probSplit21[0] += app;
                //REprintf("%f ", app);
                
              }
              //REprintf("%f %f %f %f %f %f \n",probNoSplit[0], probSplit12[0],probSplit21[0],Clusters->Probs->ProbsAcc[0]->vec(k),Clusters->Probs->ProbsAcc[0]->vec(k1),Clusters->Probs->ProbsAcc[0]->vec(k2) );
                
            }
        }
        probSplit12[0] += lgammafn(nk1)+lgammafn(nk2);
        probSplit21[0] += lgammafn(nk1)+lgammafn(nk2);
        probNoSplit[0] += lgammafn(nk1+nk2);
        samp = Class_Utils::sample_DiscreteVar(prob,3 );
        //REprintf("%f %f %f %i %i %i\n",prob[0],prob[1],prob[2],samp, k1,k2);
        if(samp==0)
        {
            for(int i=0;i<nk1;i++)
            {
                Clusters->Zeta.Pvec(Indexk1.vec(i))[0] = k2;
            }
        }
        if(samp==1)
        {
            for(int i=0;i<nk2;i++)
            {
                Clusters->Zeta.Pvec(Indexk2.vec(i))[0] = k2;
            }
        }
        if(samp==2)
        {
            
        }
        Clusters->update_EmptyAndNonEmptyClusters();
      }
      
  }
    
    
	void samp_stMixtureDP_SplitTwoRegimes(Class_Parameter *DPpar)
	{
	  //REprintf("Split");
		 int k1 = 0;
		 int k2 = 0;
		 int k = 0;
		 
		 
		 double prob[3] = {0.0};
		 double *probSplit12 = &prob[0];
		 double *probSplit21 =  &prob[1];
		 double *probNoSplit =  &prob[2];
		 double u;
		 if(Clusters->nEmpty>0)
		 {
			
			
			
			u = floor(runif(0.0,Clusters->nNonEmpty));
			k1 = Clusters->NonEmptyC.vec((int)u);
			
			k2 = Clusters->EmptyC.vec(0);
			
			
			int nk1 = 0;
			int nk2 = 0;
			int Indexk1_P[Clusters->NObsInClust.vec(k1)];
			Vector<int>Indexk1(Clusters->NObsInClust.vec(k1),Indexk1_P);
			int Indexk2_P[Clusters->NObsInClust.vec(k1)];
			Vector<int>Indexk2(Clusters->NObsInClust.vec(k1),Indexk2_P);
			
			double app;
			int samp;
			
			Vector<double> ObsY(nVars,Y.Pmat(0,0));
		 
			probSplit12[0] = 0.0;
			probSplit21[0] = 0.0;
			probNoSplit[0] = 0.0;
			double probu = runif(0.0,1.0);
			for(int i=0;i<nObs;i++)
			{
				 k = Clusters->Zeta.vec(i);
				 if(k==k1)
				 {
					ObsY.P = Y.Pmat(i,0);  
					
					Likelihood->computeLogDensityForLike_WithoutNA(&app,&ObsY, &Container[k], i);
					probNoSplit[0] += app;
				  // REprintf("%i %f ",i, app);
					if(runif(0.0,1.0)<probu)
					{
					  Likelihood->computeLogDensityForLike_WithoutNA(&app,&ObsY, &Container[k1], i);
					  probSplit12[0] += app;
					 // REprintf("%f ", app);
					  
					  
					  Indexk2.Pvec(nk2)[0] = i;
					  nk2++;
					  Likelihood->computeLogDensityForLike_WithoutNA(&app,&ObsY, &Container[k2], i);
					  probSplit21[0] += app;
					 // REprintf("%f ", app);
					}else{
					  Indexk1.Pvec(nk1)[0] = i;
					  nk1++;
					  Likelihood->computeLogDensityForLike_WithoutNA(&app,&ObsY, &Container[k2], i);
					  probSplit12[0] += app;
					 // REprintf("%f ", app);
					  
					  Likelihood->computeLogDensityForLike_WithoutNA(&app,&ObsY, &Container[k1], i);
					  probSplit21[0] += app;
					  //REprintf("%f ", app);
					  
					}
					//REprintf("%f %f %f %f %f %f \n",probNoSplit[0], probSplit12[0],probSplit21[0],Clusters->Probs->ProbsAcc[0]->vec(k),Clusters->Probs->ProbsAcc[0]->vec(k1),Clusters->Probs->ProbsAcc[0]->vec(k2) );
					  
				 }
			}
			probSplit12[0] += lgammafn(nk1)+lgammafn(nk2) + log(DPpar->ParameterAcc);
			probSplit21[0] += lgammafn(nk1)+lgammafn(nk2)+ log(DPpar->ParameterAcc);
			probNoSplit[0] += lgammafn(nk1+nk2);
			samp = Class_Utils::sample_DiscreteVar(prob,3 );
			//REprintf("%f %f %f %i %i %i\n",prob[0],prob[1],prob[2],samp, k1,k2);
			if(samp==0)
			{
				 for(int i=0;i<nk1;i++)
				 {
					  Clusters->Zeta.Pvec(Indexk1.vec(i))[0] = k2;
				 }
			}
			if(samp==1)
			{
				 for(int i=0;i<nk2;i++)
				 {
					  Clusters->Zeta.Pvec(Indexk2.vec(i))[0] = k2;
				 }
			}
			if(samp==2)
			{
				 
			}
			Clusters->update_EmptyAndNonEmptyClusters();
		 }
		 
	}
    
    
    void samp_stMixtureDP_CheckLastElementNocheck()
    {
        //double u;
        
        vector< vector <int> > AppSamp;
        //double sum;
        int i,k;
        double ret_P[Kmax];
        Vector<double> ret(Kmax,ret_P);
        
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        for(i=0;i<nObs;i++)
        {
			  ObsY.P = Y.Pmat(i,0);
            //REprintf("\n");
            for(int k=0;k<Kmax;k++)
            {
                
                Likelihood->computeLogDensityForLike_WithoutNA(ret.Pvec(k),&ObsY, &Container[k], i);
                
                
                ret.Pvec(k)[0] += log(Clusters->Probs->ProbsAcc[0]->vec(k));
                
            }
            //
            
            Clusters->Zeta.Pvec(i)[0] = Class_Utils::sample_DiscreteVar(ret.P, Kmax);
//			  for(int hh=0;hh<Kmax;hh++)
//			  {
//				  REprintf("%i %f %i\n",hh,ret.vec(hh),Clusters->Zeta.Pvec(i)[0]);
//			  }
			  
        }
        //error("");
        
        
        
        
    }
    void samp_stMixtureDP_CheckLastElementNocheck_BeamSampler()
    {
        error("NOn capisco perchè non funziona");
        //double u;
        
        vector< vector <int> > AppSamp;
        //double sum;
        int i,k;
        double ret_P[Kmax];
        Vector<double> ret(Kmax,ret_P);
        
        
        for(i=0;i<nObs;i++)
        {
            AppSamp.push_back(vector<int>());
            k = Clusters->Zeta.vec(i);
            double u = runif(0.0,Clusters->Probs->ProbsAcc[0]->vec(k));
            
            double sum = 1.0;
            
            k=0;
            do{
                if(Clusters->Probs->ProbsAcc[0]->vec(k)>=u)
                {
                    AppSamp[i].push_back(k);
                    //Rprintf("%i %i \n", i, k);
                }
                sum -= Clusters->Probs->ProbsAcc[0]->vec(k);
                k++;
            }while((sum>u)&(k<Kmax));
            //Clusters->Probs->ProbsAcc[0]->Print("Prob");
            //Rprintf("%i %i %f\n",(int)AppSamp[i].size(),AppSamp[i].size(),u);
        }
        //Clusters->Probs->ProbsAcc[0]->Print("ProbVec");
        //Rprintf("END");
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        for(i=0;i<nObs;i++)
        {
            //REprintf("\n");
            for(int j=0;j<AppSamp[i].size();j++)
            {
                k = AppSamp[i][j];
                ObsY.P = Y.Pmat(i,0);
                Likelihood->computeLogDensityForLike_WithoutNA(ret.Pvec(j),&ObsY, &Container[k], i);
                
                
                ret.Pvec(j)[0] += log(Clusters->Probs->ProbsAcc[0]->vec(k));
                
                //REprintf("%f %f \n",ret.Pvec(j),log(Clusters->Probs->ProbsAcc[0]->vec(k)));
            }
            //
            
            Clusters->Zeta.Pvec(i)[0] = AppSamp[i][Class_Utils::sample_DiscreteVar(ret.P, (int)AppSamp[i].size()) ];
            //REprintf("samp %i \n",Clusters->Zeta.Pvec(i)[0]);
        }
        //error("");
        
        
        
        
    }
    
    //    void samp_stChangePointDPMargPi_CheckLastElement(Class_Parameter *eta)
    //    {
    //        double u;
    //        double v;
    //        int i;
    //
    //        int k;
    //        int kNew;
    //        int kPrev;
    //        int kFol;
    //
    //        double ProbNew;
    //        double ProbPrev;
    //        double ProbFol;
    //        double Probk;
    //
    //        Vector<double> ObsY(nVars,Y.Pmat(0,0));
    //
    //        double LikePar;
    //        u = runif(0.0,3.0);
    //        v = runif(0.0,1.0);
    //
    //
    //        if(u<1.0)
    //        {
    //            // univariate update
    //            if(v<0.5)
    //            {
    //                i = 0;
    //                k           = Clusters->Zeta.vec(i);
    //                kNew        = Clusters->EmptyC.vec(Clusters->nNonEmpty-1);
    //                //kPrev     = 0;
    //                kFol        = Clusters->Zeta.vec(i+1);
    //
    //                ProbUnc     =
    //                ProbNew = ;
    //                ProbPrev;
    //                ProbFol;
    //
    //
    //
    //
    //                i = nObs-1;
    //                ObsY.P = Y.Pmat(i,0);
    //                for(k=0;k<KProp;k++)
    //                {
    //                    Likelihood->computeLogDensityForLike(VecLike.Pvec(k),&ObsY, &Container[k], i);
    //                }
    //            }else{
    //
    //            }
    //        }
    //        if(u>=3.0)
    //        {
    //            // split
    //        }
    //        if((u>=1.0)&(u<2))
    //        {
    //            // merge
    //        }
    //
    //    }
    
    
    
    void samp_stChangePointDP_CheckLastElement(Class_Parameter *eta)
    {
        
        double ProbPropGivenAcc = 0.0;
        double ProbAccGivenProp = 0.0;
        int KAcc = 1;
        int KProp = 1;
        int kprop;
        int KmaxInt;
        
        
        double u;
        
        u = runif(0.0,1.0);
        KAcc = Clusters->nNonEmpty;
        if(KAcc!=1)
        {
            if(u<1.0/3.0)
            {
                KProp = KAcc-1;
            }else{
                if(u>2.0/3.0)
                {
                    KProp = KAcc+1;
                }else{
                    KProp = KAcc;
                    //KUnchanged = 1;
                }
            }
        }else{
            if(u<1.0/2.0)
            {
                KProp = 1;
            }else{
                KProp = 2;
            }
        }
        
        //        int NObsInClustProp_P[KProp];
        //        Vector<int> NObsInClustProp(KProp,NObsInClustProp_P);
        //        NObsInClustProp.Init(0);
        
        if(KAcc==1)
        {
            if(KProp==1)
            {
                ProbPropGivenAcc = 1.0/2.0;
                ProbAccGivenProp = 1.0/2.0;
            }
            if(KProp!=1)
            {
                ProbPropGivenAcc = 1.0/2.0;
                ProbAccGivenProp = 1.0/3.0;
            }
        }
        if(KAcc!=1)
        {
            if(KProp==1)
            {
                ProbPropGivenAcc = 1.0/3.0;
                ProbAccGivenProp = 1.0/2.0;
            }
            if(KProp!=1)
            {
                ProbPropGivenAcc = 1.0/3.0;
                ProbAccGivenProp = 1.0/3.0;
            }
        }
        
        
        
        
        KmaxInt = max(KAcc, KProp);
        
        double Molt = 100;
        int k,i, kprec;
        double SumLog, MHratio;
        //double SumLogProp,SumLogAcc;
        
        
        double logPstProp_P[KmaxInt*nObs];
        Matrix <double> logPstProp(nObs,KmaxInt,logPstProp_P);
        logPstProp.Init(0.0);
        
        double Sampst_P[2];
        Vector <double> Sampst(2,Sampst_P);
        
        double applogPstProp_P[2];
        Vector <double> applogPstProp(2,applogPstProp_P);
        applogPstProp.Init(0.0);
        
        double VecLike_P[KmaxInt];
        Vector<double> VecLike(KmaxInt,VecLike_P);
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        
        double logMatCPProb_P[KmaxInt*KmaxInt];
        Matrix <double> logMatCPProb(KmaxInt,KmaxInt,logMatCPProb_P);
        logMatCPProb.Init(0.0);
        for(k=0;k<KmaxInt;k++)
        {
            logMatCPProb.Pmat(k,k)[0] = log(Molt*Clusters->Probs->ProbsAcc[0]->vec(k));
            logMatCPProb.Pmat(k,k)[0] = log(Molt-Molt*Clusters->Probs->ProbsAcc[0]->vec(k));
            
        }
        
        logPstProp.Pmat(0,0)[0] = 0.0;
        //Rprintf("CCww \n");
        
        for(i=1;i<KmaxInt;i++)
        {
            k = 0;
            kprec = 0;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
            for(k=1;k<i;k++)
            {
                kprec = k-1;
                applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                //Rprintf("AAA %f %f %f  \n", applogPstProp.Pvec(0)[0],logMatCPProb.mat(kprec,k),logPstProp.mat(i-1,kprec) );
                kprec = k;
                applogPstProp.Pvec(1)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                //Rprintf("AAA %f %f %f \n", applogPstProp.Pvec(1)[0],logMatCPProb.mat(kprec,k),logPstProp.mat(i-1,kprec) );
                
                
                
                Class_Utils::log_sum_exp(logPstProp.Pmat(i,k), 2, applogPstProp.Pvec(0));
                //Rprintf("%f dd\n",logPstProp.Pmat(i,k)[0]);
                //log_sum_exp(double *ret, int k, double *logx)
            }
            k = i;
            kprec = k-1;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
            //Rprintf("%f \n",logPstProp.Pmat(i,k)[0]);
            
            
            ObsY.P = Y.Pmat(i,0);
            for(k=0;k<=i;k++)
            {
                Likelihood->computeLogDensityForLike(VecLike.Pvec(k),&ObsY, &Container[k], i);
            }
            for(k=0;k<=i;k++)
            {
                logPstProp.Pmat(i,k)[0] += VecLike.vec(k);
            }
            Class_Utils::log_sum_exp(&SumLog, i+1, logPstProp.Pmat(i,0));
            //log_sum_exp(double *ret, int k, double *logx)
            for(k=0;k<=i;k++)
            {
                logPstProp.Pmat(i,k)[0] = logPstProp.Pmat(i,k)[0]-SumLog;
            }
            //Rprintf("\n");
        }
        //Rprintf("CC \n");
        
        
        
        for(i=KmaxInt;i<nObs-1;i++)
        {
            
            k = 0;
            kprec = 0;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
            
            for(k=1;k<KmaxInt;k++)
            {
                kprec = k-1;
                applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                kprec = k;
                applogPstProp.Pvec(1)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                Class_Utils::log_sum_exp(logPstProp.Pmat(i,k), 2, applogPstProp.Pvec(0));
                
            }
            ObsY.P = Y.Pmat(i,0);
            for(k=0;k<KmaxInt;k++)
            {
                Likelihood->computeLogDensityForLike(VecLike.Pvec(k),&ObsY, &Container[k], i);
            }
            for(k=0;k<KmaxInt;k++)
            {
                logPstProp.Pmat(i,k)[0] += VecLike.vec(k);
            }
            Class_Utils::log_sum_exp(&SumLog, KmaxInt, logPstProp.Pmat(i,0));
            for(k=0;k<KmaxInt;k++)
            {
                logPstProp.Pmat(i,k)[0] = logPstProp.Pmat(i,k)[0]-SumLog;
            }
            
        }
        
        i=nObs-1;
        k = 0;
        kprec = 0;
        applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
        logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
        
        for(k=1;k<KmaxInt;k++)
        {
            kprec = k-1;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            kprec = k;
            applogPstProp.Pvec(1)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            Class_Utils::log_sum_exp(logPstProp.Pmat(i,k), 2, applogPstProp.Pvec(0));
            
        }
        ObsY.P = Y.Pmat(i,0);
        for(k=0;k<KmaxInt;k++)
        {
            Likelihood->computeLogDensityForLike(VecLike.Pvec(k),&ObsY, &Container[k], i);
        }
        for(k=0;k<KmaxInt;k++)
        {
            logPstProp.Pmat(i,k)[0] += VecLike.vec(k);
        }
        
        
        // sample
        i = nObs-1;
        
        kprop = (int)runif(0.0,KProp);
        
        MHratio = 0.0;
        MHratio += log(ProbAccGivenProp)-1.0*log(ProbPropGivenAcc);
        MHratio += log(KProp)-1.0*log(KAcc);
        MHratio += logPstProp.mat(i,kprop)-1.0*(logPstProp.mat(i,KAcc-1));
        
        Rprintf("%i %i %i %f \n", KProp,KAcc,kprop, MHratio);
        u = runif(0.0,1.0);
        if(u<exp(MHratio))
        {
            Clusters->Zeta.Pvec(i)[0] = kprop;
        }
        
        
        
        for(i=nObs-2;i>=max(KmaxInt-1,0);i--)
        {
            
            if(Clusters->Zeta.vec(i+1)!=0)
            {
                k = Clusters->Zeta.vec(i+1)-1;
                Sampst.Pvec(0)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                
                k = Clusters->Zeta.vec(i+1);
                Sampst.Pvec(1)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                
                Clusters->Zeta.Pvec(i)[0] = Class_Utils::sample_DiscreteVar(Sampst.Pvec(0), 2)+Clusters->Zeta.vec(i+1)-1;
            }else{
                Clusters->Zeta.Pvec(i)[0] = 0;
            }
            
        }
        for(i=max(KmaxInt-2,0);i>=0;i--)
        {
            if(Clusters->Zeta.vec(i+1)==(i+1))
            {
                Clusters->Zeta.Pvec(i)[0] = i;
            }else{
                if(Clusters->Zeta.vec(i+1)!=0)
                {
                    k = Clusters->Zeta.vec(i+1)-1;
                    Sampst.Pvec(0)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                    
                    k = Clusters->Zeta.vec(i+1);
                    Sampst.Pvec(1)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                    
                    Clusters->Zeta.Pvec(i)[0] = Class_Utils::sample_DiscreteVar(Sampst.Pvec(0), 2)+Clusters->Zeta.vec(i+1)-1;
                }else{
                    Clusters->Zeta.Pvec(i)[0] = 0;
                }
            }
        }
        Clusters->update_EmptyAndNonEmptyClusters();
        
        if(Clusters->Zeta.vec(i)==Kmax)
        {
            error("\n\n s_T = Kmax - CP approximation may be no more valid\n\n");
        }
        
    }
    
    
    
    
    
    
    
    
    void samp_stChangePointDPNotSequentialstFixedK_CheckLastElement(Class_Parameter *eta)
    {
        //error("USARE LA FUNZIONE SENZA ARGOMENTO");
        
        
        double Molt = 1.0;
        int k,i, kprec;
        double SumLog;
        
        int Kobs;
        
        
        
        double Sampst_P[2];
        Vector <double> Sampst(2,Sampst_P);
        
        double applogPstProp_P[2];
        Vector <double> applogPstProp(2,applogPstProp_P);
        applogPstProp.Init(0.0);
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        //        int ClusterIndex_P[Kmax];
        //        Vector <int> ClusterIndex(Kmax,ClusterIndex_P);
        //
        
        Kobs = Clusters->nNonEmpty;
        
        
        //        for(k=0;k<Clusters->nNonEmpty;k++)
        //        {
        //            ClusterIndex.Pvec(k)[0] = Clusters->NonEmptyC.vec(k);
        //        }
        
        //        k = 0;
        //        ClusterIndex.Pvec(0)[0] = Clusters->Zeta.vec(0);
        //        for(i=1;i<nObs;i++)
        //        {
        //            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
        //            {
        //                k++;
        //                ClusterIndex.Pvec(k)[0] = Clusters->Zeta.vec(i);
        //            }
        //        }
        //
        
        double logPstProp_P[Kobs*nObs];
        Matrix <double> logPstProp(nObs,Kobs,logPstProp_P);
        logPstProp.Init(0.0);
        
        double logMatCPProb_P[Kobs*Kobs];
        Matrix <double> logMatCPProb(Kobs,Kobs,logMatCPProb_P);
        
        double VecLike_P[Kobs];
        Vector<double> VecLike(Kobs,VecLike_P);
        
        logMatCPProb.Init(0.0);
        for(k=0;k<Kobs-1;k++)
        {
            //k = ClusterIndex.vec(k);
            logMatCPProb.Pmat(k,k)[0] = log(Molt*Clusters->Probs->ProbsAcc[0]->vec(Clusters->NonEmptyC.vec(k)));
            logMatCPProb.Pmat(k,k+1)[0] = log(Molt-Molt*Clusters->Probs->ProbsAcc[0]->vec(Clusters->NonEmptyC.vec(k)));
            //logMatCPProb.Pmat(k,k)[0] = 0.0;
        }
        logMatCPProb.Pmat(Kobs-1,Kobs-1)[0] = 0.0;
        
        logPstProp.Pmat(0,0)[0] = 0.0;
        //Rprintf("CCww \n");
        for(i=1;i<Kobs;i++)
        {
            k = 0;
            kprec = 0;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
            for(k=1;k<i;k++)
            {
                kprec = k-1;
                applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                //Rprintf("AAA %f %f %f  \n", applogPstProp.Pvec(0)[0],logMatCPProb.mat(kprec,k),logPstProp.mat(i-1,kprec) );
                kprec = k;
                applogPstProp.Pvec(1)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                //Rprintf("AAA %f %f %f \n", applogPstProp.Pvec(1)[0],logMatCPProb.mat(kprec,k),logPstProp.mat(i-1,kprec) );
                
                
                
                Class_Utils::log_sum_exp(logPstProp.Pmat(i,k), 2, applogPstProp.Pvec(0));
                //Rprintf("%f dd\n",logPstProp.Pmat(i,k)[0]);
                //log_sum_exp(double *ret, int k, double *logx)
            }
            k = i;
            kprec = k-1;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
            //Rprintf("%f \n",logPstProp.Pmat(i,k)[0]);
            
            
            ObsY.P = Y.Pmat(i,0);
            for(k=0;k<=i;k++)
            {
                Likelihood->computeLogDensityForLike_WithoutNA(VecLike.Pvec(k),&ObsY, &Container[Clusters->NonEmptyC.vec(k)], i);
            }
            for(k=0;k<=i;k++)
            {
                logPstProp.Pmat(i,k)[0] += VecLike.vec(k);
            }
            Class_Utils::log_sum_exp(&SumLog, i+1, logPstProp.Pmat(i,0));
            //log_sum_exp(double *ret, int k, double *logx)
            for(k=0;k<=i;k++)
            {
                logPstProp.Pmat(i,k)[0] = logPstProp.Pmat(i,k)[0]-SumLog;
            }
            //Rprintf("\n");
        }
        //Rprintf("CC \n");
        
        
        for(i=Kobs;i<nObs;i++)
        {
            
            k = 0;
            kprec = 0;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
            
            for(k=1;k<Kobs;k++)
            {
                kprec = k-1;
                applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                kprec = k;
                applogPstProp.Pvec(1)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                Class_Utils::log_sum_exp(logPstProp.Pmat(i,k), 2, applogPstProp.Pvec(0));
                
            }
            ObsY.P = Y.Pmat(i,0);
            for(k=0;k<Kobs;k++)
            {
                Likelihood->computeLogDensityForLike_WithoutNA(VecLike.Pvec(k),&ObsY, &Container[Clusters->NonEmptyC.vec(k)], i);
            }
            for(k=0;k<Kobs;k++)
            {
                logPstProp.Pmat(i,k)[0] += VecLike.vec(k);
            }
            Class_Utils::log_sum_exp(&SumLog, Kobs, logPstProp.Pmat(i,0));
            for(k=0;k<Kobs;k++)
            {
                logPstProp.Pmat(i,k)[0] = logPstProp.Pmat(i,k)[0]-SumLog;
            }
            
        }
        
        
        //        for(i=0;i<logPstProp.nRows;i++)
        //        {
        //            for(k=0;k<logPstProp.nCols;k++)
        //            {
        //                Rprintf("%f ", exp(logPstProp.mat(i,k)));
        //            }
        //            Rprintf("\n");
        //        }
        
        // sample
        i = nObs-1;
        Clusters->Zeta.Pvec(i)[0] = Kobs-1;
        
        
        for(i=nObs-2;i>=max(Kobs-1,0);i--)
        {
            
            if(Clusters->Zeta.vec(i+1)!=0)
            {
                k = Clusters->Zeta.vec(i+1)-1;
                Sampst.Pvec(0)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                
                k = Clusters->Zeta.vec(i+1);
                Sampst.Pvec(1)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                
                Clusters->Zeta.Pvec(i)[0] = Class_Utils::sample_DiscreteVar(Sampst.Pvec(0), 2)+Clusters->Zeta.vec(i+1)-1;
            }else{
                Clusters->Zeta.Pvec(i)[0] = 0;
            }
            
        }
        for(i=max(Kobs-2,0);i>=0;i--)
        {
            if(Clusters->Zeta.vec(i+1)==(i+1))
            {
                Clusters->Zeta.Pvec(i)[0] = i;
            }else{
                if(Clusters->Zeta.vec(i+1)!=0)
                {
                    k = Clusters->Zeta.vec(i+1)-1;
                    Sampst.Pvec(0)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                    
                    k = Clusters->Zeta.vec(i+1);
                    Sampst.Pvec(1)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                    
                    Clusters->Zeta.Pvec(i)[0] = Class_Utils::sample_DiscreteVar(Sampst.Pvec(0), 2)+Clusters->Zeta.vec(i+1)-1;
                }else{
                    Clusters->Zeta.Pvec(i)[0] = 0;
                }
            }
        }
        
        
        for(i=0;i<nObs;i++)
        {
            Clusters->Zeta.Pvec(i)[0] = Clusters->NonEmptyC.vec(Clusters->Zeta.Pvec(i)[0]);
        }
        //Clusters->Zeta.Print("Zeta");
        Clusters->update_EmptyAndNonEmptyClusters();
        //error("SS");
        //        if(Clusters->nNonEmpty<=0)
        //        {
        //            Rprintf("\n\n s_T = Kmax - CP approximation may be no more valid\n\n");
        //        }
        //
    }
    
    
    void samp_stChangePointDPNotSequentialstFixedK_CheckLastElement()
    {
        
        
        
        double Molt = 1.0;
        int k,i, kprec;
        double SumLog;
        
        int Kobs;
        
        
        
        double Sampst_P[2];
        Vector <double> Sampst(2,Sampst_P);
        
        double applogPstProp_P[2];
        Vector <double> applogPstProp(2,applogPstProp_P);
        applogPstProp.Init(0.0);
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        //        int ClusterIndex_P[Kmax];
        //        Vector <int> ClusterIndex(Kmax,ClusterIndex_P);
        //
        
        Kobs = Clusters->nNonEmpty;
        
        
        //        for(k=0;k<Clusters->nNonEmpty;k++)
        //        {
        //            ClusterIndex.Pvec(k)[0] = Clusters->NonEmptyC.vec(k);
        //        }
        
        //        k = 0;
        //        ClusterIndex.Pvec(0)[0] = Clusters->Zeta.vec(0);
        //        for(i=1;i<nObs;i++)
        //        {
        //            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
        //            {
        //                k++;
        //                ClusterIndex.Pvec(k)[0] = Clusters->Zeta.vec(i);
        //            }
        //        }
        //
        
        double logPstProp_P[Kobs*nObs];
        Matrix <double> logPstProp(nObs,Kobs,logPstProp_P);
        logPstProp.Init(0.0);
        
        double logMatCPProb_P[Kobs*Kobs];
        Matrix <double> logMatCPProb(Kobs,Kobs,logMatCPProb_P);
        
        double VecLike_P[Kobs];
        Vector<double> VecLike(Kobs,VecLike_P);
        
        logMatCPProb.Init(0.0);
        for(k=0;k<Kobs-1;k++)
        {
            //k = ClusterIndex.vec(k);
            logMatCPProb.Pmat(k,k)[0] = log(Molt*Clusters->Probs->ProbsAcc[0]->vec(Clusters->NonEmptyC.vec(k)));
            logMatCPProb.Pmat(k,k+1)[0] = log(Molt-Molt*Clusters->Probs->ProbsAcc[0]->vec(Clusters->NonEmptyC.vec(k)));
            //logMatCPProb.Pmat(k,k)[0] = 0.0;
        }
        logMatCPProb.Pmat(Kobs-1,Kobs-1)[0] = 0.0;
        
        logPstProp.Pmat(0,0)[0] = 0.0;
        //Rprintf("CCww \n");
        for(i=1;i<Kobs;i++)
        {
            k = 0;
            kprec = 0;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
            for(k=1;k<i;k++)
            {
                kprec = k-1;
                applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                //Rprintf("AAA %f %f %f  \n", applogPstProp.Pvec(0)[0],logMatCPProb.mat(kprec,k),logPstProp.mat(i-1,kprec) );
                kprec = k;
                applogPstProp.Pvec(1)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                //Rprintf("AAA %f %f %f \n", applogPstProp.Pvec(1)[0],logMatCPProb.mat(kprec,k),logPstProp.mat(i-1,kprec) );
                
                
                
                Class_Utils::log_sum_exp(logPstProp.Pmat(i,k), 2, applogPstProp.Pvec(0));
                //Rprintf("%f dd\n",logPstProp.Pmat(i,k)[0]);
                //log_sum_exp(double *ret, int k, double *logx)
            }
            k = i;
            kprec = k-1;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
            //Rprintf("%f \n",logPstProp.Pmat(i,k)[0]);
            
            
            ObsY.P = Y.Pmat(i,0);
            for(k=0;k<=i;k++)
            {
                Likelihood->computeLogDensityForLike_WithoutNA(VecLike.Pvec(k),&ObsY, &Container[Clusters->NonEmptyC.vec(k)], i);
            }
            for(k=0;k<=i;k++)
            {
                logPstProp.Pmat(i,k)[0] += VecLike.vec(k);
            }
            Class_Utils::log_sum_exp(&SumLog, i+1, logPstProp.Pmat(i,0));
            //log_sum_exp(double *ret, int k, double *logx)
            for(k=0;k<=i;k++)
            {
                logPstProp.Pmat(i,k)[0] = logPstProp.Pmat(i,k)[0]-SumLog;
            }
            //Rprintf("\n");
        }
        //Rprintf("CC \n");
        
        
        for(i=Kobs;i<nObs;i++)
        {
            
            k = 0;
            kprec = 0;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
            
            for(k=1;k<Kobs;k++)
            {
                kprec = k-1;
                applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                kprec = k;
                applogPstProp.Pvec(1)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                Class_Utils::log_sum_exp(logPstProp.Pmat(i,k), 2, applogPstProp.Pvec(0));
                
            }
            ObsY.P = Y.Pmat(i,0);
            for(k=0;k<Kobs;k++)
            {
                Likelihood->computeLogDensityForLike_WithoutNA(VecLike.Pvec(k),&ObsY, &Container[Clusters->NonEmptyC.vec(k)], i);
            }
            for(k=0;k<Kobs;k++)
            {
                logPstProp.Pmat(i,k)[0] += VecLike.vec(k);
            }
            Class_Utils::log_sum_exp(&SumLog, Kobs, logPstProp.Pmat(i,0));
            for(k=0;k<Kobs;k++)
            {
                logPstProp.Pmat(i,k)[0] = logPstProp.Pmat(i,k)[0]-SumLog;
            }
            
        }
        
        
        //        for(i=0;i<logPstProp.nRows;i++)
        //        {
        //            for(k=0;k<logPstProp.nCols;k++)
        //            {
        //                Rprintf("%f ", exp(logPstProp.mat(i,k)));
        //            }
        //            Rprintf("\n");
        //        }
        
        // sample
        i = nObs-1;
        Clusters->Zeta.Pvec(i)[0] = Kobs-1;
        
        
        for(i=nObs-2;i>=max(Kobs-1,0);i--)
        {
            
            if(Clusters->Zeta.vec(i+1)!=0)
            {
                k = Clusters->Zeta.vec(i+1)-1;
                Sampst.Pvec(0)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                
                k = Clusters->Zeta.vec(i+1);
                Sampst.Pvec(1)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                
                Clusters->Zeta.Pvec(i)[0] = Class_Utils::sample_DiscreteVar(Sampst.Pvec(0), 2)+Clusters->Zeta.vec(i+1)-1;
            }else{
                Clusters->Zeta.Pvec(i)[0] = 0;
            }
            
        }
        for(i=max(Kobs-2,0);i>=0;i--)
        {
            if(Clusters->Zeta.vec(i+1)==(i+1))
            {
                Clusters->Zeta.Pvec(i)[0] = i;
            }else{
                if(Clusters->Zeta.vec(i+1)!=0)
                {
                    k = Clusters->Zeta.vec(i+1)-1;
                    Sampst.Pvec(0)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                    
                    k = Clusters->Zeta.vec(i+1);
                    Sampst.Pvec(1)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                    
                    Clusters->Zeta.Pvec(i)[0] = Class_Utils::sample_DiscreteVar(Sampst.Pvec(0), 2)+Clusters->Zeta.vec(i+1)-1;
                }else{
                    Clusters->Zeta.Pvec(i)[0] = 0;
                }
            }
        }
        
        
        for(i=0;i<nObs;i++)
        {
            Clusters->Zeta.Pvec(i)[0] = Clusters->NonEmptyC.vec(Clusters->Zeta.Pvec(i)[0]);
        }
        //Clusters->Zeta.Print("Zeta");
        Clusters->update_EmptyAndNonEmptyClusters();
        //error("SS");
        //        if(Clusters->nNonEmpty<=0)
        //        {
        //            Rprintf("\n\n s_T = Kmax - CP approximation may be no more valid\n\n");
        //        }
        //
    }
    
    
    
    
    double compute_loggammaSampleCP(double eta, double c, int n)
    {
        double ret;
        ret = lgamma(eta+1.0)+lgamma(n+1)-lgamma(n+1+eta+1-c);
        return(ret);
    }
    
    
    //
    
    // ANCHOR test split
    void samp_stChangePointSplit_CheckLastElement(Class_Parameter *eta)
    {
        //Rprintf("Split\n");
        int ErrorNumberClusters = 0;
        int CheckError = 0;
        int Kobs;
        //int KobsStar;
        int Kempty;
        //int k;
        int k0;
        int k0prec;
        int kK;
        
        
        int deltaP1;
        int deltaL1;
        int deltak;
        
        int kNew;
        int i,j;
        int samp;
        //int knext;
        int KmaxObs;
        int KFirstObs;
        int KsecondObs;
        int KmaxObsL1;
        int kSeq;
        int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        double appProb;
        
        //double LogLikeL1 = 0.0;
        //double LogLikeP1 = 0.0;
        //double LogLikek_New = 0.0;
        double LogLikek_k = 0.0;
        double LogLikek_P1 = 0.0;
        double LogLikek_L1 = 0.0;
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int startL1pre = 0;
        int endL1 = 0;
        int endL1pre = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nL1pre = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexL1pre = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        double gammaP1;
        double gammaL1;
        double gammak;
        double gammaL1k;
        double gammaP1k;
        
        
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        Kvoid = Clusters->nEmpty;
        Kempty = Clusters->nEmpty;
        
        
        
        
        
        k0 = 1;
        kK = 0;
        kNew = 0;
        
        deltaP1 = 0;
        deltaL1 = 0;
        deltak = 0;
        
        k0prec = 1;
        
        //
        
        
        
        //KobsStar = Kobs;
        KmaxObs = Clusters->NonEmptyC.vec(Kobs-1);
        KFirstObs = Clusters->NonEmptyC.vec(0);
        
        if(Kobs>1)
        {
            KmaxObsL1 = Clusters->NonEmptyC.vec(Kobs-2);
            KsecondObs = Clusters->NonEmptyC.vec(1);
        }else{
            KmaxObsL1 = KmaxObs;
            KsecondObs = KFirstObs;
        }
        
        
        
        //if(Kobs>1)
        //{
        
        kSeq                = 0;
        IndexL1             = Clusters->NonEmptyC.vec(kSeq);
        IndexL1pre = IndexL1;
        if(Kobs>1)
        {
            IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
        }else{
            IndexP1             = IndexL1;
        }
        Indexk              = Clusters->EmptyC.vec(kNew);
        
        
        startk      = 0;
        startL1     = 0;
        startL1pre     = startL1;
        
        
        endL1       = startL1;
        endL1pre = endL1;
        endk        = startL1+Clusters->NObsInClust.vec(IndexL1)-1;
        
        
        nL1         = endL1-startL1+1;
        nL1pre         = nL1;
        nk          = endk-startk+1; //
        
        if(Kobs>1)
        {
            //Rprintf("MMM %i \n",Kobs);
            startP1     = startL1+Clusters->NObsInClust.vec(IndexL1);
            endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
            nP1         = endP1-startP1+1;
        }
        
        if(Clusters->nEmpty==0)
        {
            ErrorNumberClusters = 1;
            CheckError = 1;
            //Rprintf("Inizia con il numero max di stati\n");
        }
        
        
        //       Clusters->Zeta.Print("Zeta");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //Rprintf("\nSPLIT\n");
        for(i=0;i<nObs;i++)
        {
            //            Rprintf("Indice %i\n",i);
            //            Rprintf("L1pre %i %i %i %i\n", IndexL1pre, startL1pre, endL1pre, nL1pre);
            //            Rprintf("L1 %i %i %i %i\n", IndexL1, startL1, endL1, nL1);
            //            Rprintf("P1 %i %i %i %i\n", IndexP1, startP1, endP1, nP1);
            //            Rprintf("k %i %i %i %i\n", Indexk, startk, endk, nk);
            
            if(ErrorNumberClusters==1)
            {
                if(CheckError==0)
                {
                    //Rprintf("K may be non well estimated\n");
                    CheckError = 1;
                }
                
            }else{
                if((startL1==startk)&(nk>0))
                {
                    //Rprintf("Nuovo codice");
                    
                    LogLikek_k = 0.0;
                    LogLikek_P1 = 0.0;
                    LogLikek_L1 = 0.0;
                    
                    
                    j = startk;
                    ObsY.P = Y.Pmat(j,0);
                    Likelihood->computeLogDensityForLike_WithoutNA(&appProb,&ObsY, &Container[Indexk],j);
                    LogLikek_k += appProb;
                    
                    Likelihood->computeLogDensityForLike_WithoutNA(&appProb,&ObsY, &Container[IndexL1],j);
                    LogLikek_L1 += appProb;
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        Likelihood->computeLogDensityForLike_WithoutNA(&appProb,&ObsY, &Container[IndexL1pre],j);
                        LogLikek_P1 += appProb;
                    }
                    
                    // if(nk>1)
                    // {
                    
                    // }else{
                    //     gammaL1     = 0.0;
                    //     gammaL1k     = 0.0;
                    // }
                    
                    gammaL1         = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0),nk-1);
                    gammaL1k        = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0),nk);
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        gammaP1    = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1pre);
                        gammaP1k   = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1pre+1);
                    }else{
                        gammaP1    = 0.0;
                        gammaP1k   = 0.0;
                    }
                    
                    gammak          = compute_loggammaSampleCP(eta->ParameterAcc, 0,1);
                    
                    
                    
                    logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1;
                    logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1;
                    logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k;
                    
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                        //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                        //Rprintf("SAmpione su 2, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                    }
                    
                    
                    if(samp==0)
                    {
                        // rimando su dove ero
                        //                    Rprintf("\nS0\n");
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        // NO_ERROR Indexk      = Indexk;
                        
                        // NO_ERROR startL1     = startL1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        // NO_ERROR endL1pre       = endL1pre;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                    }
                    if(samp==1)
                    {
                        // cmapiono k
                        //                    Rprintf("\nS1\n");
                        //
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j=startk;
                        Clusters->Zeta.Pvec(j)[0]  = Indexk;
                        
                        startL1pre     = startk;
                        endL1pre       = startk;
                        nL1pre         = endL1pre-startL1pre+1;
                        IndexL1pre     = Indexk;
                        
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        startk      = startL1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                    }
                    if(samp==2)
                    {
                        // passo a quello prima
                        //                    Rprintf("\nS2\n");
                        //                    Rprintf("%f %f \n", logProbL1[0],logProbk[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j= startk;
                        Clusters->Zeta.Pvec(j)[0]  = IndexL1pre;
                        
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        endL1pre       = endL1pre+1;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                    }
                    
                    
                    
                }else{
                    if((nk!=0))
                    {
                        //Rprintf("Vecchio codice\n");
                        
                        
                        if(nL1==1)
                        {
                            LogLikek_k = 0.0;
                            LogLikek_P1 = 0.0;
                            LogLikek_L1 = 0.0;
                            
                            for(j=startk;j<=endk;j++)
                            {
                                ObsY.P = Y.Pmat(j,0);
                                //ObsY.Print("Y");
                                Likelihood->computeLogDensityForLike_WithoutNA(&appProb,&ObsY, &Container[Indexk],j);
                                LogLikek_k += appProb;
                                //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                                Likelihood->computeLogDensityForLike_WithoutNA(&appProb,&ObsY, &Container[IndexL1],j);
                                LogLikek_L1 += appProb;
                                //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                                
                                
                                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                                {
                                    Likelihood->computeLogDensityForLike_WithoutNA(&appProb,&ObsY, &Container[IndexP1],j);
                                    LogLikek_P1 += appProb;
                                    //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                                }
                            }
                            
                        }else{
                            j = startk-1;
                            
                            ObsY.P = Y.Pmat(j,0);
                            //ObsY.Print("Y");
                            Likelihood->computeLogDensityForLike_WithoutNA(&appProb,&ObsY, &Container[Indexk],j);
                            LogLikek_k -= appProb;
                            //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                            Likelihood->computeLogDensityForLike_WithoutNA(&appProb,&ObsY, &Container[IndexL1],j);
                            LogLikek_L1 -= appProb;
                            //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                            
                            
                            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                            {
                                Likelihood->computeLogDensityForLike_WithoutNA(&appProb,&ObsY, &Container[IndexP1],j);
                                LogLikek_P1 -= appProb;
                                //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                            }
                        }
                        //                        LogLikek_k = 0.0;
                        //                        LogLikek_P1 = 0.0;
                        //                        LogLikek_L1 = 0.0;
                        
                        //                        for(j=startk;j<=endk;j++)
                        //                        {
                        //                            //Rprintf("j = %i\n",j);
                        //                            ObsY.P = Y.Pmat(j,0);
                        //                            //ObsY.Print("Y");
                        //                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                        //                            LogLikek_k += appProb;
                        //                            //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                        //                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                        //                            LogLikek_L1 += appProb;
                        //                            //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                        //
                        //
                        //                            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        //                            {
                        //                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                        //                                LogLikek_P1 += appProb;
                        //                                //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                        //                            }
                        //                        }
                        gammaL1     = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1);
                        
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            gammaP1     = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1,nObs-1,1,0),nP1);
                            gammaP1k    = compute_loggammaSampleCP(eta->ParameterAcc,Class_Utils::ifelse(endP1,nObs-1,1,0), nP1+nk);
                        }else{
                            gammaP1     = 0.0;
                            gammaP1k    = 0.0;
                        }
                        
                        gammak      = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0), nk);
                        gammaL1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0), nL1+nk);
                        
                        
                        logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1;
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1;
                        }
                        
                        logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k;
                        
                        
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                            //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                        }else{
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                            //Rprintf("SAmpione su 2, z=%i %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                        }
                        
                        
                        
                        //Rprintf("Samp %i\n", samp);
                        if(samp==0)
                        {
                            //                        Rprintf("\nS0\n");
                            //                        Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                            //                        Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            // NO_ERROR Indexk      = Indexk;
                            
                            
                            // NO_ERROR startL1     = startL1;
                            endL1       = endL1+1;
                            nL1         = endL1-startL1+1;
                            // NO_ERROR IndexL1      = IndexL1;
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            // NO_ERROR startL1pre     = startL1pre;
                            // NO_ERROR endL1pre       = endL1pre;
                            nL1pre         = endL1pre-startL1pre+1;
                            // NO_ERROR IndexL1pre      = IndexL1pre;
                            
                            
                            
                        }
                        if(samp==1)
                        {
                            //                        Rprintf("\nS1\n");
                            //
                            //                        Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                            //                        Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = Indexk;
                            }
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre          = nL1;
                            IndexL1pre      = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = Indexk;
                            
                            
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            kNew++;
                            if(kNew>=(Kvoid-2))
                            {
                                ErrorNumberClusters = 1;
                            }else{
                                
                                Indexk              = Clusters->EmptyC.vec(kNew);
                            }
                        }
                        if(samp==2)
                        {
                            //                        Rprintf("\nS2\n");
                            //                        Rprintf("%f %f \n", logProbL1[0],logProbk[0]);
                            //                        Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                            //                        Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = IndexP1;
                            }
                            
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre              = nL1;
                            IndexL1pre          = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            endk        = endP1;
                            nk          = endk-startk+1;
                            // NO_ERROR Indexk      = Indexk;
                            //                            kNew++;
                            //                            if(kNew>=(Kvoid-2))
                            //                            {
                            //                                ErrorNumberClusters = 1;
                            //                            }else{
                            //
                            //                                Indexk              = Clusters->EmptyC.vec(kNew);
                            //                            }
                            
                            
                            if(IndexL1!=KmaxObs)
                            {
                                kSeq++;
                                IndexP1      =  Clusters->NonEmptyC.vec(kSeq+1);
                                startP1     = endk+1;
                                endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                nP1         = endP1-startP1+1;
                            }
                            
                        }
                        
                        
                    }else{
                        if(IndexL1!=KmaxObs)
                        {
                            //Rprintf("Non campiono\n");
                            
                            
                            startL1pre = startL1;
                            endL1pre = endL1;
                            nL1pre  = nL1;
                            IndexL1pre = IndexL1;
                            
                            IndexL1             = IndexP1;
                            startL1             = startP1;
                            endL1               = startP1;
                            nL1                 = endL1-startL1+1;
                            
                            
                            // NO_ERROR Indexk              = Indexk;
                            startk              = startL1;
                            endk                = endP1;
                            nk                  = endk-startk+1;
                            
                            if(IndexP1!=KmaxObs)
                            {
                                kSeq++;
                                //Rprintf("\nSstar1\n");
                                IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
                                //Rprintf("\nSstar2\n");
                                startP1             = startL1+Clusters->NObsInClust.vec(IndexL1);
                                //Rprintf("\nSsta3\n");
                                endP1               = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                //Rprintf("\nSstar5\n");
                                nP1                 = endP1-startP1+1;
                            }
                        }
                        
                    }
                }
            }
            
            
            
            
            
        }
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        //Clusters->Zeta.Print("ZetaPost");
        
        //Clusters->Zeta.Print("Zeta");
        
        //error("STOP");
        Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    
    void samp_stChangePointSplit_CheckLastElement_CheckCor(Class_Parameter *eta)
    {
        //Rprintf("Split\n");
        int ErrorNumberClusters = 0;
        int CheckError = 0;
        int Kobs;
        //int KobsStar;
        int Kempty;
        //int k;
        int k0;
        int k0prec;
        int kK;
        
        
        int deltaP1;
        int deltaL1;
        int deltak;
        
        int kNew;
        int i,j;
        int samp;
        //int knext;
        int KmaxObs;
        int KFirstObs;
        int KsecondObs;
        int KmaxObsL1;
        int kSeq;
        int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        double appProb;
        
        //double LogLikeL1 = 0.0;
        //double LogLikeP1 = 0.0;
        //double LogLikek_New = 0.0;
        double LogLikek_k = 0.0;
        double LogLikek_P1 = 0.0;
        double LogLikek_L1 = 0.0;
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int startL1pre = 0;
        int endL1 = 0;
        int endL1pre = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nL1pre = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexL1pre = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        double gammaP1 = 0.0;
        double gammaL1 = 0.0;
        double gammak = 0.0;
        double gammaL1k = 0.0;
        double gammaP1k = 0.0;
        
        
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        Kvoid = Clusters->nEmpty;
        Kempty = Clusters->nEmpty;
        
        
        
        
        
        k0 = 1;
        kK = 0;
        kNew = 0;
        
        deltaP1 = 0;
        deltaL1 = 0;
        deltak = 0;
        
        k0prec = 1;
        
        //
        
        
        
        //KobsStar = Kobs;
        KmaxObs = Clusters->NonEmptyC.vec(Kobs-1);
        KFirstObs = Clusters->NonEmptyC.vec(0);
        
        if(Kobs>1)
        {
            KmaxObsL1 = Clusters->NonEmptyC.vec(Kobs-2);
            KsecondObs = Clusters->NonEmptyC.vec(1);
        }else{
            KmaxObsL1 = KmaxObs;
            KsecondObs = KFirstObs;
        }
        
        
        
        //if(Kobs>1)
        //{
        
        kSeq                = 0;
        IndexL1             = Clusters->NonEmptyC.vec(kSeq);
        IndexL1pre = IndexL1;
        if(Kobs>1)
        {
            IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
        }else{
            IndexP1             = IndexL1;
        }
        Indexk              = Clusters->EmptyC.vec(kNew);
        
        
        startk      = 0;
        startL1     = 0;
        startL1pre     = startL1;
        
        
        endL1       = startL1;
        endL1pre = endL1;
        endk        = startL1+Clusters->NObsInClust.vec(IndexL1)-1;
        
        
        nL1         = endL1-startL1+1;
        nL1pre         = nL1;
        nk          = endk-startk+1; //
        
        if(Kobs>1)
        {
            //Rprintf("MMM %i \n",Kobs);
            startP1     = startL1+Clusters->NObsInClust.vec(IndexL1);
            endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
            nP1         = endP1-startP1+1;
        }
        
        if(Clusters->nEmpty==0)
        {
            ErrorNumberClusters = 1;
            CheckError = 1;
            //Rprintf("Inizia con il numero max di stati\n");
        }
        
        
        //       Clusters->Zeta.Print("Zeta");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //Rprintf("\nSPLIT\n");
        for(i=0;i<nObs;i++)
        {
            //            Rprintf("Indice %i\n",i);
            //            Rprintf("L1pre %i %i %i %i\n", IndexL1pre, startL1pre, endL1pre, nL1pre);
            //            Rprintf("L1 %i %i %i %i\n", IndexL1, startL1, endL1, nL1);
            //            Rprintf("P1 %i %i %i %i\n", IndexP1, startP1, endP1, nP1);
            //            Rprintf("k %i %i %i %i\n", Indexk, startk, endk, nk);
            
            if(ErrorNumberClusters==1)
            {
                if(CheckError==0)
                {
                    //Rprintf("K may be non well estimated\n");
                    CheckError = 1;
                }
                
            }else{
                if((startL1==startk)&(nk>0))
                {
                    //Rprintf("Nuovo codice");
                    
                    LogLikek_k = 0.0;
                    LogLikek_P1 = 0.0;
                    LogLikek_L1 = 0.0;
                    
                    
                    j = startk;
                    ObsY.P = Y.Pmat(j,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                    LogLikek_k += appProb;
                    
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                    LogLikek_L1 += appProb;
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1pre],j);
                        LogLikek_P1 += appProb;
                    }
                    
                    // if(nk>1)
                    // {
                    
                    // }else{
                    //     gammaL1     = 0.0;
                    //     gammaL1k     = 0.0;
                    // }
                    
                    gammaL1         = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0),nk-1);
                    gammaL1k        = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0),nk);
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        gammaP1    = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1pre);
                        gammaP1k   = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1pre+1);
                    }else{
                        gammaP1    = 0.0;
                        gammaP1k   = 0.0;
                    }
                    
                    gammak          = compute_loggammaSampleCP(eta->ParameterAcc, 0,1);
                    
                    
                    
                    logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1;
                    logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1;
                    logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k;
                    
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                        //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                        //Rprintf("SAmpione su 2, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                    }
                    
                    
                    if(samp==0)
                    {
                        // rimando su dove ero
                        //                    Rprintf("\nS0\n");
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        // NO_ERROR Indexk      = Indexk;
                        
                        // NO_ERROR startL1     = startL1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        // NO_ERROR endL1pre       = endL1pre;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                    }
                    if(samp==1)
                    {
                        // cmapiono k
                        //                    Rprintf("\nS1\n");
                        //
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j=startk;
                        Clusters->Zeta.Pvec(j)[0]  = Indexk;
                        
                        startL1pre     = startk;
                        endL1pre       = startk;
                        nL1pre         = endL1pre-startL1pre+1;
                        IndexL1pre     = Indexk;
                        
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        startk      = startL1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                    }
                    if(samp==2)
                    {
                        // passo a quello prima
                        //                    Rprintf("\nS2\n");
                        //                    Rprintf("%f %f \n", logProbL1[0],logProbk[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j= startk;
                        Clusters->Zeta.Pvec(j)[0]  = IndexL1pre;
                        
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        endL1pre       = endL1pre+1;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                    }
                    
                    
                    
                }else{
                    if((nk!=0))
                    {
                        //Rprintf("Vecchio codice\n");
                        
                        
                        if(nL1==1)
                        {
                            LogLikek_k = 0.0;
                            LogLikek_P1 = 0.0;
                            LogLikek_L1 = 0.0;
                            
                            for(j=startk;j<=endk;j++)
                            {
                                ObsY.P = Y.Pmat(j,0);
                                //ObsY.Print("Y");
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                                LogLikek_k += appProb;
                                //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                                LogLikek_L1 += appProb;
                                //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                                
                                
                                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                                {
                                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                    LogLikek_P1 += appProb;
                                    //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                                }
                            }
                            
                        }else{
                            j = startk-1;
                            
                            ObsY.P = Y.Pmat(j,0);
                            //ObsY.Print("Y");
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                            LogLikek_k -= appProb;
                            //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                            LogLikek_L1 -= appProb;
                            //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                            
                            
                            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                            {
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                LogLikek_P1 -= appProb;
                                //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                            }
                        }
                        //                        LogLikek_k = 0.0;
                        //                        LogLikek_P1 = 0.0;
                        //                        LogLikek_L1 = 0.0;
                        
                        //                        for(j=startk;j<=endk;j++)
                        //                        {
                        //                            //Rprintf("j = %i\n",j);
                        //                            ObsY.P = Y.Pmat(j,0);
                        //                            //ObsY.Print("Y");
                        //                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                        //                            LogLikek_k += appProb;
                        //                            //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                        //                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                        //                            LogLikek_L1 += appProb;
                        //                            //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                        //
                        //
                        //                            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        //                            {
                        //                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                        //                                LogLikek_P1 += appProb;
                        //                                //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                        //                            }
                        //                        }
                        gammaL1     = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1);
                        
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            gammaP1     = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1,nObs-1,1,0),nP1);
                            gammaP1k    = compute_loggammaSampleCP(eta->ParameterAcc,Class_Utils::ifelse(endP1,nObs-1,1,0), nP1+nk);
                        }else{
                            gammaP1     = 0.0;
                            gammaP1k    = 0.0;
                        }
                        
                        gammak      = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0), nk);
                        gammaL1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0), nL1+nk);
                        
                        
                        logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1;
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1;
                        }
                        
                        logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k;
                        
                        
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                            //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                        }else{
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                            //Rprintf("SAmpione su 2, z=%i %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                        }
                        
                        
                        
                        //Rprintf("Samp %i\n", samp);
                        if(samp==0)
                        {
                            //                        Rprintf("\nS0\n");
                            //                        Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                            //                        Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            // NO_ERROR Indexk      = Indexk;
                            
                            
                            // NO_ERROR startL1     = startL1;
                            endL1       = endL1+1;
                            nL1         = endL1-startL1+1;
                            // NO_ERROR IndexL1      = IndexL1;
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            // NO_ERROR startL1pre     = startL1pre;
                            // NO_ERROR endL1pre       = endL1pre;
                            nL1pre         = endL1pre-startL1pre+1;
                            // NO_ERROR IndexL1pre      = IndexL1pre;
                            
                            
                            
                        }
                        if(samp==1)
                        {
                            //                        Rprintf("\nS1\n");
                            //
                            //                        Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                            //                        Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = Indexk;
                            }
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre          = nL1;
                            IndexL1pre      = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = Indexk;
                            
                            
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            kNew++;
                            if(kNew>=(Kvoid-2))
                            {
                                ErrorNumberClusters = 1;
                            }else{
                                
                                Indexk              = Clusters->EmptyC.vec(kNew);
                            }
                        }
                        if(samp==2)
                        {
                            //                        Rprintf("\nS2\n");
                            //                        Rprintf("%f %f \n", logProbL1[0],logProbk[0]);
                            //                        Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                            //                        Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = IndexP1;
                            }
                            
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre              = nL1;
                            IndexL1pre          = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            endk        = endP1;
                            nk          = endk-startk+1;
                            // NO_ERROR Indexk      = Indexk;
                            //                            kNew++;
                            //                            if(kNew>=(Kvoid-2))
                            //                            {
                            //                                ErrorNumberClusters = 1;
                            //                            }else{
                            //
                            //                                Indexk              = Clusters->EmptyC.vec(kNew);
                            //                            }
                            
                            
                            if(IndexL1!=KmaxObs)
                            {
                                kSeq++;
                                IndexP1      =  Clusters->NonEmptyC.vec(kSeq+1);
                                startP1     = endk+1;
                                endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                nP1         = endP1-startP1+1;
                            }
                            
                        }
                        
                        
                    }else{
                        if(IndexL1!=KmaxObs)
                        {
                            //Rprintf("Non campiono\n");
                            
                            
                            startL1pre = startL1;
                            endL1pre = endL1;
                            nL1pre  = nL1;
                            IndexL1pre = IndexL1;
                            
                            IndexL1             = IndexP1;
                            startL1             = startP1;
                            endL1               = startP1;
                            nL1                 = endL1-startL1+1;
                            
                            
                            // NO_ERROR Indexk              = Indexk;
                            startk              = startL1;
                            endk                = endP1;
                            nk                  = endk-startk+1;
                            
                            if(IndexP1!=KmaxObs)
                            {
                                kSeq++;
                                //Rprintf("\nSstar1\n");
                                IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
                                //Rprintf("\nSstar2\n");
                                startP1             = startL1+Clusters->NObsInClust.vec(IndexL1);
                                //Rprintf("\nSsta3\n");
                                endP1               = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                //Rprintf("\nSstar5\n");
                                nP1                 = endP1-startP1+1;
                            }
                        }
                        
                    }
                }
            }
            
            
            
            
            
        }
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        //Clusters->Zeta.Print("ZetaPost");
        
        //Clusters->Zeta.Print("Zeta");
        
        //error("STOP");
        Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    
    void sample_DPparameterGammaPrior_CP(Class_Parameter *eta)
    {
        double s = 0.0;
        double r = 0.0;
        for(int k1=0;k1<Clusters->nNonEmpty-1;k1++)
        {
            int k = Clusters->NonEmptyC.vec(k1);
            
            r += log(rbeta(eta->ParameterAcc+1, 1.0*Clusters->NObsInClust.vec(k)+1.0   )  );
            double u = runif(0.0,1.0);
            if(u< (1.0*Clusters->NObsInClust.vec(k)+1.0 )/(1.0*Clusters->NObsInClust.vec(k)+1.0+eta->ParameterAcc ) )
            {
                s++;
            }
        }
        int k1;
        k1 = Clusters->nNonEmpty-1;
        int k = Clusters->NonEmptyC.vec(k1);
        
        r += log(rbeta(eta->ParameterAcc+1, 1.0*Clusters->NObsInClust.vec(k)   )  );
        double u = runif(0.0,1.0);
        if(u< (1.0*Clusters->NObsInClust.vec(k) )/(1.0*Clusters->NObsInClust.vec(k)+eta->ParameterAcc ) )
        {
            s++;
        }
        eta->ParameterAcc = rgamma(eta->PriorParameter->HyperparametersAcc.vec(0)[0]+2.0*Clusters->nNonEmpty-1.0-s,1.0/(eta->PriorParameter->HyperparametersAcc.vec(1)[0]-r));
        
    }
    
    
    
    // ANCHOR MERGE st
    void samp_stChangePointMerge_CheckLastElement(Class_Parameter *eta)
    {
        int ControllWhile = 0;
        int StopMerge = 0;
        int Kobs;
        int KobsStar;
        int Kempty;
        int k;
        //int k0;
        //int k0prec;
        //int kK;
        //int kKP1;
        //int kNew;
        int i;
        int samp;
        //int knext;
        
        
        //int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        double appProb;
        
        
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int endL1 = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        double gammaP1 = 0.0;
        double gammaL1 = 0.0;
        
        double gammaL1k = 0.0;
        double gammaP1k = 0.0;
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        
        KobsStar = Kobs;
        Kempty = Clusters->nEmpty;
        //        k0 = 1;
        //        kK = 0;
        //        //kNew = 0;
        //        //kKP1 = 0;
        //        k0prec = 1;
        //
        //        int NonEmptyC_P[Kobs];
        //        Vector <int> NonEmptyC(Kobs,NonEmptyC_P);
        //        k = 0;
        //        NonEmptyC.Pvec(0)[0] = Clusters->Zeta.vec(0);
        //        for(i=1;i<nObs;i++)
        //        {
        //            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
        //            {
        //                k++;
        //                NonEmptyC.Pvec(k)[0] = Clusters->Zeta.vec(i);
        //            }
        //        }
        
        
        int VecPrec_P[Kmax];
        Vector <int>VecPrec(Kmax, VecPrec_P);
        
        int VecSuc_P[Kmax];
        Vector <int>VecSuc(Kmax, VecSuc_P);
        VecSuc.Init(-99);
        
        int VecN_P[Kmax];
        Vector <int>VecN(Kmax, VecN_P);
        VecN.Init(-99);
        
        int VecStart_P[Kmax];
        Vector <int>VecStart(Kmax, VecStart_P);
        VecStart.Init(-99);
        
        int VecEnd_P[Kmax];
        Vector <int>VecEnd(Kmax, VecEnd_P);
        VecEnd.Init(-99);
        
        
        VecStart.Pvec(Clusters->Zeta.vec(0))[0] = 0;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                VecPrec.Pvec(Clusters->Zeta.vec(i))[0] = Clusters->Zeta.vec(i-1);
                VecSuc.Pvec(Clusters->Zeta.vec(i-1))[0] = Clusters->Zeta.vec(i);
                VecStart.Pvec(Clusters->Zeta.vec(i))[0] = i;
                VecEnd.Pvec(Clusters->Zeta.vec(i-1))[0] = i-1;
            }
        }
        VecEnd.Pvec(Clusters->Zeta.vec(nObs-1))[0] = nObs-1;
        for(k=0;k<Kmax;k++)
        {
            VecN.Pvec(k)[0] = Clusters->NObsInClust.vec(k);
        }
        
        
        
        //knext       = 0;
        
        IndexL1     = Clusters->Zeta.vec(0);
        startL1     = VecStart.vec(IndexL1);
        endL1       = VecEnd.vec(IndexL1);
        nL1         = VecN.vec(IndexL1);
        
        
        Indexk     = Clusters->Zeta.vec(0);
        startk     = VecStart.vec(Indexk);
        endk       = VecEnd.vec(Indexk);
        nk         = VecN.vec(Indexk);
        
        if(Kobs>1)
        {
            IndexP1     = VecSuc.vec(Indexk);
            startP1     = VecStart.vec(IndexP1);
            endP1       = VecEnd.vec(IndexP1);
            nP1         = VecN.vec(IndexP1);
        }else{
            IndexP1     = Indexk;
            startP1     = startk;
            endP1       = endk;
            nP1         = nk;
        }
        
        if(Kobs==1)
        {
            StopMerge=1;
        }
        //Rprintf("Merge");
        while(StopMerge==0 ){
            
            ControllWhile++;
            
            double LogLikeL1 = 0.0;
            double LogLikeP1 = 0.0;
            //double LogLikek_New = 0.0;
            double LogLikek_k = 0.0;
            double LogLikek_P1 = 0.0;
            double LogLikek_L1 = 0.0;
            
            double gammak = 0.0;
            
            //LogLikeL1 = 0.0;
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                for(i=startL1;i<=endL1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike_WithoutNA(&appProb,&ObsY, &Container[IndexL1], i);
                    LogLikeL1 += appProb;
                }
            }
            LogLikeP1 = 0.0;
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                for(i=startP1;i<=endP1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike_WithoutNA(&appProb,&ObsY, &Container[IndexP1], i);
                    LogLikeP1 += appProb;
                }
            }
            
            
            LogLikek_k = 0.0;
            LogLikek_P1 = 0.0;
            LogLikek_L1 = 0.0;
            for(i=startk;i<=endk;i++)
            {
                ObsY.P = Y.Pmat(i,0);
                Likelihood->computeLogDensityForLike_WithoutNA(&appProb,&ObsY, &Container[Indexk], i);
                LogLikek_k += appProb;
                
                //Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexNew], i);
                //LogLikek_New += appProb;
                
                Likelihood->computeLogDensityForLike_WithoutNA(&appProb,&ObsY, &Container[IndexP1], i);
                LogLikek_P1 += appProb;
                
                Likelihood->computeLogDensityForLike_WithoutNA(&appProb,&ObsY, &Container[IndexL1], i);
                LogLikek_L1 += appProb;
            }
            
            
            gammak      = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk, nObs-1,1,0), nk);
            
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                gammaL1     = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1);
                gammaL1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0), nL1+nk);
            }else{
                gammaL1     = 0.0;
                gammaL1k    = 0.0;
            }
            
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                gammaP1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0), nP1+nk);
                gammaP1     = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0),nP1);
            }else{
                gammaP1k    = 0.0;
                gammaP1     = 0.0;
            }
            
            logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1+LogLikeL1+LogLikeP1;
            logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1+LogLikeP1+LogLikeL1;
            logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k+LogLikeP1+LogLikeL1;
            
            //REprintf("\n%f %f %f \n %f %f %f \n %f %f %f \n",LogLikeL1, LogLikek_k,LogLikeP1,
            //          LogLikek_L1,LogLikek_k,LogLikek_P1,
            //        logProbL1[0],logProbk[0],logProbP1[0]);
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // L1 e P1
                    samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                }else{
                    // L1
                    samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                }
            }else{
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // P1
                    samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(1), 2)+1;
                }else{
                    StopMerge   = 1;
                    samp        = 5;
                }
            }
            //logProb.Print("A");
            
            if(samp==0)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexL1;
                }
                
                //VecStart.Pvec(IndexL1)[0]       = VecStart.Pvec(IndexL1)[0];
                VecEnd.Pvec(IndexL1)[0]         = VecEnd.Pvec(Indexk)[0];
                VecN.Pvec(IndexL1)[0]           = VecN.Pvec(IndexL1)[0]+VecN.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                
                Indexk     = IndexL1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
            }
            if(samp==1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)==1)
                {
                    StopMerge = 1;
                }else{
                    if(Class_Utils::ifelse(endP1,nObs-1,1,0)!=1)
                    {
                        IndexP1     = VecSuc.vec(IndexP1);
                        startP1     = VecStart.vec(IndexP1);
                        endP1       = VecEnd.vec(IndexP1);
                        nP1         = VecN.vec(IndexP1);
                    }
                    
                    Indexk     = VecSuc.vec(Indexk);
                    startk     = VecStart.vec(Indexk);
                    endk       = VecEnd.vec(Indexk);
                    nk         = VecN.vec(Indexk);
                    
                    IndexL1     = VecPrec.vec(Indexk);
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                
                
            }
            if(samp==2)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexP1;
                }
                VecStart.Pvec(IndexP1)[0]       = VecStart.Pvec(Indexk)[0];
                //VecEnd.Pvec(IndexP1)[0]         = VecEnd.Pvec(IndexP1)[0];
                VecN.Pvec(IndexP1)[0]           = VecN.Pvec(IndexP1)[0]+VecN.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                Indexk     = IndexP1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
            }
            
        }
        
        if(ControllWhile>Kobs*Kobs)
        {
            error("CONTROLLARE WHILE LOOP");
        }
        
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        
        Clusters->update_EmptyAndNonEmptyClusters();
        
        
        
        
        
        
        //Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    void samp_stChangePointMerge(Class_Parameter *eta, int length, vector<VectorParameters> &xi, vector <Matrix<int >* >  &FromCpToLevel2, int isp)
    {
        int ControllWhile = 0;
        int StopMerge = 0;
        int Kobs;
        int KobsStar;
        int Kempty;
        int k;
        //int k0;
        //int k0prec;
        //int kK;
        //int kKP1;
        //int kNew;
        int i;
        int samp;
        //int knext;
        
        
        //int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        
        
        
        double appProb;
        
        
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int endL1 = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        double gammaP1 = 0.0;
        double gammaL1 = 0.0;
        
        double gammaL1k = 0.0;
        double gammaP1k = 0.0;
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        
        KobsStar = Kobs;
        Kempty = Clusters->nEmpty;
        
        
        int VecPrec_P[Kmax];
        Vector <int>VecPrec(Kmax, VecPrec_P);
        
        int VecSuc_P[Kmax];
        Vector <int>VecSuc(Kmax, VecSuc_P);
        VecSuc.Init(-99);
        
        int VecN_P[Kmax];
        Vector <int>VecN(Kmax, VecN_P);
        VecN.Init(-99);
        
        int VecStart_P[Kmax];
        Vector <int>VecStart(Kmax, VecStart_P);
        VecStart.Init(-99);
        
        int VecEnd_P[Kmax];
        Vector <int>VecEnd(Kmax, VecEnd_P);
        VecEnd.Init(-99);
        
        
        VecStart.Pvec(Clusters->Zeta.vec(0))[0] = 0;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                VecPrec.Pvec(Clusters->Zeta.vec(i))[0] = Clusters->Zeta.vec(i-1);
                VecSuc.Pvec(Clusters->Zeta.vec(i-1))[0] = Clusters->Zeta.vec(i);
                VecStart.Pvec(Clusters->Zeta.vec(i))[0] = i;
                VecEnd.Pvec(Clusters->Zeta.vec(i-1))[0] = i-1;
            }
        }
        VecEnd.Pvec(Clusters->Zeta.vec(nObs-1))[0] = nObs-1;
        for(k=0;k<Kmax;k++)
        {
            VecN.Pvec(k)[0] = Clusters->NObsInClust.vec(k);
        }
        
        
        //Likelihood->ProbSecondLev[0][ipar].VectorAcc.Pvec(k)[0];
        //knext       = 0;
        
        IndexL1     = Clusters->Zeta.vec(0);
        startL1     = VecStart.vec(IndexL1);
        endL1       = VecEnd.vec(IndexL1);
        nL1         = VecN.vec(IndexL1);
        
        
        Indexk     = Clusters->Zeta.vec(0);
        startk     = VecStart.vec(Indexk);
        endk       = VecEnd.vec(Indexk);
        nk         = VecN.vec(Indexk);
        
        if(Kobs>1)
        {
            IndexP1     = VecSuc.vec(Indexk);
            startP1     = VecStart.vec(IndexP1);
            endP1       = VecEnd.vec(IndexP1);
            nP1         = VecN.vec(IndexP1);
        }else{
            IndexP1     = Indexk;
            startP1     = startk;
            endP1       = endk;
            nP1         = nk;
        }
        
        
        
        /**** nuovi parametri ****/
        double probxiL1;
        double probxiP1;
        double probxiK;
        
        
        
        
        vector <int> ClustIndex;
        
        
        
        ClustIndex.push_back(Clusters->Zeta.vec(0));
        for(i=1;i<nObs;i++)
        {
            //REprintf("%i \n",Clusters->Zeta.vec(i));
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                ClustIndex.push_back(Clusters->Zeta.vec(i));
            }
        }
        
        
        vector <double> logXI;
        vector <double> logSumXI;
        for(k=0;k<ClustIndex.size();k++)
        {
            logXI.push_back(0.0);
            logSumXI.push_back(0.0);
            
            int ipar;
            
            ipar = 0;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat( ClustIndex[k],isp)));
            ipar = 2;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(ClustIndex[k],isp)));
            ipar = 4;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(ClustIndex[k],isp)) );
            for(ipar=5;ipar<12;ipar++)
            {
                logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(ClustIndex[k],isp)) );
            }
            
        }
        
        double AppSum[Kmax];
        logSumXI[0] = 0;
        for(k=1;k<ClustIndex.size();k++)
        {
            AppSum[k] = logXI[k-1];
            Class_Utils::log_sum_exp(&logSumXI[k],k, &AppSum[1]);
        }
        
        //        REprintf("Cluster \n%i \n",Clusters->Zeta.vec(0));
        //        for(i=1;i<nObs;i++)
        //        {
        //            REprintf("%i \n",Clusters->Zeta.vec(i));
        //        }
        //        REprintf("Stato inziale \n");
        //        for(k=0;k<ClustIndex.size();k++)
        //        {
        //            REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
        //        }
        
        
        int kxi = 0;
        
        /**** nuovi parametri  END ****/
        if(Kobs==1)
        {
            StopMerge=1;
        }
        //Rprintf("Merge");
        while(StopMerge==0 ){
            
            ControllWhile++;
            
            double LogLikeL1 = 0.0;
            double LogLikeP1 = 0.0;
            //double LogLikek_New = 0.0;
            double LogLikek_k = 0.0;
            double LogLikek_P1 = 0.0;
            double LogLikek_L1 = 0.0;
            
            double gammak = 0.0;
            
            //LogLikeL1 = 0.0;
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                for(i=startL1;i<=endL1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                    LogLikeL1 += appProb;
                }
            }
            LogLikeP1 = 0.0;
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                for(i=startP1;i<=endP1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                    LogLikeP1 += appProb;
                }
            }
            
            
            LogLikek_k = 0.0;
            LogLikek_P1 = 0.0;
            LogLikek_L1 = 0.0;
            for(i=startk;i<=endk;i++)
            {
                ObsY.P = Y.Pmat(i,0);
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk], i);
                LogLikek_k += appProb;
                
                //Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexNew], i);
                //LogLikek_New += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                LogLikek_P1 += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                LogLikek_L1 += appProb;
            }
            
            
            gammak      = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk, nObs-1,1,0), nk);
            
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                gammaL1     = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1);
                gammaL1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0), nL1+nk);
            }else{
                gammaL1     = 0.0;
                gammaL1k    = 0.0;
            }
            
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                gammaP1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0), nP1+nk);
                gammaP1     = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0),nP1);
            }else{
                gammaP1k    = 0.0;
                gammaP1     = 0.0;
            }
            
            // contributo prob G_0
            probxiL1 = 0.0;
            probxiP1 = 0.0;
            probxiK  = logXI[kxi];
            
            //REprintf("probxiK kxi=%i \n", kxi);
            for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
            {
                probxiK -= Class_Utils::log1mexp(logSumXI[jjj]);
                //REprintf("jjj=%i logSumXI[jjj] %f sum %e %e \n",jjj,logSumXI[jjj],Class_Utils::log1mexp(logSumXI[jjj]),probxiK);
            }
            //REprintf("probxip1 kxi=%i \n", kxi);
            for(int jjj=kxi+2;jjj<ClustIndex.size();jjj++)
            {
                probxiP1 -= Class_Utils::log1mexp( log(exp( logSumXI[jjj] )- exp(logXI[kxi])  ));
                //REprintf("jjj=%i logSumXI[jjj] %f sum %e %e \n",jjj,log(exp( logSumXI[jjj] )- exp(logXI[kxi])  ),Class_Utils::log1mexp( log(exp( logSumXI[jjj] )- exp(logXI[kxi])  )), probxiP1);
            }
            probxiL1 = probxiP1;
            //
            logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1+LogLikeL1+LogLikeP1+probxiL1;
            logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1+LogLikeP1+LogLikeL1+probxiP1;
            logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k+LogLikeP1+LogLikeL1+probxiK;
            
            
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // L1 e P1
                    if(nk<length)
                    {
                        double PP[2];
                        PP[0] = logProb.vec(0);
                        PP[1] = logProb.vec(2);
                        samp = Class_Utils::sample_DiscreteVar(PP, 2);
                        if(samp==1)
                        {
                            samp = 2;
                        }
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                    }
                    
                }else{
                    // L1
                    if(nk<length)
                    {
                        samp = 0;
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                    }
                    
                }
            }else{
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // P1
                    if(nk<length)
                    {
                        samp = 2;
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(1), 2)+1;
                    }
                }else{
                    StopMerge   = 1;
                    samp        = 5;
                }
            }
            //logProb.Print("A");
            
            //            REprintf("Kobs %i  samp %i probxiL1 %f probxiP1 %f probxiK %f nk %i\n", Kobs, samp,probxiL1,probxiP1 ,probxiK, nk);
            //
            //            // xi
            //            REprintf("pre sample\n");
            //            for(k=0;k<ClustIndex.size();k++)
            //            {
            //                REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
            //            }
            if(samp==0)
            {
                for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                {
                    logSumXI[jjj]  =  log(exp( logSumXI[jjj] )- exp(logXI[kxi]));
                }
                logXI.erase(logXI.begin()+kxi);
                logSumXI.erase(logSumXI.begin()+kxi);
                ClustIndex.erase(ClustIndex.begin()+kxi);
                kxi--;
                
                
            }
            if(samp==1)
            {
                kxi++;
            }
            if(samp==2)
            {
                for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                {
                    logSumXI[jjj]  =  log(exp( logSumXI[jjj] )- exp(logXI[kxi]));
                }
                logXI.erase(logXI.begin()+kxi);
                logSumXI.erase(logSumXI.begin()+kxi);
                ClustIndex.erase(ClustIndex.begin()+kxi);
                kxi = kxi;
            }
            logSumXI[0] = 0;
            //            REprintf("post sample\n");
            //            for(k=0;k<ClustIndex.size();k++)
            //            {
            //                REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
            //            }
            
            
            if(samp==0)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexL1;
                }
                
                //VecStart.Pvec(IndexL1)[0]       = VecStart.Pvec(IndexL1)[0];
                VecEnd.Pvec(IndexL1)[0]         = VecEnd.Pvec(Indexk)[0];
                VecN.Pvec(IndexL1)[0]           = VecN.Pvec(IndexL1)[0]+VecN.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                
                Indexk     = IndexL1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
                
                
            }
            if(samp==1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)==1)
                {
                    StopMerge = 1;
                }else{
                    if(Class_Utils::ifelse(endP1,nObs-1,1,0)!=1)
                    {
                        IndexP1     = VecSuc.vec(IndexP1);
                        startP1     = VecStart.vec(IndexP1);
                        endP1       = VecEnd.vec(IndexP1);
                        nP1         = VecN.vec(IndexP1);
                    }
                    
                    Indexk     = VecSuc.vec(Indexk);
                    startk     = VecStart.vec(Indexk);
                    endk       = VecEnd.vec(Indexk);
                    nk         = VecN.vec(Indexk);
                    
                    IndexL1     = VecPrec.vec(Indexk);
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                
                
            }
            if(samp==2)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexP1;
                }
                VecStart.Pvec(IndexP1)[0]       = VecStart.Pvec(Indexk)[0];
                //VecEnd.Pvec(IndexP1)[0]         = VecEnd.Pvec(IndexP1)[0];
                VecN.Pvec(IndexP1)[0]           = VecN.Pvec(IndexP1)[0]+VecN.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                Indexk     = IndexP1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
            }
            
            
            
        }
        
        if(ControllWhile>Kobs*Kobs)
        {
            error("CONTROLLARE WHILE LOOP");
        }
        
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        
        Clusters->update_EmptyAndNonEmptyClusters();
        
        
        
        
        
        
        //Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    
    
    
    void samp_stChangePointMerge_Check(Class_Parameter *eta, int length, vector<VectorParameters> &xi, vector <Matrix<int >* >  &FromCpToLevel2, int isp)
    {
        int ControllWhile = 0;
        int StopMerge = 0;
        int Kobs;
        int KobsStar;
        int Kempty;
        int k;
        //int k0;
        //int k0prec;
        //int kK;
        //int kKP1;
        //int kNew;
        int i;
        int samp;
        //int knext;
        
        
        //int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        
        
        
        double appProb;
        
        
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int endL1 = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        double gammaP1 = 0.0;
        double gammaL1 = 0.0;
        
        double gammaL1k = 0.0;
        double gammaP1k = 0.0;
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        
        KobsStar = Kobs;
        Kempty = Clusters->nEmpty;
        
        
        int VecPrec_P[Kmax];
        Vector <int>VecPrec(Kmax, VecPrec_P);
        
        int VecSuc_P[Kmax];
        Vector <int>VecSuc(Kmax, VecSuc_P);
        VecSuc.Init(-99);
        
        int VecN_P[Kmax];
        Vector <int>VecN(Kmax, VecN_P);
        VecN.Init(-99);
        
        int VecStart_P[Kmax];
        Vector <int>VecStart(Kmax, VecStart_P);
        VecStart.Init(-99);
        
        int VecEnd_P[Kmax];
        Vector <int>VecEnd(Kmax, VecEnd_P);
        VecEnd.Init(-99);
        
        
        VecStart.Pvec(Clusters->Zeta.vec(0))[0] = 0;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                VecPrec.Pvec(Clusters->Zeta.vec(i))[0] = Clusters->Zeta.vec(i-1);
                VecSuc.Pvec(Clusters->Zeta.vec(i-1))[0] = Clusters->Zeta.vec(i);
                VecStart.Pvec(Clusters->Zeta.vec(i))[0] = i;
                VecEnd.Pvec(Clusters->Zeta.vec(i-1))[0] = i-1;
            }
        }
        VecEnd.Pvec(Clusters->Zeta.vec(nObs-1))[0] = nObs-1;
        for(k=0;k<Kmax;k++)
        {
            VecN.Pvec(k)[0] = Clusters->NObsInClust.vec(k);
        }
        
        
        //Likelihood->ProbSecondLev[0][ipar].VectorAcc.Pvec(k)[0];
        //knext       = 0;
        
        IndexL1     = Clusters->Zeta.vec(0);
        startL1     = VecStart.vec(IndexL1);
        endL1       = VecEnd.vec(IndexL1);
        nL1         = VecN.vec(IndexL1);
        
        
        Indexk     = Clusters->Zeta.vec(0);
        startk     = VecStart.vec(Indexk);
        endk       = VecEnd.vec(Indexk);
        nk         = VecN.vec(Indexk);
        
        if(Kobs>1)
        {
            IndexP1     = VecSuc.vec(Indexk);
            startP1     = VecStart.vec(IndexP1);
            endP1       = VecEnd.vec(IndexP1);
            nP1         = VecN.vec(IndexP1);
        }else{
            IndexP1     = Indexk;
            startP1     = startk;
            endP1       = endk;
            nP1         = nk;
        }
        
        
        
        /**** nuovi parametri ****/
        double probxiL1;
        double probxiP1;
        double probxiK;
        
        
        
        
        vector <int> ClustIndex;
        
        
        
        ClustIndex.push_back(Clusters->Zeta.vec(0));
        for(i=1;i<nObs;i++)
        {
            //REprintf("%i \n",Clusters->Zeta.vec(i));
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                ClustIndex.push_back(Clusters->Zeta.vec(i));
            }
        }
        
        
        vector <double> logXI;
        vector <double> logSumXI;
        for(k=0;k<ClustIndex.size();k++)
        {
            logXI.push_back(0.0);
            logSumXI.push_back(0.0);
            
            int ipar;
            
            ipar = 0;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat( ClustIndex[k],isp)));
            ipar = 2;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(ClustIndex[k],isp)));
            ipar = 4;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(ClustIndex[k],isp)) );
            for(ipar=5;ipar<12;ipar++)
            {
                logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(ClustIndex[k],isp)) );
            }
            
        }
        
        double AppSum[Kmax];
        logSumXI[0] = 0;
        for(k=1;k<ClustIndex.size();k++)
        {
            AppSum[k] = logXI[k-1];
            Class_Utils::log_sum_exp(&logSumXI[k],k, &AppSum[1]);
        }
        
        REprintf("Cluster \n%i \n",Clusters->Zeta.vec(0));
        for(i=1;i<nObs;i++)
        {
            REprintf("%i \n",Clusters->Zeta.vec(i));
        }
        REprintf("Stato inziale \n");
        for(k=0;k<ClustIndex.size();k++)
        {
            REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
        }
        
        
        int kxi = 0;
        
        /**** nuovi parametri  END ****/
        if(Kobs==1)
        {
            StopMerge=1;
        }
        int countr = 0;
        //Rprintf("Merge");
        while(StopMerge==0 ){
            
            ControllWhile++;
            
            double LogLikeL1 = 0.0;
            double LogLikeP1 = 0.0;
            //double LogLikek_New = 0.0;
            double LogLikek_k = 0.0;
            double LogLikek_P1 = 0.0;
            double LogLikek_L1 = 0.0;
            
            double gammak = 0.0;
            
            //LogLikeL1 = 0.0;
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                for(i=startL1;i<=endL1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                    LogLikeL1 += appProb;
                }
            }
            LogLikeP1 = 0.0;
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                for(i=startP1;i<=endP1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                    LogLikeP1 += appProb;
                }
            }
            
            
            LogLikek_k = 0.0;
            LogLikek_P1 = 0.0;
            LogLikek_L1 = 0.0;
            for(i=startk;i<=endk;i++)
            {
                ObsY.P = Y.Pmat(i,0);
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk], i);
                LogLikek_k += appProb;
                
                //Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexNew], i);
                //LogLikek_New += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                LogLikek_P1 += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                LogLikek_L1 += appProb;
            }
            
            
            gammak      = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk, nObs-1,1,0), nk);
            
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                gammaL1     = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1);
                gammaL1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0), nL1+nk);
            }else{
                gammaL1     = 0.0;
                gammaL1k    = 0.0;
            }
            
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                gammaP1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0), nP1+nk);
                gammaP1     = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0),nP1);
            }else{
                gammaP1k    = 0.0;
                gammaP1     = 0.0;
            }
            
            // contributo prob G_0
            probxiL1 = 0.0;
            probxiP1 = 0.0;
            probxiK  = logXI[kxi];
            
            REprintf("probxiK kxi=%i \n", kxi);
            for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
            {
                probxiK -= Class_Utils::log1mexp(logSumXI[jjj]);
                REprintf("jjj=%i logSumXI[jjj] %f sum %e %e \n",jjj,logSumXI[jjj],Class_Utils::log1mexp(logSumXI[jjj]),probxiK);
            }
            REprintf("probxip1 kxi=%i \n", kxi);
            for(int jjj=kxi+2;jjj<ClustIndex.size();jjj++)
            {
                probxiP1 -= Class_Utils::log1mexp( log(exp( logSumXI[jjj] )- exp(logXI[kxi])  ));
                REprintf("jjj=%i logSumXI[jjj] %f sum %e %e \n",jjj,log(exp( logSumXI[jjj] )- exp(logXI[kxi])  ),Class_Utils::log1mexp( log(exp( logSumXI[jjj] )- exp(logXI[kxi])  )), probxiP1);
            }
            probxiL1 = probxiP1;
            //
            logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1+LogLikeL1+LogLikeP1+probxiL1;
            logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1+LogLikeP1+LogLikeL1+probxiP1;
            logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k+LogLikeP1+LogLikeL1+probxiK;
            
            REprintf(" logProbL1[0] %f logProbk[0] %f logProbP1[0] %f  \n gammaL1 %f gammak %f gammaP1 %f gammaP1k %f gammaL1k %f  \n LogLikeL1 %f LogLikek_k %f LogLikeP1 %f LogLikek_L1 %f LogLikek_P1 %f  \n probxiL1 %f probxiK %f probxiP1 %f \n", logProbL1[0],logProbk[0],logProbP1[0],gammaL1,gammak,gammaP1,gammaP1k,gammaL1k ,LogLikeL1,LogLikek_k,LogLikeP1,LogLikek_L1,LogLikek_P1,  probxiL1, probxiK, probxiP1                 );
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // L1 e P1
                    if(nk<length)
                    {
                        double PP[2];
                        PP[0] = logProb.vec(0);
                        PP[1] = logProb.vec(2);
                        samp = Class_Utils::sample_DiscreteVar(PP, 2);
                        if(samp==1)
                        {
                            samp = 2;
                        }
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                    }
                    
                }else{
                    // L1
                    if(nk<length)
                    {
                        samp = 0;
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                    }
                    
                }
            }else{
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // P1
                    if(nk<length)
                    {
                        samp = 2;
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(1), 2)+1;
                    }
                }else{
                    StopMerge   = 1;
                    samp        = 5;
                }
            }
            //logProb.Print("A");
            
            REprintf("Kobs %i  samp %i probxiL1 %f probxiP1 %f probxiK %f nk %i\n", Kobs, samp,probxiL1,probxiP1 ,probxiK, nk);
            
            // xi
            REprintf("pre sample samp %i startk %i endk %i\n",samp,startk,endk);
            for(k=0;k<ClustIndex.size();k++)
            {
                REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
            }
            
            if(samp==0)
            {
                for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                {
                    logSumXI[jjj]  =  log(exp( logSumXI[jjj] )- exp(logXI[kxi]));
                }
                logXI.erase(logXI.begin()+kxi);
                logSumXI.erase(logSumXI.begin()+kxi);
                ClustIndex.erase(ClustIndex.begin()+kxi);
                kxi--;
                
                
            }
            if(samp==1)
            {
                kxi++;
            }
            if(samp==2)
            {
                for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                {
                    logSumXI[jjj]  =  log(exp( logSumXI[jjj] )- exp(logXI[kxi]));
                }
                logXI.erase(logXI.begin()+kxi);
                logSumXI.erase(logSumXI.begin()+kxi);
                ClustIndex.erase(ClustIndex.begin()+kxi);
                kxi = kxi;
            }
            logSumXI[0] = 0;
            REprintf("post sample\n");
            for(k=0;k<ClustIndex.size();k++)
            {
                REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
            }
            REprintf("IndicesPre %i %i %i\n", IndexL1,Indexk,IndexP1);
            
            if(samp==0)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexL1;
                }
                
                //VecStart.Pvec(IndexL1)[0]       = VecStart.Pvec(IndexL1)[0];
                VecEnd.Pvec(IndexL1)[0]         = VecEnd.Pvec(Indexk)[0];
                VecN.Pvec(IndexL1)[0]           = VecN.Pvec(IndexL1)[0]+VecN.Pvec(Indexk)[0];
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                
                
                
                Indexk     = IndexL1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                
                
                
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
                
                
            }
            if(samp==1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)==1)
                {
                    StopMerge = 1;
                }else{
                    if(Class_Utils::ifelse(endP1,nObs-1,1,0)!=1)
                    {
                        IndexP1     = VecSuc.vec(IndexP1);
                        startP1     = VecStart.vec(IndexP1);
                        endP1       = VecEnd.vec(IndexP1);
                        nP1         = VecN.vec(IndexP1);
                    }
                    
                    Indexk     = VecSuc.vec(Indexk);
                    startk     = VecStart.vec(Indexk);
                    endk       = VecEnd.vec(Indexk);
                    nk         = VecN.vec(Indexk);
                    
                    IndexL1     = VecPrec.vec(Indexk);
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                
                
            }
            if(samp==2)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexP1;
                }
                VecStart.Pvec(IndexP1)[0]       = VecStart.Pvec(Indexk)[0];
                //VecEnd.Pvec(IndexP1)[0]         = VecEnd.Pvec(IndexP1)[0];
                VecN.Pvec(IndexP1)[0]           = VecN.Pvec(IndexP1)[0]+VecN.Pvec(Indexk)[0];
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                Indexk     = IndexP1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
            }
            REprintf("IndicesPost %i %i %i\n", IndexL1,Indexk,IndexP1);
            for(int iii=0;iii<6;iii++)
            {
                REprintf("State %i - %i %i %i %i %i\n", iii, VecStart.vec(iii),VecEnd.vec(iii),VecN.vec(iii), VecPrec.vec(iii) , VecSuc.vec(iii));
            }
            
            countr++;
            if(countr ==9)
            {
                error("S %i",countr);
            }
            REprintf("\n\n\n");
        }
        error("S %i",countr);
        if(ControllWhile>Kobs*Kobs)
        {
            error("CONTROLLARE WHILE LOOP");
        }
        
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        
        Clusters->update_EmptyAndNonEmptyClusters();
        
        
        
        
        
        
        //Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    
    
    
    
    void samp_stChangePointSplit(Class_Parameter *eta, int length, vector<VectorParameters> &xi, vector <Matrix<int >* >  &FromCpToLevel2, int isp)
    {
        //Rprintf("Split\n");
        int ErrorNumberClusters = 0;
        int CheckError = 0;
        int Kobs;
        //int KobsStar;
        int Kempty;
        //int k;
        int k0;
        int k0prec;
        int kK;
        
        
        int deltaP1;
        int deltaL1;
        int deltak;
        
        int kNew;
        int i,j;
        int samp;
        //int knext;
        int KmaxObs;
        int KFirstObs;
        int KsecondObs;
        int KmaxObsL1;
        int kSeq;
        int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        double appProb;
        
        //double LogLikeL1 = 0.0;
        //double LogLikeP1 = 0.0;
        //double LogLikek_New = 0.0;
        double LogLikek_k = 0.0;
        double LogLikek_P1 = 0.0;
        double LogLikek_L1 = 0.0;
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int startL1pre = 0;
        int endL1 = 0;
        int endL1pre = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nL1pre = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexL1pre = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        double gammaP1 = 0.0;
        double gammaL1 = 0.0;
        double gammak = 0.0;
        double gammaL1k = 0.0;
        double gammaP1k = 0.0;
        
        
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        Kvoid = Clusters->nEmpty;
        Kempty = Clusters->nEmpty;
        
        
        
        
        
        k0 = 1;
        kK = 0;
        kNew = 0;
        
        deltaP1 = 0;
        deltaL1 = 0;
        deltak = 0;
        
        k0prec = 1;
        
        //
        
        
        
        //KobsStar = Kobs;
        KmaxObs = Clusters->NonEmptyC.vec(Kobs-1);
        KFirstObs = Clusters->NonEmptyC.vec(0);
        
        if(Kobs>1)
        {
            KmaxObsL1 = Clusters->NonEmptyC.vec(Kobs-2);
            KsecondObs = Clusters->NonEmptyC.vec(1);
        }else{
            KmaxObsL1 = KmaxObs;
            KsecondObs = KFirstObs;
        }
        
        
        
        //if(Kobs>1)
        //{
        
        kSeq                = 0;
        IndexL1             = Clusters->NonEmptyC.vec(kSeq);
        IndexL1pre = IndexL1;
        if(Kobs>1)
        {
            IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
        }else{
            IndexP1             = IndexL1;
        }
        Indexk              = Clusters->EmptyC.vec(kNew);
        
        
        startk      = 0;
        startL1     = 0;
        startL1pre     = startL1;
        
        
        endL1       = startL1;
        endL1pre = endL1;
        endk        = startL1+Clusters->NObsInClust.vec(IndexL1)-1;
        
        
        nL1         = endL1-startL1+1;
        nL1pre         = nL1;
        nk          = endk-startk+1; //
        
        if(Kobs>1)
        {
            //Rprintf("MMM %i \n",Kobs);
            startP1     = startL1+Clusters->NObsInClust.vec(IndexL1);
            endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
            nP1         = endP1-startP1+1;
        }
        
        if(Clusters->nEmpty==0)
        {
            ErrorNumberClusters = 1;
            CheckError = 1;
            //Rprintf("Inizia con il numero max di stati\n");
        }
        
        
        //       Clusters->Zeta.Print("Zeta");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //Rprintf("\nSPLIT\n");
        
        
        
        /**** nuovi parametri ****/
        double probxiL1;
        double probxiP1;
        double probxiK;
        
        
        
        
        vector <int> ClustIndex;
        
        
        //REprintf("Cluster \n%i \n",Clusters->Zeta.vec(0));
        ClustIndex.push_back(Clusters->Zeta.vec(0));
        for(i=1;i<nObs;i++)
        {
            //REprintf("%i \n",Clusters->Zeta.vec(i));
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                ClustIndex.push_back(Clusters->Zeta.vec(i));
            }
        }
        
        
        vector <double> logXI;
        vector <double> logSumXI;
        for(int k=0;k<Kmax;k++)
        {
            logXI.push_back(0.0);
            int ipar;
            
            ipar = 0;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(k,isp)));
            ipar = 2;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(k,isp)));
            ipar = 4;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(k,isp)) );
            for(ipar=5;ipar<12;ipar++)
            {
                logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(k,isp)) );
            }
        }
        for(int k=0;k<ClustIndex.size();k++)
        {
            logXI.push_back(0.0);
            logSumXI.push_back(0.0);
            
        }
        
        double AppSum[Kmax];
        logSumXI[0] = 0;
        for(int k=1;k<ClustIndex.size();k++)
        {
            AppSum[k] = logXI[ClustIndex[k-1]];
            Class_Utils::log_sum_exp(&logSumXI[k],k, &AppSum[1]);
        }
        
        
        
        int kxi = 0;
        
        /**** nuovi parametri  END ****/
        
        
        
        for(i=0;i<nObs;i++)
        {
            
            if(ErrorNumberClusters==1)
            {
                if(CheckError==0)
                {
                    //Rprintf("K may be non well estimated\n");
                    CheckError = 1;
                }
                
            }else{
                if((startL1==startk)&(nk>0))
                {
                    //Rprintf("Nuovo codice");
                    
                    LogLikek_k = 0.0;
                    LogLikek_P1 = 0.0;
                    LogLikek_L1 = 0.0;
                    
                    
                    j = startk;
                    ObsY.P = Y.Pmat(j,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                    LogLikek_k += appProb;
                    
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                    LogLikek_L1 += appProb;
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1pre],j);
                        LogLikek_P1 += appProb;
                    }
                    
                    // if(nk>1)
                    // {
                    
                    // }else{
                    //     gammaL1     = 0.0;
                    //     gammaL1k     = 0.0;
                    // }
                    
                    gammaL1         = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0),nk-1);
                    gammaL1k        = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0),nk);
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        gammaP1    = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1pre);
                        gammaP1k   = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1pre+1);
                    }else{
                        gammaP1    = 0.0;
                        gammaP1k   = 0.0;
                    }
                    
                    gammak          = compute_loggammaSampleCP(eta->ParameterAcc, 0,1);
                    
                    
                    // contributo prob G_0
                    probxiL1 = 0.0;
                    probxiP1 = 0.0;
                    probxiK  = logXI[Indexk];
                    
                    for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                    {
                        probxiK -= Class_Utils::log1mexp( log(exp( logSumXI[jjj] )+ exp(logXI[Indexk])  ));
                    }
                    if(kxi==0)
                    {
                        probxiK -= Class_Utils::log1mexp(logXI[Indexk]);
                    }else{
                        probxiK -= Class_Utils::log1mexp( log(exp( logSumXI[kxi] )+ exp(logXI[Indexk])  ));
                    }
                    for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                    {
                        probxiP1 -= Class_Utils::log1mexp( logSumXI[jjj]);
                    }
                    probxiL1 = probxiP1;
                    
                    logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1+probxiL1;
                    logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1+probxiP1;
                    logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k+probxiK;
                    
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                        //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                        //Rprintf("SAmpione su 2, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                    }
                    if(length>1)
                    {
                        samp = 0;
                    }
                    //REprintf("%i %i \n", nk, length);
                    
                    
                    //                    REprintf("Kobs %i  samp %i probxiL1 %f probxiP1 %f probxiK %f nk %i \n prob %f %f %f\n  ", Kobs, samp,probxiL1,probxiP1 ,probxiK, nk, logProbL1[0] ,
                    //                             logProbP1[0],
                    //                             logProbk[0] );
                    //                    // xi
                    //                    REprintf("pre sample\n");
                    //                    for(int k=0;k<ClustIndex.size();k++)
                    //                    {
                    //                        REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i logXI[Indexk] %f\n",logXI[ClustIndex[k]],logSumXI[k],ClustIndex[k],logXI[Indexk] );
                    //                    }
                    if(samp==0)
                    {
                        
                    }
                    if(samp==1)
                    {
                        for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                        {
                            logSumXI[jjj] =  Class_Utils::log1mexp( log(exp( logSumXI[jjj] )+ exp(logXI[Indexk])  ));
                        }
                    }
                    if(samp==2)
                    {
                        
                    }
                    if(samp==0)
                    {
                        // rimando su dove ero
                        //                    Rprintf("\nS0\n");
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        // NO_ERROR Indexk      = Indexk;
                        
                        // NO_ERROR startL1     = startL1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        // NO_ERROR endL1pre       = endL1pre;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                    }
                    if(samp==1)
                    {
                        // cmapiono k
                        //                    Rprintf("\nS1\n");
                        //
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j=startk;
                        Clusters->Zeta.Pvec(j)[0]  = Indexk;
                        
                        startL1pre     = startk;
                        endL1pre       = startk;
                        nL1pre         = endL1pre-startL1pre+1;
                        IndexL1pre     = Indexk;
                        
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        startk      = startL1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                    }
                    if(samp==2)
                    {
                        // passo a quello prima
                        //                    Rprintf("\nS2\n");
                        //                    Rprintf("%f %f \n", logProbL1[0],logProbk[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j= startk;
                        Clusters->Zeta.Pvec(j)[0]  = IndexL1pre;
                        
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        endL1pre       = endL1pre+1;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                    }
                    
                    
                    
                }else{
                    if((nk!=0))
                    {
                        //Rprintf("Vecchio codice\n");
                        
                        
                        if(nL1==1)
                        {
                            LogLikek_k = 0.0;
                            LogLikek_P1 = 0.0;
                            LogLikek_L1 = 0.0;
                            
                            for(j=startk;j<=endk;j++)
                            {
                                ObsY.P = Y.Pmat(j,0);
                                //ObsY.Print("Y");
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                                LogLikek_k += appProb;
                                //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                                LogLikek_L1 += appProb;
                                //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                                
                                
                                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                                {
                                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                    LogLikek_P1 += appProb;
                                    //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                                }
                            }
                            
                        }else{
                            j = startk-1;
                            
                            ObsY.P = Y.Pmat(j,0);
                            //ObsY.Print("Y");
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                            LogLikek_k -= appProb;
                            //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                            LogLikek_L1 -= appProb;
                            //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                            
                            
                            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                            {
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                LogLikek_P1 -= appProb;
                                //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                            }
                        }
                        
                        gammaL1     = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1);
                        
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            gammaP1     = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1,nObs-1,1,0),nP1);
                            gammaP1k    = compute_loggammaSampleCP(eta->ParameterAcc,Class_Utils::ifelse(endP1,nObs-1,1,0), nP1+nk);
                        }else{
                            gammaP1     = 0.0;
                            gammaP1k    = 0.0;
                        }
                        
                        gammak      = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0), nk);
                        gammaL1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0), nL1+nk);
                        
                        
                        probxiL1 = 0.0;
                        probxiP1 = 0.0;
                        probxiK  = logXI[Indexk];
                        
                        for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                        {
                            probxiK -= Class_Utils::log1mexp( log(exp( logSumXI[jjj] )+ exp(logXI[Indexk])  ));
                        }
                        if(kxi==0)
                        {
                            probxiK -= Class_Utils::log1mexp(logXI[Indexk]);
                        }else{
                            probxiK -= Class_Utils::log1mexp( log(exp( logSumXI[kxi] )+ exp(logXI[Indexk])  ));
                        }
                        for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                        {
                            probxiP1 -= Class_Utils::log1mexp( logSumXI[jjj]);
                        }
                        probxiL1 = probxiP1;
                        
                        logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1+probxiL1;
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1+probxiP1;
                        }
                        
                        logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k+probxiK;
                        
                        
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                            //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                        }else{
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                            //Rprintf("SAmpione su 2, z=%i %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                        }
                        
                        //                        REprintf("Kobs %i  samp %i probxiL1 %f probxiP1 %f probxiK %f nk %i \n prob %f %f %f\n  ", Kobs, samp,probxiL1,probxiP1 ,probxiK, nk, logProbL1[0] ,
                        //                                 logProbP1[0],
                        //                                 logProbk[0] );
                        //                        // xi
                        //                        REprintf("pre sample\n");
                        //                        for(int k=0;k<ClustIndex.size();k++)
                        //                        {
                        //                            REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i logXI[Indexk] %f\n",logXI[ClustIndex[k]],logSumXI[k],ClustIndex[k],logXI[Indexk] );
                        //                        }
                        if((nk<length)||(nL1<length))
                        {
                            samp = 0;
                        }
                        if(samp==0)
                        {
                            
                        }
                        if(samp==1)
                        {
                            for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                            {
                                logSumXI[jjj] =  Class_Utils::log1mexp( log(exp( logSumXI[jjj] )+ exp(logXI[Indexk])  ));
                            }
                        }
                        if(samp==2)
                        {
                            
                        }
                        
                        //Rprintf("Samp %i\n", samp);
                        if(samp==0)
                        {
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            // NO_ERROR Indexk      = Indexk;
                            
                            
                            // NO_ERROR startL1     = startL1;
                            endL1       = endL1+1;
                            nL1         = endL1-startL1+1;
                            // NO_ERROR IndexL1      = IndexL1;
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            // NO_ERROR startL1pre     = startL1pre;
                            // NO_ERROR endL1pre       = endL1pre;
                            nL1pre         = endL1pre-startL1pre+1;
                            // NO_ERROR IndexL1pre      = IndexL1pre;
                            
                            
                            
                        }
                        if(samp==1)
                        {
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = Indexk;
                            }
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre          = nL1;
                            IndexL1pre      = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = Indexk;
                            
                            
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            kNew++;
                            if(kNew>=(Kvoid-2))
                            {
                                ErrorNumberClusters = 1;
                            }else{
                                
                                Indexk              = Clusters->EmptyC.vec(kNew);
                            }
                        }
                        if(samp==2)
                        {
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = IndexP1;
                            }
                            
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre              = nL1;
                            IndexL1pre          = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            endk        = endP1;
                            nk          = endk-startk+1;
                            // NO_ERROR Indexk      = Indexk;
                            //                            kNew++;
                            //                            if(kNew>=(Kvoid-2))
                            //                            {
                            //                                ErrorNumberClusters = 1;
                            //                            }else{
                            //
                            //                                Indexk              = Clusters->EmptyC.vec(kNew);
                            //                            }
                            
                            
                            if(IndexL1!=KmaxObs)
                            {
                                kSeq++;
                                IndexP1      =  Clusters->NonEmptyC.vec(kSeq+1);
                                startP1     = endk+1;
                                endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                nP1         = endP1-startP1+1;
                            }
                            
                        }
                        
                        
                    }else{
                        if(IndexL1!=KmaxObs)
                        {
                            //Rprintf("Non campiono\n");
                            
                            kxi++;
                            startL1pre = startL1;
                            endL1pre = endL1;
                            nL1pre  = nL1;
                            IndexL1pre = IndexL1;
                            
                            IndexL1             = IndexP1;
                            startL1             = startP1;
                            endL1               = startP1;
                            nL1                 = endL1-startL1+1;
                            
                            
                            // NO_ERROR Indexk              = Indexk;
                            startk              = startL1;
                            endk                = endP1;
                            nk                  = endk-startk+1;
                            
                            if(IndexP1!=KmaxObs)
                            {
                                kSeq++;
                                //Rprintf("\nSstar1\n");
                                IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
                                //Rprintf("\nSstar2\n");
                                startP1             = startL1+Clusters->NObsInClust.vec(IndexL1);
                                //Rprintf("\nSsta3\n");
                                endP1               = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                //Rprintf("\nSstar5\n");
                                nP1                 = endP1-startP1+1;
                            }
                        }
                        
                    }
                }
            }
            
            
            
            
            
        }
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        //Clusters->Zeta.Print("ZetaPost");
        
        //Clusters->Zeta.Print("Zeta");
        
        //error("STOP");
        Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    void samp_stChangePointSplit_withPi(Vector <double> *Pi, Vector <double> *PiStick, int lengths,int isp)
    {
        //Rprintf("Split\n");
        int ErrorNumberClusters = 0;
        int CheckError = 0;
        int Kobs;
        //int KobsStar;
        int Kempty;
        //int k;
        int k0;
        int k0prec;
        int kK;
        
        
        
        
        int kNew;
        int i,j;
        int samp;
        //int knext;
        int KmaxObs;
        int KFirstObs;
        int KsecondObs;
        int KmaxObsL1;
        int kSeq;
        int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        double appProb;
        
        //double LogLikeL1 = 0.0;
        //double LogLikeP1 = 0.0;
        //double LogLikek_New = 0.0;
        double LogLikek_k = 0.0;
        double LogLikek_P1 = 0.0;
        double LogLikek_L1 = 0.0;
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int startL1pre = 0;
        int endL1 = 0;
        int endL1pre = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nL1pre = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexL1pre = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        //        double gammaP1 = 0.0;
        //        double gammaL1 = 0.0;
        //        double gammak = 0.0;
        //        double gammaL1k = 0.0;
        //        double gammaP1k = 0.0;
        
        
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        Kvoid = Clusters->nEmpty;
        Kempty = Clusters->nEmpty;
        
        
        
        
        
        k0 = 1;
        kK = 0;
        kNew = 0;
        
        //        deltaP1 = 0;
        //        deltaL1 = 0;
        //        deltak = 0;
        
        k0prec = 1;
        
        //
        
        
        
        //KobsStar = Kobs;
        KmaxObs = Clusters->NonEmptyC.vec(Kobs-1);
        KFirstObs = Clusters->NonEmptyC.vec(0);
        
        if(Kobs>1)
        {
            KmaxObsL1 = Clusters->NonEmptyC.vec(Kobs-2);
            KsecondObs = Clusters->NonEmptyC.vec(1);
        }else{
            KmaxObsL1 = KmaxObs;
            KsecondObs = KFirstObs;
        }
        
        
        
        //if(Kobs>1)
        //{
        
        kSeq                = 0;
        IndexL1             = Clusters->NonEmptyC.vec(kSeq);
        IndexL1pre = IndexL1;
        if(Kobs>1)
        {
            IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
        }else{
            IndexP1             = IndexL1;
        }
        Indexk              = Clusters->EmptyC.vec(kNew);
        
        
        startk      = 0;
        startL1     = 0;
        startL1pre     = startL1;
        
        
        endL1       = startL1;
        endL1pre = endL1;
        endk        = startL1+Clusters->NObsInClust.vec(IndexL1)-1;
        
        
        nL1         = endL1-startL1+1;
        nL1pre         = nL1;
        nk          = endk-startk+1; //
        
        if(Kobs>1)
        {
            //Rprintf("MMM %i \n",Kobs);
            startP1     = startL1+Clusters->NObsInClust.vec(IndexL1);
            endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
            nP1         = endP1-startP1+1;
        }
        
        if(Clusters->nEmpty==0)
        {
            ErrorNumberClusters = 1;
            CheckError = 1;
            //Rprintf("Inizia con il numero max di stati\n");
        }
        
        
        //       Clusters->Zeta.Print("Zeta");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //Rprintf("\nSPLIT\n");
        
        
        
        /**** nuovi parametri ****/
        double probxiL1;
        double probxiP1;
        double probxiK;
        
        
        
        
        vector <int> ClustIndex;
        vector <int> ClustN;
        
        
        
        ClustIndex.push_back(Clusters->Zeta.vec(0));
        ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[0]));
        for(i=1;i<nObs;i++)
        {
            //REprintf("%i \n",Clusters->Zeta.vec(i));
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                ClustIndex.push_back(Clusters->Zeta.vec(i));
                ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[ClustIndex.size()-1]));
            }
        }
        
        
        //vector <double> logPI;
        //vector <double> NologPI;
        vector <double> logSumPI;
        for(int k=0;k<ClustIndex.size();k++)
        {
            logSumPI.push_back(0.0);
            //NologPI.push_back(Pi->vec(ClustIndex[k]));
            //logPI.push_back(Pi->vec(log(ClustIndex[k])));
        }
        
        //Pi->Print("pi");
        //PiStick->Print("stick");
        for(int k=0;k<ClustIndex.size();k++)
        {
            logSumPI.push_back(0.0);
        }
        
        double AppSum[Kmax];
        logSumPI[0] = 0;
        for(int k=1;k<ClustIndex.size();k++)
        {
            AppSum[k] = log(Pi->vec(ClustIndex[k-1]));
            Class_Utils::log_sum_exp(&logSumPI[k],k, &AppSum[1]);
        }
        
        
        //        REprintf("Cluster \n%i \n",Clusters->Zeta.vec(0));
        //        for(i=1;i<nObs;i++)
        //        {
        //            REprintf("%i \n",Clusters->Zeta.vec(i));
        //        }
        //        REprintf("Stato inziale \n");
        //        for(int k=0;k<ClustIndex.size();k++)
        //        {
        //            REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i %i\n",log(Pi->vec(ClustIndex[k])),logSumPI[k],ClustIndex[k] ,ClustN[k]);
        //        }
        
        
        
        int kL1 = 0;
        
        /**** nuovi parametri  END ****/
        
        
        
        for(i=0;i<nObs;i++)
        {
            //REprintf("\n\n%i\n",i);
            if(ErrorNumberClusters==1)
            {
                if(CheckError==0)
                {
                    //Rprintf("K may be non well estimated\n");
                    CheckError = 1;
                }
                
            }else{
                if((startL1==startk)&(nk>0))
                {
                    //Rprintf("Nuovo codice");
                    
                    LogLikek_k = 0.0;
                    LogLikek_P1 = 0.0;
                    LogLikek_L1 = 0.0;
                    
                    
                    j = startk;
                    ObsY.P = Y.Pmat(j,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                    LogLikek_k += appProb;
                    
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                    LogLikek_L1 += appProb;
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1pre],j);
                        LogLikek_P1 += appProb;
                    }
                    
                    
                    // contributo prob G_0
                    
                    //REprintf("probxiK kL1=%i \n", kL1);
                    
                    
                    probxiP1 = probxiL1 = probxiK = 0.0;
                    for(int jjj=kL1;jjj<ClustIndex.size();jjj++)
                    {
                        double n1 =1.0*(ClustN[jjj]-lengths+1);
                        
                        probxiL1 -= n1*Class_Utils::log1mexp(logSumPI[jjj]);
                        probxiK -=  n1*Class_Utils::log1mexp(log(exp(logSumPI[jjj])+Pi->vec(Indexk)));
                        //REprintf("jjj=%i n1 %f suml1 %f sumk %f ,l1 %f k %f\n",jjj,n1,logSumPI[jjj],log(exp(logSumPI[jjj])+Pi->vec(Indexk)),probxiL1,probxiK);
                    }
                    if(IndexL1!=IndexL1pre)
                    {
                        probxiP1 = probxiL1;
                    }
                    
                    probxiK += (1.0*(nk-lengths+1))* (log(Pi->vec(Indexk))-Class_Utils::log1mexp(logSumPI[kL1]));
                    probxiL1 += (1.0*nk)* (log(Pi->vec(IndexL1))-Class_Utils::log1mexp(logSumPI[kL1]));
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        probxiP1 = (1.0*nk)* log(Pi->vec(IndexL1pre)-Class_Utils::log1mexp(logSumPI[kL1-1]));
                    }
                    
                    
                    //REprintf("Start probxiL1 %f probxiK %f probxiP1 %f\n",probxiL1, probxiK, probxiP1);
                    //REprintf("Probs probxiL1 %f probxiK %f probxiP1 %f\n",Pi->vec(IndexL1),Pi->vec(Indexk), Pi->vec(IndexL1pre));
                    
                    
                    logProbL1[0]        = LogLikek_L1+probxiL1;
                    logProbP1[0]        = LogLikek_P1+probxiP1;
                    logProbk[0]         = LogLikek_k+probxiK;
                    
                    //REprintf("PREV %f %f %f\n", logProbL1[0] ,logProbk[0],logProbP1[0]  );
                    if(IndexL1!=IndexL1pre)
                    {
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                        //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                        //Rprintf("SAmpione su 2, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                    }
                    if(lengths>1)
                    {
                        samp = 0;
                    }
                    
                    if(samp==0)
                    {
                        
                    }
                    if(samp==1)
                    {
                        logSumPI.insert(logSumPI.begin()+kL1,logSumPI[kL1] );
                        ClustIndex.insert(ClustIndex.begin()+kL1, Indexk);
                        ClustN[kL1] = ClustN[kL1]-nk;
                        ClustN.insert(ClustN.begin()+kL1, nk);
                        for(int jjj=kL1+1;jjj<ClustIndex.size();jjj++)
                        {
                            logSumPI[jjj] =  Class_Utils::log1mexp( log(exp( logSumPI[jjj] )+ exp(   log(Pi->vec(Indexk)) )  ));
                        }
                        kL1++;
                    }
                    if(samp==2)
                    {
                        ClustN[kL1-1] = ClustN[kL1-1]+nk;
                    }
                    if(samp==0)
                    {
                        // rimando su dove ero
                        //                    Rprintf("\nS0\n");
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        // NO_ERROR Indexk      = Indexk;
                        
                        // NO_ERROR startL1     = startL1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        // NO_ERROR endL1pre       = endL1pre;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                    }
                    if(samp==1)
                    {
                        // cmapiono k
                        //                    Rprintf("\nS1\n");
                        //
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j=startk;
                        Clusters->Zeta.Pvec(j)[0]  = Indexk;
                        
                        startL1pre     = startk;
                        endL1pre       = startk;
                        nL1pre         = endL1pre-startL1pre+1;
                        IndexL1pre     = Indexk;
                        
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        startk      = startL1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                    }
                    if(samp==2)
                    {
                        // passo a quello prima
                        //                    Rprintf("\nS2\n");
                        //                    Rprintf("%f %f \n", logProbL1[0],logProbk[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j= startk;
                        Clusters->Zeta.Pvec(j)[0]  = IndexL1pre;
                        
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        endL1pre       = endL1pre+1;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                    }
                    
                    
                    
                }else{
                    if((nk!=0))
                    {
                        //Rprintf("Vecchio codice\n");
                        
                        
                        if(nL1==1)
                        {
                            LogLikek_k = 0.0;
                            LogLikek_P1 = 0.0;
                            LogLikek_L1 = 0.0;
                            
                            for(j=startk;j<=endk;j++)
                            {
                                ObsY.P = Y.Pmat(j,0);
                                //ObsY.Print("Y");
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                                LogLikek_k += appProb;
                                //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                                LogLikek_L1 += appProb;
                                //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                                
                                
                                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                                {
                                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                    LogLikek_P1 += appProb;
                                    //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                                }
                            }
                            
                        }else{
                            j = startk-1;
                            
                            ObsY.P = Y.Pmat(j,0);
                            //ObsY.Print("Y");
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                            LogLikek_k -= appProb;
                            //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                            LogLikek_L1 -= appProb;
                            //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                            
                            
                            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                            {
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                LogLikek_P1 -= appProb;
                                //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                            }
                        }
                        
                        
                        //REprintf("probxiK kL1=%i \n", kL1);
                        
                        
                        probxiP1 = probxiL1 = probxiK = 0.0;
                        for(int jjj=kL1+1;jjj<ClustIndex.size();jjj++)
                        {
                            double n1 =1.0*(ClustN[jjj]-lengths+1);
                            
                            probxiL1 -= n1*Class_Utils::log1mexp(logSumPI[jjj]);
                            probxiK -=  n1*Class_Utils::log1mexp(log(exp(logSumPI[jjj])+Pi->vec(Indexk)));
                            //REprintf("jjj=%i n1 %f suml1 %f sumk %f ,l1 %f k %f\n",jjj,n1,logSumPI[jjj],log(exp(logSumPI[jjj])+Pi->vec(Indexk)),probxiL1,probxiK);
                        }
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            probxiP1 = probxiL1;
                        }
                        
                        probxiK += (1.0*(nk-lengths+1))* (log(Pi->vec(Indexk))-Class_Utils::log1mexp(       log(exp(logSumPI[kL1])+Pi->vec(IndexL1) )       ));
                        probxiL1 += (1.0*nk)* (log(Pi->vec(IndexL1))-Class_Utils::log1mexp(logSumPI[kL1]));
                        
                        if(IndexL1!=IndexL1pre)
                        {
                            probxiP1 = (1.0*nk)* log(Pi->vec(IndexP1)-Class_Utils::log1mexp(logSumPI[kL1+1]));
                        }
                        
                        
                        //REprintf("Start probxiL1 %f probxiK %f probxiP1 %f\n",probxiL1, probxiK, probxiP1);
                        //REprintf("Probs probxiL1 %f probxiK %f probxiP1 %f\n",Pi->vec(IndexL1),Pi->vec(Indexk), Pi->vec(IndexL1pre));
                        
                        
                        logProbL1[0]        = LogLikek_L1+probxiL1;
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            logProbP1[0]        = LogLikek_P1+probxiP1;
                        }
                        logProbk[0]         = LogLikek_k+probxiK;
                        
                        //REprintf("%f %f %f\n", logProbL1[0] ,logProbk[0],logProbP1[0]  );
                        
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                            //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                        }else{
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                            //Rprintf("SAmpione su 2, z=%i %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                        }
                        
                        //                        REprintf("Kobs %i  samp %i probxiL1 %f probxiP1 %f probxiK %f nk %i \n prob %f %f %f\n  ", Kobs, samp,probxiL1,probxiP1 ,probxiK, nk, logProbL1[0] ,
                        //                                 logProbP1[0],
                        //                                 logProbk[0] );
                        //                        // xi
                        //                        REprintf("pre sample\n");
                        //                        for(int k=0;k<ClustIndex.size();k++)
                        //                        {
                        //                            REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i logXI[Indexk] %f\n",logXI[ClustIndex[k]],logSumXI[k],ClustIndex[k],logXI[Indexk] );
                        //                        }
                        if((nk<lengths)||(nL1<lengths))
                        {
                            samp = 0;
                        }
                        if(samp==0)
                        {
                            
                        }
                        if(samp==1)
                        {
                            logSumPI.insert(logSumPI.begin()+kL1+1,log(exp(logSumPI[kL1])+Pi->vec(IndexL1)));
                            ClustN[kL1] = ClustN[kL1]-nk;
                            ClustN.insert(ClustN.begin()+kL1+1, nk);
                            ClustIndex.insert(ClustIndex.begin()+kL1+1, Indexk);
                            for(int jjj=kL1+2;jjj<ClustIndex.size();jjj++)
                            {
                                logSumPI[jjj] =  Class_Utils::log1mexp( log(exp( logSumPI[jjj] )+ Pi->vec(Indexk)  ));
                            }
                            
                        }
                        if(samp==2)
                        {
                            ClustN[kL1+1] = ClustN[kL1+1]+nk;
                        }
                        
                        //Rprintf("Samp %i\n", samp);
                        if(samp==0)
                        {
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            // NO_ERROR Indexk      = Indexk;
                            
                            
                            // NO_ERROR startL1     = startL1;
                            endL1       = endL1+1;
                            nL1         = endL1-startL1+1;
                            // NO_ERROR IndexL1      = IndexL1;
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            // NO_ERROR startL1pre     = startL1pre;
                            // NO_ERROR endL1pre       = endL1pre;
                            nL1pre         = endL1pre-startL1pre+1;
                            // NO_ERROR IndexL1pre      = IndexL1pre;
                            
                            
                            
                        }
                        if(samp==1)
                        {
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = Indexk;
                            }
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre          = nL1;
                            IndexL1pre      = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = Indexk;
                            
                            
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            kNew++;
                            if(kNew>=(Kvoid-2))
                            {
                                ErrorNumberClusters = 1;
                            }else{
                                
                                Indexk              = Clusters->EmptyC.vec(kNew);
                            }
                        }
                        if(samp==2)
                        {
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = IndexP1;
                            }
                            
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre              = nL1;
                            IndexL1pre          = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            endk        = endP1;
                            nk          = endk-startk+1;
                            // NO_ERROR Indexk      = Indexk;
                            //                            kNew++;
                            //                            if(kNew>=(Kvoid-2))
                            //                            {
                            //                                ErrorNumberClusters = 1;
                            //                            }else{
                            //
                            //                                Indexk              = Clusters->EmptyC.vec(kNew);
                            //                            }
                            
                            
                            if(IndexL1!=KmaxObs)
                            {
                                kSeq++;
                                IndexP1      =  Clusters->NonEmptyC.vec(kSeq+1);
                                startP1     = endk+1;
                                endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                nP1         = endP1-startP1+1;
                            }
                            
                        }
                        
                        
                    }else{
                        if(IndexL1!=KmaxObs)
                        {
                            //Rprintf("Non campiono\n");
                            
                            kL1++;
                            startL1pre = startL1;
                            endL1pre = endL1;
                            nL1pre  = nL1;
                            IndexL1pre = IndexL1;
                            
                            IndexL1             = IndexP1;
                            startL1             = startP1;
                            endL1               = startP1;
                            nL1                 = endL1-startL1+1;
                            
                            
                            // NO_ERROR Indexk              = Indexk;
                            startk              = startL1;
                            endk                = endP1;
                            nk                  = endk-startk+1;
                            
                            if(IndexP1!=KmaxObs)
                            {
                                kSeq++;
                                //Rprintf("\nSstar1\n");
                                IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
                                //Rprintf("\nSstar2\n");
                                startP1             = startL1+Clusters->NObsInClust.vec(IndexL1);
                                //Rprintf("\nSsta3\n");
                                endP1               = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                //Rprintf("\nSstar5\n");
                                nP1                 = endP1-startP1+1;
                            }
                        }
                        
                    }
                }
            }
            
            
            
            
            
        }
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        //Clusters->Zeta.Print("ZetaPost");
        
        //Clusters->Zeta.Print("Zeta");
        
        //error("STOP");
        Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    
    
    void samp_stChangePointMerge_withPi(Vector <double> *Pi, Vector <double> *PiStick, int lengths,int isp)
    {
        int ControllWhile = 0;
        int StopMerge = 0;
        int Kobs;
        int KobsStar;
        int Kempty;
        int k;
        //int k0;
        //int k0prec;
        //int kK;
        //int kKP1;
        //int kNew;
        int i;
        int samp;
        //int knext;
        
        
        //int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        
        
        
        double appProb;
        
        
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int endL1 = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        //        double gammaP1 = 0.0;
        //        double gammaL1 = 0.0;
        //
        //        double gammaL1k = 0.0;
        //        double gammaP1k = 0.0;
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        
        KobsStar = Kobs;
        Kempty = Clusters->nEmpty;
        
        
        int VecPrec_P[Kmax];
        Vector <int>VecPrec(Kmax, VecPrec_P);
        
        int VecSuc_P[Kmax];
        Vector <int>VecSuc(Kmax, VecSuc_P);
        VecSuc.Init(-99);
        
        int VecN_P[Kmax];
        Vector <int>VecN(Kmax, VecN_P);
        VecN.Init(-99);
        
        int VecStart_P[Kmax];
        Vector <int>VecStart(Kmax, VecStart_P);
        VecStart.Init(-99);
        
        int VecEnd_P[Kmax];
        Vector <int>VecEnd(Kmax, VecEnd_P);
        VecEnd.Init(-99);
        
        
        VecStart.Pvec(Clusters->Zeta.vec(0))[0] = 0;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                VecPrec.Pvec(Clusters->Zeta.vec(i))[0] = Clusters->Zeta.vec(i-1);
                VecSuc.Pvec(Clusters->Zeta.vec(i-1))[0] = Clusters->Zeta.vec(i);
                VecStart.Pvec(Clusters->Zeta.vec(i))[0] = i;
                VecEnd.Pvec(Clusters->Zeta.vec(i-1))[0] = i-1;
            }
        }
        VecEnd.Pvec(Clusters->Zeta.vec(nObs-1))[0] = nObs-1;
        for(k=0;k<Kmax;k++)
        {
            VecN.Pvec(k)[0] = Clusters->NObsInClust.vec(k);
        }
        
        
        //Likelihood->ProbSecondLev[0][ipar].VectorAcc.Pvec(k)[0];
        //knext       = 0;
        
        IndexL1     = Clusters->Zeta.vec(0);
        startL1     = VecStart.vec(IndexL1);
        endL1       = VecEnd.vec(IndexL1);
        nL1         = VecN.vec(IndexL1);
        
        
        Indexk     = Clusters->Zeta.vec(0);
        startk     = VecStart.vec(Indexk);
        endk       = VecEnd.vec(Indexk);
        nk         = VecN.vec(Indexk);
        
        if(Kobs>1)
        {
            IndexP1     = VecSuc.vec(Indexk);
            startP1     = VecStart.vec(IndexP1);
            endP1       = VecEnd.vec(IndexP1);
            nP1         = VecN.vec(IndexP1);
        }else{
            IndexP1     = Indexk;
            startP1     = startk;
            endP1       = endk;
            nP1         = nk;
        }
        
        
        
        /**** nuovi parametri ****/
        double probxiL1;
        double probxiP1;
        double probxiK;
        
        
        
        //
        //        vector <int> ClustIndex;
        //
        //
        //
        //        ClustIndex.push_back(Clusters->Zeta.vec(0));
        //        for(i=1;i<nObs;i++)
        //        {
        //            //REprintf("%i \n",Clusters->Zeta.vec(i));
        //            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
        //            {
        //                ClustIndex.push_back(Clusters->Zeta.vec(i));
        //            }
        //        }
        //
        //
        vector <int> ClustIndex;
        vector <int> ClustN;
        
        
        //REprintf("Cluster \n%i \n",Clusters->Zeta.vec(0));
        ClustIndex.push_back(Clusters->Zeta.vec(0));
        ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[0]));
        for(i=1;i<nObs;i++)
        {
            //REprintf("%i \n",Clusters->Zeta.vec(i));
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                ClustIndex.push_back(Clusters->Zeta.vec(i));
                ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[ClustIndex.size()-1]));
            }
        }
        
        //vector <double> logPI;
        vector <double> logSumPI;
        for(k=0;k<ClustIndex.size();k++)
        {
            //logPI.push_back(0.0);
            
            //logPI[k] = Pi->vec(ClustIndex[k]);
            
            
            
        }
        
        for(int k=0;k<ClustIndex.size();k++)
        {
            logSumPI.push_back(0.0);
        }
        
        double AppSum[Kmax];
        logSumPI[0] = 0;
        for(int k=1;k<ClustIndex.size();k++)
        {
            AppSum[k] = log(Pi->vec(ClustIndex[k-1]));
            Class_Utils::log_sum_exp(&logSumPI[k],k, &AppSum[1]);
        }
        
        //        double AppSum[Kmax];
        //        logSumXI[0] = 0;
        //        for(k=1;k<ClustIndex.size();k++)
        //        {
        //            AppSum[k] = logXI[k-1];
        //            Class_Utils::log_sum_exp(&logSumXI[k],k, &AppSum[1]);
        //        }
        
        //        REprintf("Cluster \n%i \n",Clusters->Zeta.vec(0));
        //        for(i=1;i<nObs;i++)
        //        {
        //            REprintf("%i \n",Clusters->Zeta.vec(i));
        //        }
        //        REprintf("Stato inziale \n");
        //        for(k=0;k<ClustIndex.size();k++)
        //        {
        //            REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
        //        }
        
        
        int kxi = 0;
        
        /**** nuovi parametri  END ****/
        if(Kobs==1)
        {
            StopMerge=1;
        }
        //Rprintf("Merge");
        while(StopMerge==0 ){
            
            ControllWhile++;
            
            double LogLikeL1 = 0.0;
            double LogLikeP1 = 0.0;
            //double LogLikek_New = 0.0;
            double LogLikek_k = 0.0;
            double LogLikek_P1 = 0.0;
            double LogLikek_L1 = 0.0;
            
            double gammak = 0.0;
            
            //LogLikeL1 = 0.0;
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                for(i=startL1;i<=endL1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                    LogLikeL1 += appProb;
                }
            }
            LogLikeP1 = 0.0;
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                for(i=startP1;i<=endP1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                    LogLikeP1 += appProb;
                }
            }
            
            
            LogLikek_k = 0.0;
            LogLikek_P1 = 0.0;
            LogLikek_L1 = 0.0;
            for(i=startk;i<=endk;i++)
            {
                ObsY.P = Y.Pmat(i,0);
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk], i);
                LogLikek_k += appProb;
                
                //Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexNew], i);
                //LogLikek_New += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                LogLikek_P1 += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                LogLikek_L1 += appProb;
            }
            
            
            //            gammak      = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk, nObs-1,1,0), nk);
            //
            //            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            //            {
            //                gammaL1     = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1);
            //                gammaL1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0), nL1+nk);
            //            }else{
            //                gammaL1     = 0.0;
            //                gammaL1k    = 0.0;
            //            }
            //
            //            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            //            {
            //                gammaP1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0), nP1+nk);
            //                gammaP1     = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0),nP1);
            //            }else{
            //                gammaP1k    = 0.0;
            //                gammaP1     = 0.0;
            //            }
            //
            probxiP1 = 0.0;
            probxiL1 = 0.0;
            probxiK = 0.0;
            
            
            probxiK = ( 1.0*(ClustN[kxi]-lengths+1) )*( Pi->vec(Indexk)-Class_Utils::log1mexp(logSumPI[kxi])  );
            for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
            {
                probxiK -= (1.0*ClustN[jjj])*Class_Utils::log1mexp(logSumPI[jjj]);
            }
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                probxiL1 = (1.0*ClustN[kxi])*( Pi->vec(IndexL1)-Class_Utils::log1mexp(logSumPI[kxi-1]));
                for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                {
                    probxiL1 -= (1.0*ClustN[jjj])*Class_Utils::log1mexp( log(exp(logSumPI[jjj])-Pi->vec(Indexk)) );
                    
                }
            }
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                probxiP1 = (1.0*ClustN[kxi])*( Pi->vec(IndexL1)-Class_Utils::log1mexp(logSumPI[kxi]));
                for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                {
                    probxiP1 -= (1.0*ClustN[jjj])*Class_Utils::log1mexp( log(exp(logSumPI[jjj])-Pi->vec(Indexk)) );
                }
            }
            
            //
            logProbL1[0]        = LogLikek_L1+LogLikeL1+LogLikeP1+probxiL1;
            logProbP1[0]        = LogLikek_P1+LogLikeP1+LogLikeL1+probxiP1;
            logProbk[0]         = LogLikek_k+LogLikeP1+LogLikeL1+probxiK;
            
            
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // L1 e P1
                    if(nk<lengths)
                    {
                        double PP[2];
                        PP[0] = logProb.vec(0);
                        PP[1] = logProb.vec(2);
                        samp = Class_Utils::sample_DiscreteVar(PP, 2);
                        if(samp==1)
                        {
                            samp = 2;
                        }
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                    }
                    
                }else{
                    // L1
                    if(nk<lengths)
                    {
                        samp = 0;
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                    }
                    
                }
            }else{
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // P1
                    if(nk<lengths)
                    {
                        samp = 2;
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(1), 2)+1;
                    }
                }else{
                    StopMerge   = 1;
                    samp        = 5;
                }
            }
            //logProb.Print("A");
            
            //            REprintf("Kobs %i  samp %i probxiL1 %f probxiP1 %f probxiK %f nk %i\n", Kobs, samp,probxiL1,probxiP1 ,probxiK, nk);
            //
            //            // xi
            //            REprintf("pre sample\n");
            //            for(k=0;k<ClustIndex.size();k++)
            //            {
            //                REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
            //            }
            if(samp==0)
            {
                for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                {
                    logSumPI[jjj]  =  log(exp( logSumPI[jjj] )- Pi->vec(Indexk));
                }
                ClustN[kxi-1] = ClustN[kxi-1]+ClustN[kxi];
                //logPI.erase(logPI.begin()+kxi);
                logSumPI.erase(logSumPI.begin()+kxi);
                ClustIndex.erase(ClustIndex.begin()+kxi);
                ClustN.erase(ClustN.begin()+kxi);
                kxi--;
                
                
            }
            if(samp==1)
            {
                kxi++;
            }
            if(samp==2)
            {
                for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                {
                    logSumPI[jjj]  =  log(exp( logSumPI[jjj] )- Pi->vec(Indexk));
                }
                ClustN[kxi+1] = ClustN[kxi+1]+ClustN[kxi];
                //logPI.erase(logPI.begin()+kxi);
                logSumPI.erase(logSumPI.begin()+kxi);
                ClustIndex.erase(ClustIndex.begin()+kxi);
                ClustN.erase(ClustN.begin()+kxi);
                kxi = kxi;
            }
            logSumPI[0] = 0;
            //            REprintf("post sample\n");
            //            for(k=0;k<ClustIndex.size();k++)
            //            {
            //                REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
            //            }
            
            
            if(samp==0)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexL1;
                }
                
                //VecStart.Pvec(IndexL1)[0]       = VecStart.Pvec(IndexL1)[0];
                VecEnd.Pvec(IndexL1)[0]         = VecEnd.Pvec(Indexk)[0];
                VecN.Pvec(IndexL1)[0]           = VecN.Pvec(IndexL1)[0]+VecN.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                
                Indexk     = IndexL1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
                
                
            }
            if(samp==1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)==1)
                {
                    StopMerge = 1;
                }else{
                    if(Class_Utils::ifelse(endP1,nObs-1,1,0)!=1)
                    {
                        IndexP1     = VecSuc.vec(IndexP1);
                        startP1     = VecStart.vec(IndexP1);
                        endP1       = VecEnd.vec(IndexP1);
                        nP1         = VecN.vec(IndexP1);
                    }
                    
                    Indexk     = VecSuc.vec(Indexk);
                    startk     = VecStart.vec(Indexk);
                    endk       = VecEnd.vec(Indexk);
                    nk         = VecN.vec(Indexk);
                    
                    IndexL1     = VecPrec.vec(Indexk);
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                
                
            }
            if(samp==2)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexP1;
                }
                VecStart.Pvec(IndexP1)[0]       = VecStart.Pvec(Indexk)[0];
                //VecEnd.Pvec(IndexP1)[0]         = VecEnd.Pvec(IndexP1)[0];
                VecN.Pvec(IndexP1)[0]           = VecN.Pvec(IndexP1)[0]+VecN.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                Indexk     = IndexP1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
            }
            
            
            
        }
        
        if(ControllWhile>Kobs*Kobs)
        {
            error("CONTROLLARE WHILE LOOP");
        }
        
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        
        Clusters->update_EmptyAndNonEmptyClusters();
        
        
        
        
        
        
        //Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    
    
    double gammaWithBetaAlphaCP(vector <int> *nk, vector <double> *logbetak, int m, double alpha, int start)
    {
        int nElem = (int)logbetak[0].size();
        int k;
        double ret = 0.0;
        double G1,G2,G3;
        double LogBetaVec[nElem];
        double LogBetaVecSum[nElem];
        double app = 0.0;
        k=0;
        LogBetaVec[k]       = logbetak[0][k];
        LogBetaVecSum[k]    = logbetak[0][k];
        for(k=1;k<nElem;k++)
        {
            LogBetaVec[k]       = logbetak[0][k];
            Class_Utils::log_sum_exp(&LogBetaVecSum[k],k+1, &LogBetaVec[0]);
        }
        for(k=start;k<nElem-1;k++)
        {
            G3 = lgamma1p(nk[0][k]-m+alpha+app+1);
            G1 =  lgamma(exp(logspace_add (log(nk[0][k]-m+1), log(alpha)+logbetak[0][k])));
            app = exp(Class_Utils::log1mexp(LogBetaVecSum[k])+log(alpha));
            G2 = lgamma1p(app);
            
            ret += G1+G2-G3;
            
        }
        k = nElem-1;
        G3 = lgamma1p(nk[0][k]-m+alpha+app);
        G1 =  lgamma(exp(logspace_add (log(nk[0][k]-m+1), log(alpha)+logbetak[0][k])));
        app = exp(Class_Utils::log1mexp(LogBetaVecSum[k])+log(alpha));
        G2 =  lgamma(app);
        ret += G1+G2-G3;
        
        return(ret);
    }
    
    void samp_stChangePointSplit_withPimarg(int lengths,int isp, Matrix<double> *logBeta2, double alpha)
    {
        //Rprintf("Split\n");
        int ErrorNumberClusters = 0;
        int CheckError = 0;
        int Kobs;
        //int KobsStar;
        int Kempty;
        //int k;
        int k0;
        int k0prec;
        int kK;
        
        
        
        
        int kNew;
        int i,j;
        int samp;
        //int knext;
        int KmaxObs;
        int KFirstObs;
        int KsecondObs;
        int KmaxObsL1;
        int kSeq;
        int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        double appProb;
        
        //double LogLikeL1 = 0.0;
        //double LogLikeP1 = 0.0;
        //double LogLikek_New = 0.0;
        double LogLikek_k = 0.0;
        double LogLikek_P1 = 0.0;
        double LogLikek_L1 = 0.0;
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int startL1pre = 0;
        int endL1 = 0;
        int endL1pre = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nL1pre = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexL1pre = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        //        double gammaP1 = 0.0;
        //        double gammaL1 = 0.0;
        //        double gammak = 0.0;
        //        double gammaL1k = 0.0;
        //        double gammaP1k = 0.0;
        
        
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        Kvoid = Clusters->nEmpty;
        Kempty = Clusters->nEmpty;
        
        
        
        
        
        k0 = 1;
        kK = 0;
        kNew = 0;
        
        //        deltaP1 = 0;
        //        deltaL1 = 0;
        //        deltak = 0;
        
        k0prec = 1;
        
        //
        
        
        
        //KobsStar = Kobs;
        KmaxObs = Clusters->NonEmptyC.vec(Kobs-1);
        KFirstObs = Clusters->NonEmptyC.vec(0);
        
        if(Kobs>1)
        {
            KmaxObsL1 = Clusters->NonEmptyC.vec(Kobs-2);
            KsecondObs = Clusters->NonEmptyC.vec(1);
        }else{
            KmaxObsL1 = KmaxObs;
            KsecondObs = KFirstObs;
        }
        
        
        
        //if(Kobs>1)
        //{
        
        kSeq                = 0;
        IndexL1             = Clusters->NonEmptyC.vec(kSeq);
        IndexL1pre = IndexL1;
        if(Kobs>1)
        {
            IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
        }else{
            IndexP1             = IndexL1;
        }
        Indexk              = Clusters->EmptyC.vec(kNew);
        
        
        startk      = 0;
        startL1     = 0;
        startL1pre     = startL1;
        
        
        endL1       = startL1;
        endL1pre = endL1;
        endk        = startL1+Clusters->NObsInClust.vec(IndexL1)-1;
        
        
        nL1         = endL1-startL1+1;
        nL1pre         = nL1;
        nk          = endk-startk+1; //
        
        if(Kobs>1)
        {
            //Rprintf("MMM %i \n",Kobs);
            startP1     = startL1+Clusters->NObsInClust.vec(IndexL1);
            endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
            nP1         = endP1-startP1+1;
        }
        
        if(Clusters->nEmpty==0)
        {
            ErrorNumberClusters = 1;
            CheckError = 1;
            //Rprintf("Inizia con il numero max di stati\n");
        }
        
        
        //       Clusters->Zeta.Print("Zeta");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //Rprintf("\nSPLIT\n");
        
        
        
        /**** nuovi parametri ****/
        double probxiL1;
        double probxiP1;
        double probxiK;
        
        
        
        
        vector <int> ClustIndex;
        vector <int> ClustN;
        vector <int> ClustNK;
        vector <int> ClustNL1;
        vector <int> ClustNP1;
        
        
        
        ClustIndex.push_back(Clusters->Zeta.vec(0));
        ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[0]));
        ClustNK.push_back(ClustN[ClustN.size()-1]);
        ClustNL1.push_back(ClustN[ClustN.size()-1]);
        ClustNP1.push_back(ClustN[ClustN.size()-1]);
        for(i=1;i<nObs;i++)
        {
            //REprintf("%i \n",Clusters->Zeta.vec(i));
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                ClustIndex.push_back(Clusters->Zeta.vec(i));
                ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[ClustIndex.size()-1]));
                ClustNK.push_back(ClustN[ClustN.size()-1]);
                ClustNL1.push_back(ClustN[ClustN.size()-1]);
                ClustNP1.push_back(ClustN[ClustN.size()-1]);
            }
        }
        
        
        //vector <double> logPI;
        //vector <double> NologPI;
        vector <double> logBetaVecK;
        vector <double> logBetaVecL1;
        vector <double> logBetaVecP1;
        for(int k=0;k<ClustIndex.size();k++)
        {
            logBetaVecK.push_back(logBeta2->mat(isp,ClustIndex[k]));
            logBetaVecL1.push_back(logBeta2->mat(isp,ClustIndex[k]));
            logBetaVecP1.push_back(logBeta2->mat(isp,ClustIndex[k]));
        }
        
        int kL1 = 0;
        
        //        /**** nuovi parametri  END ****/
        //        REprintf("L1\n");
        //        for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
        //        {
        //            REprintf("%i ",ClustNL1[hhh]);
        //        }
        //        REprintf("\n");
        //        for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
        //        {
        //            REprintf("%f ",logBetaVecL1[hhh]);
        //        }
        //        REprintf("\n");
        //
        //
        //        REprintf("K\n");
        //        for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
        //        {
        //            REprintf("%i ",ClustNK[hhh]);
        //        }
        //        REprintf("\n");
        //        for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
        //        {
        //            REprintf("%f ",logBetaVecK[hhh]);
        //        }
        //        REprintf("\n");
        //
        //        REprintf("P1\n");
        //        for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
        //        {
        //            REprintf("%i ",ClustNP1[hhh]);
        //        }
        //        REprintf("\n");
        //        for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
        //        {
        //            REprintf("%f ",logBetaVecP1[hhh]);
        //        }
        //        REprintf("\n\n\n");
        //
        
        for(i=0;i<nObs;i++)
        {
            //REprintf("\n\n%i\n",i);
            if(ErrorNumberClusters==1)
            {
                if(CheckError==0)
                {
                    //Rprintf("K may be non well estimated\n");
                    CheckError = 1;
                }
                
            }else{
                if((startL1==startk)&(nk>0))
                {
                    //Rprintf("Nuovo codice");
                    
                    LogLikek_k = 0.0;
                    LogLikek_P1 = 0.0;
                    LogLikek_L1 = 0.0;
                    
                    
                    j = startk;
                    ObsY.P = Y.Pmat(j,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                    LogLikek_k += appProb;
                    
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                    LogLikek_L1 += appProb;
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1pre],j);
                        LogLikek_P1 += appProb;
                    }
                    
                    
                    /***********/
                    //K
                    ClustNK[kL1] = ClustNK[kL1]-1;
                    ClustNK.insert(ClustNK.begin()+kL1, 1);
                    logBetaVecK.insert(logBetaVecK.begin()+kL1, logBeta2->mat(isp,Indexk));
                    probxiK = gammaWithBetaAlphaCP(&ClustNK, &logBetaVecK, lengths, alpha, 0);
                    
                    //L1
                    probxiL1 = gammaWithBetaAlphaCP(&ClustNL1, &logBetaVecL1, lengths, alpha, 0);
                    
                    //P1
                    probxiP1 = 0.0;
                    if(IndexL1!=IndexL1pre)
                    {
                        ClustNP1[kL1] = ClustNP1[kL1]-1;
                        ClustNP1[kL1-1] = ClustNP1[kL1-1]+1;
                        probxiP1 = gammaWithBetaAlphaCP(&ClustNP1, &logBetaVecP1, lengths, alpha, 0);
                    }
                    
                    /***********/
                    
                    logProbL1[0]        = LogLikek_L1+probxiL1;
                    logProbP1[0]        = LogLikek_P1+probxiP1;
                    logProbk[0]         = LogLikek_k+probxiK;
                    
                    //REprintf("PREV %f %f %f\n", logProbL1[0] ,logProbk[0],logProbP1[0]  );
                    if(IndexL1!=IndexL1pre)
                    {
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                        //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                        //Rprintf("SAmpione su 2, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                    }
                    if(1<lengths)
                    {
                        samp = 0;
                    }
                    if(nL1==1)
                    {
                        samp = 0;
                    }
                    
                    
                    //                    REprintf("samp-1\n %i\n probxiL1 %f,probxiK %f,probxiP1 %f, kL1 %i \n   logProbL1[0]  %f,logProbk[0]  %f,logProbP1[0]  %f \n   ",samp,probxiL1,probxiK,probxiP1, kL1, logProbL1[0],logProbk[0] ,logProbP1[0]);
                    //
                    //                    REprintf("L1\n");
                    //                    for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
                    //                    {
                    //                        REprintf("%i ",ClustNL1[hhh]);
                    //                    }
                    //                    REprintf("\n");
                    //                    for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
                    //                    {
                    //                        REprintf("%f ",logBetaVecL1[hhh]);
                    //                    }
                    //                    REprintf("\n");
                    //
                    //
                    //                    REprintf("K\n");
                    //                    for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
                    //                    {
                    //                        REprintf("%i ",ClustNK[hhh]);
                    //                    }
                    //                    REprintf("\n");
                    //                    for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
                    //                    {
                    //                        REprintf("%f ",logBetaVecK[hhh]);
                    //                    }
                    //                    REprintf("\n");
                    //
                    //                    REprintf("P1\n");
                    //                    for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
                    //                    {
                    //                        REprintf("%i ",ClustNP1[hhh]);
                    //                    }
                    //                    REprintf("\n");
                    //                    for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
                    //                    {
                    //                        REprintf("%f ",logBetaVecP1[hhh]);
                    //                    }
                    //                    REprintf("\n\n\n");
                    
                    if(samp==0)
                    {
                        ClustNK  = ClustNL1;
                        ClustNP1 = ClustNL1;
                        logBetaVecK = logBetaVecL1;
                        logBetaVecP1 = logBetaVecL1;
                    }
                    if(samp==1)
                    {
                        ClustNL1 = ClustNK;
                        ClustNP1 = ClustNK;
                        
                        logBetaVecL1 = logBetaVecK;
                        logBetaVecP1 = logBetaVecK;
                        
                        kL1++;
                    }
                    if(samp==2)
                    {
                        ClustNK  = ClustNP1;
                        ClustNL1 = ClustNP1;
                        
                        logBetaVecK = logBetaVecP1;
                        logBetaVecL1 = logBetaVecP1;
                    }
                    if(samp==0)
                    {
                        // rimando su dove ero
                        //                    Rprintf("\nS0\n");
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        // NO_ERROR Indexk      = Indexk;
                        
                        // NO_ERROR startL1     = startL1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        // NO_ERROR endL1pre       = endL1pre;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                    }
                    if(samp==1)
                    {
                        // cmapiono k
                        //                    Rprintf("\nS1\n");
                        //
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j=startk;
                        Clusters->Zeta.Pvec(j)[0]  = Indexk;
                        
                        startL1pre     = startk;
                        endL1pre       = startk;
                        nL1pre         = endL1pre-startL1pre+1;
                        IndexL1pre     = Indexk;
                        
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        startk      = startL1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                    }
                    if(samp==2)
                    {
                        // passo a quello prima
                        //                    Rprintf("\nS2\n");
                        //                    Rprintf("%f %f \n", logProbL1[0],logProbk[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j= startk;
                        Clusters->Zeta.Pvec(j)[0]  = IndexL1pre;
                        
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        endL1pre       = endL1pre+1;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                    }
                    
                    
                    
                }else{
                    if((nk!=0))
                    {
                        //Rprintf("Vecchio codice\n");
                        
                        
                        if(nL1==1)
                        {
                            LogLikek_k = 0.0;
                            LogLikek_P1 = 0.0;
                            LogLikek_L1 = 0.0;
                            
                            for(j=startk;j<=endk;j++)
                            {
                                ObsY.P = Y.Pmat(j,0);
                                //ObsY.Print("Y");
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                                LogLikek_k += appProb;
                                //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                                LogLikek_L1 += appProb;
                                //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                                
                                
                                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                                {
                                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                    LogLikek_P1 += appProb;
                                    //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                                }
                            }
                            
                        }else{
                            j = startk-1;
                            
                            ObsY.P = Y.Pmat(j,0);
                            //ObsY.Print("Y");
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                            LogLikek_k -= appProb;
                            //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                            LogLikek_L1 -= appProb;
                            //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                            
                            
                            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                            {
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                LogLikek_P1 -= appProb;
                                //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                            }
                        }
                        
                        
                        /***********/
                        
                        //K
                        ClustNK[kL1] = ClustNK[kL1]-nk;
                        ClustNK.insert(ClustNK.begin()+kL1+1, nk);
                        logBetaVecK.insert(logBetaVecK.begin()+kL1+1, logBeta2->mat(isp,Indexk));
                        probxiK = gammaWithBetaAlphaCP(&ClustNK, &logBetaVecK, lengths, alpha, 0);
                        
                        //L1
                        probxiL1 = gammaWithBetaAlphaCP(&ClustNL1, &logBetaVecL1, lengths, alpha, 0);
                        
                        //P1
                        probxiP1 = 0.0;
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            ClustNP1[kL1]   = ClustNP1[kL1]-nk;
                            ClustNP1[kL1+1] = ClustNP1[kL1+1]+nk;
                            probxiP1 = gammaWithBetaAlphaCP(&ClustNP1, &logBetaVecP1, lengths, alpha, 0);
                        }
                        
                        
                        /***********/
                        
                        
                        logProbL1[0]        = LogLikek_L1+probxiL1;
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            logProbP1[0]        = LogLikek_P1+probxiP1;
                        }
                        logProbk[0]         = LogLikek_k+probxiK;
                        
                        //REprintf("%f %f %f\n", logProbL1[0] ,logProbk[0],logProbP1[0]  );
                        
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                            //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                        }else{
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                            //Rprintf("SAmpione su 2, z=%i %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                        }
                        
                        
                        if((nk<lengths)||(nL1<lengths))
                        {
                            samp = 0;
                        }
                        
                        
                        //                       REprintf("samp-2 \n %i\n probxiL1 %f,probxiK %f,probxiP1 %f, kL1 %i \n   logProbL1[0]  %f,logProbk[0]  %f,logProbP1[0]  %f \n   ",samp,probxiL1,probxiK,probxiP1, kL1, logProbL1[0],logProbk[0] ,logProbP1[0]);
                        //
                        //                        REprintf("L1\n");
                        //                        for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
                        //                        {
                        //                            REprintf("%i ",ClustNL1[hhh]);
                        //                        }
                        //                        REprintf("\n");
                        //                        for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
                        //                        {
                        //                            REprintf("%f ",logBetaVecL1[hhh]);
                        //                        }
                        //                        REprintf("\n");
                        //
                        //
                        //                        REprintf("K\n");
                        //                        for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
                        //                        {
                        //                            REprintf("%i ",ClustNK[hhh]);
                        //                        }
                        //                        REprintf("\n");
                        //                        for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
                        //                        {
                        //                            REprintf("%f ",logBetaVecK[hhh]);
                        //                        }
                        //                        REprintf("\n");
                        //
                        //                        REprintf("P1\n");
                        //                        for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
                        //                        {
                        //                            REprintf("%i ",ClustNP1[hhh]);
                        //                        }
                        //                        REprintf("\n");
                        //                        for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
                        //                        {
                        //                            REprintf("%f ",logBetaVecP1[hhh]);
                        //                        }
                        //                        REprintf("\n\n\n");
                        
                        
                        if(samp==0)
                        {
                            ClustNK  = ClustNL1;
                            ClustNP1 = ClustNL1;
                            
                            logBetaVecK = logBetaVecL1;
                            logBetaVecP1 = logBetaVecL1;
                            
                        }
                        if(samp==1)
                        {
                            ClustNL1 = ClustNK;
                            ClustNP1 = ClustNK;
                            
                            logBetaVecP1 = logBetaVecK;
                            logBetaVecL1 = logBetaVecK;
                            kL1++;
                        }
                        if(samp==2)
                        {
                            ClustNK  = ClustNP1;
                            ClustNL1 = ClustNP1;
                            
                            logBetaVecK = logBetaVecP1;
                            logBetaVecL1 = logBetaVecP1;
                            kL1++;
                        }
                        
                        if(samp==0)
                        {
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            // NO_ERROR Indexk      = Indexk;
                            
                            
                            // NO_ERROR startL1     = startL1;
                            endL1       = endL1+1;
                            nL1         = endL1-startL1+1;
                            // NO_ERROR IndexL1      = IndexL1;
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            // NO_ERROR startL1pre     = startL1pre;
                            // NO_ERROR endL1pre       = endL1pre;
                            nL1pre         = endL1pre-startL1pre+1;
                            // NO_ERROR IndexL1pre      = IndexL1pre;
                            
                            
                            
                        }
                        if(samp==1)
                        {
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = Indexk;
                            }
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre          = nL1;
                            IndexL1pre      = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = Indexk;
                            
                            
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            kNew++;
                            if(kNew>=(Kvoid-2))
                            {
                                ErrorNumberClusters = 1;
                            }else{
                                
                                Indexk              = Clusters->EmptyC.vec(kNew);
                            }
                        }
                        if(samp==2)
                        {
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = IndexP1;
                            }
                            
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre              = nL1;
                            IndexL1pre          = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            endk        = endP1;
                            nk          = endk-startk+1;
                            // NO_ERROR Indexk      = Indexk;
                            //                            kNew++;
                            //                            if(kNew>=(Kvoid-2))
                            //                            {
                            //                                ErrorNumberClusters = 1;
                            //                            }else{
                            //
                            //                                Indexk              = Clusters->EmptyC.vec(kNew);
                            //                            }
                            
                            
                            if(IndexL1!=KmaxObs)
                            {
                                kSeq++;
                                IndexP1      =  Clusters->NonEmptyC.vec(kSeq+1);
                                startP1     = endk+1;
                                endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                nP1         = endP1-startP1+1;
                            }
                            
                        }
                        
                        
                    }else{
                        if(IndexL1!=KmaxObs)
                        {
                            //Rprintf("Non campiono\n");
                            
                            kL1++;
                            startL1pre = startL1;
                            endL1pre = endL1;
                            nL1pre  = nL1;
                            IndexL1pre = IndexL1;
                            
                            IndexL1             = IndexP1;
                            startL1             = startP1;
                            endL1               = startP1;
                            nL1                 = endL1-startL1+1;
                            
                            
                            // NO_ERROR Indexk              = Indexk;
                            startk              = startL1;
                            endk                = endP1;
                            nk                  = endk-startk+1;
                            
                            if(IndexP1!=KmaxObs)
                            {
                                kSeq++;
                                //Rprintf("\nSstar1\n");
                                IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
                                //Rprintf("\nSstar2\n");
                                startP1             = startL1+Clusters->NObsInClust.vec(IndexL1);
                                //Rprintf("\nSsta3\n");
                                endP1               = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                //Rprintf("\nSstar5\n");
                                nP1                 = endP1-startP1+1;
                            }
                        }
                        
                    }
                }
            }
            
            
            
            
            
        }
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        //Clusters->Zeta.Print("ZetaPost");
        
        //Clusters->Zeta.Print("Zeta");
        
        //error("STOP");
        Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    void samp_stChangePointMerge_withPimarg(int lengths,int isp, Matrix<double> *logBeta2, double alpha)
    {
        int ControllWhile = 0;
        int StopMerge = 0;
        int Kobs;
        int KobsStar;
        int Kempty;
        int k;
        //int k0;
        //int k0prec;
        //int kK;
        //int kKP1;
        //int kNew;
        int i;
        int samp;
        //int knext;
        
        
        //int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        
        
        
        double appProb;
        
        
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int endL1 = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        //        double gammaP1 = 0.0;
        //        double gammaL1 = 0.0;
        //
        //        double gammaL1k = 0.0;
        //        double gammaP1k = 0.0;
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        
        KobsStar = Kobs;
        Kempty = Clusters->nEmpty;
        
        
        int VecPrec_P[Kmax];
        Vector <int>VecPrec(Kmax, VecPrec_P);
        
        int VecSuc_P[Kmax];
        Vector <int>VecSuc(Kmax, VecSuc_P);
        VecSuc.Init(-99);
        
        int VecN_P[Kmax];
        Vector <int>VecN(Kmax, VecN_P);
        VecN.Init(-99);
        
        int VecStart_P[Kmax];
        Vector <int>VecStart(Kmax, VecStart_P);
        VecStart.Init(-99);
        
        int VecEnd_P[Kmax];
        Vector <int>VecEnd(Kmax, VecEnd_P);
        VecEnd.Init(-99);
        
        
        VecStart.Pvec(Clusters->Zeta.vec(0))[0] = 0;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                VecPrec.Pvec(Clusters->Zeta.vec(i))[0] = Clusters->Zeta.vec(i-1);
                VecSuc.Pvec(Clusters->Zeta.vec(i-1))[0] = Clusters->Zeta.vec(i);
                VecStart.Pvec(Clusters->Zeta.vec(i))[0] = i;
                VecEnd.Pvec(Clusters->Zeta.vec(i-1))[0] = i-1;
            }
        }
        VecEnd.Pvec(Clusters->Zeta.vec(nObs-1))[0] = nObs-1;
        for(k=0;k<Kmax;k++)
        {
            VecN.Pvec(k)[0] = Clusters->NObsInClust.vec(k);
        }
        
        
        //Likelihood->ProbSecondLev[0][ipar].VectorAcc.Pvec(k)[0];
        //knext       = 0;
        
        IndexL1     = Clusters->Zeta.vec(0);
        startL1     = VecStart.vec(IndexL1);
        endL1       = VecEnd.vec(IndexL1);
        nL1         = VecN.vec(IndexL1);
        
        
        Indexk     = Clusters->Zeta.vec(0);
        startk     = VecStart.vec(Indexk);
        endk       = VecEnd.vec(Indexk);
        nk         = VecN.vec(Indexk);
        
        if(Kobs>1)
        {
            IndexP1     = VecSuc.vec(Indexk);
            startP1     = VecStart.vec(IndexP1);
            endP1       = VecEnd.vec(IndexP1);
            nP1         = VecN.vec(IndexP1);
        }else{
            IndexP1     = Indexk;
            startP1     = startk;
            endP1       = endk;
            nP1         = nk;
        }
        
        
        
        /**** nuovi parametri ****/
        double probxiL1;
        double probxiP1;
        double probxiK;
        
        
        
        //
        //        vector <int> ClustIndex;
        //
        //
        //
        //        ClustIndex.push_back(Clusters->Zeta.vec(0));
        //        for(i=1;i<nObs;i++)
        //        {
        //            //REprintf("%i \n",Clusters->Zeta.vec(i));
        //            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
        //            {
        //                ClustIndex.push_back(Clusters->Zeta.vec(i));
        //            }
        //        }
        //
        //
        vector <int> ClustIndex;
        vector <int> ClustN;
        vector <int> ClustNK;
        vector <int> ClustNL1;
        vector <int> ClustNP1;
        
        
        //REprintf("Cluster \n%i \n",Clusters->Zeta.vec(0));
        ClustIndex.push_back(Clusters->Zeta.vec(0));
        ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[0]));
        ClustNK.push_back(ClustN[ClustN.size()-1]);
        ClustNL1.push_back(ClustN[ClustN.size()-1]);
        ClustNP1.push_back(ClustN[ClustN.size()-1]);
        for(i=1;i<nObs;i++)
        {
            //REprintf("%i \n",Clusters->Zeta.vec(i));
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                ClustIndex.push_back(Clusters->Zeta.vec(i));
                ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[ClustIndex.size()-1]));
                ClustNK.push_back(ClustN[ClustN.size()-1]);
                ClustNL1.push_back(ClustN[ClustN.size()-1]);
                ClustNP1.push_back(ClustN[ClustN.size()-1]);
            }
        }
        vector <double> logBetaVecK;
        vector <double> logBetaVecL1;
        vector <double> logBetaVecP1;
        for(int k=0;k<ClustIndex.size();k++)
        {
            logBetaVecK.push_back(logBeta2->mat(isp,ClustIndex[k]));
            logBetaVecL1.push_back(logBeta2->mat(isp,ClustIndex[k]));
            logBetaVecP1.push_back(logBeta2->mat(isp,ClustIndex[k]));
        }
        
        int kxi = 0;
        
        /**** nuovi parametri  END ****/
        if(Kobs==1)
        {
            StopMerge=1;
        }
        //Rprintf("Merge");
        while(StopMerge==0 ){
            
            ControllWhile++;
            
            double LogLikeL1 = 0.0;
            double LogLikeP1 = 0.0;
            //double LogLikek_New = 0.0;
            double LogLikek_k = 0.0;
            double LogLikek_P1 = 0.0;
            double LogLikek_L1 = 0.0;
            
            double gammak = 0.0;
            
            //LogLikeL1 = 0.0;
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                for(i=startL1;i<=endL1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                    LogLikeL1 += appProb;
                }
            }
            LogLikeP1 = 0.0;
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                for(i=startP1;i<=endP1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                    LogLikeP1 += appProb;
                }
            }
            
            
            LogLikek_k = 0.0;
            LogLikek_P1 = 0.0;
            LogLikek_L1 = 0.0;
            for(i=startk;i<=endk;i++)
            {
                ObsY.P = Y.Pmat(i,0);
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk], i);
                LogLikek_k += appProb;
                
                //Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexNew], i);
                //LogLikek_New += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                LogLikek_P1 += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                LogLikek_L1 += appProb;
            }
            
            
            /***********/
            
            //K
            probxiK = gammaWithBetaAlphaCP(&ClustNK, &logBetaVecK, lengths, alpha, 0);
            
            //L1
            probxiL1 = 0.0;
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                ClustNL1[kxi-1]   = ClustNK[kxi-1]+ClustNK[kxi];
                ClustNL1.erase(ClustNL1.begin()+kxi);
                logBetaVecL1.erase(logBetaVecL1.begin()+kxi);
                probxiL1 = gammaWithBetaAlphaCP(&ClustNL1, &logBetaVecL1, lengths, alpha, 0);
            }
            
            
            //P1
            probxiP1 = 0.0;
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                ClustNP1[kxi+1]   = ClustNK[kxi+1]+ClustNK[kxi];
                ClustNP1.erase(ClustNP1.begin()+kxi);
                logBetaVecP1.erase(logBetaVecP1.begin()+kxi);
                probxiP1 = gammaWithBetaAlphaCP(&ClustNP1, &logBetaVecP1, lengths, alpha, 0);
            }
            
            
            /***********/
            
            logProbL1[0]        = LogLikek_L1+LogLikeL1+LogLikeP1+probxiL1;
            logProbP1[0]        = LogLikek_P1+LogLikeP1+LogLikeL1+probxiP1;
            logProbk[0]         = LogLikek_k+LogLikeP1+LogLikeL1+probxiK;
            
            
            
            
            
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // L1 e P1
                    if((nk<lengths) || (nk==1))
                    {
                        double PP[2];
                        PP[0] = logProb.vec(0);
                        PP[1] = logProb.vec(2);
                        samp = Class_Utils::sample_DiscreteVar(PP, 2);
                        if(samp==1)
                        {
                            samp = 2;
                        }
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                    }
                    
                }else{
                    // L1
                    if((nk<lengths) || (nk==1))
                    {
                        samp = 0;
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                    }
                    
                }
            }else{
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // P1
                    if((nk<lengths) || (nk==1))
                    {
                        samp = 2;
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(1), 2)+1;
                    }
                }else{
                    StopMerge   = 1;
                    samp        = 5;
                }
            }
            //
            //            REprintf("samp-2 \n %i\n probxiL1 %f,probxiK %f,probxiP1 %f, kxi %i \n   logProbL1[0]  %f,logProbk[0]  %f,logProbP1[0]  %f \n   ",samp,probxiL1,probxiK,probxiP1,kxi, logProbL1[0],logProbk[0] ,logProbP1[0]);
            //
            //            REprintf("L1\n");
            //            for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
            //            {
            //                REprintf("%i ",ClustNL1[hhh]);
            //            }
            //            REprintf("\n");
            //            for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
            //            {
            //                REprintf("%f ",logBetaVecL1[hhh]);
            //            }
            //            REprintf("\n");
            //
            //
            //            REprintf("K\n");
            //            for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
            //            {
            //                REprintf("%i ",ClustNK[hhh]);
            //            }
            //            REprintf("\n");
            //            for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
            //            {
            //                REprintf("%f ",logBetaVecK[hhh]);
            //            }
            //            REprintf("\n");
            //
            //            REprintf("P1\n");
            //            for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
            //            {
            //                REprintf("%i ",ClustNP1[hhh]);
            //            }
            //            REprintf("\n");
            //            for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
            //            {
            //                REprintf("%f ",logBetaVecP1[hhh]);
            //            }
            //            REprintf("\n\n\n");
            
            if(samp==0)
            {
                ClustNK  = ClustNL1;
                ClustNP1 = ClustNL1;
                
                logBetaVecK = logBetaVecL1;
                logBetaVecP1 = logBetaVecL1;
                kxi--;
            }
            if(samp==1)
            {
                ClustNL1 = ClustNK;
                ClustNP1 = ClustNK;
                
                logBetaVecP1 = logBetaVecK;
                logBetaVecL1 = logBetaVecK;
                kxi++;
            }
            if(samp==2)
            {
                ClustNK  = ClustNP1;
                ClustNL1 = ClustNP1;
                
                logBetaVecK = logBetaVecP1;
                logBetaVecL1 = logBetaVecP1;
                kxi = kxi;
            }
            
            
            
            
            if(samp==0)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexL1;
                }
                
                //VecStart.Pvec(IndexL1)[0]       = VecStart.Pvec(IndexL1)[0];
                VecEnd.Pvec(IndexL1)[0]         = VecEnd.Pvec(Indexk)[0];
                VecN.Pvec(IndexL1)[0]           = VecN.Pvec(IndexL1)[0]+VecN.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                
                Indexk     = IndexL1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
                
                
            }
            if(samp==1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)==1)
                {
                    StopMerge = 1;
                }else{
                    if(Class_Utils::ifelse(endP1,nObs-1,1,0)!=1)
                    {
                        IndexP1     = VecSuc.vec(IndexP1);
                        startP1     = VecStart.vec(IndexP1);
                        endP1       = VecEnd.vec(IndexP1);
                        nP1         = VecN.vec(IndexP1);
                    }
                    
                    Indexk     = VecSuc.vec(Indexk);
                    startk     = VecStart.vec(Indexk);
                    endk       = VecEnd.vec(Indexk);
                    nk         = VecN.vec(Indexk);
                    
                    IndexL1     = VecPrec.vec(Indexk);
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                
                
            }
            if(samp==2)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexP1;
                }
                VecStart.Pvec(IndexP1)[0]       = VecStart.Pvec(Indexk)[0];
                //VecEnd.Pvec(IndexP1)[0]         = VecEnd.Pvec(IndexP1)[0];
                VecN.Pvec(IndexP1)[0]           = VecN.Pvec(IndexP1)[0]+VecN.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                Indexk     = IndexP1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
            }
            
            
            
        }
        
        if(ControllWhile>Kobs*Kobs)
        {
            error("CONTROLLARE WHILE LOOP");
        }
        
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        
        Clusters->update_EmptyAndNonEmptyClusters();
        
        
        
        
        
        
        //Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    
    
    
    
    
    void samp_stChangePointSplit_withPimarg_TODELETE(int lengths,int isp, Matrix<double> *logBeta2, double alpha)
    {
        //Rprintf("Split\n");
        int ErrorNumberClusters = 0;
        int CheckError = 0;
        int Kobs;
        //int KobsStar;
        int Kempty;
        //int k;
        int k0;
        int k0prec;
        int kK;
        
        
        
        
        int kNew;
        int i,j;
        int samp;
        //int knext;
        int KmaxObs;
        int KFirstObs;
        int KsecondObs;
        int KmaxObsL1;
        int kSeq;
        int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        double appProb;
        
        //double LogLikeL1 = 0.0;
        //double LogLikeP1 = 0.0;
        //double LogLikek_New = 0.0;
        double LogLikek_k = 0.0;
        double LogLikek_P1 = 0.0;
        double LogLikek_L1 = 0.0;
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int startL1pre = 0;
        int endL1 = 0;
        int endL1pre = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nL1pre = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexL1pre = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        //        double gammaP1 = 0.0;
        //        double gammaL1 = 0.0;
        //        double gammak = 0.0;
        //        double gammaL1k = 0.0;
        //        double gammaP1k = 0.0;
        
        
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        Kvoid = Clusters->nEmpty;
        Kempty = Clusters->nEmpty;
        
        
        
        
        
        k0 = 1;
        kK = 0;
        kNew = 0;
        
        //        deltaP1 = 0;
        //        deltaL1 = 0;
        //        deltak = 0;
        
        k0prec = 1;
        
        //
        
        
        
        //KobsStar = Kobs;
        KmaxObs = Clusters->NonEmptyC.vec(Kobs-1);
        KFirstObs = Clusters->NonEmptyC.vec(0);
        
        if(Kobs>1)
        {
            KmaxObsL1 = Clusters->NonEmptyC.vec(Kobs-2);
            KsecondObs = Clusters->NonEmptyC.vec(1);
        }else{
            KmaxObsL1 = KmaxObs;
            KsecondObs = KFirstObs;
        }
        
        
        
        //if(Kobs>1)
        //{
        
        kSeq                = 0;
        IndexL1             = Clusters->NonEmptyC.vec(kSeq);
        IndexL1pre = IndexL1;
        if(Kobs>1)
        {
            IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
        }else{
            IndexP1             = IndexL1;
        }
        Indexk              = Clusters->EmptyC.vec(kNew);
        
        
        startk      = 0;
        startL1     = 0;
        startL1pre     = startL1;
        
        
        endL1       = startL1;
        endL1pre = endL1;
        endk        = startL1+Clusters->NObsInClust.vec(IndexL1)-1;
        
        
        nL1         = endL1-startL1+1;
        nL1pre         = nL1;
        nk          = endk-startk+1; //
        
        if(Kobs>1)
        {
            //Rprintf("MMM %i \n",Kobs);
            startP1     = startL1+Clusters->NObsInClust.vec(IndexL1);
            endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
            nP1         = endP1-startP1+1;
        }
        
        if(Clusters->nEmpty==0)
        {
            ErrorNumberClusters = 1;
            CheckError = 1;
            //Rprintf("Inizia con il numero max di stati\n");
        }
        
        for(int hhh5=0;hhh5<Clusters->Zeta.nElem;hhh5++)
        {
            REprintf("%i %f %f %f\n",Clusters->Zeta.vec(hhh5),Y.mat(hhh5,0),Y.mat(hhh5,1),Y.mat(hhh5,2));
        }
        
        //        Clusters->NObsInClust.Print("NObsInClust");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //Rprintf("\nSPLIT\n");
        
        
        
        /**** nuovi parametri ****/
        double probxiL1;
        double probxiP1;
        double probxiK;
        
        
        
        
        vector <int> ClustIndex;
        vector <int> ClustN;
        vector <int> ClustNK;
        vector <int> ClustNL1;
        vector <int> ClustNP1;
        
        
        
        ClustIndex.push_back(Clusters->Zeta.vec(0));
        ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[0]));
        ClustNK.push_back(ClustN[ClustN.size()-1]);
        ClustNL1.push_back(ClustN[ClustN.size()-1]);
        ClustNP1.push_back(ClustN[ClustN.size()-1]);
        for(i=1;i<nObs;i++)
        {
            //REprintf("%i \n",Clusters->Zeta.vec(i));
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                ClustIndex.push_back(Clusters->Zeta.vec(i));
                ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[ClustIndex.size()-1]));
                ClustNK.push_back(ClustN[ClustN.size()-1]);
                ClustNL1.push_back(ClustN[ClustN.size()-1]);
                ClustNP1.push_back(ClustN[ClustN.size()-1]);
            }
        }
        
        
        //vector <double> logPI;
        //vector <double> NologPI;
        vector <double> logBetaVecK;
        vector <double> logBetaVecL1;
        vector <double> logBetaVecP1;
        for(int k=0;k<ClustIndex.size();k++)
        {
            logBetaVecK.push_back(logBeta2->mat(isp,ClustIndex[k]));
            logBetaVecL1.push_back(logBeta2->mat(isp,ClustIndex[k]));
            logBetaVecP1.push_back(logBeta2->mat(isp,ClustIndex[k]));
        }
        
        int kL1 = 0;
        
        //        /**** nuovi parametri  END ****/
        //        REprintf("L1\n");
        //        for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
        //        {
        //            REprintf("%i ",ClustNL1[hhh]);
        //        }
        //        REprintf("\n");
        //        for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
        //        {
        //            REprintf("%f ",logBetaVecL1[hhh]);
        //        }
        //        REprintf("\n");
        //
        //
        //        REprintf("K\n");
        //        for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
        //        {
        //            REprintf("%i ",ClustNK[hhh]);
        //        }
        //        REprintf("\n");
        //        for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
        //        {
        //            REprintf("%f ",logBetaVecK[hhh]);
        //        }
        //        REprintf("\n");
        //
        //        REprintf("P1\n");
        //        for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
        //        {
        //            REprintf("%i ",ClustNP1[hhh]);
        //        }
        //        REprintf("\n");
        //        for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
        //        {
        //            REprintf("%f ",logBetaVecP1[hhh]);
        //        }
        //        REprintf("\n\n\n");
        //
        
        for(int hhh4=0;hhh4<12;hhh4++)
        {
            REprintf("GP %f %f %f \n", Container[Indexk].GPVec[0][0].vec((hhh4%12)),Container[Indexk].GPVec[1][0].vec((hhh4%12)),Container[Indexk].GPVec[2][0].vec((hhh4%12)));
        }
        
        
        Container[Indexk].VectorCont->VectorAcc.Pvec(0)[0] =   Container[IndexL1].VectorCont->VectorAcc.Pvec(0)[0];
        Container[Indexk].VectorCont->VectorAcc.Pvec(2)[0] =   Container[IndexL1].VectorCont->VectorAcc.Pvec(2)[0];
        Container[Indexk].VectorCont->VectorAcc.Pvec(4)[0] =   Container[IndexL1].VectorCont->VectorAcc.Pvec(4)[0];
        
        for(int hhh6=0;hhh6<3;hhh6++)
        {
            for(int hhh7=0;hhh7<3;hhh7++)
            {
                Container[Indexk].PDmat[0].SigmaAccInv.Pmat(hhh6,hhh7)[0] =  Container[IndexL1].PDmat[0].SigmaAccInv.Pmat(hhh6,hhh7)[0];
            }
            Container[Indexk].PDmat[0].logdetAcc = Container[IndexL1].PDmat[0].logdetAcc;
        }
        
        Container[Indexk].VectorCont->VectorAcc.Pvec(0)[0] = 1.0;
        Container[Indexk].VectorCont->VectorAcc.Pvec(2)[0] = 0.8;
        Container[Indexk].VectorCont->VectorAcc.Pvec(4)[0] = -1.0;
        
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(0,0)[0] = 5.1763316;
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(0,1)[0] = 2.706754;
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(0,2)[0] = -0.3647139;
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(1,0)[0] = 2.7067539;
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(1,1)[0] = 30.150798;
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(1,2)[0] = 3.6386338;
        
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(2,0)[0] = -0.3647139 ;
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(2,1)[0] = 3.638634;
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(2,2)[0] = 30.9750457;
        
        
        Container[Indexk].PDmat[0].logdetAcc = -8.417953;
        
        for(i=0;i<nObs;i++)
        {
            REprintf("\n\n%i\n",i);
            if(ErrorNumberClusters==1)
            {
                if(CheckError==0)
                {
                    //Rprintf("K may be non well estimated\n");
                    CheckError = 1;
                }
                
            }else{
                if((startL1==startk)&(nk>0))
                {
                    //Rprintf("Nuovo codice");
                    
                    LogLikek_k = 0.0;
                    LogLikek_P1 = 0.0;
                    LogLikek_L1 = 0.0;
                    
                    
                    j = startk;
                    ObsY.P = Y.Pmat(j,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                    LogLikek_k += appProb;
                    
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                    LogLikek_L1 += appProb;
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1pre],j);
                        LogLikek_P1 += appProb;
                    }
                    
                    
                    /***********/
                    //K
                    ClustNK[kL1] = ClustNK[kL1]-1;
                    ClustNK.insert(ClustNK.begin()+kL1, 1);
                    logBetaVecK.insert(logBetaVecK.begin()+kL1, logBeta2->mat(isp,Indexk));
                    probxiK = gammaWithBetaAlphaCP(&ClustNK, &logBetaVecK, lengths, alpha, 0);
                    
                    //L1
                    probxiL1 = gammaWithBetaAlphaCP(&ClustNL1, &logBetaVecL1, lengths, alpha, 0);
                    
                    //P1
                    probxiP1 = 0.0;
                    if(IndexL1!=IndexL1pre)
                    {
                        ClustNP1[kL1] = ClustNP1[kL1]-1;
                        ClustNP1[kL1-1] = ClustNP1[kL1-1]+1;
                        probxiP1 = gammaWithBetaAlphaCP(&ClustNP1, &logBetaVecP1, lengths, alpha, 0);
                    }
                    
                    /***********/
                    
                    logProbL1[0]        = LogLikek_L1+probxiL1;
                    logProbP1[0]        = LogLikek_P1+probxiP1;
                    logProbk[0]         = LogLikek_k+probxiK;
                    
                    //REprintf("PREV %f %f %f\n", logProbL1[0] ,logProbk[0],logProbP1[0]  );
                    if(IndexL1!=IndexL1pre)
                    {
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                        //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                        //Rprintf("SAmpione su 2, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                    }
                    if(1<lengths)
                    {
                        samp = 0;
                    }
                    if(nL1==1)
                    {
                        samp = 0;
                    }
                    
                    
                    REprintf("samp-1\n %i\n probxiL1 %f,probxiK %f,probxiP1 %f, kL1 %i \n   logProbL1[0]  %f,logProbk[0]  %f,logProbP1[0]  %f \n  %i %i %i \n  ",samp,probxiL1,probxiK,probxiP1, kL1,
                             LogLikek_L1,LogLikek_k,LogLikek_P1 ,nL1,nk,nL1pre);
                    REprintf("L1 %f %f %f \n K %f %f %f\n  L1pre %f %f %f \n", Container[IndexL1].VectorCont->VectorAcc.vec(0), Container[IndexL1].VectorCont->VectorAcc.vec(2), Container[IndexL1].VectorCont->VectorAcc.vec(4),
                             Container[Indexk].VectorCont->VectorAcc.vec(0),     Container[Indexk].VectorCont->VectorAcc.vec(2),      Container[Indexk].VectorCont->VectorAcc.vec(4),
                             Container[IndexL1pre].VectorCont->VectorAcc.vec(0),     Container[IndexL1pre].VectorCont->VectorAcc.vec(2),      Container[IndexL1pre].VectorCont->VectorAcc.vec(4)
                             );
                    Container[IndexL1].PDmat[0].SigmaAcc.Print("IndexL1");
                    Container[Indexk].PDmat[0].SigmaAcc.Print("Indexk");
                    Container[IndexL1pre].PDmat[0].SigmaAcc.Print("IndexL1pre");
                    
                    REprintf("GP %f %f %f \n", Container[Indexk].GPVec[0][0].vec((j%12)),Container[Indexk].GPVec[1][0].vec((j%12)),Container[Indexk].GPVec[2][0].vec((j%12)));
                    //
                    //                    REprintf("L1\n");
                    //                    for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
                    //                    {
                    //                        REprintf("%i ",ClustNL1[hhh]);
                    //                    }
                    //                    REprintf("\n");
                    //                    for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
                    //                    {
                    //                        REprintf("%f ",logBetaVecL1[hhh]);
                    //                    }
                    //                    REprintf("\n");
                    //
                    //
                    //                    REprintf("K\n");
                    //                    for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
                    //                    {
                    //                        REprintf("%i ",ClustNK[hhh]);
                    //                    }
                    //                    REprintf("\n");
                    //                    for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
                    //                    {
                    //                        REprintf("%f ",logBetaVecK[hhh]);
                    //                    }
                    //                    REprintf("\n");
                    //
                    //                    REprintf("P1\n");
                    //                    for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
                    //                    {
                    //                        REprintf("%i ",ClustNP1[hhh]);
                    //                    }
                    //                    REprintf("\n");
                    //                    for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
                    //                    {
                    //                        REprintf("%f ",logBetaVecP1[hhh]);
                    //                    }
                    //                    REprintf("\n\n\n");
                    
                    if(samp==0)
                    {
                        ClustNK  = ClustNL1;
                        ClustNP1 = ClustNL1;
                        logBetaVecK = logBetaVecL1;
                        logBetaVecP1 = logBetaVecL1;
                    }
                    if(samp==1)
                    {
                        ClustNL1 = ClustNK;
                        ClustNP1 = ClustNK;
                        
                        logBetaVecL1 = logBetaVecK;
                        logBetaVecP1 = logBetaVecK;
                        
                        kL1++;
                    }
                    if(samp==2)
                    {
                        ClustNK  = ClustNP1;
                        ClustNL1 = ClustNP1;
                        
                        logBetaVecK = logBetaVecP1;
                        logBetaVecL1 = logBetaVecP1;
                    }
                    if(samp==0)
                    {
                        // rimando su dove ero
                        //                    Rprintf("\nS0\n");
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        // NO_ERROR Indexk      = Indexk;
                        
                        // NO_ERROR startL1     = startL1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        // NO_ERROR endL1pre       = endL1pre;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                    }
                    if(samp==1)
                    {
                        // cmapiono k
                        //                    Rprintf("\nS1\n");
                        //
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j=startk;
                        Clusters->Zeta.Pvec(j)[0]  = Indexk;
                        
                        startL1pre     = startk;
                        endL1pre       = startk;
                        nL1pre         = endL1pre-startL1pre+1;
                        IndexL1pre     = Indexk;
                        
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        startk      = startL1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                    }
                    if(samp==2)
                    {
                        // passo a quello prima
                        //                    Rprintf("\nS2\n");
                        //                    Rprintf("%f %f \n", logProbL1[0],logProbk[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j= startk;
                        Clusters->Zeta.Pvec(j)[0]  = IndexL1pre;
                        
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        endL1pre       = endL1pre+1;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                    }
                    
                    
                    
                }else{
                    if((nk!=0))
                    {
                        //Rprintf("Vecchio codice\n");
                        
                        
                        if(nL1==1)
                        {
                            LogLikek_k = 0.0;
                            LogLikek_P1 = 0.0;
                            LogLikek_L1 = 0.0;
                            
                            for(j=startk;j<=endk;j++)
                            {
                                ObsY.P = Y.Pmat(j,0);
                                //ObsY.Print("Y");
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                                LogLikek_k += appProb;
                                //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                                LogLikek_L1 += appProb;
                                //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                                
                                
                                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                                {
                                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                    LogLikek_P1 += appProb;
                                    //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                                }
                            }
                            
                        }else{
                            j = startk-1;
                            
                            ObsY.P = Y.Pmat(j,0);
                            //ObsY.Print("Y");
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                            LogLikek_k -= appProb;
                            //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                            LogLikek_L1 -= appProb;
                            //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                            
                            
                            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                            {
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                LogLikek_P1 -= appProb;
                                //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                            }
                        }
                        
                        
                        /***********/
                        
                        //K
                        ClustNK[kL1] = ClustNK[kL1]-nk;
                        ClustNK.insert(ClustNK.begin()+kL1+1, nk);
                        logBetaVecK.insert(logBetaVecK.begin()+kL1+1, logBeta2->mat(isp,Indexk));
                        probxiK = gammaWithBetaAlphaCP(&ClustNK, &logBetaVecK, lengths, alpha, 0);
                        
                        //L1
                        probxiL1 = gammaWithBetaAlphaCP(&ClustNL1, &logBetaVecL1, lengths, alpha, 0);
                        
                        //P1
                        probxiP1 = 0.0;
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            ClustNP1[kL1]   = ClustNP1[kL1]-nk;
                            ClustNP1[kL1+1] = ClustNP1[kL1+1]+nk;
                            probxiP1 = gammaWithBetaAlphaCP(&ClustNP1, &logBetaVecP1, lengths, alpha, 0);
                        }
                        
                        
                        /***********/
                        
                        
                        logProbL1[0]        = LogLikek_L1+probxiL1;
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            logProbP1[0]        = LogLikek_P1+probxiP1;
                        }
                        logProbk[0]         = LogLikek_k+probxiK;
                        
                        //REprintf("%f %f %f\n", logProbL1[0] ,logProbk[0],logProbP1[0]  );
                        
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                            //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                        }else{
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                            //Rprintf("SAmpione su 2, z=%i %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                        }
                        
                        
                        if((nk<lengths)||(nL1<lengths))
                        {
                            samp = 0;
                        }
                        
                        
                        REprintf("samp-2 \n %i\n probxiL1 %f,probxiK %f,probxiP1 %f, kL1 %i \n   logProbL1[0]  %f,logProbk[0]  %f,logProbP1[0]  %f \n %i %i %i \n   ",samp,probxiL1,probxiK,probxiP1, kL1, LogLikek_L1,LogLikek_k,LogLikek_P1, nL1, nk,nP1);
                        REprintf("L1 %f %f %f \n K %f %f %f \n P1  %f %f %f \n",
                                 Container[IndexL1].VectorCont->VectorAcc.vec(0), Container[IndexL1].VectorCont->VectorAcc.vec(2), Container[IndexL1].VectorCont->VectorAcc.vec(4),
                                 Container[Indexk].VectorCont->VectorAcc.vec(0),Container[Indexk].VectorCont->VectorAcc.vec(2), Container[Indexk].VectorCont->VectorAcc.vec(4),
                                 Container[IndexP1].VectorCont->VectorAcc.vec(0),     Container[IndexP1].VectorCont->VectorAcc.vec(2),      Container[IndexP1].VectorCont->VectorAcc.vec(4));
                        
                        
                        Container[IndexL1].PDmat[0].SigmaAcc.Print("IndexL1");
                        Container[Indexk].PDmat[0].SigmaAcc.Print("Indexk");
                        Container[IndexP1].PDmat[0].SigmaAcc.Print("IndexP1");
                        
                        REprintf("GP %f %f %f \n", Container[Indexk].GPVec[0][0].vec((j%12)),Container[Indexk].GPVec[1][0].vec((j%12)),Container[Indexk].GPVec[2][0].vec((j%12)));
                        //
                        //                        REprintf("L1\n");
                        //                        for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
                        //                        {
                        //                            REprintf("%i ",ClustNL1[hhh]);
                        //                        }
                        //                        REprintf("\n");
                        //                        for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
                        //                        {
                        //                            REprintf("%f ",logBetaVecL1[hhh]);
                        //                        }
                        //                        REprintf("\n");
                        //
                        //
                        //                        REprintf("K\n");
                        //                        for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
                        //                        {
                        //                            REprintf("%i ",ClustNK[hhh]);
                        //                        }
                        //                        REprintf("\n");
                        //                        for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
                        //                        {
                        //                            REprintf("%f ",logBetaVecK[hhh]);
                        //                        }
                        //                        REprintf("\n");
                        //
                        //                        REprintf("P1\n");
                        //                        for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
                        //                        {
                        //                            REprintf("%i ",ClustNP1[hhh]);
                        //                        }
                        //                        REprintf("\n");
                        //                        for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
                        //                        {
                        //                            REprintf("%f ",logBetaVecP1[hhh]);
                        //                        }
                        //                        REprintf("\n\n\n");
                        
                        
                        if(samp==0)
                        {
                            ClustNK  = ClustNL1;
                            ClustNP1 = ClustNL1;
                            
                            logBetaVecK = logBetaVecL1;
                            logBetaVecP1 = logBetaVecL1;
                            
                        }
                        if(samp==1)
                        {
                            ClustNL1 = ClustNK;
                            ClustNP1 = ClustNK;
                            
                            logBetaVecP1 = logBetaVecK;
                            logBetaVecL1 = logBetaVecK;
                            kL1++;
                        }
                        if(samp==2)
                        {
                            ClustNK  = ClustNP1;
                            ClustNL1 = ClustNP1;
                            
                            logBetaVecK = logBetaVecP1;
                            logBetaVecL1 = logBetaVecP1;
                            kL1++;
                        }
                        
                        if(samp==0)
                        {
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            // NO_ERROR Indexk      = Indexk;
                            
                            
                            // NO_ERROR startL1     = startL1;
                            endL1       = endL1+1;
                            nL1         = endL1-startL1+1;
                            // NO_ERROR IndexL1      = IndexL1;
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            // NO_ERROR startL1pre     = startL1pre;
                            // NO_ERROR endL1pre       = endL1pre;
                            nL1pre         = endL1pre-startL1pre+1;
                            // NO_ERROR IndexL1pre      = IndexL1pre;
                            
                            
                            
                        }
                        if(samp==1)
                        {
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = Indexk;
                            }
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre          = nL1;
                            IndexL1pre      = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = Indexk;
                            
                            
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            kNew++;
                            if(kNew>=(Kvoid-2))
                            {
                                ErrorNumberClusters = 1;
                            }else{
                                
                                Indexk              = Clusters->EmptyC.vec(kNew);
                            }
                        }
                        if(samp==2)
                        {
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = IndexP1;
                            }
                            
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre              = nL1;
                            IndexL1pre          = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            endk        = endP1;
                            nk          = endk-startk+1;
                            // NO_ERROR Indexk      = Indexk;
                            //                            kNew++;
                            //                            if(kNew>=(Kvoid-2))
                            //                            {
                            //                                ErrorNumberClusters = 1;
                            //                            }else{
                            //
                            //                                Indexk              = Clusters->EmptyC.vec(kNew);
                            //                            }
                            
                            
                            if(IndexL1!=KmaxObs)
                            {
                                kSeq++;
                                IndexP1      =  Clusters->NonEmptyC.vec(kSeq+1);
                                startP1     = endk+1;
                                endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                nP1         = endP1-startP1+1;
                            }
                            
                        }
                        
                        
                    }else{
                        if(IndexL1!=KmaxObs)
                        {
                            //Rprintf("Non campiono\n");
                            
                            kL1++;
                            startL1pre = startL1;
                            endL1pre = endL1;
                            nL1pre  = nL1;
                            IndexL1pre = IndexL1;
                            
                            IndexL1             = IndexP1;
                            startL1             = startP1;
                            endL1               = startP1;
                            nL1                 = endL1-startL1+1;
                            
                            
                            // NO_ERROR Indexk              = Indexk;
                            startk              = startL1;
                            endk                = endP1;
                            nk                  = endk-startk+1;
                            
                            if(IndexP1!=KmaxObs)
                            {
                                kSeq++;
                                //Rprintf("\nSstar1\n");
                                IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
                                //Rprintf("\nSstar2\n");
                                startP1             = startL1+Clusters->NObsInClust.vec(IndexL1);
                                //Rprintf("\nSsta3\n");
                                endP1               = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                //Rprintf("\nSstar5\n");
                                nP1                 = endP1-startP1+1;
                            }
                        }
                        
                    }
                }
            }
            
            
            
            
            
        }
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        //Clusters->Zeta.Print("ZetaPost");
        
        //Clusters->Zeta.Print("Zeta");
        
        //error("STOP");
        Clusters->update_EmptyAndNonEmptyClusters();
        
        Clusters->Zeta.Print("Zeta");
    }
    
    
    
    
};

class Class_Mixture_TODELETE_PERCLIMA
{
private:
    
    
public:
    // STUFF
    int nObs;
    int nVars;
    int Kmax;
    
    int UserControlledMemory;
    
    // MEMBERS
    Matrix <double>         Y;
    //Matrix <double>         YProp;
    //Matrix <double>         YTransformed;
    ClusterIndex            *Clusters;
    Poly_Density            *Likelihood;

    
    vector<Class_Parameter_PDMatrixUnivSamp >   *CovMat;
    vector<VectorParameters>                    *VectorParam;
    Matrix<double>                              *Covariates;
    
    vector <ParametersContainer>                Container;

    // CONSTRUCTORS
    Class_Mixture_TODELETE_PERCLIMA(){};
    
    //DESTRUCTORS
    ~Class_Mixture_TODELETE_PERCLIMA(){};

    
    
    void create_fullObject( Matrix<double>* y, ClusterIndex* clust, Poly_Density *like, int usr )
    {
        UserControlledMemory    = usr;
        
        Kmax     = clust->Kmax;
        Y           = Matrix<double>(y->nRows,y->nCols, y->P);
        nObs        = Y.nRows;
        nVars       = Y.nCols;
        
        Likelihood  = like;
        Clusters    = clust;
        
        for(int k=0;k<Kmax;k++)
        {
            Container.push_back(ParametersContainer());
        }
        
        
    }
    void add_Varmat_for_MultiNormal( vector<Class_Parameter_PDMatrixUnivSamp >   *covmat)
    {
        CovMat  = covmat;

        for(int k=0;k<Kmax;k++)
        {
            Container[k].PDmat  = &covmat[0][k];
        }
        
    }
    
    void add_RegVarmat_for_MultiNormal(vector<VectorParameters> *regCoef, vector<Class_Parameter_PDMatrixUnivSamp >   *covmat, Matrix<double> *Covar)
    {
        VectorParam = regCoef;
        CovMat  = covmat;
        Covariates = Covar;
        
        for(int k=0;k<Kmax;k++)
        {
            Container[k].VectorCont = &regCoef[0][k];
            Container[k].PDmat  = &covmat[0][k];
            Container[k].Cov    = &Covar[0];
        }
        
    }
    
    void add_RegVarmat_for_MultiNormal_Type_Clima(vector<VectorParameters> *regCoef, vector<Class_Parameter_PDMatrixUnivSamp >   *covmat, Matrix<double> *Covar, Vector <int> *TypeLike)
    {
        VectorParam = regCoef;
        CovMat  = covmat;
        Covariates = Covar;
        
        for(int k=0;k<Kmax;k++)
        {
            Container[k].VectorCont = &regCoef[0][k];
            Container[k].PDmat  = &covmat[0][k];
            Container[k].Cov    = &Covar[0];
            Container[k].TypeLike    = &TypeLike[0];
        }
        
    }
    void add_RegVarmat_for_MultiNormal_Type_ClimaSeason(vector<VectorParameters> *regCoef, vector<Class_Parameter_PDMatrixUnivSamp >   *covmat, Matrix<double> *Covar, Vector <int> *TypeLike,vector<Class_Gaussian_Multivariate> *GP)
    {
        VectorParam = regCoef;
        CovMat  = covmat;
        Covariates = Covar;
        
        for(int k=0;k<Kmax;k++)
        {
            Container[k].VectorCont = &regCoef[0][k];
            Container[k].PDmat  = &covmat[0][k];
            Container[k].Cov    = &Covar[0];
            Container[k].TypeLike    = &TypeLike[0];
            //Container[k].GPVec    = &GP[0];
            for(int j=0;j<GP->size(); j++)
            {
                Container[k].GPVec.push_back(&GP[0][j].Omega);
            }
        }
        
        
        
    }

    void sampleNA_MultiNormLikeRegUni( vector< Vector<int> > *VectorNA)
    {
        //error("Da Testare");
        int obs;
        for(int i=0;i<nVars;i++)
        {
            //Rprintf("i= %i",i);
            for(int  j=0;j<VectorNA[0][i].nElem;j++)
            {
                //Rprintf("j= %i\n",j);
                obs     = VectorNA[0][i].vec(j);
                //Rprintf("VectorNA[0][i].vec(j)= %i\n",VectorNA[0][i].vec(j));
                sampleNA_MultiNormLikeRegUni( obs, i);
            }
        }
    }
    void sampleNA_MultiNormLikeRegUni( int obs, int nvar)
    {
        
        // da testare
        double omega_P[nVars];
        Vector <double> omega(nVars,omega_P);
        
        double muA;
        double varA;
        
        muA     = 0.0;
        varA    = 0.0;
        
        //int obs;
        int k;
        int i;
        int j;
        int h;
        i = nvar;
        
        //obs     = VectorNA[0][i].vec(j);
        k       = Clusters->Zeta.vec(obs);
        double Xbeta_P[nVars];
        Vector<double>Xbeta (nVars,Xbeta_P);
        
        for(h=0;h<nVars;h++)
        {
            Xbeta.Pvec(h)[0] = 0.0;
            for(j = 0; j<Covariates->nCols;j++)
            {
                Xbeta.Pvec(h)[0] += Covariates[0].mat(nVars*obs+h,j)*VectorParam[0][k].VectorAcc.vec(j);
            }
        }

        omega.P = Y.Pmat(obs,0);
        Class_MultivariateNormal::external_computeConditioanlMeanAndVariance_uni(i,  &muA,  &varA, &CovMat[0][k].SigmaAccInv, &Xbeta, &omega);
        
        Y.Pmat(obs,i)[0] = rnorm(muA, pow(varA,0.5));
    }
    
    void sampleNA_MultiNormLikeRegAll( Vector<int>  *VectorNA)
    {
        //error("Da Testare");
        
        for(int  j=0;j<VectorNA[0].nElem;j++)
        {
            int obs     = VectorNA[0].vec(j);
            sampleNA_MultiNormLikeRegAll( obs);
        }
    }
    void sampleNA_MultiNormLikeRegAll( int obs)
    {
        // DA FARE UN CHECK -  non so se funziona
   
//        double muA;
//        double varA;
//
//        muA     = 0.0;
//        varA    = 0.0;
        
        //int obs;
        int k;
        //int i;
        int j;
        int h;
   
        
        
        Vector<double> Omega(nVars,Y.Pmat(obs,0));
        
        k       = Clusters->Zeta.vec(obs);
        double Xbeta_P[nVars];
        Vector<double>Xbeta (nVars,Xbeta_P);
        
        for(h=0;h<nVars;h++)
        {
            Xbeta.Pvec(h)[0] = 0.0;
            for(j = 0; j<Covariates->nCols;j++)
            {
                Xbeta.Pvec(h)[0] += Covariates[0].mat(nVars*obs+h,j)*VectorParam[0][k].VectorAcc.vec(j);
            }
        }
        Class_MultivariateNormal::external_SampleMultivariate(&Omega, &Xbeta, &CovMat[0][k].SigmaCholAcc);

        
        
    }
    
    

    void sample_LikeParam_MultiNormLike_Reg_NormalPrior()
    {
        
        sample_LikeParam_MultiNormLike_Reg_NormalPrior(&Y);
        
    }
    
    void sample_LikeParam_MultiNormLike_Reg_NormalPrior(Matrix <double> * Data)
    {
        Timing T1;
        Timing T2;
        Timing T3;
        Timing T4;
        Timing T5;
        Timing T6;
        int k,i,j;

        const double SumPar = 1.0;
        int dimCov = Covariates->nCols;
        

        Matrix <double> CovApp(nVars,dimCov,0);
        Vector <double> YApp(nVars,0);
        
        //Rprintf("A1\n");
        double MeanPar_P[dimCov*Kmax];
        double CovPar_P[dimCov*dimCov*Kmax];
        vector <Vector<double> > MeanPar;
        vector <Matrix<double> > CovPar;
        
//Rprintf("A1_1 %i %i  %i %i %i\n",Kmax, nObs, Covariates->nRows,dimCov, Clusters->nNonEmpty );
        for(k=0;k< Kmax;k++)
        {
            MeanPar.push_back(Vector<double>(dimCov,&MeanPar_P[k*dimCov]));
            CovPar.push_back(Matrix<double>(dimCov,dimCov,&CovPar_P[k*dimCov*dimCov]));
        }
        //Rprintf("A1_2\n");
        for(i=0;i< Clusters->nNonEmpty;i++)
        {
            //REprintf("dj=%i k=%i \n",i,Clusters->NonEmptyC.vec(i));
            k = Clusters->NonEmptyC.vec(i);
           //Rprintf("A1_3\n");
            MeanPar[k].Init(0.0);
            CovPar[k].Init(0.0);
            
        }

        //Rprintf("A5\n");
        for(j=0;j< Clusters->nNonEmpty;j++)
        {
            //REprintf("j=%i k=%i \n",j,Clusters->NonEmptyC.vec(j));
            k = Clusters->NonEmptyC.vec(j);
            // prior hyperparameters
            for(i=0;i<dimCov;i++)
            {
                //REprintf("%i %f %f\n",i,VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0],VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]);
                
                CovPar[k].Pmat(i,i)[0]   = 1.0/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
                MeanPar[k].Pvec(i)[0]  = VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
            }
  
        }
        
//Rprintf("A6\n");
        for(i=0;i<nObs;i++)
        {
            //
           
            //
            // likelihood contribution
            k           = Clusters->Zeta.vec(i);
            
            CovApp.P = Covariates[0].Pmat(i*nVars,0);
            YApp.P = Y.Pmat(i,0);
            // molto poco performante
            Class_MultivariateNormal::external_ParametersForFullConditioanlBeta_WithoutMolt(&CovApp,&CovMat[0][k].SigmaAccInv, &YApp, &CovPar[k], &MeanPar[k], &SumPar);
            
            
        }
//Rprintf("A7\n");
        for(i=0;i< Clusters->nNonEmpty;i++)
        {
            k = Clusters->NonEmptyC.vec(i);
            //CovPar[k].Print("Cov2");
            //MeanPar[k].Print("Mean2");
            //Rprintf("%i %i\n",Clusters->nNonEmpty,Clusters->NonEmptyC.vec(i));
            Class_MultivariateNormal::external_finalizedRegFullConditional(&CovPar[k],&MeanPar[k], 1);
            
            Class_MultivariateNormal::external_SampleMultivariate(&VectorParam[0][k].VectorAcc, &MeanPar[k], &CovPar[k]);
            VectorParam[0][k].update_ParameterAcc();
        }
//Rprintf("A8\n");
        for(i=0;i< Clusters->nEmpty;i++)
        {
            //Rprintf("A10 %i\n",i);
            k = Clusters->EmptyC.vec(i);
            //Rprintf("%i ",k );
            for(j=0;j<dimCov;j++)
            {
                VectorParam[0][k].VectorAcc.Pvec(j)[0] = rnorm(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(0)[0],pow(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(1)[0],0.5));
            }
            
            VectorParam[0][k].update_ParameterAcc();
        }

    }
    
    void sample_LikeParam_MultiNormLike_Reg_NormalPrior_TODELETE()
    {
        
        sample_LikeParam_MultiNormLike_Reg_NormalPrior_TODELETE(&Y);
        
    }
    
    void sample_LikeParam_MultiNormLike_Reg_NormalPrior_TODELETE(Matrix <double> * Data)
    {
        Timing T1;
        Timing T2;
        Timing T3;
        Timing T4;
        Timing T5;
        Timing T6;
        int k,i,j;
        
        const double SumPar = 1.0;
        int dimCov = Covariates->nCols;
        
        
        Matrix <double> CovApp(nVars,dimCov,0);
        Vector <double> YApp(nVars,0);
        
        //Rprintf("A1\n");
        double MeanPar_P[dimCov*Kmax];
        double CovPar_P[dimCov*dimCov*Kmax];
        vector <Vector<double> > MeanPar;
        vector <Matrix<double> > CovPar;
        
        //Rprintf("A1_1 %i %i  %i %i %i\n",Kmax, nObs, Covariates->nRows,dimCov, Clusters->nNonEmpty );
        for(k=0;k< Kmax;k++)
        {
            MeanPar.push_back(Vector<double>(dimCov,&MeanPar_P[k*dimCov]));
            CovPar.push_back(Matrix<double>(dimCov,dimCov,&CovPar_P[k*dimCov*dimCov]));
        }
        //Rprintf("A1_2\n");
        for(i=0;i< Clusters->nNonEmpty;i++)
        {
            //REprintf("dj=%i k=%i \n",i,Clusters->NonEmptyC.vec(i));
            k = Clusters->NonEmptyC.vec(i);
            //Rprintf("A1_3\n");
            MeanPar[k].Init(0.0);
            CovPar[k].Init(0.0);
        }
        
        //Rprintf("A5\n");
        for(j=0;j< Clusters->nNonEmpty;j++)
        {
            //REprintf("j=%i k=%i \n",j,Clusters->NonEmptyC.vec(j));
            k = Clusters->NonEmptyC.vec(j);
            // prior hyperparameters
            for(i=0;i<dimCov;i++)
            {
                //REprintf("%i %f %f\n",i,VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0],VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]);
                
                CovPar[k].Pmat(i,i)[0]   = 1.0/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
                MeanPar[k].Pvec(i)[0]  = VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
            }
            
        }
        
        //Rprintf("A6\n");
        for(i=0;i<nObs;i++)
        {
            //
            
            //
            // likelihood contribution
            k           = Clusters->Zeta.vec(i);
            
            CovApp.P = Covariates[0].Pmat(i*nVars,0);
            YApp.P = Y.Pmat(i,0);
            // molto poco performante
        Class_MultivariateNormal::external_ParametersForFullConditioanlBeta_WithoutMolt(&CovApp,&CovMat[0][k].SigmaAccInv, &YApp, &CovPar[k], &MeanPar[k], &SumPar);
            
            
        }
        //Rprintf("A7\n");
        for(i=0;i< Clusters->nNonEmpty;i++)
        {
            k = Clusters->NonEmptyC.vec(i);
            //CovPar[k].Print("Cov2");
            //MeanPar[k].Print("Mean2");
            //Rprintf("%i %i\n",Clusters->nNonEmpty,Clusters->NonEmptyC.vec(i));
            Class_MultivariateNormal::external_finalizedRegFullConditional(&CovPar[k],&MeanPar[k], 1);
            
            Class_MultivariateNormal::external_SampleMultivariate(&VectorParam[0][k].VectorAcc, &MeanPar[k], &CovPar[k]);
            VectorParam[0][k].update_ParameterAcc();
        }
        //Rprintf("A8\n");
        for(i=0;i< Clusters->nEmpty;i++)
        {
            //Rprintf("A10 %i\n",i);
            k = Clusters->EmptyC.vec(i);
            //Rprintf("%i ",k );
            for(j=0;j<dimCov;j++)
            {
                VectorParam[0][k].VectorAcc.Pvec(j)[0] = rnorm(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(0)[0],pow(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(1)[0],0.5));
            }
            
            VectorParam[0][k].update_ParameterAcc();
        }
        
    }

    
    void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishartZeroMean()
    {
        sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishartZeroMean(&Y);
    }
    void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishartZeroMean(Matrix <double> * Data)
    {
        int k,i,j,h;
        int K = Kmax;
        //int Kapp;
        
        //int nclust[K];
        double appMeanPar_P[nVars];
        //        double MeanPar_P[nVars*K];
        double CovPar_P[nVars*nVars*K];
        double nu_P[K];
        
        Vector<double> appMeanPar(nVars,appMeanPar_P);
        Vector<double> nu(K,nu_P);
        //        vector <Vector<double> > MeanPar;
        vector <Matrix<double> > CovPar;
        
        double omega_P[nVars];
        Vector <double> omega(nVars,omega_P);
        
//        double Xbeta_P[nVars];
//        Vector<double>Xbeta (nVars,Xbeta_P);
        
        
        //Rprintf("S1\n");
        for(k=0;k< Kmax;k++)
        {
            CovPar.push_back(Matrix<double>(nVars,nVars,CovPar_P[k*nVars*nVars]));
        }
        for(i=0;i< Clusters->nNonEmpty;i++)
        {
            k = Clusters->NonEmptyC.vec(i);
            CovPar[k].Init(0.0);
            
            //nclust[k] = 0.0;
        }
        
        //Rprintf("S2\n");
        for(i=0;i< Clusters->nNonEmpty;i++)
        {
            k = Clusters->NonEmptyC.vec(i);
            nu.Pvec(k)[0] = CovMat[0][k].PriorParameter->nuAcc[0]+Clusters->NObsInClust.vec(k);
            
            CovPar[k].Init(0.0);
            for(h=0;h<nVars;h++)
            {
                for(j=0;j<nVars;j++)
                {
                    CovPar[k].Pmat(h,j)[0] = CovMat[0][k].PriorParameter->PsiAcc[0].Pmat(h,j)[0];
                }
                
            }
            
        }
        //Rprintf("S3\n");
        for(i=0;i<nObs;i++)
        {
            // likelihood contribution
            k           = Clusters->Zeta.vec(i);
            omega.P     = Data->Pmat(i,0);
            
//            for(h=0;h<nVars;h++)
//            {
//                Xbeta.Pvec(h)[0] = 0.0;
//                for(j = 0; j<Covariates->nCols;j++)
//                {
//                    Xbeta.Pvec(h)[0] += Covariates[0].mat(nVars*i+h,j)*VectorParam[0][k].VectorAcc.vec(j);
//                }
//            }
            
//            for(j=0;j<nVars;j++)
//            {
//                for(h=j;h<nVars;h++)
//                {
//                    CovPar[k].Pmat(j,h)[0] += (omega.vec(j)-Xbeta.vec(j))*(omega.vec(h)-Xbeta.vec(h));
//                }
//            }
            for(j=0;j<nVars;j++)
            {
                for(h=j;h<nVars;h++)
                {
                    CovPar[k].Pmat(j,h)[0] += omega.vec(j)*omega.vec(h);
                }
            }
        }
        

        for(i=0;i< Clusters->nNonEmpty;i++)
        {
            
            k = Clusters->NonEmptyC.vec(i);
            Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc, &CovMat[0][k].SigmaAccInv, &CovPar[k], nu.Pvec(k)[0]);
            
            CovMat[0][k].compute_InvAccAndChol();
        }
        //Rprintf("S5\n");
        for(i=0;i< Clusters->nEmpty;i++)
        {
            // Rprintf("S1 %i\n",i);
            k = Clusters->EmptyC.vec(i);
            //Rprintf("S1 %i %f\n",k,CovMat[0][k].PriorParameter->nuAcc[0]);
            
            //CovMat[0][k].PriorParameter->PsiAcc->Print("Psi");
            Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc,&CovMat[0][k].SigmaAccInv, &CovMat[0][k].PriorParameter->PsiAcc[0], CovMat[0][k].PriorParameter->nuAcc[0]);
            //Rprintf("S11\n");
            CovMat[0][k].compute_InvAccAndChol();
            //Rprintf("S12\n");
        }
        // Rprintf("S6\n");
        
        
        
    }
    
    
    void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart()
    {
        sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart(&Y);
    }
    
    void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart(Matrix <double> * Data)
    {
        int k,i,j,h;
        int K = Kmax;
        
        //int Kapp;
        
        //int nclust[K];
        double appMeanPar_P[nVars];
        //        double MeanPar_P[nVars*K];
        double CovPar_P[nVars*nVars*K];
        double nu_P[K];
        
        Vector<double> appMeanPar(nVars,appMeanPar_P);
        Vector<double> nu(K,nu_P);
        //        vector <Vector<double> > MeanPar;
        vector <Matrix<double> > CovPar;
        
        double omega_P[nVars];
        Vector <double> omega(nVars,omega_P);
        
        double Xbeta_P[nVars];
        Vector<double>Xbeta (nVars,Xbeta_P);
        
        
        //Rprintf("S1\n");
        for(k=0;k< Kmax;k++)
        {
            CovPar.push_back(Matrix<double>(nVars,nVars,&CovPar_P[k*nVars*nVars]));
        }
        for(i=0;i< Clusters->nNonEmpty;i++)
        {
            k = Clusters->NonEmptyC.vec(i);
            CovPar[k].Init(0.0);
            
            //nclust[k] = 0.0;
        }

        //Rprintf("S2\n");
        for(i=0;i< Clusters->nNonEmpty;i++)
        {
            k = Clusters->NonEmptyC.vec(i);
            nu.Pvec(k)[0] = CovMat[0][k].PriorParameter->nuAcc[0]+Clusters->NObsInClust.vec(k);
            
            CovPar[k].Init(0.0);
            for(h=0;h<nVars;h++)
            {
                for(j=0;j<nVars;j++)
                {
                    CovPar[k].Pmat(h,j)[0] = CovMat[0][k].PriorParameter->PsiAcc[0].Pmat(h,j)[0];
                }
                
            }
            
        }
        //Rprintf("S3\n");
        for(i=0;i<nObs;i++)
        {
            // likelihood contribution
            k           = Clusters->Zeta.vec(i);
            omega.P     = Data->Pmat(i,0);
            
            for(h=0;h<nVars;h++)
            {
                Xbeta.Pvec(h)[0] = 0.0;
                for(j = 0; j<Covariates->nCols;j++)
                {
                    Xbeta.Pvec(h)[0] += Covariates[0].mat(nVars*i+h,j)*VectorParam[0][k].VectorAcc.vec(j);
                }
            }
            
            for(j=0;j<nVars;j++)
            {
                for(h=j;h<nVars;h++)
                {
                    CovPar[k].Pmat(j,h)[0] += (omega.vec(j)-Xbeta.vec(j))*(omega.vec(h)-Xbeta.vec(h));
                }
            }
        }
        
        //Rprintf("%i\n ", Clusters->nNonEmpty);
//        for(i=0;i< Clusters->nNonEmpty;i++)
//        {
//            Rprintf("%i  ", Clusters->NonEmptyC.vec(i));
//        }
        //Rprintf("S4\n");
        for(i=0;i< Clusters->nNonEmpty;i++)
        {
           
            k = Clusters->NonEmptyC.vec(i);
            Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc, &CovMat[0][k].SigmaAccInv, &CovPar[k], nu.Pvec(k)[0]);
        
            CovMat[0][k].compute_InvAccAndChol();
        }
        //Rprintf("S5\n");
        for(i=0;i< Clusters->nEmpty;i++)
        {
            // Rprintf("S1 %i\n",i);
            k = Clusters->EmptyC.vec(i);
            //Rprintf("S1 %i %f\n",k,CovMat[0][k].PriorParameter->nuAcc[0]);
            
            //CovMat[0][k].PriorParameter->PsiAcc->Print("Psi");
            Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc,&CovMat[0][k].SigmaAccInv, &CovMat[0][k].PriorParameter->PsiAcc[0], CovMat[0][k].PriorParameter->nuAcc[0]);
            //Rprintf("S11\n");
            CovMat[0][k].compute_InvAccAndChol();
            //Rprintf("S12\n");
        }
       // Rprintf("S6\n");
        
        
        
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
//    void sample_LikeParam_MultiNormLike_Reg_NormalPrior_Marginal(int k)
//    {
//
//        sample_LikeParam_MultiNormLike_Reg_NormalPrior_Marginal(&Y,k);
//
//    }
    
    void sample_LikeParam_MultiNormLike_Reg_NormalPrior_Marginal(int k)
    {
       
        int j;
        //const double SumPar = 1.0;
        int dimCov = Covariates->nCols;
        
        
        Matrix <double> CovApp(nVars,dimCov,0);
        Vector <double> YApp(nVars,0);
        
        //Rprintf("A1\n");
//        double MeanPar_P[dimCov*Clusters->nNonEmpty];
//        double CovPar_P[dimCov*dimCov*Clusters->nNonEmpty];
//        vector <Vector<double> > MeanPar;
//        vector <Matrix<double> > CovPar;
        

        //Rprintf("%i ",k );
        for(j=0;j<dimCov;j++)
        {
            VectorParam[0][k].VectorAcc.Pvec(j)[0] = rnorm(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(0)[0],pow(VectorParam[0][k].PriorParameters[0][j][0].HyperparametersAcc.vec(1)[0],0.5));
        }
        
        VectorParam[0][k].update_ParameterAcc();
        
//
//        //        T1.compute_start();
//        //Rprintf("A1\n");
//        for(k=0;k< Kmax;k++)
//        {
//            MeanPar.push_back(Vector<double>(dimCov,MeanPar_P[k*dimCov]));
//            CovPar.push_back(Matrix<double>(dimCov,dimCov,CovPar_P[k*dimCov*dimCov]));
//        }
//        for(i=0;i< Clusters->nNonEmpty;i++)
//        {
//            k = Clusters->NonEmptyC.vec(i);
//            MeanPar[k].Init(0.0);
//            CovPar[k].Init(0.0);
//
//        }
//
//        //Rprintf("A5\n");
//        for(j=0;j< Clusters->nNonEmpty;j++)
//        {
//            k = Clusters->NonEmptyC.vec(j);
//            // prior hyperparameters
//            for(i=0;i<dimCov;i++)
//            {
//                CovPar[k].Pmat(i,i)[0]   = 1.0/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
//                MeanPar[k].Pvec(i)[0]  = VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(0)[0]/VectorParam[0][k].PriorParameters[0][i][0].HyperparametersAcc.vec(1)[0];
//            }
//            //CovPar[k].Print("Cov");
//            //MeanPar[k].Print("Mean");
//        }
//
//        //        T3.compute_end();
//        //        T4.compute_start();
//        //Rprintf("A8\n");
//        //Covariates[0].Print("Covariates");
//        for(i=0;i<nObs;i++)
//        {
//            // likelihood contribution
//            k           = Clusters->Zeta.vec(i);
//
//            CovApp.P = Covariates[0].Pmat(i*nVars,0);
//            YApp.P = Y.Pmat(i,0);
//            // molto poco performante
//            Class_MultivariateNormal::external_ParametersForFullConditioanlBeta_WithoutMolt(&CovApp,&CovMat[0][k].SigmaAccInv, &YApp, &CovPar[k], &MeanPar[k], &SumPar);
//
//
//        }
//        //        T4.compute_end();
//        //        T5.compute_start();
//        //Rprintf("A9\n");
//        for(i=0;i< Clusters->nNonEmpty;i++)
//        {
//            k = Clusters->NonEmptyC.vec(i);
//            //CovPar[k].Print("Cov2");
//            //MeanPar[k].Print("Mean2");
//            //Rprintf("%i %i\n",Clusters->nNonEmpty,Clusters->NonEmptyC.vec(i));
//            Class_MultivariateNormal::external_finalizedRegFullConditional(&CovPar[k],&MeanPar[k], 1);
//
//            Class_MultivariateNormal::external_SampleMultivariate(&VectorParam[0][k].VectorAcc, &MeanPar[k], &CovPar[k]);
//            VectorParam[0][k].update_ParameterAcc();
//        }
//        //        T5.compute_end();
//        //        T6.compute_start();
//        //Rprintf("A10\n");
//        for(i=0;i< Clusters->nEmpty;i++)
//        {
//            //Rprintf("A10 %i\n",i);
//
//        }
    }
    
    
    
//    void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_Marginal()
//    {
//        sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_Marginal(&Y);
//    }
    
    void sample_LikeParam_MultiNormLikeReg_Sigma_InverseWishart_Marginal(int k)
    {
        //int i,j,h;
        //int K = Kmax;
        
        //int Kapp;
        
//        //int nclust[K];
//        double appMeanPar_P[nVars];
//        //        double MeanPar_P[nVars*K];
//        double CovPar_P[nVars*nVars*K];
//        double nu_P[K];
//
//        Vector<double> appMeanPar(nVars,appMeanPar_P);
//        Vector<double> nu(K,nu_P);
//        //        vector <Vector<double> > MeanPar;
//        vector <Matrix<double> > CovPar;
//
//        double omega_P[nVars];
//        Vector <double> omega(nVars,omega_P);
//
//        double Xbeta_P[nVars];
//        Vector<double>Xbeta (nVars,Xbeta_P);
        
        Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc,&CovMat[0][k].SigmaAccInv, &CovMat[0][k].PriorParameter->PsiAcc[0], CovMat[0][k].PriorParameter->nuAcc[0]);
        //Rprintf("S11\n");
        CovMat[0][k].compute_InvAccAndChol();
        
//        //Rprintf("S1\n");
//        for(k=0;k< Kmax;k++)
//        {
//            CovPar.push_back(Matrix<double>(nVars,nVars,CovPar_P[k*nVars*nVars]));
//        }
//        for(i=0;i< Clusters->nNonEmpty;i++)
//        {
//            k = Clusters->NonEmptyC.vec(i);
//            CovPar[k].Init(0.0);
//
//            //nclust[k] = 0.0;
//        }
//
//        //Rprintf("S2\n");
//        for(i=0;i< Clusters->nNonEmpty;i++)
//        {
//            k = Clusters->NonEmptyC.vec(i);
//            nu.Pvec(k)[0] = K-1+ CovMat[0][k].PriorParameter->nuAcc[0]+Clusters->NObsInClust.vec(k);
//
//            CovPar[k].Init(0.0);
//            for(h=0;h<nVars;h++)
//            {
//                for(j=0;j<nVars;j++)
//                {
//                    CovPar[k].Pmat(h,j)[0] = CovMat[0][k].PriorParameter->PsiAcc[0].Pmat(h,j)[0];
//                }
//
//            }
//
//        }
//        //Rprintf("S3\n");
//        for(i=0;i<nObs;i++)
//        {
//            // likelihood contribution
//            k           = Clusters->Zeta.vec(i);
//            omega.P     = Data->Pmat(i,0);
//
//            for(h=0;h<nVars;h++)
//            {
//                Xbeta.Pvec(h)[0] = 0.0;
//                for(j = 0; j<Covariates->nCols;j++)
//                {
//                    Xbeta.Pvec(h)[0] += Covariates[0].mat(nVars*i+h,j)*VectorParam[0][k].VectorAcc.vec(j);
//                }
//            }
//
//            for(j=0;j<nVars;j++)
//            {
//                for(h=j;h<nVars;h++)
//                {
//                    CovPar[k].Pmat(j,h)[0] += (omega.vec(j)-Xbeta.vec(j))*(omega.vec(h)-Xbeta.vec(h));
//                }
//            }
//        }
//
//        //Rprintf("%i\n ", Clusters->nNonEmpty);
//        //        for(i=0;i< Clusters->nNonEmpty;i++)
//        //        {
//        //            Rprintf("%i  ", Clusters->NonEmptyC.vec(i));
//        //        }
//        //Rprintf("S4\n");
//        for(i=0;i< Clusters->nNonEmpty;i++)
//        {
//
//            k = Clusters->NonEmptyC.vec(i);
//            Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc, &CovMat[0][k].SigmaAccInv, &CovPar[k], nu.Pvec(k)[0]);
//
//            CovMat[0][k].compute_InvAccAndChol();
//        }
//        //Rprintf("S5\n");
//        for(i=0;i< Clusters->nEmpty;i++)
//        {
//            // Rprintf("S1 %i\n",i);
//            k = Clusters->EmptyC.vec(i);
//            //Rprintf("S1 %i %f\n",k,CovMat[0][k].PriorParameter->nuAcc[0]);
//
//            //CovMat[0][k].PriorParameter->PsiAcc->Print("Psi");
//            Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc,&CovMat[0][k].SigmaAccInv, &CovMat[0][k].PriorParameter->PsiAcc[0], CovMat[0][k].PriorParameter->nuAcc[0]);
//            //Rprintf("S11\n");
//            CovMat[0][k].compute_InvAccAndChol();
//            //Rprintf("S12\n");
//        }
        // Rprintf("S6\n");
        
        
        
    }
    
    
    
    void samp_stMixtureDP_CheckLastElement()
    {
        //double u;
        
        vector< vector <int> > AppSamp;
        //double sum;
        int i,k;
        double ret_P[Kmax];
        Vector<double> ret(Kmax,ret_P);
        
        
        for(i=0;i<nObs;i++)
        {
            AppSamp.push_back(vector<int>());
            k = Clusters->Zeta.vec(i);
            double u = runif(0.0,Clusters->Probs->ProbsAcc[0]->vec(k));
            
            double sum = 1.0;
            
            k=0;
            do{
                if(Clusters->Probs->ProbsAcc[0]->vec(k)>u)
                {
                    AppSamp[i].push_back(k);
                    //Rprintf("%i %i \n", i, k);
                }
                sum -= Clusters->Probs->ProbsAcc[0]->vec(k);
                k++;
            }while((sum>u)&(k<Kmax));
            //Clusters->Probs->ProbsAcc[0]->Print("Prob");
            //Rprintf("%i %i %f\n",(int)AppSamp[i].size(),AppSamp[i].size(),u);
        }
        //Clusters->Probs->ProbsAcc[0]->Print("ProbVec");
        //Rprintf("END");
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        for(i=0;i<nObs;i++)
        {
            for(int j=0;j<AppSamp[i].size();j++)
            {
                k = AppSamp[i][j];
                ObsY.P = Y.Pmat(i,0);
                Likelihood->computeLogDensityForLike(ret.Pvec(j),&ObsY, &Container[k], i);
            }
            //
            
            Clusters->Zeta.Pvec(i)[0] = AppSamp[i][Class_Utils::sample_DiscreteVar(ret.P, (int)AppSamp[i].size()) ];
            if(Clusters->nNonEmpty>=(Kmax))
            {
                Rprintf("error: Kmax occupied regimes -  approximation is not valid");
            }
        }
        //Clusters->Zeta.Print("Zeta");
        Clusters->update_EmptyAndNonEmptyClusters();
        
        

        
    }
    
//    void samp_stChangePointDPMargPi_CheckLastElement(Class_Parameter *eta)
//    {
//        double u;
//        double v;
//        int i;
//
//        int k;
//        int kNew;
//        int kPrev;
//        int kFol;
//
//        double ProbNew;
//        double ProbPrev;
//        double ProbFol;
//        double Probk;
//
//        Vector<double> ObsY(nVars,Y.Pmat(0,0));
//
//        double LikePar;
//        u = runif(0.0,3.0);
//        v = runif(0.0,1.0);
//
//
//        if(u<1.0)
//        {
//            // univariate update
//            if(v<0.5)
//            {
//                i = 0;
//                k           = Clusters->Zeta.vec(i);
//                kNew        = Clusters->EmptyC.vec(Clusters->nNonEmpty-1);
//                //kPrev     = 0;
//                kFol        = Clusters->Zeta.vec(i+1);
//
//                ProbUnc     =
//                ProbNew = ;
//                ProbPrev;
//                ProbFol;
//
//
//
//
//                i = nObs-1;
//                ObsY.P = Y.Pmat(i,0);
//                for(k=0;k<KProp;k++)
//                {
//                    Likelihood->computeLogDensityForLike(VecLike.Pvec(k),&ObsY, &Container[k], i);
//                }
//            }else{
//
//            }
//        }
//        if(u>=3.0)
//        {
//            // split
//        }
//        if((u>=1.0)&(u<2))
//        {
//            // merge
//        }
//
//    }
    
    
    
    void samp_stChangePointDP_CheckLastElement(Class_Parameter *eta)
    {
        
        double ProbPropGivenAcc = 0.0;
        double ProbAccGivenProp = 0.0;
        int KAcc = 1;
        int KProp = 1;
        int kprop;
        int KmaxInt;
        
        
        double u;
        
        u = runif(0.0,1.0);
        KAcc = Clusters->nNonEmpty;
        if(KAcc!=1)
        {
            if(u<1.0/3.0)
            {
                KProp = KAcc-1;
            }else{
                if(u>2.0/3.0)
                {
                    KProp = KAcc+1;
                }else{
                    KProp = KAcc;
                    //KUnchanged = 1;
                }
            }
        }else{
            if(u<1.0/2.0)
            {
                KProp = 1;
            }else{
                KProp = 2;
            }
        }
        
//        int NObsInClustProp_P[KProp];
//        Vector<int> NObsInClustProp(KProp,NObsInClustProp_P);
//        NObsInClustProp.Init(0);
        
        if(KAcc==1)
        {
            if(KProp==1)
            {
                ProbPropGivenAcc = 1.0/2.0;
                ProbAccGivenProp = 1.0/2.0;
            }
            if(KProp!=1)
            {
                ProbPropGivenAcc = 1.0/2.0;
                ProbAccGivenProp = 1.0/3.0;
            }
        }
        if(KAcc!=1)
        {
            if(KProp==1)
            {
                ProbPropGivenAcc = 1.0/3.0;
                ProbAccGivenProp = 1.0/2.0;
            }
            if(KProp!=1)
            {
                ProbPropGivenAcc = 1.0/3.0;
                ProbAccGivenProp = 1.0/3.0;
            }
        }

        
        
        
        KmaxInt = max(KAcc, KProp);
        
        double Molt = 100;
        int k,i, kprec;
        double SumLog, MHratio;
        //double SumLogProp,SumLogAcc;
        
        
        double logPstProp_P[KmaxInt*nObs];
        Matrix <double> logPstProp(nObs,KmaxInt,logPstProp_P);
        logPstProp.Init(0.0);

        double Sampst_P[2];
        Vector <double> Sampst(2,Sampst_P);

        double applogPstProp_P[2];
        Vector <double> applogPstProp(2,applogPstProp_P);
        applogPstProp.Init(0.0);

        double VecLike_P[KmaxInt];
        Vector<double> VecLike(KmaxInt,VecLike_P);

        Vector<double> ObsY(nVars,Y.Pmat(0,0));


        double logMatCPProb_P[KmaxInt*KmaxInt];
        Matrix <double> logMatCPProb(KmaxInt,KmaxInt,logMatCPProb_P);
        logMatCPProb.Init(0.0);
        for(k=0;k<KmaxInt;k++)
        {
            logMatCPProb.Pmat(k,k)[0] = log(Molt*Clusters->Probs->ProbsAcc[0]->vec(k));
            logMatCPProb.Pmat(k,k)[0] = log(Molt-Molt*Clusters->Probs->ProbsAcc[0]->vec(k));
            
        }

        logPstProp.Pmat(0,0)[0] = 0.0;
        //Rprintf("CCww \n");
        
        for(i=1;i<KmaxInt;i++)
        {
            k = 0;
            kprec = 0;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
            for(k=1;k<i;k++)
            {
                kprec = k-1;
                applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                //Rprintf("AAA %f %f %f  \n", applogPstProp.Pvec(0)[0],logMatCPProb.mat(kprec,k),logPstProp.mat(i-1,kprec) );
                kprec = k;
                applogPstProp.Pvec(1)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                //Rprintf("AAA %f %f %f \n", applogPstProp.Pvec(1)[0],logMatCPProb.mat(kprec,k),logPstProp.mat(i-1,kprec) );
                
                
                
                Class_Utils::log_sum_exp(logPstProp.Pmat(i,k), 2, applogPstProp.Pvec(0));
                //Rprintf("%f dd\n",logPstProp.Pmat(i,k)[0]);
                //log_sum_exp(double *ret, int k, double *logx)
            }
            k = i;
            kprec = k-1;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
            //Rprintf("%f \n",logPstProp.Pmat(i,k)[0]);
            
            
            ObsY.P = Y.Pmat(i,0);
            for(k=0;k<=i;k++)
            {
                Likelihood->computeLogDensityForLike(VecLike.Pvec(k),&ObsY, &Container[k], i);
            }
            for(k=0;k<=i;k++)
            {
                logPstProp.Pmat(i,k)[0] += VecLike.vec(k);
            }
            Class_Utils::log_sum_exp(&SumLog, i+1, logPstProp.Pmat(i,0));
            //log_sum_exp(double *ret, int k, double *logx)
            for(k=0;k<=i;k++)
            {
                logPstProp.Pmat(i,k)[0] = logPstProp.Pmat(i,k)[0]-SumLog;
            }
            //Rprintf("\n");
        }
        //Rprintf("CC \n");
        
        
        
        for(i=KmaxInt;i<nObs-1;i++)
        {
           
            k = 0;
            kprec = 0;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
        
            for(k=1;k<KmaxInt;k++)
            {
                kprec = k-1;
                applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                kprec = k;
                applogPstProp.Pvec(1)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                Class_Utils::log_sum_exp(logPstProp.Pmat(i,k), 2, applogPstProp.Pvec(0));
              
            }
            ObsY.P = Y.Pmat(i,0);
            for(k=0;k<KmaxInt;k++)
            {
                Likelihood->computeLogDensityForLike(VecLike.Pvec(k),&ObsY, &Container[k], i);
            }
            for(k=0;k<KmaxInt;k++)
            {
                logPstProp.Pmat(i,k)[0] += VecLike.vec(k);
            }
            Class_Utils::log_sum_exp(&SumLog, KmaxInt, logPstProp.Pmat(i,0));
            for(k=0;k<KmaxInt;k++)
            {
                logPstProp.Pmat(i,k)[0] = logPstProp.Pmat(i,k)[0]-SumLog;
            }

        }
        
        i=nObs-1;
        k = 0;
        kprec = 0;
        applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
        logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
        
        for(k=1;k<KmaxInt;k++)
        {
            kprec = k-1;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            kprec = k;
            applogPstProp.Pvec(1)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            Class_Utils::log_sum_exp(logPstProp.Pmat(i,k), 2, applogPstProp.Pvec(0));
            
        }
        ObsY.P = Y.Pmat(i,0);
        for(k=0;k<KmaxInt;k++)
        {
            Likelihood->computeLogDensityForLike(VecLike.Pvec(k),&ObsY, &Container[k], i);
        }
        for(k=0;k<KmaxInt;k++)
        {
            logPstProp.Pmat(i,k)[0] += VecLike.vec(k);
        }
  
        
        // sample
        i = nObs-1;
        
        kprop = (int)runif(0.0,KProp);
        
        MHratio = 0.0;
        MHratio += log(ProbAccGivenProp)-1.0*log(ProbPropGivenAcc);
        MHratio += log(KProp)-1.0*log(KAcc);
        MHratio += logPstProp.mat(i,kprop)-1.0*(logPstProp.mat(i,KAcc-1));
        
        Rprintf("%i %i %i %f \n", KProp,KAcc,kprop, MHratio);
        u = runif(0.0,1.0);
        if(u<exp(MHratio))
        {
            Clusters->Zeta.Pvec(i)[0] = kprop;
        }
        


        for(i=nObs-2;i>=max(KmaxInt-1,0);i--)
        {

            if(Clusters->Zeta.vec(i+1)!=0)
            {
                k = Clusters->Zeta.vec(i+1)-1;
                Sampst.Pvec(0)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));

                k = Clusters->Zeta.vec(i+1);
                Sampst.Pvec(1)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));

                Clusters->Zeta.Pvec(i)[0] = Class_Utils::sample_DiscreteVar(Sampst.Pvec(0), 2)+Clusters->Zeta.vec(i+1)-1;
            }else{
                Clusters->Zeta.Pvec(i)[0] = 0;
            }

        }
        for(i=max(KmaxInt-2,0);i>=0;i--)
        {
            if(Clusters->Zeta.vec(i+1)==(i+1))
            {
                Clusters->Zeta.Pvec(i)[0] = i;
            }else{
                if(Clusters->Zeta.vec(i+1)!=0)
                {
                    k = Clusters->Zeta.vec(i+1)-1;
                    Sampst.Pvec(0)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));

                    k = Clusters->Zeta.vec(i+1);
                    Sampst.Pvec(1)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));

                    Clusters->Zeta.Pvec(i)[0] = Class_Utils::sample_DiscreteVar(Sampst.Pvec(0), 2)+Clusters->Zeta.vec(i+1)-1;
                }else{
                    Clusters->Zeta.Pvec(i)[0] = 0;
                }
            }
        }
        Clusters->update_EmptyAndNonEmptyClusters();

        if(Clusters->Zeta.vec(i)==Kmax)
        {
            error("\n\n s_T = Kmax - CP approximation may be no more valid\n\n");
        }

    }
    
    
    
    
    
    
 
    
    void samp_stChangePointDPNotSequentialstFixedK_CheckLastElement(Class_Parameter *eta)
    {
        //error("USARE LA FUNZIONE SENZA ARGOMENTO");

        
        double Molt = 1.0;
        int k,i, kprec;
        double SumLog;
        
        int Kobs;
        
        
        
        double Sampst_P[2];
        Vector <double> Sampst(2,Sampst_P);
        
        double applogPstProp_P[2];
        Vector <double> applogPstProp(2,applogPstProp_P);
        applogPstProp.Init(0.0);
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
//        int ClusterIndex_P[Kmax];
//        Vector <int> ClusterIndex(Kmax,ClusterIndex_P);
//
        
        Kobs = Clusters->nNonEmpty;
        
        
//        for(k=0;k<Clusters->nNonEmpty;k++)
//        {
//            ClusterIndex.Pvec(k)[0] = Clusters->NonEmptyC.vec(k);
//        }

//        k = 0;
//        ClusterIndex.Pvec(0)[0] = Clusters->Zeta.vec(0);
//        for(i=1;i<nObs;i++)
//        {
//            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
//            {
//                k++;
//                ClusterIndex.Pvec(k)[0] = Clusters->Zeta.vec(i);
//            }
//        }
//
        
        double logPstProp_P[Kobs*nObs];
        Matrix <double> logPstProp(nObs,Kobs,logPstProp_P);
        logPstProp.Init(0.0);
        
        double logMatCPProb_P[Kobs*Kobs];
        Matrix <double> logMatCPProb(Kobs,Kobs,logMatCPProb_P);
        
        double VecLike_P[Kobs];
        Vector<double> VecLike(Kobs,VecLike_P);
        
        logMatCPProb.Init(0.0);
        for(k=0;k<Kobs-1;k++)
        {
            //k = ClusterIndex.vec(k);
            logMatCPProb.Pmat(k,k)[0] = log(Molt*Clusters->Probs->ProbsAcc[0]->vec(Clusters->NonEmptyC.vec(k)));
            logMatCPProb.Pmat(k,k+1)[0] = log(Molt-Molt*Clusters->Probs->ProbsAcc[0]->vec(Clusters->NonEmptyC.vec(k)));
            //logMatCPProb.Pmat(k,k)[0] = 0.0;
        }
        logMatCPProb.Pmat(Kobs-1,Kobs-1)[0] = 0.0;
        
        logPstProp.Pmat(0,0)[0] = 0.0;
        //Rprintf("CCww \n");
        for(i=1;i<Kobs;i++)
        {
            k = 0;
            kprec = 0;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
            for(k=1;k<i;k++)
            {
                kprec = k-1;
                applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                //Rprintf("AAA %f %f %f  \n", applogPstProp.Pvec(0)[0],logMatCPProb.mat(kprec,k),logPstProp.mat(i-1,kprec) );
                kprec = k;
                applogPstProp.Pvec(1)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                //Rprintf("AAA %f %f %f \n", applogPstProp.Pvec(1)[0],logMatCPProb.mat(kprec,k),logPstProp.mat(i-1,kprec) );
                
                
                
                Class_Utils::log_sum_exp(logPstProp.Pmat(i,k), 2, applogPstProp.Pvec(0));
                //Rprintf("%f dd\n",logPstProp.Pmat(i,k)[0]);
                //log_sum_exp(double *ret, int k, double *logx)
            }
            k = i;
            kprec = k-1;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
            //Rprintf("%f \n",logPstProp.Pmat(i,k)[0]);
            
            
            ObsY.P = Y.Pmat(i,0);
            for(k=0;k<=i;k++)
            {
                Likelihood->computeLogDensityForLike(VecLike.Pvec(k),&ObsY, &Container[Clusters->NonEmptyC.vec(k)], i);
            }
            for(k=0;k<=i;k++)
            {
                logPstProp.Pmat(i,k)[0] += VecLike.vec(k);
            }
            Class_Utils::log_sum_exp(&SumLog, i+1, logPstProp.Pmat(i,0));
            //log_sum_exp(double *ret, int k, double *logx)
            for(k=0;k<=i;k++)
            {
                logPstProp.Pmat(i,k)[0] = logPstProp.Pmat(i,k)[0]-SumLog;
            }
            //Rprintf("\n");
        }
        //Rprintf("CC \n");
        
        
        for(i=Kobs;i<nObs;i++)
        {
            
            k = 0;
            kprec = 0;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
            
            for(k=1;k<Kobs;k++)
            {
                kprec = k-1;
                applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                kprec = k;
                applogPstProp.Pvec(1)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                Class_Utils::log_sum_exp(logPstProp.Pmat(i,k), 2, applogPstProp.Pvec(0));
                
            }
            ObsY.P = Y.Pmat(i,0);
            for(k=0;k<Kobs;k++)
            {
                Likelihood->computeLogDensityForLike(VecLike.Pvec(k),&ObsY, &Container[Clusters->NonEmptyC.vec(k)], i);
            }
            for(k=0;k<Kobs;k++)
            {
                logPstProp.Pmat(i,k)[0] += VecLike.vec(k);
            }
            Class_Utils::log_sum_exp(&SumLog, Kobs, logPstProp.Pmat(i,0));
            for(k=0;k<Kobs;k++)
            {
                logPstProp.Pmat(i,k)[0] = logPstProp.Pmat(i,k)[0]-SumLog;
            }
            
        }
        
        
//        for(i=0;i<logPstProp.nRows;i++)
//        {
//            for(k=0;k<logPstProp.nCols;k++)
//            {
//                Rprintf("%f ", exp(logPstProp.mat(i,k)));
//            }
//            Rprintf("\n");
//        }
       
        // sample
        i = nObs-1;
        Clusters->Zeta.Pvec(i)[0] = Kobs-1;
        
        
        for(i=nObs-2;i>=max(Kobs-1,0);i--)
        {
            
            if(Clusters->Zeta.vec(i+1)!=0)
            {
                k = Clusters->Zeta.vec(i+1)-1;
                Sampst.Pvec(0)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                
                k = Clusters->Zeta.vec(i+1);
                Sampst.Pvec(1)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                
                Clusters->Zeta.Pvec(i)[0] = Class_Utils::sample_DiscreteVar(Sampst.Pvec(0), 2)+Clusters->Zeta.vec(i+1)-1;
            }else{
                Clusters->Zeta.Pvec(i)[0] = 0;
            }
            
        }
        for(i=max(Kobs-2,0);i>=0;i--)
        {
            if(Clusters->Zeta.vec(i+1)==(i+1))
            {
                Clusters->Zeta.Pvec(i)[0] = i;
            }else{
                if(Clusters->Zeta.vec(i+1)!=0)
                {
                    k = Clusters->Zeta.vec(i+1)-1;
                    Sampst.Pvec(0)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                    
                    k = Clusters->Zeta.vec(i+1);
                    Sampst.Pvec(1)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                    
                    Clusters->Zeta.Pvec(i)[0] = Class_Utils::sample_DiscreteVar(Sampst.Pvec(0), 2)+Clusters->Zeta.vec(i+1)-1;
                }else{
                    Clusters->Zeta.Pvec(i)[0] = 0;
                }
            }
        }
        
        
        for(i=0;i<nObs;i++)
        {
            Clusters->Zeta.Pvec(i)[0] = Clusters->NonEmptyC.vec(Clusters->Zeta.Pvec(i)[0]);
        }
        //Clusters->Zeta.Print("Zeta");
        Clusters->update_EmptyAndNonEmptyClusters();
        //error("SS");
//        if(Clusters->nNonEmpty<=0)
//        {
//            Rprintf("\n\n s_T = Kmax - CP approximation may be no more valid\n\n");
//        }
//
    }
    
    
    void samp_stChangePointDPNotSequentialstFixedK_CheckLastElement()
    {
        
        
        
        double Molt = 1.0;
        int k,i, kprec;
        double SumLog;
        
        int Kobs;
        
        
        
        double Sampst_P[2];
        Vector <double> Sampst(2,Sampst_P);
        
        double applogPstProp_P[2];
        Vector <double> applogPstProp(2,applogPstProp_P);
        applogPstProp.Init(0.0);
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        //        int ClusterIndex_P[Kmax];
        //        Vector <int> ClusterIndex(Kmax,ClusterIndex_P);
        //
        
        Kobs = Clusters->nNonEmpty;
        
        
        //        for(k=0;k<Clusters->nNonEmpty;k++)
        //        {
        //            ClusterIndex.Pvec(k)[0] = Clusters->NonEmptyC.vec(k);
        //        }
        
        //        k = 0;
        //        ClusterIndex.Pvec(0)[0] = Clusters->Zeta.vec(0);
        //        for(i=1;i<nObs;i++)
        //        {
        //            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
        //            {
        //                k++;
        //                ClusterIndex.Pvec(k)[0] = Clusters->Zeta.vec(i);
        //            }
        //        }
        //
        
        double logPstProp_P[Kobs*nObs];
        Matrix <double> logPstProp(nObs,Kobs,logPstProp_P);
        logPstProp.Init(0.0);
        
        double logMatCPProb_P[Kobs*Kobs];
        Matrix <double> logMatCPProb(Kobs,Kobs,logMatCPProb_P);
        
        double VecLike_P[Kobs];
        Vector<double> VecLike(Kobs,VecLike_P);
        
        logMatCPProb.Init(0.0);
        for(k=0;k<Kobs-1;k++)
        {
            //k = ClusterIndex.vec(k);
            logMatCPProb.Pmat(k,k)[0] = log(Molt*Clusters->Probs->ProbsAcc[0]->vec(Clusters->NonEmptyC.vec(k)));
            logMatCPProb.Pmat(k,k+1)[0] = log(Molt-Molt*Clusters->Probs->ProbsAcc[0]->vec(Clusters->NonEmptyC.vec(k)));
            //logMatCPProb.Pmat(k,k)[0] = 0.0;
        }
        logMatCPProb.Pmat(Kobs-1,Kobs-1)[0] = 0.0;
        
        logPstProp.Pmat(0,0)[0] = 0.0;
        //Rprintf("CCww \n");
        for(i=1;i<Kobs;i++)
        {
            k = 0;
            kprec = 0;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
            for(k=1;k<i;k++)
            {
                kprec = k-1;
                applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                //Rprintf("AAA %f %f %f  \n", applogPstProp.Pvec(0)[0],logMatCPProb.mat(kprec,k),logPstProp.mat(i-1,kprec) );
                kprec = k;
                applogPstProp.Pvec(1)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                //Rprintf("AAA %f %f %f \n", applogPstProp.Pvec(1)[0],logMatCPProb.mat(kprec,k),logPstProp.mat(i-1,kprec) );
                
                
                
                Class_Utils::log_sum_exp(logPstProp.Pmat(i,k), 2, applogPstProp.Pvec(0));
                //Rprintf("%f dd\n",logPstProp.Pmat(i,k)[0]);
                //log_sum_exp(double *ret, int k, double *logx)
            }
            k = i;
            kprec = k-1;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
            //Rprintf("%f \n",logPstProp.Pmat(i,k)[0]);
            
            
            ObsY.P = Y.Pmat(i,0);
            for(k=0;k<=i;k++)
            {
                Likelihood->computeLogDensityForLike(VecLike.Pvec(k),&ObsY, &Container[Clusters->NonEmptyC.vec(k)], i);
            }
            for(k=0;k<=i;k++)
            {
                logPstProp.Pmat(i,k)[0] += VecLike.vec(k);
            }
            Class_Utils::log_sum_exp(&SumLog, i+1, logPstProp.Pmat(i,0));
            //log_sum_exp(double *ret, int k, double *logx)
            for(k=0;k<=i;k++)
            {
                logPstProp.Pmat(i,k)[0] = logPstProp.Pmat(i,k)[0]-SumLog;
            }
            //Rprintf("\n");
        }
        //Rprintf("CC \n");
        
        
        for(i=Kobs;i<nObs;i++)
        {
            
            k = 0;
            kprec = 0;
            applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
            logPstProp.Pmat(i,k)[0] = applogPstProp.Pvec(0)[0];
            
            for(k=1;k<Kobs;k++)
            {
                kprec = k-1;
                applogPstProp.Pvec(0)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                kprec = k;
                applogPstProp.Pvec(1)[0] =  logMatCPProb.mat(kprec,k)-log(Molt)+logPstProp.mat(i-1,kprec);
                Class_Utils::log_sum_exp(logPstProp.Pmat(i,k), 2, applogPstProp.Pvec(0));
                
            }
            ObsY.P = Y.Pmat(i,0);
            for(k=0;k<Kobs;k++)
            {
                Likelihood->computeLogDensityForLike(VecLike.Pvec(k),&ObsY, &Container[Clusters->NonEmptyC.vec(k)], i);
            }
            for(k=0;k<Kobs;k++)
            {
                logPstProp.Pmat(i,k)[0] += VecLike.vec(k);
            }
            Class_Utils::log_sum_exp(&SumLog, Kobs, logPstProp.Pmat(i,0));
            for(k=0;k<Kobs;k++)
            {
                logPstProp.Pmat(i,k)[0] = logPstProp.Pmat(i,k)[0]-SumLog;
            }
            
        }
        
        
        //        for(i=0;i<logPstProp.nRows;i++)
        //        {
        //            for(k=0;k<logPstProp.nCols;k++)
        //            {
        //                Rprintf("%f ", exp(logPstProp.mat(i,k)));
        //            }
        //            Rprintf("\n");
        //        }
        
        // sample
        i = nObs-1;
        Clusters->Zeta.Pvec(i)[0] = Kobs-1;
        
        
        for(i=nObs-2;i>=max(Kobs-1,0);i--)
        {
            
            if(Clusters->Zeta.vec(i+1)!=0)
            {
                k = Clusters->Zeta.vec(i+1)-1;
                Sampst.Pvec(0)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                
                k = Clusters->Zeta.vec(i+1);
                Sampst.Pvec(1)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                
                Clusters->Zeta.Pvec(i)[0] = Class_Utils::sample_DiscreteVar(Sampst.Pvec(0), 2)+Clusters->Zeta.vec(i+1)-1;
            }else{
                Clusters->Zeta.Pvec(i)[0] = 0;
            }
            
        }
        for(i=max(Kobs-2,0);i>=0;i--)
        {
            if(Clusters->Zeta.vec(i+1)==(i+1))
            {
                Clusters->Zeta.Pvec(i)[0] = i;
            }else{
                if(Clusters->Zeta.vec(i+1)!=0)
                {
                    k = Clusters->Zeta.vec(i+1)-1;
                    Sampst.Pvec(0)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                    
                    k = Clusters->Zeta.vec(i+1);
                    Sampst.Pvec(1)[0] = logPstProp.Pmat(i,k)[0] + (logMatCPProb.mat(k,Clusters->Zeta.vec(i+1)));
                    
                    Clusters->Zeta.Pvec(i)[0] = Class_Utils::sample_DiscreteVar(Sampst.Pvec(0), 2)+Clusters->Zeta.vec(i+1)-1;
                }else{
                    Clusters->Zeta.Pvec(i)[0] = 0;
                }
            }
        }
        
        
        for(i=0;i<nObs;i++)
        {
            Clusters->Zeta.Pvec(i)[0] = Clusters->NonEmptyC.vec(Clusters->Zeta.Pvec(i)[0]);
        }
        //Clusters->Zeta.Print("Zeta");
        Clusters->update_EmptyAndNonEmptyClusters();
        //error("SS");
        //        if(Clusters->nNonEmpty<=0)
        //        {
        //            Rprintf("\n\n s_T = Kmax - CP approximation may be no more valid\n\n");
        //        }
        //
    }
    
    
    
 
    double compute_loggammaSampleCP(double eta, double c, int n)
    {
        double ret;
        ret = lgamma(eta+1.0)+lgamma(n+1)-lgamma(n+1+eta+1-c);
        return(ret);
    }
    
    
//

    // ANCHOR test split
    void samp_stChangePointSplit_CheckLastElement(Class_Parameter *eta)
    {
        //Rprintf("Split\n");
        int ErrorNumberClusters = 0;
        int CheckError = 0;
        int Kobs;
        //int KobsStar;
        int Kempty;
        //int k;
        int k0;
        int k0prec;
        int kK;
        
        
        int deltaP1;
        int deltaL1;
        int deltak;
        
        int kNew;
        int i,j;
        int samp;
        //int knext;
        int KmaxObs;
        int KFirstObs;
        int KsecondObs;
        int KmaxObsL1;
        int kSeq;
        int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        double appProb;
        
        //double LogLikeL1 = 0.0;
        //double LogLikeP1 = 0.0;
        //double LogLikek_New = 0.0;
        double LogLikek_k = 0.0;
        double LogLikek_P1 = 0.0;
        double LogLikek_L1 = 0.0;
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int startL1pre = 0;
        int endL1 = 0;
        int endL1pre = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nL1pre = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexL1pre = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        double gammaP1;
        double gammaL1;
        double gammak;
        double gammaL1k;
        double gammaP1k;
       
        

        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        Kvoid = Clusters->nEmpty;
        Kempty = Clusters->nEmpty;
   
        
        
        
        
        k0 = 1;
        kK = 0;
        kNew = 0;
        
        deltaP1 = 0;
        deltaL1 = 0;
        deltak = 0;
        
        k0prec = 1;
        
        //
        

        
        //KobsStar = Kobs;
        KmaxObs = Clusters->NonEmptyC.vec(Kobs-1);
        KFirstObs = Clusters->NonEmptyC.vec(0);
        
        if(Kobs>1)
        {
            KmaxObsL1 = Clusters->NonEmptyC.vec(Kobs-2);
            KsecondObs = Clusters->NonEmptyC.vec(1);
        }else{
            KmaxObsL1 = KmaxObs;
            KsecondObs = KFirstObs;
        }
        
        
        
        //if(Kobs>1)
        //{
        
        kSeq                = 0;
        IndexL1             = Clusters->NonEmptyC.vec(kSeq);
        IndexL1pre = IndexL1;
        if(Kobs>1)
        {
            IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
        }else{
            IndexP1             = IndexL1;
        }
        Indexk              = Clusters->EmptyC.vec(kNew);
        
        
        startk      = 0;
        startL1     = 0;
        startL1pre     = startL1;
        
        
        endL1       = startL1;
        endL1pre = endL1;
        endk        = startL1+Clusters->NObsInClust.vec(IndexL1)-1;
        
        
        nL1         = endL1-startL1+1;
        nL1pre         = nL1;
        nk          = endk-startk+1; //
        
        if(Kobs>1)
        {
            //Rprintf("MMM %i \n",Kobs);
            startP1     = startL1+Clusters->NObsInClust.vec(IndexL1);
            endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
            nP1         = endP1-startP1+1;
        }

        if(Clusters->nEmpty==0)
        {
            ErrorNumberClusters = 1;
            CheckError = 1;
            //Rprintf("Inizia con il numero max di stati\n");
        }
        

//       Clusters->Zeta.Print("Zeta");
//        Clusters->NObsInClust.Print("NObsInClust");
//        Clusters->NObsInClust.Print("NObsInClust");
//Rprintf("\nSPLIT\n");
        for(i=0;i<nObs;i++)
        {
//            Rprintf("Indice %i\n",i);
//            Rprintf("L1pre %i %i %i %i\n", IndexL1pre, startL1pre, endL1pre, nL1pre);
//            Rprintf("L1 %i %i %i %i\n", IndexL1, startL1, endL1, nL1);
//            Rprintf("P1 %i %i %i %i\n", IndexP1, startP1, endP1, nP1);
//            Rprintf("k %i %i %i %i\n", Indexk, startk, endk, nk);

            if(ErrorNumberClusters==1)
            {
                if(CheckError==0)
                {
                    //Rprintf("K may be non well estimated\n");
                    CheckError = 1;
                }
                
            }else{
                if((startL1==startk)&(nk>0))
                {
                    //Rprintf("Nuovo codice");

                    LogLikek_k = 0.0;
                    LogLikek_P1 = 0.0;
                    LogLikek_L1 = 0.0;
                    
                    
                    j = startk;
                    ObsY.P = Y.Pmat(j,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                    LogLikek_k += appProb;
                    
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                    LogLikek_L1 += appProb;
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1pre],j);
                        LogLikek_P1 += appProb;
                    }
                    
                    // if(nk>1)
                    // {
                    
                    // }else{
                    //     gammaL1     = 0.0;
                    //     gammaL1k     = 0.0;
                    // }
                    
                    gammaL1         = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0),nk-1);
                    gammaL1k        = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0),nk);
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        gammaP1    = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1pre);
                        gammaP1k   = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1pre+1);
                    }else{
                        gammaP1    = 0.0;
                        gammaP1k   = 0.0;
                    }
                    
                    gammak          = compute_loggammaSampleCP(eta->ParameterAcc, 0,1);
                    
                    
                    
                    logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1;
                    logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1;
                    logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k;
                    
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                        //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                        //Rprintf("SAmpione su 2, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                    }
                    
                    
                    if(samp==0)
                    {
                        // rimando su dove ero
                        //                    Rprintf("\nS0\n");
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        // NO_ERROR Indexk      = Indexk;
                        
                        // NO_ERROR startL1     = startL1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        // NO_ERROR endL1pre       = endL1pre;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                    }
                    if(samp==1)
                    {
                        // cmapiono k
                        //                    Rprintf("\nS1\n");
                        //
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j=startk;
                        Clusters->Zeta.Pvec(j)[0]  = Indexk;
                        
                        startL1pre     = startk;
                        endL1pre       = startk;
                        nL1pre         = endL1pre-startL1pre+1;
                        IndexL1pre     = Indexk;
                        
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        startk      = startL1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                    }
                    if(samp==2)
                    {
                        // passo a quello prima
                        //                    Rprintf("\nS2\n");
                        //                    Rprintf("%f %f \n", logProbL1[0],logProbk[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j= startk;
                        Clusters->Zeta.Pvec(j)[0]  = IndexL1pre;
                        
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        endL1pre       = endL1pre+1;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
 
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                    }
                    
                    
                    
                }else{
                    if((nk!=0))
                    {
                        //Rprintf("Vecchio codice\n");

                        
                        if(nL1==1)
                        {
                            LogLikek_k = 0.0;
                            LogLikek_P1 = 0.0;
                            LogLikek_L1 = 0.0;

                            for(j=startk;j<=endk;j++)
                            {
                                ObsY.P = Y.Pmat(j,0);
                                //ObsY.Print("Y");
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                                LogLikek_k += appProb;
                                //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                                LogLikek_L1 += appProb;
                                //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                                
                                
                                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                                {
                                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                    LogLikek_P1 += appProb;
                                    //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                                }
                            }
                            
                        }else{
                            j = startk-1;
                            
                            ObsY.P = Y.Pmat(j,0);
                            //ObsY.Print("Y");
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                            LogLikek_k -= appProb;
                            //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                            LogLikek_L1 -= appProb;
                            //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                            
                            
                            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                            {
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                LogLikek_P1 -= appProb;
                                //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                            }
                        }
//                        LogLikek_k = 0.0;
//                        LogLikek_P1 = 0.0;
//                        LogLikek_L1 = 0.0;

//                        for(j=startk;j<=endk;j++)
//                        {
//                            //Rprintf("j = %i\n",j);
//                            ObsY.P = Y.Pmat(j,0);
//                            //ObsY.Print("Y");
//                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
//                            LogLikek_k += appProb;
//                            //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
//                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
//                            LogLikek_L1 += appProb;
//                            //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
//
//
//                            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
//                            {
//                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
//                                LogLikek_P1 += appProb;
//                                //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
//                            }
//                        }
                        gammaL1     = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1);
                        
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            gammaP1     = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1,nObs-1,1,0),nP1);
                            gammaP1k    = compute_loggammaSampleCP(eta->ParameterAcc,Class_Utils::ifelse(endP1,nObs-1,1,0), nP1+nk);
                        }else{
                            gammaP1     = 0.0;
                            gammaP1k    = 0.0;
                        }
                        
                        gammak      = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0), nk);
                        gammaL1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0), nL1+nk);
                        
                        
                        logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1;
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1;
                        }
                        
                        logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k;
                        
                        
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                            //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                        }else{
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                            //Rprintf("SAmpione su 2, z=%i %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                        }
                        
                        
                        
                        //Rprintf("Samp %i\n", samp);
                        if(samp==0)
                        {
                            //                        Rprintf("\nS0\n");
                            //                        Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                            //                        Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            // NO_ERROR Indexk      = Indexk;
                            
                            
                            // NO_ERROR startL1     = startL1;
                            endL1       = endL1+1;
                            nL1         = endL1-startL1+1;
                            // NO_ERROR IndexL1      = IndexL1;
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            // NO_ERROR startL1pre     = startL1pre;
                            // NO_ERROR endL1pre       = endL1pre;
                            nL1pre         = endL1pre-startL1pre+1;
                            // NO_ERROR IndexL1pre      = IndexL1pre;
                            
                            
                            
                        }
                        if(samp==1)
                        {
                            //                        Rprintf("\nS1\n");
                            //
                            //                        Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                            //                        Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = Indexk;
                            }
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre          = nL1;
                            IndexL1pre      = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = Indexk;
                            
                            
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            kNew++;
                            if(kNew>=(Kvoid-2))
                            {
                                ErrorNumberClusters = 1;
                            }else{
                                
                                Indexk              = Clusters->EmptyC.vec(kNew);
                            }
                        }
                        if(samp==2)
                        {
                            //                        Rprintf("\nS2\n");
                            //                        Rprintf("%f %f \n", logProbL1[0],logProbk[0]);
                            //                        Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                            //                        Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = IndexP1;
                            }
                            
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre              = nL1;
                            IndexL1pre          = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            endk        = endP1;
                            nk          = endk-startk+1;
                            // NO_ERROR Indexk      = Indexk;
//                            kNew++;
//                            if(kNew>=(Kvoid-2))
//                            {
//                                ErrorNumberClusters = 1;
//                            }else{
//
//                                Indexk              = Clusters->EmptyC.vec(kNew);
//                            }


                            if(IndexL1!=KmaxObs)
                            {
                                kSeq++;
                                IndexP1      =  Clusters->NonEmptyC.vec(kSeq+1);
                                startP1     = endk+1;
                                endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                nP1         = endP1-startP1+1;
                            }
                            
                        }
                        
                        
                    }else{
                        if(IndexL1!=KmaxObs)
                        {
                            //Rprintf("Non campiono\n");
                            
                            
                            startL1pre = startL1;
                            endL1pre = endL1;
                            nL1pre  = nL1;
                            IndexL1pre = IndexL1;
                            
                            IndexL1             = IndexP1;
                            startL1             = startP1;
                            endL1               = startP1;
                            nL1                 = endL1-startL1+1;
                            
                            
                            // NO_ERROR Indexk              = Indexk;
                            startk              = startL1;
                            endk                = endP1;
                            nk                  = endk-startk+1;
                            
                            if(IndexP1!=KmaxObs)
                            {
                                kSeq++;
                                //Rprintf("\nSstar1\n");
                                IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
                                //Rprintf("\nSstar2\n");
                                startP1             = startL1+Clusters->NObsInClust.vec(IndexL1);
                                //Rprintf("\nSsta3\n");
                                endP1               = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                //Rprintf("\nSstar5\n");
                                nP1                 = endP1-startP1+1;
                            }
                        }
                        
                    }
                }
            }
    
            

            
            
        }
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }

        //Clusters->Zeta.Print("ZetaPost");
        
        //Clusters->Zeta.Print("Zeta");
        
        //error("STOP");
           Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    
    void samp_stChangePointSplit_CheckLastElement_CheckCor(Class_Parameter *eta)
    {
        //Rprintf("Split\n");
        int ErrorNumberClusters = 0;
        int CheckError = 0;
        int Kobs;
        //int KobsStar;
        int Kempty;
        //int k;
        int k0;
        int k0prec;
        int kK;
        
        
        int deltaP1;
        int deltaL1;
        int deltak;
        
        int kNew;
        int i,j;
        int samp;
        //int knext;
        int KmaxObs;
        int KFirstObs;
        int KsecondObs;
        int KmaxObsL1;
        int kSeq;
        int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        double appProb;
        
        //double LogLikeL1 = 0.0;
        //double LogLikeP1 = 0.0;
        //double LogLikek_New = 0.0;
        double LogLikek_k = 0.0;
        double LogLikek_P1 = 0.0;
        double LogLikek_L1 = 0.0;
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int startL1pre = 0;
        int endL1 = 0;
        int endL1pre = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nL1pre = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexL1pre = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        double gammaP1 = 0.0;
        double gammaL1 = 0.0;
        double gammak = 0.0;
        double gammaL1k = 0.0;
        double gammaP1k = 0.0;
        
        
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        Kvoid = Clusters->nEmpty;
        Kempty = Clusters->nEmpty;
        
        
        
        
        
        k0 = 1;
        kK = 0;
        kNew = 0;
        
        deltaP1 = 0;
        deltaL1 = 0;
        deltak = 0;
        
        k0prec = 1;
        
        //
        
        
        
        //KobsStar = Kobs;
        KmaxObs = Clusters->NonEmptyC.vec(Kobs-1);
        KFirstObs = Clusters->NonEmptyC.vec(0);
        
        if(Kobs>1)
        {
            KmaxObsL1 = Clusters->NonEmptyC.vec(Kobs-2);
            KsecondObs = Clusters->NonEmptyC.vec(1);
        }else{
            KmaxObsL1 = KmaxObs;
            KsecondObs = KFirstObs;
        }
        
        
        
        //if(Kobs>1)
        //{
        
        kSeq                = 0;
        IndexL1             = Clusters->NonEmptyC.vec(kSeq);
        IndexL1pre = IndexL1;
        if(Kobs>1)
        {
            IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
        }else{
            IndexP1             = IndexL1;
        }
        Indexk              = Clusters->EmptyC.vec(kNew);
        
        
        startk      = 0;
        startL1     = 0;
        startL1pre     = startL1;
        
        
        endL1       = startL1;
        endL1pre = endL1;
        endk        = startL1+Clusters->NObsInClust.vec(IndexL1)-1;
        
        
        nL1         = endL1-startL1+1;
        nL1pre         = nL1;
        nk          = endk-startk+1; //
        
        if(Kobs>1)
        {
            //Rprintf("MMM %i \n",Kobs);
            startP1     = startL1+Clusters->NObsInClust.vec(IndexL1);
            endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
            nP1         = endP1-startP1+1;
        }
        
        if(Clusters->nEmpty==0)
        {
            ErrorNumberClusters = 1;
            CheckError = 1;
            //Rprintf("Inizia con il numero max di stati\n");
        }
        
        
        //       Clusters->Zeta.Print("Zeta");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //Rprintf("\nSPLIT\n");
        for(i=0;i<nObs;i++)
        {
            //            Rprintf("Indice %i\n",i);
            //            Rprintf("L1pre %i %i %i %i\n", IndexL1pre, startL1pre, endL1pre, nL1pre);
            //            Rprintf("L1 %i %i %i %i\n", IndexL1, startL1, endL1, nL1);
            //            Rprintf("P1 %i %i %i %i\n", IndexP1, startP1, endP1, nP1);
            //            Rprintf("k %i %i %i %i\n", Indexk, startk, endk, nk);
            
            if(ErrorNumberClusters==1)
            {
                if(CheckError==0)
                {
                    //Rprintf("K may be non well estimated\n");
                    CheckError = 1;
                }
                
            }else{
                if((startL1==startk)&(nk>0))
                {
                    //Rprintf("Nuovo codice");
                    
                    LogLikek_k = 0.0;
                    LogLikek_P1 = 0.0;
                    LogLikek_L1 = 0.0;
                    
                    
                    j = startk;
                    ObsY.P = Y.Pmat(j,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                    LogLikek_k += appProb;
                    
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                    LogLikek_L1 += appProb;
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1pre],j);
                        LogLikek_P1 += appProb;
                    }
                    
                    // if(nk>1)
                    // {
                    
                    // }else{
                    //     gammaL1     = 0.0;
                    //     gammaL1k     = 0.0;
                    // }
                    
                    gammaL1         = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0),nk-1);
                    gammaL1k        = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0),nk);
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        gammaP1    = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1pre);
                        gammaP1k   = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1pre+1);
                    }else{
                        gammaP1    = 0.0;
                        gammaP1k   = 0.0;
                    }
                    
                    gammak          = compute_loggammaSampleCP(eta->ParameterAcc, 0,1);
                    
                    
                    
                    logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1;
                    logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1;
                    logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k;
                    
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                        //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                        //Rprintf("SAmpione su 2, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                    }
                    
                    
                    if(samp==0)
                    {
                        // rimando su dove ero
                        //                    Rprintf("\nS0\n");
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        // NO_ERROR Indexk      = Indexk;
                        
                        // NO_ERROR startL1     = startL1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        // NO_ERROR endL1pre       = endL1pre;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                    }
                    if(samp==1)
                    {
                        // cmapiono k
                        //                    Rprintf("\nS1\n");
                        //
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j=startk;
                        Clusters->Zeta.Pvec(j)[0]  = Indexk;
                        
                        startL1pre     = startk;
                        endL1pre       = startk;
                        nL1pre         = endL1pre-startL1pre+1;
                        IndexL1pre     = Indexk;
                        
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        startk      = startL1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                    }
                    if(samp==2)
                    {
                        // passo a quello prima
                        //                    Rprintf("\nS2\n");
                        //                    Rprintf("%f %f \n", logProbL1[0],logProbk[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j= startk;
                        Clusters->Zeta.Pvec(j)[0]  = IndexL1pre;
                        
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        endL1pre       = endL1pre+1;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                    }
                    
                    
                    
                }else{
                    if((nk!=0))
                    {
                        //Rprintf("Vecchio codice\n");
                        
                        
                        if(nL1==1)
                        {
                            LogLikek_k = 0.0;
                            LogLikek_P1 = 0.0;
                            LogLikek_L1 = 0.0;
                            
                            for(j=startk;j<=endk;j++)
                            {
                                ObsY.P = Y.Pmat(j,0);
                                //ObsY.Print("Y");
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                                LogLikek_k += appProb;
                                //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                                LogLikek_L1 += appProb;
                                //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                                
                                
                                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                                {
                                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                    LogLikek_P1 += appProb;
                                    //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                                }
                            }
                            
                        }else{
                            j = startk-1;
                            
                            ObsY.P = Y.Pmat(j,0);
                            //ObsY.Print("Y");
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                            LogLikek_k -= appProb;
                            //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                            LogLikek_L1 -= appProb;
                            //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                            
                            
                            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                            {
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                LogLikek_P1 -= appProb;
                                //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                            }
                        }
                        //                        LogLikek_k = 0.0;
                        //                        LogLikek_P1 = 0.0;
                        //                        LogLikek_L1 = 0.0;
                        
                        //                        for(j=startk;j<=endk;j++)
                        //                        {
                        //                            //Rprintf("j = %i\n",j);
                        //                            ObsY.P = Y.Pmat(j,0);
                        //                            //ObsY.Print("Y");
                        //                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                        //                            LogLikek_k += appProb;
                        //                            //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                        //                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                        //                            LogLikek_L1 += appProb;
                        //                            //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                        //
                        //
                        //                            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        //                            {
                        //                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                        //                                LogLikek_P1 += appProb;
                        //                                //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                        //                            }
                        //                        }
                        gammaL1     = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1);
                        
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            gammaP1     = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1,nObs-1,1,0),nP1);
                            gammaP1k    = compute_loggammaSampleCP(eta->ParameterAcc,Class_Utils::ifelse(endP1,nObs-1,1,0), nP1+nk);
                        }else{
                            gammaP1     = 0.0;
                            gammaP1k    = 0.0;
                        }
                        
                        gammak      = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0), nk);
                        gammaL1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0), nL1+nk);
                        
                        
                        logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1;
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1;
                        }
                        
                        logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k;
                        
                        
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                            //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                        }else{
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                            //Rprintf("SAmpione su 2, z=%i %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                        }
                        
                        
                        
                        //Rprintf("Samp %i\n", samp);
                        if(samp==0)
                        {
                            //                        Rprintf("\nS0\n");
                            //                        Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                            //                        Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            // NO_ERROR Indexk      = Indexk;
                            
                            
                            // NO_ERROR startL1     = startL1;
                            endL1       = endL1+1;
                            nL1         = endL1-startL1+1;
                            // NO_ERROR IndexL1      = IndexL1;
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            // NO_ERROR startL1pre     = startL1pre;
                            // NO_ERROR endL1pre       = endL1pre;
                            nL1pre         = endL1pre-startL1pre+1;
                            // NO_ERROR IndexL1pre      = IndexL1pre;
                            
                            
                            
                        }
                        if(samp==1)
                        {
                            //                        Rprintf("\nS1\n");
                            //
                            //                        Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                            //                        Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = Indexk;
                            }
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre          = nL1;
                            IndexL1pre      = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = Indexk;
                            
                            
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            kNew++;
                            if(kNew>=(Kvoid-2))
                            {
                                ErrorNumberClusters = 1;
                            }else{
                                
                                Indexk              = Clusters->EmptyC.vec(kNew);
                            }
                        }
                        if(samp==2)
                        {
                            //                        Rprintf("\nS2\n");
                            //                        Rprintf("%f %f \n", logProbL1[0],logProbk[0]);
                            //                        Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                            //                        Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                            //                        Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = IndexP1;
                            }
                            
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre              = nL1;
                            IndexL1pre          = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            endk        = endP1;
                            nk          = endk-startk+1;
                            // NO_ERROR Indexk      = Indexk;
                            //                            kNew++;
                            //                            if(kNew>=(Kvoid-2))
                            //                            {
                            //                                ErrorNumberClusters = 1;
                            //                            }else{
                            //
                            //                                Indexk              = Clusters->EmptyC.vec(kNew);
                            //                            }
                            
                            
                            if(IndexL1!=KmaxObs)
                            {
                                kSeq++;
                                IndexP1      =  Clusters->NonEmptyC.vec(kSeq+1);
                                startP1     = endk+1;
                                endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                nP1         = endP1-startP1+1;
                            }
                            
                        }
                        
                        
                    }else{
                        if(IndexL1!=KmaxObs)
                        {
                            //Rprintf("Non campiono\n");
                            
                            
                            startL1pre = startL1;
                            endL1pre = endL1;
                            nL1pre  = nL1;
                            IndexL1pre = IndexL1;
                            
                            IndexL1             = IndexP1;
                            startL1             = startP1;
                            endL1               = startP1;
                            nL1                 = endL1-startL1+1;
                            
                            
                            // NO_ERROR Indexk              = Indexk;
                            startk              = startL1;
                            endk                = endP1;
                            nk                  = endk-startk+1;
                            
                            if(IndexP1!=KmaxObs)
                            {
                                kSeq++;
                                //Rprintf("\nSstar1\n");
                                IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
                                //Rprintf("\nSstar2\n");
                                startP1             = startL1+Clusters->NObsInClust.vec(IndexL1);
                                //Rprintf("\nSsta3\n");
                                endP1               = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                //Rprintf("\nSstar5\n");
                                nP1                 = endP1-startP1+1;
                            }
                        }
                        
                    }
                }
            }
            
            
            
            
            
        }
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        //Clusters->Zeta.Print("ZetaPost");
        
        //Clusters->Zeta.Print("Zeta");
        
        //error("STOP");
        Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    
    void sample_DPparameterGammaPrior_CP(Class_Parameter *eta)
    {
        double s = 0.0;
        double r = 0.0;
        for(int k1=0;k1<Clusters->nNonEmpty-1;k1++)
        {
            int k = Clusters->NonEmptyC.vec(k1);
            
            r += log(rbeta(eta->ParameterAcc+1, 1.0*Clusters->NObsInClust.vec(k)+1.0   )  );
            double u = runif(0.0,1.0);
            if(u< (1.0*Clusters->NObsInClust.vec(k)+1.0 )/(1.0*Clusters->NObsInClust.vec(k)+1.0+eta->ParameterAcc ) )
            {
                s++;
            }
        }
        int k1;
        k1 = Clusters->nNonEmpty-1;
        int k = Clusters->NonEmptyC.vec(k1);
        
        r += log(rbeta(eta->ParameterAcc+1, 1.0*Clusters->NObsInClust.vec(k)   )  );
        double u = runif(0.0,1.0);
        if(u< (1.0*Clusters->NObsInClust.vec(k) )/(1.0*Clusters->NObsInClust.vec(k)+eta->ParameterAcc ) )
        {
            s++;
        }
        eta->ParameterAcc = rgamma(eta->PriorParameter->HyperparametersAcc.vec(0)[0]+2.0*Clusters->nNonEmpty-1.0-s,1.0/(eta->PriorParameter->HyperparametersAcc.vec(1)[0]-r));
        
    }
    
    
    
    // ANCHOR MERGE st
    void samp_stChangePointMerge_CheckLastElement(Class_Parameter *eta)
    {
        int ControllWhile = 0;
        int StopMerge = 0;
        int Kobs;
        int KobsStar;
        int Kempty;
        int k;
        //int k0;
        //int k0prec;
        //int kK;
        //int kKP1;
        //int kNew;
        int i;
        int samp;
        //int knext;
   
        
        //int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        double appProb;
        
      
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int endL1 = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        double gammaP1 = 0.0;
        double gammaL1 = 0.0;
        
        double gammaL1k = 0.0;
        double gammaP1k = 0.0;
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        
        KobsStar = Kobs;
        Kempty = Clusters->nEmpty;
//        k0 = 1;
//        kK = 0;
//        //kNew = 0;
//        //kKP1 = 0;
//        k0prec = 1;
//
        //        int NonEmptyC_P[Kobs];
        //        Vector <int> NonEmptyC(Kobs,NonEmptyC_P);
        //        k = 0;
        //        NonEmptyC.Pvec(0)[0] = Clusters->Zeta.vec(0);
        //        for(i=1;i<nObs;i++)
        //        {
        //            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
        //            {
        //                k++;
        //                NonEmptyC.Pvec(k)[0] = Clusters->Zeta.vec(i);
        //            }
        //        }
        
        
        int VecPrec_P[Kmax];
        Vector <int>VecPrec(Kmax, VecPrec_P);
        
        int VecSuc_P[Kmax];
        Vector <int>VecSuc(Kmax, VecSuc_P);
        VecSuc.Init(-99);
        
        int VecN_P[Kmax];
        Vector <int>VecN(Kmax, VecN_P);
        VecN.Init(-99);
        
        int VecStart_P[Kmax];
        Vector <int>VecStart(Kmax, VecStart_P);
        VecStart.Init(-99);
        
        int VecEnd_P[Kmax];
        Vector <int>VecEnd(Kmax, VecEnd_P);
        VecEnd.Init(-99);
        
        
        VecStart.Pvec(Clusters->Zeta.vec(0))[0] = 0;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                VecPrec.Pvec(Clusters->Zeta.vec(i))[0] = Clusters->Zeta.vec(i-1);
                VecSuc.Pvec(Clusters->Zeta.vec(i-1))[0] = Clusters->Zeta.vec(i);
                VecStart.Pvec(Clusters->Zeta.vec(i))[0] = i;
                VecEnd.Pvec(Clusters->Zeta.vec(i-1))[0] = i-1;
            }
        }
        VecEnd.Pvec(Clusters->Zeta.vec(nObs-1))[0] = nObs-1;
        for(k=0;k<Kmax;k++)
        {
            VecN.Pvec(k)[0] = Clusters->NObsInClust.vec(k);
        }
        
        
        
        //knext       = 0;
 
        IndexL1     = Clusters->Zeta.vec(0);
        startL1     = VecStart.vec(IndexL1);
        endL1       = VecEnd.vec(IndexL1);
        nL1         = VecN.vec(IndexL1);
        
        
        Indexk     = Clusters->Zeta.vec(0);
        startk     = VecStart.vec(Indexk);
        endk       = VecEnd.vec(Indexk);
        nk         = VecN.vec(Indexk);
        
        if(Kobs>1)
        {
            IndexP1     = VecSuc.vec(Indexk);
            startP1     = VecStart.vec(IndexP1);
            endP1       = VecEnd.vec(IndexP1);
            nP1         = VecN.vec(IndexP1);
        }else{
            IndexP1     = Indexk;
            startP1     = startk;
            endP1       = endk;
            nP1         = nk;
        }

        if(Kobs==1)
        {
            StopMerge=1;
        }
        //Rprintf("Merge");
        while(StopMerge==0 ){
            
            ControllWhile++;
            
            double LogLikeL1 = 0.0;
            double LogLikeP1 = 0.0;
            //double LogLikek_New = 0.0;
            double LogLikek_k = 0.0;
            double LogLikek_P1 = 0.0;
            double LogLikek_L1 = 0.0;
            
            double gammak = 0.0;
            
            //LogLikeL1 = 0.0;
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                for(i=startL1;i<=endL1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                    LogLikeL1 += appProb;
                }
            }
            LogLikeP1 = 0.0;
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                for(i=startP1;i<=endP1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                    LogLikeP1 += appProb;
                }
            }
            
            
            LogLikek_k = 0.0;
            LogLikek_P1 = 0.0;
            LogLikek_L1 = 0.0;
            for(i=startk;i<=endk;i++)
            {
                ObsY.P = Y.Pmat(i,0);
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk], i);
                LogLikek_k += appProb;
                
                //Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexNew], i);
                //LogLikek_New += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                LogLikek_P1 += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                LogLikek_L1 += appProb;
            }
            
            
            gammak      = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk, nObs-1,1,0), nk);
            
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                gammaL1     = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1);
                gammaL1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0), nL1+nk);
            }else{
                gammaL1     = 0.0;
                gammaL1k    = 0.0;
            }
            
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                gammaP1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0), nP1+nk);
                gammaP1     = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0),nP1);
            }else{
                gammaP1k    = 0.0;
                gammaP1     = 0.0;
            }
            
            logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1+LogLikeL1+LogLikeP1;
            logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1+LogLikeP1+LogLikeL1;
            logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k+LogLikeP1+LogLikeL1;
            
            //REprintf("\n%f %f %f \n %f %f %f \n %f %f %f \n",LogLikeL1, LogLikek_k,LogLikeP1,
            //          LogLikek_L1,LogLikek_k,LogLikek_P1,
             //        logProbL1[0],logProbk[0],logProbP1[0]);
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // L1 e P1
                    samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                }else{
                    // L1
                    samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                }
            }else{
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // P1
                    samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(1), 2)+1;
                }else{
                    StopMerge   = 1;
                    samp        = 5;
                }
            }
            //logProb.Print("A");
            
            if(samp==0)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexL1;
                }
                
                //VecStart.Pvec(IndexL1)[0]       = VecStart.Pvec(IndexL1)[0];
                VecEnd.Pvec(IndexL1)[0]         = VecEnd.Pvec(Indexk)[0];
                VecN.Pvec(IndexL1)[0]           = VecN.Pvec(IndexL1)[0]+VecN.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                
                Indexk     = IndexL1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
            }
            if(samp==1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)==1)
                {
                    StopMerge = 1;
                }else{
                    if(Class_Utils::ifelse(endP1,nObs-1,1,0)!=1)
                    {
                        IndexP1     = VecSuc.vec(IndexP1);
                        startP1     = VecStart.vec(IndexP1);
                        endP1       = VecEnd.vec(IndexP1);
                        nP1         = VecN.vec(IndexP1);
                    }
                    
                    Indexk     = VecSuc.vec(Indexk);
                    startk     = VecStart.vec(Indexk);
                    endk       = VecEnd.vec(Indexk);
                    nk         = VecN.vec(Indexk);
                    
                    IndexL1     = VecPrec.vec(Indexk);
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                
                
            }
            if(samp==2)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexP1;
                }
                VecStart.Pvec(IndexP1)[0]       = VecStart.Pvec(Indexk)[0];
                //VecEnd.Pvec(IndexP1)[0]         = VecEnd.Pvec(IndexP1)[0];
                VecN.Pvec(IndexP1)[0]           = VecN.Pvec(IndexP1)[0]+VecN.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                Indexk     = IndexP1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
            }
            
        }
        
        if(ControllWhile>Kobs*Kobs)
        {
            error("CONTROLLARE WHILE LOOP");
        }
        
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        
        Clusters->update_EmptyAndNonEmptyClusters();
        
        
        
        
        
        
        //Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    
   
    
    
    
    
    
    
    
    
    void samp_stChangePointMerge(Class_Parameter *eta, int length, vector<VectorParameters> &xi, vector <Matrix<int >* >  &FromCpToLevel2, int isp)
    {
        int ControllWhile = 0;
        int StopMerge = 0;
        int Kobs;
        int KobsStar;
        int Kempty;
        int k;
        //int k0;
        //int k0prec;
        //int kK;
        //int kKP1;
        //int kNew;
        int i;
        int samp;
        //int knext;
        
        
        //int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        

        
        
        double appProb;
        
        
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int endL1 = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        double gammaP1 = 0.0;
        double gammaL1 = 0.0;
        
        double gammaL1k = 0.0;
        double gammaP1k = 0.0;
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        
        KobsStar = Kobs;
        Kempty = Clusters->nEmpty;

        
        int VecPrec_P[Kmax];
        Vector <int>VecPrec(Kmax, VecPrec_P);
        
        int VecSuc_P[Kmax];
        Vector <int>VecSuc(Kmax, VecSuc_P);
        VecSuc.Init(-99);
        
        int VecN_P[Kmax];
        Vector <int>VecN(Kmax, VecN_P);
        VecN.Init(-99);
        
        int VecStart_P[Kmax];
        Vector <int>VecStart(Kmax, VecStart_P);
        VecStart.Init(-99);
        
        int VecEnd_P[Kmax];
        Vector <int>VecEnd(Kmax, VecEnd_P);
        VecEnd.Init(-99);
        
        
        VecStart.Pvec(Clusters->Zeta.vec(0))[0] = 0;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                VecPrec.Pvec(Clusters->Zeta.vec(i))[0] = Clusters->Zeta.vec(i-1);
                VecSuc.Pvec(Clusters->Zeta.vec(i-1))[0] = Clusters->Zeta.vec(i);
                VecStart.Pvec(Clusters->Zeta.vec(i))[0] = i;
                VecEnd.Pvec(Clusters->Zeta.vec(i-1))[0] = i-1;
            }
        }
        VecEnd.Pvec(Clusters->Zeta.vec(nObs-1))[0] = nObs-1;
        for(k=0;k<Kmax;k++)
        {
            VecN.Pvec(k)[0] = Clusters->NObsInClust.vec(k);
        }
        
        
        //Likelihood->ProbSecondLev[0][ipar].VectorAcc.Pvec(k)[0];
        //knext       = 0;
        
        IndexL1     = Clusters->Zeta.vec(0);
        startL1     = VecStart.vec(IndexL1);
        endL1       = VecEnd.vec(IndexL1);
        nL1         = VecN.vec(IndexL1);
        
        
        Indexk     = Clusters->Zeta.vec(0);
        startk     = VecStart.vec(Indexk);
        endk       = VecEnd.vec(Indexk);
        nk         = VecN.vec(Indexk);
        
        if(Kobs>1)
        {
            IndexP1     = VecSuc.vec(Indexk);
            startP1     = VecStart.vec(IndexP1);
            endP1       = VecEnd.vec(IndexP1);
            nP1         = VecN.vec(IndexP1);
        }else{
            IndexP1     = Indexk;
            startP1     = startk;
            endP1       = endk;
            nP1         = nk;
        }
        
        
        
        /**** nuovi parametri ****/
        double probxiL1;
        double probxiP1;
        double probxiK;
        
        
        
        
        vector <int> ClustIndex;

        
        
        ClustIndex.push_back(Clusters->Zeta.vec(0));
        for(i=1;i<nObs;i++)
        {
            //REprintf("%i \n",Clusters->Zeta.vec(i));
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                ClustIndex.push_back(Clusters->Zeta.vec(i));
            }
        }
        
        
        vector <double> logXI;
        vector <double> logSumXI;
        for(k=0;k<ClustIndex.size();k++)
        {
            logXI.push_back(0.0);
            logSumXI.push_back(0.0);
            
            int ipar;
            
            ipar = 0;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat( ClustIndex[k],isp)));
            ipar = 2;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(ClustIndex[k],isp)));
            ipar = 4;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(ClustIndex[k],isp)) );
            for(ipar=5;ipar<12;ipar++)
            {
                logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(ClustIndex[k],isp)) );
            }
            
        }

        double AppSum[Kmax];
        logSumXI[0] = 0;
        for(k=1;k<ClustIndex.size();k++)
        {
            AppSum[k] = logXI[k-1];
            Class_Utils::log_sum_exp(&logSumXI[k],k, &AppSum[1]);
        }
        
//        REprintf("Cluster \n%i \n",Clusters->Zeta.vec(0));
//        for(i=1;i<nObs;i++)
//        {
//            REprintf("%i \n",Clusters->Zeta.vec(i));
//        }
//        REprintf("Stato inziale \n");
//        for(k=0;k<ClustIndex.size();k++)
//        {
//            REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
//        }

        
        int kxi = 0;
        
        /**** nuovi parametri  END ****/
        if(Kobs==1)
        {
            StopMerge=1;
        }
        //Rprintf("Merge");
        while(StopMerge==0 ){
            
            ControllWhile++;
            
            double LogLikeL1 = 0.0;
            double LogLikeP1 = 0.0;
            //double LogLikek_New = 0.0;
            double LogLikek_k = 0.0;
            double LogLikek_P1 = 0.0;
            double LogLikek_L1 = 0.0;
            
            double gammak = 0.0;
            
            //LogLikeL1 = 0.0;
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                for(i=startL1;i<=endL1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                    LogLikeL1 += appProb;
                }
            }
            LogLikeP1 = 0.0;
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                for(i=startP1;i<=endP1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                    LogLikeP1 += appProb;
                }
            }
            
            
            LogLikek_k = 0.0;
            LogLikek_P1 = 0.0;
            LogLikek_L1 = 0.0;
            for(i=startk;i<=endk;i++)
            {
                ObsY.P = Y.Pmat(i,0);
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk], i);
                LogLikek_k += appProb;
                
                //Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexNew], i);
                //LogLikek_New += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                LogLikek_P1 += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                LogLikek_L1 += appProb;
            }
            
            
            gammak      = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk, nObs-1,1,0), nk);
            
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                gammaL1     = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1);
                gammaL1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0), nL1+nk);
            }else{
                gammaL1     = 0.0;
                gammaL1k    = 0.0;
            }
            
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                gammaP1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0), nP1+nk);
                gammaP1     = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0),nP1);
            }else{
                gammaP1k    = 0.0;
                gammaP1     = 0.0;
            }
            
            // contributo prob G_0
            probxiL1 = 0.0;
            probxiP1 = 0.0;
            probxiK  = logXI[kxi];
            
            //REprintf("probxiK kxi=%i \n", kxi);
            for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
            {
                probxiK -= Class_Utils::log1mexp(logSumXI[jjj]);
                //REprintf("jjj=%i logSumXI[jjj] %f sum %e %e \n",jjj,logSumXI[jjj],Class_Utils::log1mexp(logSumXI[jjj]),probxiK);
            }
            //REprintf("probxip1 kxi=%i \n", kxi);
            for(int jjj=kxi+2;jjj<ClustIndex.size();jjj++)
            {
                probxiP1 -= Class_Utils::log1mexp( log(exp( logSumXI[jjj] )- exp(logXI[kxi])  ));
                //REprintf("jjj=%i logSumXI[jjj] %f sum %e %e \n",jjj,log(exp( logSumXI[jjj] )- exp(logXI[kxi])  ),Class_Utils::log1mexp( log(exp( logSumXI[jjj] )- exp(logXI[kxi])  )), probxiP1);
            }
            probxiL1 = probxiP1;
            //
            logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1+LogLikeL1+LogLikeP1+probxiL1;
            logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1+LogLikeP1+LogLikeL1+probxiP1;
            logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k+LogLikeP1+LogLikeL1+probxiK;
            
            
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // L1 e P1
                    if(nk<length)
                    {
                        double PP[2];
                        PP[0] = logProb.vec(0);
                        PP[1] = logProb.vec(2);
                        samp = Class_Utils::sample_DiscreteVar(PP, 2);
                        if(samp==1)
                        {
                            samp = 2;
                        }
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                    }
                    
                }else{
                    // L1
                    if(nk<length)
                    {
                        samp = 0;
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                    }
                    
                }
            }else{
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // P1
                    if(nk<length)
                    {
                        samp = 2;
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(1), 2)+1;
                    }
                }else{
                    StopMerge   = 1;
                    samp        = 5;
                }
            }
            //logProb.Print("A");
            
//            REprintf("Kobs %i  samp %i probxiL1 %f probxiP1 %f probxiK %f nk %i\n", Kobs, samp,probxiL1,probxiP1 ,probxiK, nk);
//
//            // xi
//            REprintf("pre sample\n");
//            for(k=0;k<ClustIndex.size();k++)
//            {
//                REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
//            }
            if(samp==0)
            {
                for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                {
                    logSumXI[jjj]  =  log(exp( logSumXI[jjj] )- exp(logXI[kxi]));
                }
                logXI.erase(logXI.begin()+kxi);
                logSumXI.erase(logSumXI.begin()+kxi);
                ClustIndex.erase(ClustIndex.begin()+kxi);
                kxi--;
                
                
            }
            if(samp==1)
            {
                kxi++;
            }
            if(samp==2)
            {
                for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                {
                    logSumXI[jjj]  =  log(exp( logSumXI[jjj] )- exp(logXI[kxi]));
                }
                logXI.erase(logXI.begin()+kxi);
                logSumXI.erase(logSumXI.begin()+kxi);
                ClustIndex.erase(ClustIndex.begin()+kxi);
                kxi = kxi;
            }
            logSumXI[0] = 0;
//            REprintf("post sample\n");
//            for(k=0;k<ClustIndex.size();k++)
//            {
//                REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
//            }

            
            if(samp==0)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexL1;
                }
                
                //VecStart.Pvec(IndexL1)[0]       = VecStart.Pvec(IndexL1)[0];
                VecEnd.Pvec(IndexL1)[0]         = VecEnd.Pvec(Indexk)[0];
                VecN.Pvec(IndexL1)[0]           = VecN.Pvec(IndexL1)[0]+VecN.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                
                Indexk     = IndexL1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
                
                
            }
            if(samp==1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)==1)
                {
                    StopMerge = 1;
                }else{
                    if(Class_Utils::ifelse(endP1,nObs-1,1,0)!=1)
                    {
                        IndexP1     = VecSuc.vec(IndexP1);
                        startP1     = VecStart.vec(IndexP1);
                        endP1       = VecEnd.vec(IndexP1);
                        nP1         = VecN.vec(IndexP1);
                    }
                    
                    Indexk     = VecSuc.vec(Indexk);
                    startk     = VecStart.vec(Indexk);
                    endk       = VecEnd.vec(Indexk);
                    nk         = VecN.vec(Indexk);
                    
                    IndexL1     = VecPrec.vec(Indexk);
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                
                
            }
            if(samp==2)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexP1;
                }
                VecStart.Pvec(IndexP1)[0]       = VecStart.Pvec(Indexk)[0];
                //VecEnd.Pvec(IndexP1)[0]         = VecEnd.Pvec(IndexP1)[0];
                VecN.Pvec(IndexP1)[0]           = VecN.Pvec(IndexP1)[0]+VecN.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                Indexk     = IndexP1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
            }
            
            
            
        }
        
        if(ControllWhile>Kobs*Kobs)
        {
            error("CONTROLLARE WHILE LOOP");
        }
        
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        
        Clusters->update_EmptyAndNonEmptyClusters();
        
        
        
        
        
        
        //Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    
    
    
    void samp_stChangePointMerge_Check(Class_Parameter *eta, int length, vector<VectorParameters> &xi, vector <Matrix<int >* >  &FromCpToLevel2, int isp)
    {
        int ControllWhile = 0;
        int StopMerge = 0;
        int Kobs;
        int KobsStar;
        int Kempty;
        int k;
        //int k0;
        //int k0prec;
        //int kK;
        //int kKP1;
        //int kNew;
        int i;
        int samp;
        //int knext;
        
        
        //int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        
        
        
        double appProb;
        
        
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int endL1 = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        double gammaP1 = 0.0;
        double gammaL1 = 0.0;
        
        double gammaL1k = 0.0;
        double gammaP1k = 0.0;
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        
        KobsStar = Kobs;
        Kempty = Clusters->nEmpty;
        
        
        int VecPrec_P[Kmax];
        Vector <int>VecPrec(Kmax, VecPrec_P);
        
        int VecSuc_P[Kmax];
        Vector <int>VecSuc(Kmax, VecSuc_P);
        VecSuc.Init(-99);
        
        int VecN_P[Kmax];
        Vector <int>VecN(Kmax, VecN_P);
        VecN.Init(-99);
        
        int VecStart_P[Kmax];
        Vector <int>VecStart(Kmax, VecStart_P);
        VecStart.Init(-99);
        
        int VecEnd_P[Kmax];
        Vector <int>VecEnd(Kmax, VecEnd_P);
        VecEnd.Init(-99);
        
        
        VecStart.Pvec(Clusters->Zeta.vec(0))[0] = 0;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                VecPrec.Pvec(Clusters->Zeta.vec(i))[0] = Clusters->Zeta.vec(i-1);
                VecSuc.Pvec(Clusters->Zeta.vec(i-1))[0] = Clusters->Zeta.vec(i);
                VecStart.Pvec(Clusters->Zeta.vec(i))[0] = i;
                VecEnd.Pvec(Clusters->Zeta.vec(i-1))[0] = i-1;
            }
        }
        VecEnd.Pvec(Clusters->Zeta.vec(nObs-1))[0] = nObs-1;
        for(k=0;k<Kmax;k++)
        {
            VecN.Pvec(k)[0] = Clusters->NObsInClust.vec(k);
        }
        
        
        //Likelihood->ProbSecondLev[0][ipar].VectorAcc.Pvec(k)[0];
        //knext       = 0;
        
        IndexL1     = Clusters->Zeta.vec(0);
        startL1     = VecStart.vec(IndexL1);
        endL1       = VecEnd.vec(IndexL1);
        nL1         = VecN.vec(IndexL1);
        
        
        Indexk     = Clusters->Zeta.vec(0);
        startk     = VecStart.vec(Indexk);
        endk       = VecEnd.vec(Indexk);
        nk         = VecN.vec(Indexk);
        
        if(Kobs>1)
        {
            IndexP1     = VecSuc.vec(Indexk);
            startP1     = VecStart.vec(IndexP1);
            endP1       = VecEnd.vec(IndexP1);
            nP1         = VecN.vec(IndexP1);
        }else{
            IndexP1     = Indexk;
            startP1     = startk;
            endP1       = endk;
            nP1         = nk;
        }
        
        
        
        /**** nuovi parametri ****/
        double probxiL1;
        double probxiP1;
        double probxiK;
        
        
        
        
        vector <int> ClustIndex;
        
        
        
        ClustIndex.push_back(Clusters->Zeta.vec(0));
        for(i=1;i<nObs;i++)
        {
            //REprintf("%i \n",Clusters->Zeta.vec(i));
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                ClustIndex.push_back(Clusters->Zeta.vec(i));
            }
        }
        
        
        vector <double> logXI;
        vector <double> logSumXI;
        for(k=0;k<ClustIndex.size();k++)
        {
            logXI.push_back(0.0);
            logSumXI.push_back(0.0);
            
            int ipar;
            
            ipar = 0;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat( ClustIndex[k],isp)));
            ipar = 2;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(ClustIndex[k],isp)));
            ipar = 4;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(ClustIndex[k],isp)) );
            for(ipar=5;ipar<12;ipar++)
            {
                logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(ClustIndex[k],isp)) );
            }
            
        }
        
        double AppSum[Kmax];
        logSumXI[0] = 0;
        for(k=1;k<ClustIndex.size();k++)
        {
            AppSum[k] = logXI[k-1];
            Class_Utils::log_sum_exp(&logSumXI[k],k, &AppSum[1]);
        }
        
        REprintf("Cluster \n%i \n",Clusters->Zeta.vec(0));
        for(i=1;i<nObs;i++)
        {
            REprintf("%i \n",Clusters->Zeta.vec(i));
        }
        REprintf("Stato inziale \n");
        for(k=0;k<ClustIndex.size();k++)
        {
            REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
        }
        
        
        int kxi = 0;
        
        /**** nuovi parametri  END ****/
        if(Kobs==1)
        {
            StopMerge=1;
        }
        int countr = 0;
        //Rprintf("Merge");
        while(StopMerge==0 ){
            
            ControllWhile++;
            
            double LogLikeL1 = 0.0;
            double LogLikeP1 = 0.0;
            //double LogLikek_New = 0.0;
            double LogLikek_k = 0.0;
            double LogLikek_P1 = 0.0;
            double LogLikek_L1 = 0.0;
            
            double gammak = 0.0;
            
            //LogLikeL1 = 0.0;
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                for(i=startL1;i<=endL1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                    LogLikeL1 += appProb;
                }
            }
            LogLikeP1 = 0.0;
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                for(i=startP1;i<=endP1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                    LogLikeP1 += appProb;
                }
            }
            
            
            LogLikek_k = 0.0;
            LogLikek_P1 = 0.0;
            LogLikek_L1 = 0.0;
            for(i=startk;i<=endk;i++)
            {
                ObsY.P = Y.Pmat(i,0);
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk], i);
                LogLikek_k += appProb;
                
                //Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexNew], i);
                //LogLikek_New += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                LogLikek_P1 += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                LogLikek_L1 += appProb;
            }
            
            
            gammak      = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk, nObs-1,1,0), nk);
            
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                gammaL1     = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1);
                gammaL1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0), nL1+nk);
            }else{
                gammaL1     = 0.0;
                gammaL1k    = 0.0;
            }
            
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                gammaP1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0), nP1+nk);
                gammaP1     = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0),nP1);
            }else{
                gammaP1k    = 0.0;
                gammaP1     = 0.0;
            }
            
            // contributo prob G_0
            probxiL1 = 0.0;
            probxiP1 = 0.0;
            probxiK  = logXI[kxi];
            
            REprintf("probxiK kxi=%i \n", kxi);
            for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
            {
                probxiK -= Class_Utils::log1mexp(logSumXI[jjj]);
                REprintf("jjj=%i logSumXI[jjj] %f sum %e %e \n",jjj,logSumXI[jjj],Class_Utils::log1mexp(logSumXI[jjj]),probxiK);
            }
            REprintf("probxip1 kxi=%i \n", kxi);
            for(int jjj=kxi+2;jjj<ClustIndex.size();jjj++)
            {
                probxiP1 -= Class_Utils::log1mexp( log(exp( logSumXI[jjj] )- exp(logXI[kxi])  ));
                REprintf("jjj=%i logSumXI[jjj] %f sum %e %e \n",jjj,log(exp( logSumXI[jjj] )- exp(logXI[kxi])  ),Class_Utils::log1mexp( log(exp( logSumXI[jjj] )- exp(logXI[kxi])  )), probxiP1);
            }
            probxiL1 = probxiP1;
            //
            logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1+LogLikeL1+LogLikeP1+probxiL1;
            logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1+LogLikeP1+LogLikeL1+probxiP1;
            logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k+LogLikeP1+LogLikeL1+probxiK;
            
            REprintf(" logProbL1[0] %f logProbk[0] %f logProbP1[0] %f  \n gammaL1 %f gammak %f gammaP1 %f gammaP1k %f gammaL1k %f  \n LogLikeL1 %f LogLikek_k %f LogLikeP1 %f LogLikek_L1 %f LogLikek_P1 %f  \n probxiL1 %f probxiK %f probxiP1 %f \n", logProbL1[0],logProbk[0],logProbP1[0],gammaL1,gammak,gammaP1,gammaP1k,gammaL1k ,LogLikeL1,LogLikek_k,LogLikeP1,LogLikek_L1,LogLikek_P1,  probxiL1, probxiK, probxiP1                 );
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // L1 e P1
                    if(nk<length)
                    {
                        double PP[2];
                        PP[0] = logProb.vec(0);
                        PP[1] = logProb.vec(2);
                        samp = Class_Utils::sample_DiscreteVar(PP, 2);
                        if(samp==1)
                        {
                            samp = 2;
                        }
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                    }
                    
                }else{
                    // L1
                    if(nk<length)
                    {
                        samp = 0;
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                    }
                    
                }
            }else{
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // P1
                    if(nk<length)
                    {
                        samp = 2;
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(1), 2)+1;
                    }
                }else{
                    StopMerge   = 1;
                    samp        = 5;
                }
            }
            //logProb.Print("A");
            
            REprintf("Kobs %i  samp %i probxiL1 %f probxiP1 %f probxiK %f nk %i\n", Kobs, samp,probxiL1,probxiP1 ,probxiK, nk);
            
            // xi
            REprintf("pre sample samp %i startk %i endk %i\n",samp,startk,endk);
            for(k=0;k<ClustIndex.size();k++)
            {
                REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
            }

            if(samp==0)
            {
                for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                {
                    logSumXI[jjj]  =  log(exp( logSumXI[jjj] )- exp(logXI[kxi]));
                }
                logXI.erase(logXI.begin()+kxi);
                logSumXI.erase(logSumXI.begin()+kxi);
                ClustIndex.erase(ClustIndex.begin()+kxi);
                kxi--;
                
                
            }
            if(samp==1)
            {
                kxi++;
            }
            if(samp==2)
            {
                for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                {
                    logSumXI[jjj]  =  log(exp( logSumXI[jjj] )- exp(logXI[kxi]));
                }
                logXI.erase(logXI.begin()+kxi);
                logSumXI.erase(logSumXI.begin()+kxi);
                ClustIndex.erase(ClustIndex.begin()+kxi);
                kxi = kxi;
            }
            logSumXI[0] = 0;
            REprintf("post sample\n");
            for(k=0;k<ClustIndex.size();k++)
            {
                REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
            }
            REprintf("IndicesPre %i %i %i\n", IndexL1,Indexk,IndexP1);
            
            if(samp==0)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexL1;
                }
                
                //VecStart.Pvec(IndexL1)[0]       = VecStart.Pvec(IndexL1)[0];
                VecEnd.Pvec(IndexL1)[0]         = VecEnd.Pvec(Indexk)[0];
                VecN.Pvec(IndexL1)[0]           = VecN.Pvec(IndexL1)[0]+VecN.Pvec(Indexk)[0];
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
            
                
                
                
                Indexk     = IndexL1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                
                
                
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
                
                
            }
            if(samp==1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)==1)
                {
                    StopMerge = 1;
                }else{
                    if(Class_Utils::ifelse(endP1,nObs-1,1,0)!=1)
                    {
                        IndexP1     = VecSuc.vec(IndexP1);
                        startP1     = VecStart.vec(IndexP1);
                        endP1       = VecEnd.vec(IndexP1);
                        nP1         = VecN.vec(IndexP1);
                    }
                    
                    Indexk     = VecSuc.vec(Indexk);
                    startk     = VecStart.vec(Indexk);
                    endk       = VecEnd.vec(Indexk);
                    nk         = VecN.vec(Indexk);
                    
                    IndexL1     = VecPrec.vec(Indexk);
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                
                
            }
            if(samp==2)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexP1;
                }
                VecStart.Pvec(IndexP1)[0]       = VecStart.Pvec(Indexk)[0];
                //VecEnd.Pvec(IndexP1)[0]         = VecEnd.Pvec(IndexP1)[0];
                VecN.Pvec(IndexP1)[0]           = VecN.Pvec(IndexP1)[0]+VecN.Pvec(Indexk)[0];
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                Indexk     = IndexP1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
            }
            REprintf("IndicesPost %i %i %i\n", IndexL1,Indexk,IndexP1);
            for(int iii=0;iii<6;iii++)
            {
                REprintf("State %i - %i %i %i %i %i\n", iii, VecStart.vec(iii),VecEnd.vec(iii),VecN.vec(iii), VecPrec.vec(iii) , VecSuc.vec(iii));
            }
      
            countr++;
            if(countr ==9)
            {
                error("S %i",countr);
            }
            REprintf("\n\n\n");
        }
        error("S %i",countr);
        if(ControllWhile>Kobs*Kobs)
        {
            error("CONTROLLARE WHILE LOOP");
        }
        
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        
        Clusters->update_EmptyAndNonEmptyClusters();
        
        
        
        
        
        
        //Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    
    
    
    
    void samp_stChangePointSplit(Class_Parameter *eta, int length, vector<VectorParameters> &xi, vector <Matrix<int >* >  &FromCpToLevel2, int isp)
    {
        //Rprintf("Split\n");
        int ErrorNumberClusters = 0;
        int CheckError = 0;
        int Kobs;
        //int KobsStar;
        int Kempty;
        //int k;
        int k0;
        int k0prec;
        int kK;
        
        
        int deltaP1;
        int deltaL1;
        int deltak;
        
        int kNew;
        int i,j;
        int samp;
        //int knext;
        int KmaxObs;
        int KFirstObs;
        int KsecondObs;
        int KmaxObsL1;
        int kSeq;
        int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        double appProb;
        
        //double LogLikeL1 = 0.0;
        //double LogLikeP1 = 0.0;
        //double LogLikek_New = 0.0;
        double LogLikek_k = 0.0;
        double LogLikek_P1 = 0.0;
        double LogLikek_L1 = 0.0;
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int startL1pre = 0;
        int endL1 = 0;
        int endL1pre = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nL1pre = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexL1pre = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        double gammaP1 = 0.0;
        double gammaL1 = 0.0;
        double gammak = 0.0;
        double gammaL1k = 0.0;
        double gammaP1k = 0.0;
        
        
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        Kvoid = Clusters->nEmpty;
        Kempty = Clusters->nEmpty;
        
        
        
        
        
        k0 = 1;
        kK = 0;
        kNew = 0;
        
        deltaP1 = 0;
        deltaL1 = 0;
        deltak = 0;
        
        k0prec = 1;
        
        //
        
        
        
        //KobsStar = Kobs;
        KmaxObs = Clusters->NonEmptyC.vec(Kobs-1);
        KFirstObs = Clusters->NonEmptyC.vec(0);
        
        if(Kobs>1)
        {
            KmaxObsL1 = Clusters->NonEmptyC.vec(Kobs-2);
            KsecondObs = Clusters->NonEmptyC.vec(1);
        }else{
            KmaxObsL1 = KmaxObs;
            KsecondObs = KFirstObs;
        }
        
        
        
        //if(Kobs>1)
        //{
        
        kSeq                = 0;
        IndexL1             = Clusters->NonEmptyC.vec(kSeq);
        IndexL1pre = IndexL1;
        if(Kobs>1)
        {
            IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
        }else{
            IndexP1             = IndexL1;
        }
        Indexk              = Clusters->EmptyC.vec(kNew);
        
        
        startk      = 0;
        startL1     = 0;
        startL1pre     = startL1;
        
        
        endL1       = startL1;
        endL1pre = endL1;
        endk        = startL1+Clusters->NObsInClust.vec(IndexL1)-1;
        
        
        nL1         = endL1-startL1+1;
        nL1pre         = nL1;
        nk          = endk-startk+1; //
        
        if(Kobs>1)
        {
            //Rprintf("MMM %i \n",Kobs);
            startP1     = startL1+Clusters->NObsInClust.vec(IndexL1);
            endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
            nP1         = endP1-startP1+1;
        }
        
        if(Clusters->nEmpty==0)
        {
            ErrorNumberClusters = 1;
            CheckError = 1;
            //Rprintf("Inizia con il numero max di stati\n");
        }
        
        
        //       Clusters->Zeta.Print("Zeta");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //Rprintf("\nSPLIT\n");
        
        
        
        /**** nuovi parametri ****/
        double probxiL1;
        double probxiP1;
        double probxiK;
        
        
        
        
        vector <int> ClustIndex;
        
        
        //REprintf("Cluster \n%i \n",Clusters->Zeta.vec(0));
        ClustIndex.push_back(Clusters->Zeta.vec(0));
        for(i=1;i<nObs;i++)
        {
            //REprintf("%i \n",Clusters->Zeta.vec(i));
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                ClustIndex.push_back(Clusters->Zeta.vec(i));
            }
        }
        
        
        vector <double> logXI;
        vector <double> logSumXI;
        for(int k=0;k<Kmax;k++)
        {
            logXI.push_back(0.0);
            int ipar;
            
            ipar = 0;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(k,isp)));
            ipar = 2;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(k,isp)));
            ipar = 4;
            logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(k,isp)) );
            for(ipar=5;ipar<12;ipar++)
            {
                logXI[k] += log( xi[ipar].VectorAcc.vec(FromCpToLevel2[ipar][0].mat(k,isp)) );
            }
        }
        for(int k=0;k<ClustIndex.size();k++)
        {
            logXI.push_back(0.0);
            logSumXI.push_back(0.0);
            
        }
        
        double AppSum[Kmax];
        logSumXI[0] = 0;
        for(int k=1;k<ClustIndex.size();k++)
        {
            AppSum[k] = logXI[ClustIndex[k-1]];
            Class_Utils::log_sum_exp(&logSumXI[k],k, &AppSum[1]);
        }

        
        
        int kxi = 0;
        
        /**** nuovi parametri  END ****/
        
        
        
        for(i=0;i<nObs;i++)
        {

            if(ErrorNumberClusters==1)
            {
                if(CheckError==0)
                {
                    //Rprintf("K may be non well estimated\n");
                    CheckError = 1;
                }
                
            }else{
                if((startL1==startk)&(nk>0))
                {
                    //Rprintf("Nuovo codice");
                    
                    LogLikek_k = 0.0;
                    LogLikek_P1 = 0.0;
                    LogLikek_L1 = 0.0;
                    
                    
                    j = startk;
                    ObsY.P = Y.Pmat(j,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                    LogLikek_k += appProb;
                    
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                    LogLikek_L1 += appProb;
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1pre],j);
                        LogLikek_P1 += appProb;
                    }
                    
                    // if(nk>1)
                    // {
                    
                    // }else{
                    //     gammaL1     = 0.0;
                    //     gammaL1k     = 0.0;
                    // }
                    
                    gammaL1         = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0),nk-1);
                    gammaL1k        = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0),nk);
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        gammaP1    = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1pre);
                        gammaP1k   = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1pre+1);
                    }else{
                        gammaP1    = 0.0;
                        gammaP1k   = 0.0;
                    }
                    
                    gammak          = compute_loggammaSampleCP(eta->ParameterAcc, 0,1);
                    
                    
                    // contributo prob G_0
                    probxiL1 = 0.0;
                    probxiP1 = 0.0;
                    probxiK  = logXI[Indexk];
                    
                    for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                    {
                        probxiK -= Class_Utils::log1mexp( log(exp( logSumXI[jjj] )+ exp(logXI[Indexk])  ));
                    }
                    if(kxi==0)
                    {
                        probxiK -= Class_Utils::log1mexp(logXI[Indexk]);
                    }else{
                        probxiK -= Class_Utils::log1mexp( log(exp( logSumXI[kxi] )+ exp(logXI[Indexk])  ));
                    }
                    for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                    {
                        probxiP1 -= Class_Utils::log1mexp( logSumXI[jjj]);
                    }
                    probxiL1 = probxiP1;
                    
                    logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1+probxiL1;
                    logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1+probxiP1;
                    logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k+probxiK;
                    
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                        //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                        //Rprintf("SAmpione su 2, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                    }
                    if(length>1)
                    {
                        samp = 0;
                    }
                    //REprintf("%i %i \n", nk, length);
                    
                    
//                    REprintf("Kobs %i  samp %i probxiL1 %f probxiP1 %f probxiK %f nk %i \n prob %f %f %f\n  ", Kobs, samp,probxiL1,probxiP1 ,probxiK, nk, logProbL1[0] ,
//                             logProbP1[0],
//                             logProbk[0] );
//                    // xi
//                    REprintf("pre sample\n");
//                    for(int k=0;k<ClustIndex.size();k++)
//                    {
//                        REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i logXI[Indexk] %f\n",logXI[ClustIndex[k]],logSumXI[k],ClustIndex[k],logXI[Indexk] );
//                    }
                    if(samp==0)
                    {
                        
                    }
                    if(samp==1)
                    {
                        for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                        {
                            logSumXI[jjj] =  Class_Utils::log1mexp( log(exp( logSumXI[jjj] )+ exp(logXI[Indexk])  ));
                        }
                    }
                    if(samp==2)
                    {
                        
                    }
                    if(samp==0)
                    {
                        // rimando su dove ero
                        //                    Rprintf("\nS0\n");
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        // NO_ERROR Indexk      = Indexk;
                        
                        // NO_ERROR startL1     = startL1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        // NO_ERROR endL1pre       = endL1pre;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                    }
                    if(samp==1)
                    {
                        // cmapiono k
                        //                    Rprintf("\nS1\n");
                        //
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j=startk;
                        Clusters->Zeta.Pvec(j)[0]  = Indexk;
                        
                        startL1pre     = startk;
                        endL1pre       = startk;
                        nL1pre         = endL1pre-startL1pre+1;
                        IndexL1pre     = Indexk;
                        
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        startk      = startL1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                    }
                    if(samp==2)
                    {
                        // passo a quello prima
                        //                    Rprintf("\nS2\n");
                        //                    Rprintf("%f %f \n", logProbL1[0],logProbk[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j= startk;
                        Clusters->Zeta.Pvec(j)[0]  = IndexL1pre;
                        
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        endL1pre       = endL1pre+1;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                    }
                    
                    
                    
                }else{
                    if((nk!=0))
                    {
                        //Rprintf("Vecchio codice\n");
                        
                        
                        if(nL1==1)
                        {
                            LogLikek_k = 0.0;
                            LogLikek_P1 = 0.0;
                            LogLikek_L1 = 0.0;
                            
                            for(j=startk;j<=endk;j++)
                            {
                                ObsY.P = Y.Pmat(j,0);
                                //ObsY.Print("Y");
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                                LogLikek_k += appProb;
                                //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                                LogLikek_L1 += appProb;
                                //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                                
                                
                                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                                {
                                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                    LogLikek_P1 += appProb;
                                    //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                                }
                            }
                            
                        }else{
                            j = startk-1;
                            
                            ObsY.P = Y.Pmat(j,0);
                            //ObsY.Print("Y");
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                            LogLikek_k -= appProb;
                            //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                            LogLikek_L1 -= appProb;
                            //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                            
                            
                            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                            {
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                LogLikek_P1 -= appProb;
                                //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                            }
                        }
                       
                        gammaL1     = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1);
                        
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            gammaP1     = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1,nObs-1,1,0),nP1);
                            gammaP1k    = compute_loggammaSampleCP(eta->ParameterAcc,Class_Utils::ifelse(endP1,nObs-1,1,0), nP1+nk);
                        }else{
                            gammaP1     = 0.0;
                            gammaP1k    = 0.0;
                        }
                        
                        gammak      = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0), nk);
                        gammaL1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk,nObs-1,1,0), nL1+nk);
                        
                        
                        probxiL1 = 0.0;
                        probxiP1 = 0.0;
                        probxiK  = logXI[Indexk];
                        
                        for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                        {
                            probxiK -= Class_Utils::log1mexp( log(exp( logSumXI[jjj] )+ exp(logXI[Indexk])  ));
                        }
                        if(kxi==0)
                        {
                            probxiK -= Class_Utils::log1mexp(logXI[Indexk]);
                        }else{
                            probxiK -= Class_Utils::log1mexp( log(exp( logSumXI[kxi] )+ exp(logXI[Indexk])  ));
                        }
                        for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                        {
                            probxiP1 -= Class_Utils::log1mexp( logSumXI[jjj]);
                        }
                        probxiL1 = probxiP1;
                        
                        logProbL1[0]        = gammaL1k+gammaP1+LogLikek_L1+probxiL1;
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            logProbP1[0]        = gammaL1+gammaP1k+LogLikek_P1+probxiP1;
                        }
                        
                        logProbk[0]         = gammak+gammaP1+gammaL1+LogLikek_k+probxiK;
                        
                        
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                            //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                        }else{
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                            //Rprintf("SAmpione su 2, z=%i %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                        }
                        
//                        REprintf("Kobs %i  samp %i probxiL1 %f probxiP1 %f probxiK %f nk %i \n prob %f %f %f\n  ", Kobs, samp,probxiL1,probxiP1 ,probxiK, nk, logProbL1[0] ,
//                                 logProbP1[0],
//                                 logProbk[0] );
//                        // xi
//                        REprintf("pre sample\n");
//                        for(int k=0;k<ClustIndex.size();k++)
//                        {
//                            REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i logXI[Indexk] %f\n",logXI[ClustIndex[k]],logSumXI[k],ClustIndex[k],logXI[Indexk] );
//                        }
                        if((nk<length)||(nL1<length))
                        {
                            samp = 0;
                        }
                        if(samp==0)
                        {
                            
                        }
                        if(samp==1)
                        {
                            for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                            {
                                logSumXI[jjj] =  Class_Utils::log1mexp( log(exp( logSumXI[jjj] )+ exp(logXI[Indexk])  ));
                            }
                        }
                        if(samp==2)
                        {
                            
                        }
                        
                        //Rprintf("Samp %i\n", samp);
                        if(samp==0)
                        {
     
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            // NO_ERROR Indexk      = Indexk;
                            
                            
                            // NO_ERROR startL1     = startL1;
                            endL1       = endL1+1;
                            nL1         = endL1-startL1+1;
                            // NO_ERROR IndexL1      = IndexL1;
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            // NO_ERROR startL1pre     = startL1pre;
                            // NO_ERROR endL1pre       = endL1pre;
                            nL1pre         = endL1pre-startL1pre+1;
                            // NO_ERROR IndexL1pre      = IndexL1pre;
                            
                            
                            
                        }
                        if(samp==1)
                        {
                  
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = Indexk;
                            }
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre          = nL1;
                            IndexL1pre      = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = Indexk;
                            
                            
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            kNew++;
                            if(kNew>=(Kvoid-2))
                            {
                                ErrorNumberClusters = 1;
                            }else{
                                
                                Indexk              = Clusters->EmptyC.vec(kNew);
                            }
                        }
                        if(samp==2)
                        {

                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = IndexP1;
                            }
                            
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre              = nL1;
                            IndexL1pre          = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            endk        = endP1;
                            nk          = endk-startk+1;
                            // NO_ERROR Indexk      = Indexk;
                            //                            kNew++;
                            //                            if(kNew>=(Kvoid-2))
                            //                            {
                            //                                ErrorNumberClusters = 1;
                            //                            }else{
                            //
                            //                                Indexk              = Clusters->EmptyC.vec(kNew);
                            //                            }
                            
                            
                            if(IndexL1!=KmaxObs)
                            {
                                kSeq++;
                                IndexP1      =  Clusters->NonEmptyC.vec(kSeq+1);
                                startP1     = endk+1;
                                endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                nP1         = endP1-startP1+1;
                            }
                            
                        }
                        
                        
                    }else{
                        if(IndexL1!=KmaxObs)
                        {
                            //Rprintf("Non campiono\n");
                            
                            kxi++;
                            startL1pre = startL1;
                            endL1pre = endL1;
                            nL1pre  = nL1;
                            IndexL1pre = IndexL1;
                            
                            IndexL1             = IndexP1;
                            startL1             = startP1;
                            endL1               = startP1;
                            nL1                 = endL1-startL1+1;
                            
                            
                            // NO_ERROR Indexk              = Indexk;
                            startk              = startL1;
                            endk                = endP1;
                            nk                  = endk-startk+1;
                            
                            if(IndexP1!=KmaxObs)
                            {
                                kSeq++;
                                //Rprintf("\nSstar1\n");
                                IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
                                //Rprintf("\nSstar2\n");
                                startP1             = startL1+Clusters->NObsInClust.vec(IndexL1);
                                //Rprintf("\nSsta3\n");
                                endP1               = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                //Rprintf("\nSstar5\n");
                                nP1                 = endP1-startP1+1;
                            }
                        }
                        
                    }
                }
            }
            
            
            
            
            
        }
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        //Clusters->Zeta.Print("ZetaPost");
        
        //Clusters->Zeta.Print("Zeta");
        
        //error("STOP");
        Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    
    
    
    
  
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    void samp_stChangePointSplit_withPi(Vector <double> *Pi, Vector <double> *PiStick, int lengths,int isp)
    {
        //Rprintf("Split\n");
        int ErrorNumberClusters = 0;
        int CheckError = 0;
        int Kobs;
        //int KobsStar;
        int Kempty;
        //int k;
        int k0;
        int k0prec;
        int kK;


      

        int kNew;
        int i,j;
        int samp;
        //int knext;
        int KmaxObs;
        int KFirstObs;
        int KsecondObs;
        int KmaxObsL1;
        int kSeq;
        int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;

        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);

        double appProb;

        //double LogLikeL1 = 0.0;
        //double LogLikeP1 = 0.0;
        //double LogLikek_New = 0.0;
        double LogLikek_k = 0.0;
        double LogLikek_P1 = 0.0;
        double LogLikek_L1 = 0.0;

        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int startL1pre = 0;
        int endL1 = 0;
        int endL1pre = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nL1pre = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexL1pre = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;

//        double gammaP1 = 0.0;
//        double gammaL1 = 0.0;
//        double gammak = 0.0;
//        double gammaL1k = 0.0;
//        double gammaP1k = 0.0;




        Vector<double> ObsY(nVars,Y.Pmat(0,0));

        Kobs = Clusters->nNonEmpty;
        Kvoid = Clusters->nEmpty;
        Kempty = Clusters->nEmpty;





        k0 = 1;
        kK = 0;
        kNew = 0;

//        deltaP1 = 0;
//        deltaL1 = 0;
//        deltak = 0;

        k0prec = 1;

        //



        //KobsStar = Kobs;
        KmaxObs = Clusters->NonEmptyC.vec(Kobs-1);
        KFirstObs = Clusters->NonEmptyC.vec(0);

        if(Kobs>1)
        {
            KmaxObsL1 = Clusters->NonEmptyC.vec(Kobs-2);
            KsecondObs = Clusters->NonEmptyC.vec(1);
        }else{
            KmaxObsL1 = KmaxObs;
            KsecondObs = KFirstObs;
        }



        //if(Kobs>1)
        //{

        kSeq                = 0;
        IndexL1             = Clusters->NonEmptyC.vec(kSeq);
        IndexL1pre = IndexL1;
        if(Kobs>1)
        {
            IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
        }else{
            IndexP1             = IndexL1;
        }
        Indexk              = Clusters->EmptyC.vec(kNew);


        startk      = 0;
        startL1     = 0;
        startL1pre     = startL1;


        endL1       = startL1;
        endL1pre = endL1;
        endk        = startL1+Clusters->NObsInClust.vec(IndexL1)-1;


        nL1         = endL1-startL1+1;
        nL1pre         = nL1;
        nk          = endk-startk+1; //

        if(Kobs>1)
        {
            //Rprintf("MMM %i \n",Kobs);
            startP1     = startL1+Clusters->NObsInClust.vec(IndexL1);
            endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
            nP1         = endP1-startP1+1;
        }

        if(Clusters->nEmpty==0)
        {
            ErrorNumberClusters = 1;
            CheckError = 1;
            //Rprintf("Inizia con il numero max di stati\n");
        }


        //       Clusters->Zeta.Print("Zeta");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //Rprintf("\nSPLIT\n");



        /**** nuovi parametri ****/
        double probxiL1;
        double probxiP1;
        double probxiK;




        vector <int> ClustIndex;
        vector <int> ClustN;


        
        ClustIndex.push_back(Clusters->Zeta.vec(0));
        ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[0]));
        for(i=1;i<nObs;i++)
        {
            //REprintf("%i \n",Clusters->Zeta.vec(i));
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                ClustIndex.push_back(Clusters->Zeta.vec(i));
                ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[ClustIndex.size()-1]));
            }
        }


        //vector <double> logPI;
        //vector <double> NologPI;
        vector <double> logSumPI;
        for(int k=0;k<ClustIndex.size();k++)
        {
            logSumPI.push_back(0.0);
            //NologPI.push_back(Pi->vec(ClustIndex[k]));
            //logPI.push_back(Pi->vec(log(ClustIndex[k])));
        }

        //Pi->Print("pi");
        //PiStick->Print("stick");
        for(int k=0;k<ClustIndex.size();k++)
        {
            logSumPI.push_back(0.0);
        }

        double AppSum[Kmax];
        logSumPI[0] = 0;
        for(int k=1;k<ClustIndex.size();k++)
        {
            AppSum[k] = log(Pi->vec(ClustIndex[k-1]));
            Class_Utils::log_sum_exp(&logSumPI[k],k, &AppSum[1]);
        }

        
//        REprintf("Cluster \n%i \n",Clusters->Zeta.vec(0));
//        for(i=1;i<nObs;i++)
//        {
//            REprintf("%i \n",Clusters->Zeta.vec(i));
//        }
//        REprintf("Stato inziale \n");
//        for(int k=0;k<ClustIndex.size();k++)
//        {
//            REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i %i\n",log(Pi->vec(ClustIndex[k])),logSumPI[k],ClustIndex[k] ,ClustN[k]);
//        }
        


        int kL1 = 0;

        /**** nuovi parametri  END ****/



        for(i=0;i<nObs;i++)
        {
            //REprintf("\n\n%i\n",i);
            if(ErrorNumberClusters==1)
            {
                if(CheckError==0)
                {
                    //Rprintf("K may be non well estimated\n");
                    CheckError = 1;
                }

            }else{
                if((startL1==startk)&(nk>0))
                {
                    //Rprintf("Nuovo codice");

                    LogLikek_k = 0.0;
                    LogLikek_P1 = 0.0;
                    LogLikek_L1 = 0.0;


                    j = startk;
                    ObsY.P = Y.Pmat(j,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                    LogLikek_k += appProb;

                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                    LogLikek_L1 += appProb;

                    if(IndexL1!=IndexL1pre)
                    {
                        Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1pre],j);
                        LogLikek_P1 += appProb;
                    }


                    // contributo prob G_0
                    
                    //REprintf("probxiK kL1=%i \n", kL1);
                    
                    
                    probxiP1 = probxiL1 = probxiK = 0.0;
                    for(int jjj=kL1;jjj<ClustIndex.size();jjj++)
                    {
                        double n1 =1.0*(ClustN[jjj]-lengths+1);
                        
                        probxiL1 -= n1*Class_Utils::log1mexp(logSumPI[jjj]);
                        probxiK -=  n1*Class_Utils::log1mexp(log(exp(logSumPI[jjj])+Pi->vec(Indexk)));
                        //REprintf("jjj=%i n1 %f suml1 %f sumk %f ,l1 %f k %f\n",jjj,n1,logSumPI[jjj],log(exp(logSumPI[jjj])+Pi->vec(Indexk)),probxiL1,probxiK);
                    }
                    if(IndexL1!=IndexL1pre)
                    {
                        probxiP1 = probxiL1;
                    }
                    
                    probxiK += (1.0*(nk-lengths+1))* (log(Pi->vec(Indexk))-Class_Utils::log1mexp(logSumPI[kL1]));
                    probxiL1 += (1.0*nk)* (log(Pi->vec(IndexL1))-Class_Utils::log1mexp(logSumPI[kL1]));
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        probxiP1 = (1.0*nk)* log(Pi->vec(IndexL1pre)-Class_Utils::log1mexp(logSumPI[kL1-1]));
                    }
        
                    
                    //REprintf("Start probxiL1 %f probxiK %f probxiP1 %f\n",probxiL1, probxiK, probxiP1);
                    //REprintf("Probs probxiL1 %f probxiK %f probxiP1 %f\n",Pi->vec(IndexL1),Pi->vec(Indexk), Pi->vec(IndexL1pre));
                    
                    
                    logProbL1[0]        = LogLikek_L1+probxiL1;
                    logProbP1[0]        = LogLikek_P1+probxiP1;
                    logProbk[0]         = LogLikek_k+probxiK;

                    //REprintf("PREV %f %f %f\n", logProbL1[0] ,logProbk[0],logProbP1[0]  );
                    if(IndexL1!=IndexL1pre)
                    {
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                        //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                        //Rprintf("SAmpione su 2, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                    }
                    if(lengths>1)
                    {
                        samp = 0;
                    }
                    
                    if(samp==0)
                    {

                    }
                    if(samp==1)
                    {
                        logSumPI.insert(logSumPI.begin()+kL1,logSumPI[kL1] );
                        ClustIndex.insert(ClustIndex.begin()+kL1, Indexk);
                        ClustN[kL1] = ClustN[kL1]-nk;
                        ClustN.insert(ClustN.begin()+kL1, nk);
                        for(int jjj=kL1+1;jjj<ClustIndex.size();jjj++)
                        {
                            logSumPI[jjj] =  Class_Utils::log1mexp( log(exp( logSumPI[jjj] )+ exp(   log(Pi->vec(Indexk)) )  ));
                        }
                        kL1++;
                    }
                    if(samp==2)
                    {
                        ClustN[kL1-1] = ClustN[kL1-1]+nk;
                    }
                    if(samp==0)
                    {
                        // rimando su dove ero
                        //                    Rprintf("\nS0\n");
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );

                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        // NO_ERROR Indexk      = Indexk;

                        // NO_ERROR startL1     = startL1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;

                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;

                        // NO_ERROR startL1pre     = startL1pre;
                        // NO_ERROR endL1pre       = endL1pre;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;

                    }
                    if(samp==1)
                    {
                        // cmapiono k
                        //                    Rprintf("\nS1\n");
                        //
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );

                        j=startk;
                        Clusters->Zeta.Pvec(j)[0]  = Indexk;

                        startL1pre     = startk;
                        endL1pre       = startk;
                        nL1pre         = endL1pre-startL1pre+1;
                        IndexL1pre     = Indexk;


                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;


                        startk      = startL1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{

                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }

                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                    }
                    if(samp==2)
                    {
                        // passo a quello prima
                        //                    Rprintf("\nS2\n");
                        //                    Rprintf("%f %f \n", logProbL1[0],logProbk[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );

                        j= startk;
                        Clusters->Zeta.Pvec(j)[0]  = IndexL1pre;


                        // NO_ERROR startL1pre     = startL1pre;
                        endL1pre       = endL1pre+1;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;

                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;


                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;

                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{

                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                    }



                }else{
                    if((nk!=0))
                    {
                        //Rprintf("Vecchio codice\n");


                        if(nL1==1)
                        {
                            LogLikek_k = 0.0;
                            LogLikek_P1 = 0.0;
                            LogLikek_L1 = 0.0;

                            for(j=startk;j<=endk;j++)
                            {
                                ObsY.P = Y.Pmat(j,0);
                                //ObsY.Print("Y");
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                                LogLikek_k += appProb;
                                //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                                LogLikek_L1 += appProb;
                                //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);


                                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                                {
                                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                    LogLikek_P1 += appProb;
                                    //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                                }
                            }

                        }else{
                            j = startk-1;

                            ObsY.P = Y.Pmat(j,0);
                            //ObsY.Print("Y");
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                            LogLikek_k -= appProb;
                            //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                            LogLikek_L1 -= appProb;
                            //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);


                            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                            {
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                LogLikek_P1 -= appProb;
                                //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                            }
                        }


                        //REprintf("probxiK kL1=%i \n", kL1);
                        
                        
                        probxiP1 = probxiL1 = probxiK = 0.0;
                        for(int jjj=kL1+1;jjj<ClustIndex.size();jjj++)
                        {
                            double n1 =1.0*(ClustN[jjj]-lengths+1);
                            
                            probxiL1 -= n1*Class_Utils::log1mexp(logSumPI[jjj]);
                            probxiK -=  n1*Class_Utils::log1mexp(log(exp(logSumPI[jjj])+Pi->vec(Indexk)));
                            //REprintf("jjj=%i n1 %f suml1 %f sumk %f ,l1 %f k %f\n",jjj,n1,logSumPI[jjj],log(exp(logSumPI[jjj])+Pi->vec(Indexk)),probxiL1,probxiK);
                        }
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            probxiP1 = probxiL1;
                        }
                        
                        probxiK += (1.0*(nk-lengths+1))* (log(Pi->vec(Indexk))-Class_Utils::log1mexp(       log(exp(logSumPI[kL1])+Pi->vec(IndexL1) )       ));
                        probxiL1 += (1.0*nk)* (log(Pi->vec(IndexL1))-Class_Utils::log1mexp(logSumPI[kL1]));
                        
                        if(IndexL1!=IndexL1pre)
                        {
                            probxiP1 = (1.0*nk)* log(Pi->vec(IndexP1)-Class_Utils::log1mexp(logSumPI[kL1+1]));
                        }
                        
                        
                        //REprintf("Start probxiL1 %f probxiK %f probxiP1 %f\n",probxiL1, probxiK, probxiP1);
                        //REprintf("Probs probxiL1 %f probxiK %f probxiP1 %f\n",Pi->vec(IndexL1),Pi->vec(Indexk), Pi->vec(IndexL1pre));
                        

                        logProbL1[0]        = LogLikek_L1+probxiL1;
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            logProbP1[0]        = LogLikek_P1+probxiP1;
                        }
                        logProbk[0]         = LogLikek_k+probxiK;
                        
                        //REprintf("%f %f %f\n", logProbL1[0] ,logProbk[0],logProbP1[0]  );

                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                            //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                        }else{
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                            //Rprintf("SAmpione su 2, z=%i %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                        }

                        //                        REprintf("Kobs %i  samp %i probxiL1 %f probxiP1 %f probxiK %f nk %i \n prob %f %f %f\n  ", Kobs, samp,probxiL1,probxiP1 ,probxiK, nk, logProbL1[0] ,
                        //                                 logProbP1[0],
                        //                                 logProbk[0] );
                        //                        // xi
                        //                        REprintf("pre sample\n");
                        //                        for(int k=0;k<ClustIndex.size();k++)
                        //                        {
                        //                            REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i logXI[Indexk] %f\n",logXI[ClustIndex[k]],logSumXI[k],ClustIndex[k],logXI[Indexk] );
                        //                        }
                        if((nk<lengths)||(nL1<lengths))
                        {
                            samp = 0;
                        }
                        if(samp==0)
                        {

                        }
                        if(samp==1)
                        {
                        logSumPI.insert(logSumPI.begin()+kL1+1,log(exp(logSumPI[kL1])+Pi->vec(IndexL1)));
                            ClustN[kL1] = ClustN[kL1]-nk;
                            ClustN.insert(ClustN.begin()+kL1+1, nk);
                            ClustIndex.insert(ClustIndex.begin()+kL1+1, Indexk);
                            for(int jjj=kL1+2;jjj<ClustIndex.size();jjj++)
                            {
                                logSumPI[jjj] =  Class_Utils::log1mexp( log(exp( logSumPI[jjj] )+ Pi->vec(Indexk)  ));
                            }
                           
                        }
                        if(samp==2)
                        {
                            ClustN[kL1+1] = ClustN[kL1+1]+nk;
                        }

                        //Rprintf("Samp %i\n", samp);
                        if(samp==0)
                        {

                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            // NO_ERROR Indexk      = Indexk;


                            // NO_ERROR startL1     = startL1;
                            endL1       = endL1+1;
                            nL1         = endL1-startL1+1;
                            // NO_ERROR IndexL1      = IndexL1;

                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;

                            // NO_ERROR startL1pre     = startL1pre;
                            // NO_ERROR endL1pre       = endL1pre;
                            nL1pre         = endL1pre-startL1pre+1;
                            // NO_ERROR IndexL1pre      = IndexL1pre;



                        }
                        if(samp==1)
                        {

                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = Indexk;
                            }
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre          = nL1;
                            IndexL1pre      = IndexL1;


                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = Indexk;



                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;


                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            kNew++;
                            if(kNew>=(Kvoid-2))
                            {
                                ErrorNumberClusters = 1;
                            }else{

                                Indexk              = Clusters->EmptyC.vec(kNew);
                            }
                        }
                        if(samp==2)
                        {

                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = IndexP1;
                            }

                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre              = nL1;
                            IndexL1pre          = IndexL1;


                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = IndexP1;


                            startk      = startk+1;
                            endk        = endP1;
                            nk          = endk-startk+1;
                            // NO_ERROR Indexk      = Indexk;
                            //                            kNew++;
                            //                            if(kNew>=(Kvoid-2))
                            //                            {
                            //                                ErrorNumberClusters = 1;
                            //                            }else{
                            //
                            //                                Indexk              = Clusters->EmptyC.vec(kNew);
                            //                            }


                            if(IndexL1!=KmaxObs)
                            {
                                kSeq++;
                                IndexP1      =  Clusters->NonEmptyC.vec(kSeq+1);
                                startP1     = endk+1;
                                endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                nP1         = endP1-startP1+1;
                            }

                        }


                    }else{
                        if(IndexL1!=KmaxObs)
                        {
                            //Rprintf("Non campiono\n");

                            kL1++;
                            startL1pre = startL1;
                            endL1pre = endL1;
                            nL1pre  = nL1;
                            IndexL1pre = IndexL1;

                            IndexL1             = IndexP1;
                            startL1             = startP1;
                            endL1               = startP1;
                            nL1                 = endL1-startL1+1;


                            // NO_ERROR Indexk              = Indexk;
                            startk              = startL1;
                            endk                = endP1;
                            nk                  = endk-startk+1;

                            if(IndexP1!=KmaxObs)
                            {
                                kSeq++;
                                //Rprintf("\nSstar1\n");
                                IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
                                //Rprintf("\nSstar2\n");
                                startP1             = startL1+Clusters->NObsInClust.vec(IndexL1);
                                //Rprintf("\nSsta3\n");
                                endP1               = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                //Rprintf("\nSstar5\n");
                                nP1                 = endP1-startP1+1;
                            }
                        }

                    }
                }
            }





        }
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);

        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }

        //Clusters->Zeta.Print("ZetaPost");

        //Clusters->Zeta.Print("Zeta");

        //error("STOP");
        Clusters->update_EmptyAndNonEmptyClusters();

    }

    
    
    
    void samp_stChangePointMerge_withPi(Vector <double> *Pi, Vector <double> *PiStick, int lengths,int isp)
    {
        int ControllWhile = 0;
        int StopMerge = 0;
        int Kobs;
        int KobsStar;
        int Kempty;
        int k;
        //int k0;
        //int k0prec;
        //int kK;
        //int kKP1;
        //int kNew;
        int i;
        int samp;
        //int knext;
        
        
        //int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        
        
        
        double appProb;
        
        
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int endL1 = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
//        double gammaP1 = 0.0;
//        double gammaL1 = 0.0;
//
//        double gammaL1k = 0.0;
//        double gammaP1k = 0.0;
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        
        KobsStar = Kobs;
        Kempty = Clusters->nEmpty;
        
        
        int VecPrec_P[Kmax];
        Vector <int>VecPrec(Kmax, VecPrec_P);
        
        int VecSuc_P[Kmax];
        Vector <int>VecSuc(Kmax, VecSuc_P);
        VecSuc.Init(-99);
        
        int VecN_P[Kmax];
        Vector <int>VecN(Kmax, VecN_P);
        VecN.Init(-99);
        
        int VecStart_P[Kmax];
        Vector <int>VecStart(Kmax, VecStart_P);
        VecStart.Init(-99);
        
        int VecEnd_P[Kmax];
        Vector <int>VecEnd(Kmax, VecEnd_P);
        VecEnd.Init(-99);
        
        
        VecStart.Pvec(Clusters->Zeta.vec(0))[0] = 0;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                VecPrec.Pvec(Clusters->Zeta.vec(i))[0] = Clusters->Zeta.vec(i-1);
                VecSuc.Pvec(Clusters->Zeta.vec(i-1))[0] = Clusters->Zeta.vec(i);
                VecStart.Pvec(Clusters->Zeta.vec(i))[0] = i;
                VecEnd.Pvec(Clusters->Zeta.vec(i-1))[0] = i-1;
            }
        }
        VecEnd.Pvec(Clusters->Zeta.vec(nObs-1))[0] = nObs-1;
        for(k=0;k<Kmax;k++)
        {
            VecN.Pvec(k)[0] = Clusters->NObsInClust.vec(k);
        }
        
        
        //Likelihood->ProbSecondLev[0][ipar].VectorAcc.Pvec(k)[0];
        //knext       = 0;
        
        IndexL1     = Clusters->Zeta.vec(0);
        startL1     = VecStart.vec(IndexL1);
        endL1       = VecEnd.vec(IndexL1);
        nL1         = VecN.vec(IndexL1);
        
        
        Indexk     = Clusters->Zeta.vec(0);
        startk     = VecStart.vec(Indexk);
        endk       = VecEnd.vec(Indexk);
        nk         = VecN.vec(Indexk);
        
        if(Kobs>1)
        {
            IndexP1     = VecSuc.vec(Indexk);
            startP1     = VecStart.vec(IndexP1);
            endP1       = VecEnd.vec(IndexP1);
            nP1         = VecN.vec(IndexP1);
        }else{
            IndexP1     = Indexk;
            startP1     = startk;
            endP1       = endk;
            nP1         = nk;
        }
        
        
        
        /**** nuovi parametri ****/
        double probxiL1;
        double probxiP1;
        double probxiK;
        
        
        
//
//        vector <int> ClustIndex;
//
//
//
//        ClustIndex.push_back(Clusters->Zeta.vec(0));
//        for(i=1;i<nObs;i++)
//        {
//            //REprintf("%i \n",Clusters->Zeta.vec(i));
//            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
//            {
//                ClustIndex.push_back(Clusters->Zeta.vec(i));
//            }
//        }
//
//
        vector <int> ClustIndex;
        vector <int> ClustN;
        
        
        //REprintf("Cluster \n%i \n",Clusters->Zeta.vec(0));
        ClustIndex.push_back(Clusters->Zeta.vec(0));
        ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[0]));
        for(i=1;i<nObs;i++)
        {
            //REprintf("%i \n",Clusters->Zeta.vec(i));
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                ClustIndex.push_back(Clusters->Zeta.vec(i));
                ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[ClustIndex.size()-1]));
            }
        }
        
        //vector <double> logPI;
        vector <double> logSumPI;
        for(k=0;k<ClustIndex.size();k++)
        {
            //logPI.push_back(0.0);

            //logPI[k] = Pi->vec(ClustIndex[k]);
            
            

        }
        
        for(int k=0;k<ClustIndex.size();k++)
        {
            logSumPI.push_back(0.0);
        }
        
        double AppSum[Kmax];
        logSumPI[0] = 0;
        for(int k=1;k<ClustIndex.size();k++)
        {
            AppSum[k] = log(Pi->vec(ClustIndex[k-1]));
            Class_Utils::log_sum_exp(&logSumPI[k],k, &AppSum[1]);
        }
        
//        double AppSum[Kmax];
//        logSumXI[0] = 0;
//        for(k=1;k<ClustIndex.size();k++)
//        {
//            AppSum[k] = logXI[k-1];
//            Class_Utils::log_sum_exp(&logSumXI[k],k, &AppSum[1]);
//        }
        
        //        REprintf("Cluster \n%i \n",Clusters->Zeta.vec(0));
        //        for(i=1;i<nObs;i++)
        //        {
        //            REprintf("%i \n",Clusters->Zeta.vec(i));
        //        }
        //        REprintf("Stato inziale \n");
        //        for(k=0;k<ClustIndex.size();k++)
        //        {
        //            REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
        //        }
        
        
        int kxi = 0;
        
        /**** nuovi parametri  END ****/
        if(Kobs==1)
        {
            StopMerge=1;
        }
        //Rprintf("Merge");
        while(StopMerge==0 ){
            
            ControllWhile++;
            
            double LogLikeL1 = 0.0;
            double LogLikeP1 = 0.0;
            //double LogLikek_New = 0.0;
            double LogLikek_k = 0.0;
            double LogLikek_P1 = 0.0;
            double LogLikek_L1 = 0.0;
            
            double gammak = 0.0;
            
            //LogLikeL1 = 0.0;
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                for(i=startL1;i<=endL1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                    LogLikeL1 += appProb;
                }
            }
            LogLikeP1 = 0.0;
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                for(i=startP1;i<=endP1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                    LogLikeP1 += appProb;
                }
            }
            
            
            LogLikek_k = 0.0;
            LogLikek_P1 = 0.0;
            LogLikek_L1 = 0.0;
            for(i=startk;i<=endk;i++)
            {
                ObsY.P = Y.Pmat(i,0);
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk], i);
                LogLikek_k += appProb;
                
                //Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexNew], i);
                //LogLikek_New += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                LogLikek_P1 += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                LogLikek_L1 += appProb;
            }
            
            
//            gammak      = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endk, nObs-1,1,0), nk);
//
//            if(Class_Utils::ifelse(startk,0,1,0)!=1)
//            {
//                gammaL1     = compute_loggammaSampleCP(eta->ParameterAcc, 0,nL1);
//                gammaL1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0), nL1+nk);
//            }else{
//                gammaL1     = 0.0;
//                gammaL1k    = 0.0;
//            }
//
//            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
//            {
//                gammaP1k    = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0), nP1+nk);
//                gammaP1     = compute_loggammaSampleCP(eta->ParameterAcc, Class_Utils::ifelse(endP1, nObs-1,1,0),nP1);
//            }else{
//                gammaP1k    = 0.0;
//                gammaP1     = 0.0;
//            }
//
            probxiP1 = 0.0;
            probxiL1 = 0.0;
            probxiK = 0.0;
            
            
            probxiK = ( 1.0*(ClustN[kxi]-lengths+1) )*( Pi->vec(Indexk)-Class_Utils::log1mexp(logSumPI[kxi])  );
            for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
            {
                probxiK -= (1.0*ClustN[jjj])*Class_Utils::log1mexp(logSumPI[jjj]);
            }
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                probxiL1 = (1.0*ClustN[kxi])*( Pi->vec(IndexL1)-Class_Utils::log1mexp(logSumPI[kxi-1]));
                for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                {
                    probxiL1 -= (1.0*ClustN[jjj])*Class_Utils::log1mexp( log(exp(logSumPI[jjj])-Pi->vec(Indexk)) );
                    
                }
            }
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                probxiP1 = (1.0*ClustN[kxi])*( Pi->vec(IndexL1)-Class_Utils::log1mexp(logSumPI[kxi]));
                for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                {
                    probxiP1 -= (1.0*ClustN[jjj])*Class_Utils::log1mexp( log(exp(logSumPI[jjj])-Pi->vec(Indexk)) );
                }
            }
            
            //
            logProbL1[0]        = LogLikek_L1+LogLikeL1+LogLikeP1+probxiL1;
            logProbP1[0]        = LogLikek_P1+LogLikeP1+LogLikeL1+probxiP1;
            logProbk[0]         = LogLikek_k+LogLikeP1+LogLikeL1+probxiK;
            
            
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // L1 e P1
                    if(nk<lengths)
                    {
                        double PP[2];
                        PP[0] = logProb.vec(0);
                        PP[1] = logProb.vec(2);
                        samp = Class_Utils::sample_DiscreteVar(PP, 2);
                        if(samp==1)
                        {
                            samp = 2;
                        }
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                    }
                    
                }else{
                    // L1
                    if(nk<lengths)
                    {
                        samp = 0;
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                    }
                    
                }
            }else{
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // P1
                    if(nk<lengths)
                    {
                        samp = 2;
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(1), 2)+1;
                    }
                }else{
                    StopMerge   = 1;
                    samp        = 5;
                }
            }
            //logProb.Print("A");
            
            //            REprintf("Kobs %i  samp %i probxiL1 %f probxiP1 %f probxiK %f nk %i\n", Kobs, samp,probxiL1,probxiP1 ,probxiK, nk);
            //
            //            // xi
            //            REprintf("pre sample\n");
            //            for(k=0;k<ClustIndex.size();k++)
            //            {
            //                REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
            //            }
            if(samp==0)
            {
                for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                {
                    logSumPI[jjj]  =  log(exp( logSumPI[jjj] )- Pi->vec(Indexk));
                }
                ClustN[kxi-1] = ClustN[kxi-1]+ClustN[kxi];
                //logPI.erase(logPI.begin()+kxi);
                logSumPI.erase(logSumPI.begin()+kxi);
                ClustIndex.erase(ClustIndex.begin()+kxi);
                ClustN.erase(ClustN.begin()+kxi);
                kxi--;
                
                
            }
            if(samp==1)
            {
                kxi++;
            }
            if(samp==2)
            {
                for(int jjj=kxi+1;jjj<ClustIndex.size();jjj++)
                {
                    logSumPI[jjj]  =  log(exp( logSumPI[jjj] )- Pi->vec(Indexk));
                }
                ClustN[kxi+1] = ClustN[kxi+1]+ClustN[kxi];
                //logPI.erase(logPI.begin()+kxi);
                logSumPI.erase(logSumPI.begin()+kxi);
                ClustIndex.erase(ClustIndex.begin()+kxi);
                ClustN.erase(ClustN.begin()+kxi);
                kxi = kxi;
            }
            logSumPI[0] = 0;
            //            REprintf("post sample\n");
            //            for(k=0;k<ClustIndex.size();k++)
            //            {
            //                REprintf("logXI[k] %f logSumXI[k] %f ClustIndex[k] %i\n",logXI[k],logSumXI[k],ClustIndex[k] );
            //            }
            
            
            if(samp==0)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexL1;
                }
                
                //VecStart.Pvec(IndexL1)[0]       = VecStart.Pvec(IndexL1)[0];
                VecEnd.Pvec(IndexL1)[0]         = VecEnd.Pvec(Indexk)[0];
                VecN.Pvec(IndexL1)[0]           = VecN.Pvec(IndexL1)[0]+VecN.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                
                Indexk     = IndexL1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
                
                
            }
            if(samp==1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)==1)
                {
                    StopMerge = 1;
                }else{
                    if(Class_Utils::ifelse(endP1,nObs-1,1,0)!=1)
                    {
                        IndexP1     = VecSuc.vec(IndexP1);
                        startP1     = VecStart.vec(IndexP1);
                        endP1       = VecEnd.vec(IndexP1);
                        nP1         = VecN.vec(IndexP1);
                    }
                    
                    Indexk     = VecSuc.vec(Indexk);
                    startk     = VecStart.vec(Indexk);
                    endk       = VecEnd.vec(Indexk);
                    nk         = VecN.vec(Indexk);
                    
                    IndexL1     = VecPrec.vec(Indexk);
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                
                
            }
            if(samp==2)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexP1;
                }
                VecStart.Pvec(IndexP1)[0]       = VecStart.Pvec(Indexk)[0];
                //VecEnd.Pvec(IndexP1)[0]         = VecEnd.Pvec(IndexP1)[0];
                VecN.Pvec(IndexP1)[0]           = VecN.Pvec(IndexP1)[0]+VecN.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                Indexk     = IndexP1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
            }
            
            
            
        }
        
        if(ControllWhile>Kobs*Kobs)
        {
            error("CONTROLLARE WHILE LOOP");
        }
        
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        
        Clusters->update_EmptyAndNonEmptyClusters();
        
        
        
        
        
        
        //Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    
    
    double gammaWithBetaAlphaCP(vector <int> *nk, vector <double> *logbetak, int m, double alpha, int start)
    {
        
        int nElem = (int)logbetak[0].size();
        int k;
        double ret = 0.0;
        double G1,G2,G3;
        double LogBetaVec[nElem];
        double LogBetaVecSum[nElem];
        double app = 0.0;
        k=0;
        LogBetaVec[k]       = logbetak[0][k];
        LogBetaVecSum[k]    = logbetak[0][k];
        for(k=1;k<nElem;k++)
        {
            LogBetaVec[k]       = logbetak[0][k];
            Class_Utils::log_sum_exp(&LogBetaVecSum[k],k+1, &LogBetaVec[0]);
        }
        for(k=start;k<nElem-1;k++)
        {
            if((nk[0][k]-m)>=0)
            {
                G3 = lgamma1p(nk[0][k]-m+alpha+app+1);
                G1 =  lgamma(exp(logspace_add (log(nk[0][k]-m+1), log(alpha)+logbetak[0][k])));
                app = exp(Class_Utils::log1mexp(LogBetaVecSum[k])+log(alpha));
                G2 = lgamma1p(app);
                
                ret += G1+G2-G3;
            }else{
                app = exp(Class_Utils::log1mexp(LogBetaVecSum[k])+log(alpha));
                ret += -1000000.0;
            }
            
            
        }
        k = nElem-1;
        if((nk[0][k]-m)>=0)
        {
            G3 = lgamma1p(nk[0][k]-m+alpha+app);
            G1 =  lgamma(exp(logspace_add (log(nk[0][k]-m+1), log(alpha)+logbetak[0][k])));
            app = exp(Class_Utils::log1mexp(LogBetaVecSum[k])+log(alpha));
            G2 =  lgamma(app);
            ret += G1+G2-G3;
        }else{
            app = exp(Class_Utils::log1mexp(LogBetaVecSum[k])+log(alpha));
            ret += -1000000.0;
        }
        
        
        return(ret);
    }
    
    void samp_stChangePointSplit_withPimarg(int lengths,int isp, Matrix<double> *logBeta2, double alpha)
    {
        //Rprintf("Split\n");
        int ErrorNumberClusters = 0;
        int CheckError = 0;
        int Kobs;
        //int KobsStar;
        int Kempty;
        //int k;
        int k0;
        int k0prec;
        int kK;
        
        
        
        
        int kNew;
        int i,j;
        int samp;
        //int knext;
        int KmaxObs;
        int KFirstObs;
        int KsecondObs;
        int KmaxObsL1;
        int kSeq;
        int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        double appProb;
        
        //double LogLikeL1 = 0.0;
        //double LogLikeP1 = 0.0;
        //double LogLikek_New = 0.0;
        double LogLikek_k = 0.0;
        double LogLikek_P1 = 0.0;
        double LogLikek_L1 = 0.0;
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int startL1pre = 0;
        int endL1 = 0;
        int endL1pre = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nL1pre = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexL1pre = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        //        double gammaP1 = 0.0;
        //        double gammaL1 = 0.0;
        //        double gammak = 0.0;
        //        double gammaL1k = 0.0;
        //        double gammaP1k = 0.0;
        
        
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        Kvoid = Clusters->nEmpty;
        Kempty = Clusters->nEmpty;
        
        
        
        
        
        k0 = 1;
        kK = 0;
        kNew = 0;
        
        //        deltaP1 = 0;
        //        deltaL1 = 0;
        //        deltak = 0;
        
        k0prec = 1;
        
        //
        
        
        
        //KobsStar = Kobs;
        KmaxObs = Clusters->NonEmptyC.vec(Kobs-1);
        KFirstObs = Clusters->NonEmptyC.vec(0);
        
        if(Kobs>1)
        {
            KmaxObsL1 = Clusters->NonEmptyC.vec(Kobs-2);
            KsecondObs = Clusters->NonEmptyC.vec(1);
        }else{
            KmaxObsL1 = KmaxObs;
            KsecondObs = KFirstObs;
        }
        
        
        
        //if(Kobs>1)
        //{
        
        kSeq                = 0;
        IndexL1             = Clusters->NonEmptyC.vec(kSeq);
        IndexL1pre = IndexL1;
        if(Kobs>1)
        {
            IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
        }else{
            IndexP1             = IndexL1;
        }
        Indexk              = Clusters->EmptyC.vec(kNew);
        
        
        startk      = 0;
        startL1     = 0;
        startL1pre     = startL1;
        
        
        endL1       = startL1;
        endL1pre = endL1;
        endk        = startL1+Clusters->NObsInClust.vec(IndexL1)-1;
        
        
        nL1         = endL1-startL1+1;
        nL1pre         = nL1;
        nk          = endk-startk+1; //
        
        if(Kobs>1)
        {
            //Rprintf("MMM %i \n",Kobs);
            startP1     = startL1+Clusters->NObsInClust.vec(IndexL1);
            endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
            nP1         = endP1-startP1+1;
        }
        
        if(Clusters->nEmpty==0)
        {
            ErrorNumberClusters = 1;
            CheckError = 1;
            //Rprintf("Inizia con il numero max di stati\n");
        }
        
        
        //       Clusters->Zeta.Print("Zeta");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //Rprintf("\nSPLIT\n");
        
        
        
        /**** nuovi parametri ****/
        double probxiL1;
        double probxiP1;
        double probxiK;
        
        
        
        
        vector <int> ClustIndex;
        vector <int> ClustN;
        vector <int> ClustNK;
        vector <int> ClustNL1;
        vector <int> ClustNP1;
        
        
        
        ClustIndex.push_back(Clusters->Zeta.vec(0));
        ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[0]));
        ClustNK.push_back(ClustN[ClustN.size()-1]);
        ClustNL1.push_back(ClustN[ClustN.size()-1]);
        ClustNP1.push_back(ClustN[ClustN.size()-1]);
        for(i=1;i<nObs;i++)
        {
            //REprintf("%i \n",Clusters->Zeta.vec(i));
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                ClustIndex.push_back(Clusters->Zeta.vec(i));
                ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[ClustIndex.size()-1]));
                ClustNK.push_back(ClustN[ClustN.size()-1]);
                ClustNL1.push_back(ClustN[ClustN.size()-1]);
                ClustNP1.push_back(ClustN[ClustN.size()-1]);
            }
        }
        
        
        //vector <double> logPI;
        //vector <double> NologPI;
        vector <double> logBetaVecK;
        vector <double> logBetaVecL1;
        vector <double> logBetaVecP1;
        for(int k=0;k<ClustIndex.size();k++)
        {
            logBetaVecK.push_back(logBeta2->mat(isp,ClustIndex[k]));
            logBetaVecL1.push_back(logBeta2->mat(isp,ClustIndex[k]));
            logBetaVecP1.push_back(logBeta2->mat(isp,ClustIndex[k]));
        }
        
        int kL1 = 0;
        
//        /**** nuovi parametri  END ****/
//        REprintf("L1\n");
//        for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
//        {
//            REprintf("%i ",ClustNL1[hhh]);
//        }
//        REprintf("\n");
//        for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
//        {
//            REprintf("%f ",logBetaVecL1[hhh]);
//        }
//        REprintf("\n");
//
//
//        REprintf("K\n");
//        for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
//        {
//            REprintf("%i ",ClustNK[hhh]);
//        }
//        REprintf("\n");
//        for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
//        {
//            REprintf("%f ",logBetaVecK[hhh]);
//        }
//        REprintf("\n");
//
//        REprintf("P1\n");
//        for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
//        {
//            REprintf("%i ",ClustNP1[hhh]);
//        }
//        REprintf("\n");
//        for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
//        {
//            REprintf("%f ",logBetaVecP1[hhh]);
//        }
//        REprintf("\n\n\n");
//
        
        for(i=0;i<nObs;i++)
        {
            //REprintf("\n\n%i\n",i);
            if(ErrorNumberClusters==1)
            {
                if(CheckError==0)
                {
                    //Rprintf("K may be non well estimated\n");
                    CheckError = 1;
                }
                
            }else{
                if((startL1==startk)&(nk>0))
                {
                    //Rprintf("Nuovo codice");
                    
                    LogLikek_k = 0.0;
                    LogLikek_P1 = 0.0;
                    LogLikek_L1 = 0.0;
                    
                    
                    j = startk;
                    ObsY.P = Y.Pmat(j,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                    LogLikek_k += appProb;
                    
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                    LogLikek_L1 += appProb;
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1pre],j);
                        LogLikek_P1 += appProb;
                    }
                    
                    
                    /***********/
                    //K
                    ClustNK[kL1] = ClustNK[kL1]-1;
                    ClustNK.insert(ClustNK.begin()+kL1, 1);
                    logBetaVecK.insert(logBetaVecK.begin()+kL1, logBeta2->mat(isp,Indexk));
                    probxiK = gammaWithBetaAlphaCP(&ClustNK, &logBetaVecK, lengths, alpha, 0);
                    
                    //L1
                    probxiL1 = gammaWithBetaAlphaCP(&ClustNL1, &logBetaVecL1, lengths, alpha, 0);
                    
                    //P1
                    probxiP1 = 0.0;
                    if(IndexL1!=IndexL1pre)
                    {
                        ClustNP1[kL1] = ClustNP1[kL1]-1;
                        ClustNP1[kL1-1] = ClustNP1[kL1-1]+1;
                        probxiP1 = gammaWithBetaAlphaCP(&ClustNP1, &logBetaVecP1, lengths, alpha, 0);
                    }
                    
                    /***********/
                    
                    logProbL1[0]        = LogLikek_L1+probxiL1;
                    logProbP1[0]        = LogLikek_P1+probxiP1;
                    logProbk[0]         = LogLikek_k+probxiK;
                    
                    //REprintf("PREV %f %f %f\n", logProbL1[0] ,logProbk[0],logProbP1[0]  );
                    if(IndexL1!=IndexL1pre)
                    {
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                        //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                        //Rprintf("SAmpione su 2, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                    }
                    //GIAN2
//                    if(1<lengths)
//                    {
//                        samp = 0;
//                    }
//                    if(nL1==1)
//                    {
//                        samp = 0;
//                    }
                    
                    
//                    REprintf("samp-1\n %i\n probxiL1 %f,probxiK %f,probxiP1 %f, kL1 %i \n   logProbL1[0]  %f,logProbk[0]  %f,logProbP1[0]  %f \n   ",samp,probxiL1,probxiK,probxiP1, kL1, logProbL1[0],logProbk[0] ,logProbP1[0]);
//
//                    REprintf("L1\n");
//                    for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
//                    {
//                        REprintf("%i ",ClustNL1[hhh]);
//                    }
//                    REprintf("\n");
//                    for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
//                    {
//                        REprintf("%f ",logBetaVecL1[hhh]);
//                    }
//                    REprintf("\n");
//
//
//                    REprintf("K\n");
//                    for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
//                    {
//                        REprintf("%i ",ClustNK[hhh]);
//                    }
//                    REprintf("\n");
//                    for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
//                    {
//                        REprintf("%f ",logBetaVecK[hhh]);
//                    }
//                    REprintf("\n");
//
//                    REprintf("P1\n");
//                    for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
//                    {
//                        REprintf("%i ",ClustNP1[hhh]);
//                    }
//                    REprintf("\n");
//                    for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
//                    {
//                        REprintf("%f ",logBetaVecP1[hhh]);
//                    }
//                    REprintf("\n\n\n");
                    
                    if(samp==0)
                    {
                        ClustNK  = ClustNL1;
                        ClustNP1 = ClustNL1;
                        logBetaVecK = logBetaVecL1;
                        logBetaVecP1 = logBetaVecL1;
                    }
                    if(samp==1)
                    {
                        ClustNL1 = ClustNK;
                        ClustNP1 = ClustNK;
                        
                        logBetaVecL1 = logBetaVecK;
                        logBetaVecP1 = logBetaVecK;
                        
                        kL1++;
                    }
                    if(samp==2)
                    {
                        ClustNK  = ClustNP1;
                        ClustNL1 = ClustNP1;
                        
                        logBetaVecK = logBetaVecP1;
                        logBetaVecL1 = logBetaVecP1;
                    }
                    if(samp==0)
                    {
                        // rimando su dove ero
                        //                    Rprintf("\nS0\n");
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        // NO_ERROR Indexk      = Indexk;
                        
                        // NO_ERROR startL1     = startL1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        // NO_ERROR endL1pre       = endL1pre;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                    }
                    if(samp==1)
                    {
                        // cmapiono k
                        //                    Rprintf("\nS1\n");
                        //
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j=startk;
                        Clusters->Zeta.Pvec(j)[0]  = Indexk;
                        
                        startL1pre     = startk;
                        endL1pre       = startk;
                        nL1pre         = endL1pre-startL1pre+1;
                        IndexL1pre     = Indexk;
                        
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        startk      = startL1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                    }
                    if(samp==2)
                    {
                        // passo a quello prima
                        //                    Rprintf("\nS2\n");
                        //                    Rprintf("%f %f \n", logProbL1[0],logProbk[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j= startk;
                        Clusters->Zeta.Pvec(j)[0]  = IndexL1pre;
                        
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        endL1pre       = endL1pre+1;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                    }
                    
                    
                    
                }else{
                    if((nk!=0))
                    {
                        //Rprintf("Vecchio codice\n");
                        
                        
                        if(nL1==1)
                        {
                            LogLikek_k = 0.0;
                            LogLikek_P1 = 0.0;
                            LogLikek_L1 = 0.0;
                            
                            for(j=startk;j<=endk;j++)
                            {
                                ObsY.P = Y.Pmat(j,0);
                                //ObsY.Print("Y");
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                                LogLikek_k += appProb;
                                //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                                LogLikek_L1 += appProb;
                                //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                                
                                
                                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                                {
                                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                    LogLikek_P1 += appProb;
                                    //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                                }
                            }
                            
                        }else{
                            j = startk-1;
                            
                            ObsY.P = Y.Pmat(j,0);
                            //ObsY.Print("Y");
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                            LogLikek_k -= appProb;
                            //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                            LogLikek_L1 -= appProb;
                            //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                            
                            
                            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                            {
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                LogLikek_P1 -= appProb;
                                //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                            }
                        }
                        
                        
                        /***********/
                        
                        //K
                        ClustNK[kL1] = ClustNK[kL1]-nk;
                        ClustNK.insert(ClustNK.begin()+kL1+1, nk);
                        logBetaVecK.insert(logBetaVecK.begin()+kL1+1, logBeta2->mat(isp,Indexk));
                        probxiK = gammaWithBetaAlphaCP(&ClustNK, &logBetaVecK, lengths, alpha, 0);
                        
                        //L1
                        probxiL1 = gammaWithBetaAlphaCP(&ClustNL1, &logBetaVecL1, lengths, alpha, 0);
                        
                        //P1
                        probxiP1 = 0.0;
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            ClustNP1[kL1]   = ClustNP1[kL1]-nk;
                            ClustNP1[kL1+1] = ClustNP1[kL1+1]+nk;
                            probxiP1 = gammaWithBetaAlphaCP(&ClustNP1, &logBetaVecP1, lengths, alpha, 0);
                        }
                        
                        
                        /***********/
                        
                        
                        logProbL1[0]        = LogLikek_L1+probxiL1;
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            logProbP1[0]        = LogLikek_P1+probxiP1;
                        }
                        logProbk[0]         = LogLikek_k+probxiK;
                        
                        //REprintf("%f %f %f\n", logProbL1[0] ,logProbk[0],logProbP1[0]  );
                        
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                            //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                        }else{
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                            //Rprintf("SAmpione su 2, z=%i %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                        }
                        
                        //GIAN2
//                        if((nk<lengths)or(nL1<lengths))
//                        {
//                            samp = 0;
//                        }
                        
                        
//                       REprintf("samp-2 \n %i\n probxiL1 %f,probxiK %f,probxiP1 %f, kL1 %i \n   logProbL1[0]  %f,logProbk[0]  %f,logProbP1[0]  %f \n   ",samp,probxiL1,probxiK,probxiP1, kL1, logProbL1[0],logProbk[0] ,logProbP1[0]);
//                        
//                        REprintf("L1\n");
//                        for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
//                        {
//                            REprintf("%i ",ClustNL1[hhh]);
//                        }
//                        REprintf("\n");
//                        for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
//                        {
//                            REprintf("%f ",logBetaVecL1[hhh]);
//                        }
//                        REprintf("\n");
//                        
//                        
//                        REprintf("K\n");
//                        for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
//                        {
//                            REprintf("%i ",ClustNK[hhh]);
//                        }
//                        REprintf("\n");
//                        for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
//                        {
//                            REprintf("%f ",logBetaVecK[hhh]);
//                        }
//                        REprintf("\n");
//                        
//                        REprintf("P1\n");
//                        for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
//                        {
//                            REprintf("%i ",ClustNP1[hhh]);
//                        }
//                        REprintf("\n");
//                        for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
//                        {
//                            REprintf("%f ",logBetaVecP1[hhh]);
//                        }
//                        REprintf("\n\n\n");
                        
                        
                        if(samp==0)
                        {
                            ClustNK  = ClustNL1;
                            ClustNP1 = ClustNL1;
                            
                            logBetaVecK = logBetaVecL1;
                            logBetaVecP1 = logBetaVecL1;
                            
                        }
                        if(samp==1)
                        {
                            ClustNL1 = ClustNK;
                            ClustNP1 = ClustNK;
                            
                            logBetaVecP1 = logBetaVecK;
                            logBetaVecL1 = logBetaVecK;
                            kL1++;
                        }
                        if(samp==2)
                        {
                            ClustNK  = ClustNP1;
                            ClustNL1 = ClustNP1;
                            
                            logBetaVecK = logBetaVecP1;
                            logBetaVecL1 = logBetaVecP1;
                            kL1++;
                        }
                        
                        if(samp==0)
                        {
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            // NO_ERROR Indexk      = Indexk;
                            
                            
                            // NO_ERROR startL1     = startL1;
                            endL1       = endL1+1;
                            nL1         = endL1-startL1+1;
                            // NO_ERROR IndexL1      = IndexL1;
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            // NO_ERROR startL1pre     = startL1pre;
                            // NO_ERROR endL1pre       = endL1pre;
                            nL1pre         = endL1pre-startL1pre+1;
                            // NO_ERROR IndexL1pre      = IndexL1pre;
                            
                            
                            
                        }
                        if(samp==1)
                        {
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = Indexk;
                            }
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre          = nL1;
                            IndexL1pre      = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = Indexk;
                            
                            
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            kNew++;
                            if(kNew>=(Kvoid-2))
                            {
                                ErrorNumberClusters = 1;
                            }else{
                                
                                Indexk              = Clusters->EmptyC.vec(kNew);
                            }
                        }
                        if(samp==2)
                        {
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = IndexP1;
                            }
                            
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre              = nL1;
                            IndexL1pre          = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            endk        = endP1;
                            nk          = endk-startk+1;
                            // NO_ERROR Indexk      = Indexk;
                            //                            kNew++;
                            //                            if(kNew>=(Kvoid-2))
                            //                            {
                            //                                ErrorNumberClusters = 1;
                            //                            }else{
                            //
                            //                                Indexk              = Clusters->EmptyC.vec(kNew);
                            //                            }
                            
                            
                            if(IndexL1!=KmaxObs)
                            {
                                kSeq++;
                                IndexP1      =  Clusters->NonEmptyC.vec(kSeq+1);
                                startP1     = endk+1;
                                endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                nP1         = endP1-startP1+1;
                            }
                            
                        }
                        
                        
                    }else{
                        if(IndexL1!=KmaxObs)
                        {
                            //Rprintf("Non campiono\n");
                            
                            kL1++;
                            startL1pre = startL1;
                            endL1pre = endL1;
                            nL1pre  = nL1;
                            IndexL1pre = IndexL1;
                            
                            IndexL1             = IndexP1;
                            startL1             = startP1;
                            endL1               = startP1;
                            nL1                 = endL1-startL1+1;
                            
                            
                            // NO_ERROR Indexk              = Indexk;
                            startk              = startL1;
                            endk                = endP1;
                            nk                  = endk-startk+1;
                            
                            if(IndexP1!=KmaxObs)
                            {
                                kSeq++;
                                //Rprintf("\nSstar1\n");
                                IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
                                //Rprintf("\nSstar2\n");
                                startP1             = startL1+Clusters->NObsInClust.vec(IndexL1);
                                //Rprintf("\nSsta3\n");
                                endP1               = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                //Rprintf("\nSstar5\n");
                                nP1                 = endP1-startP1+1;
                            }
                        }
                        
                    }
                }
            }
            
            
            
            
            
        }
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        //Clusters->Zeta.Print("ZetaPost");
        
        //Clusters->Zeta.Print("Zeta");
        
        //error("STOP");
        Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    void samp_stChangePointMerge_withPimarg(int lengths,int isp, Matrix<double> *logBeta2, double alpha)
    {
        int ControllWhile = 0;
        int StopMerge = 0;
        int Kobs;
        int KobsStar;
        int Kempty;
        int k;
        //int k0;
        //int k0prec;
        //int kK;
        //int kKP1;
        //int kNew;
        int i;
        int samp;
        //int knext;
        
        
        //int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        
        
        
        double appProb;
        
        
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int endL1 = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        //        double gammaP1 = 0.0;
        //        double gammaL1 = 0.0;
        //
        //        double gammaL1k = 0.0;
        //        double gammaP1k = 0.0;
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        
        KobsStar = Kobs;
        Kempty = Clusters->nEmpty;
        
        
        int VecPrec_P[Kmax];
        Vector <int>VecPrec(Kmax, VecPrec_P);
        
        int VecSuc_P[Kmax];
        Vector <int>VecSuc(Kmax, VecSuc_P);
        VecSuc.Init(-99);
        
        int VecN_P[Kmax];
        Vector <int>VecN(Kmax, VecN_P);
        VecN.Init(-99);
        
        int VecStart_P[Kmax];
        Vector <int>VecStart(Kmax, VecStart_P);
        VecStart.Init(-99);
        
        int VecEnd_P[Kmax];
        Vector <int>VecEnd(Kmax, VecEnd_P);
        VecEnd.Init(-99);
        
        
        VecStart.Pvec(Clusters->Zeta.vec(0))[0] = 0;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                VecPrec.Pvec(Clusters->Zeta.vec(i))[0] = Clusters->Zeta.vec(i-1);
                VecSuc.Pvec(Clusters->Zeta.vec(i-1))[0] = Clusters->Zeta.vec(i);
                VecStart.Pvec(Clusters->Zeta.vec(i))[0] = i;
                VecEnd.Pvec(Clusters->Zeta.vec(i-1))[0] = i-1;
            }
        }
        VecEnd.Pvec(Clusters->Zeta.vec(nObs-1))[0] = nObs-1;
        for(k=0;k<Kmax;k++)
        {
            VecN.Pvec(k)[0] = Clusters->NObsInClust.vec(k);
        }
        
        
        //Likelihood->ProbSecondLev[0][ipar].VectorAcc.Pvec(k)[0];
        //knext       = 0;
        
        IndexL1     = Clusters->Zeta.vec(0);
        startL1     = VecStart.vec(IndexL1);
        endL1       = VecEnd.vec(IndexL1);
        nL1         = VecN.vec(IndexL1);
        
        
        Indexk     = Clusters->Zeta.vec(0);
        startk     = VecStart.vec(Indexk);
        endk       = VecEnd.vec(Indexk);
        nk         = VecN.vec(Indexk);
        
        if(Kobs>1)
        {
            IndexP1     = VecSuc.vec(Indexk);
            startP1     = VecStart.vec(IndexP1);
            endP1       = VecEnd.vec(IndexP1);
            nP1         = VecN.vec(IndexP1);
        }else{
            IndexP1     = Indexk;
            startP1     = startk;
            endP1       = endk;
            nP1         = nk;
        }
        
        
        
        /**** nuovi parametri ****/
        double probxiL1;
        double probxiP1;
        double probxiK;
        
        
        
        //
        //        vector <int> ClustIndex;
        //
        //
        //
        //        ClustIndex.push_back(Clusters->Zeta.vec(0));
        //        for(i=1;i<nObs;i++)
        //        {
        //            //REprintf("%i \n",Clusters->Zeta.vec(i));
        //            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
        //            {
        //                ClustIndex.push_back(Clusters->Zeta.vec(i));
        //            }
        //        }
        //
        //
        vector <int> ClustIndex;
        vector <int> ClustN;
        vector <int> ClustNK;
        vector <int> ClustNL1;
        vector <int> ClustNP1;
        
        
        //REprintf("Cluster \n%i \n",Clusters->Zeta.vec(0));
        ClustIndex.push_back(Clusters->Zeta.vec(0));
        ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[0]));
        ClustNK.push_back(ClustN[ClustN.size()-1]);
        ClustNL1.push_back(ClustN[ClustN.size()-1]);
        ClustNP1.push_back(ClustN[ClustN.size()-1]);
        for(i=1;i<nObs;i++)
        {
            //REprintf("%i \n",Clusters->Zeta.vec(i));
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                ClustIndex.push_back(Clusters->Zeta.vec(i));
                ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[ClustIndex.size()-1]));
                ClustNK.push_back(ClustN[ClustN.size()-1]);
                ClustNL1.push_back(ClustN[ClustN.size()-1]);
                ClustNP1.push_back(ClustN[ClustN.size()-1]);
            }
        }
        vector <double> logBetaVecK;
        vector <double> logBetaVecL1;
        vector <double> logBetaVecP1;
        for(int k=0;k<ClustIndex.size();k++)
        {
            logBetaVecK.push_back(logBeta2->mat(isp,ClustIndex[k]));
            logBetaVecL1.push_back(logBeta2->mat(isp,ClustIndex[k]));
            logBetaVecP1.push_back(logBeta2->mat(isp,ClustIndex[k]));
        }
        
        int kxi = 0;
        
        /**** nuovi parametri  END ****/
        if(Kobs==1)
        {
            StopMerge=1;
        }
        //Rprintf("Merge");
        while(StopMerge==0 ){
            
            ControllWhile++;
            
            double LogLikeL1 = 0.0;
            double LogLikeP1 = 0.0;
            //double LogLikek_New = 0.0;
            double LogLikek_k = 0.0;
            double LogLikek_P1 = 0.0;
            double LogLikek_L1 = 0.0;
            
            double gammak = 0.0;
            
            //LogLikeL1 = 0.0;
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                for(i=startL1;i<=endL1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                    LogLikeL1 += appProb;
                }
            }
            LogLikeP1 = 0.0;
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                for(i=startP1;i<=endP1;i++)
                {
                    ObsY.P = Y.Pmat(i,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                    LogLikeP1 += appProb;
                }
            }
            
            
            LogLikek_k = 0.0;
            LogLikek_P1 = 0.0;
            LogLikek_L1 = 0.0;
            for(i=startk;i<=endk;i++)
            {
                ObsY.P = Y.Pmat(i,0);
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk], i);
                LogLikek_k += appProb;
                
                //Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexNew], i);
                //LogLikek_New += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1], i);
                LogLikek_P1 += appProb;
                
                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1], i);
                LogLikek_L1 += appProb;
            }
            
            
            /***********/
            
            //K
            probxiK = gammaWithBetaAlphaCP(&ClustNK, &logBetaVecK, lengths, alpha, 0);
            
            //L1
            probxiL1 = 0.0;
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                ClustNL1[kxi-1]   = ClustNK[kxi-1]+ClustNK[kxi];
                ClustNL1.erase(ClustNL1.begin()+kxi);
                logBetaVecL1.erase(logBetaVecL1.begin()+kxi);
                probxiL1 = gammaWithBetaAlphaCP(&ClustNL1, &logBetaVecL1, lengths, alpha, 0);
            }
            
            
            //P1
            probxiP1 = 0.0;
            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
            {
                ClustNP1[kxi+1]   = ClustNK[kxi+1]+ClustNK[kxi];
                ClustNP1.erase(ClustNP1.begin()+kxi);
                logBetaVecP1.erase(logBetaVecP1.begin()+kxi);
                probxiP1 = gammaWithBetaAlphaCP(&ClustNP1, &logBetaVecP1, lengths, alpha, 0);
            }
            
            
            /***********/
            
            logProbL1[0]        = LogLikek_L1+LogLikeL1+LogLikeP1+probxiL1;
            logProbP1[0]        = LogLikek_P1+LogLikeP1+LogLikeL1+probxiP1;
            logProbk[0]         = LogLikek_k+LogLikeP1+LogLikeL1+probxiK;
            
            
            

              //GIAN2
//            if(Class_Utils::ifelse(startk,0,1,0)!=1)
//            {
//                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
//                {
//                    // L1 e P1
//                    if((nk<lengths) or (nk==1))
//                    {
//                        double PP[2];
//                        PP[0] = logProb.vec(0);
//                        PP[1] = logProb.vec(2);
//                        samp = Class_Utils::sample_DiscreteVar(PP, 2);
//                        if(samp==1)
//                        {
//                            samp = 2;
//                        }
//                    }else{
//                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
//                    }
//
//                }else{
//                    // L1
//                    if((nk<lengths) or (nk==1))
//                    {
//                        samp = 0;
//                    }else{
//                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
//                    }
//
//                }
//            }else{
//                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
//                {
//                    // P1
//                    if((nk<lengths) or (nk==1))
//                    {
//                        samp = 2;
//                    }else{
//                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(1), 2)+1;
//                    }
//                }else{
//                    StopMerge   = 1;
//                    samp        = 5;
//                }
//            }
            if(Class_Utils::ifelse(startk,0,1,0)!=1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // L1 e P1
                    samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                }else{
                    // L1
                    samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                }
            }else{
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    // P1
                    samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(1), 2)+1;
                }else{
                    StopMerge   = 1;
                    samp        = 5;
                }
            }
            
//            
//            REprintf("samp-2 \n %i\n probxiL1 %f,probxiK %f,probxiP1 %f, kxi %i \n   logProbL1[0]  %f,logProbk[0]  %f,logProbP1[0]  %f \n   ",samp,probxiL1,probxiK,probxiP1,kxi, logProbL1[0],logProbk[0] ,logProbP1[0]);
//            
//            REprintf("L1\n");
//            for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
//            {
//                REprintf("%i ",ClustNL1[hhh]);
//            }
//            REprintf("\n");
//            for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
//            {
//                REprintf("%f ",logBetaVecL1[hhh]);
//            }
//            REprintf("\n");
//            
//            
//            REprintf("K\n");
//            for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
//            {
//                REprintf("%i ",ClustNK[hhh]);
//            }
//            REprintf("\n");
//            for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
//            {
//                REprintf("%f ",logBetaVecK[hhh]);
//            }
//            REprintf("\n");
//            
//            REprintf("P1\n");
//            for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
//            {
//                REprintf("%i ",ClustNP1[hhh]);
//            }
//            REprintf("\n");
//            for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
//            {
//                REprintf("%f ",logBetaVecP1[hhh]);
//            }
//            REprintf("\n\n\n");
            
            if(samp==0)
            {
                ClustNK  = ClustNL1;
                ClustNP1 = ClustNL1;
                
                logBetaVecK = logBetaVecL1;
                logBetaVecP1 = logBetaVecL1;
                kxi--;
            }
            if(samp==1)
            {
                ClustNL1 = ClustNK;
                ClustNP1 = ClustNK;
                
                logBetaVecP1 = logBetaVecK;
                logBetaVecL1 = logBetaVecK;
                kxi++;
            }
            if(samp==2)
            {
                ClustNK  = ClustNP1;
                ClustNL1 = ClustNP1;
                
                logBetaVecK = logBetaVecP1;
                logBetaVecL1 = logBetaVecP1;
                kxi = kxi;
            }
            
            
            
            
            if(samp==0)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexL1;
                }
                
                //VecStart.Pvec(IndexL1)[0]       = VecStart.Pvec(IndexL1)[0];
                VecEnd.Pvec(IndexL1)[0]         = VecEnd.Pvec(Indexk)[0];
                VecN.Pvec(IndexL1)[0]           = VecN.Pvec(IndexL1)[0]+VecN.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                
                Indexk     = IndexL1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
                
                
            }
            if(samp==1)
            {
                if(Class_Utils::ifelse(endk,nObs-1,1,0)==1)
                {
                    StopMerge = 1;
                }else{
                    if(Class_Utils::ifelse(endP1,nObs-1,1,0)!=1)
                    {
                        IndexP1     = VecSuc.vec(IndexP1);
                        startP1     = VecStart.vec(IndexP1);
                        endP1       = VecEnd.vec(IndexP1);
                        nP1         = VecN.vec(IndexP1);
                    }
                    
                    Indexk     = VecSuc.vec(Indexk);
                    startk     = VecStart.vec(Indexk);
                    endk       = VecEnd.vec(Indexk);
                    nk         = VecN.vec(Indexk);
                    
                    IndexL1     = VecPrec.vec(Indexk);
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                
                
            }
            if(samp==2)
            {
                for(i=startk;i<=endk;i++)
                {
                    Clusters->Zeta.Pvec(i)[0]  = IndexP1;
                }
                VecStart.Pvec(IndexP1)[0]       = VecStart.Pvec(Indexk)[0];
                //VecEnd.Pvec(IndexP1)[0]         = VecEnd.Pvec(IndexP1)[0];
                VecN.Pvec(IndexP1)[0]           = VecN.Pvec(IndexP1)[0]+VecN.Pvec(Indexk)[0];
                
                VecSuc.Pvec(IndexL1)[0]         = VecSuc.Pvec(Indexk)[0];
                VecPrec.Pvec(IndexP1)[0]        = VecPrec.Pvec(Indexk)[0];
                
                
                Indexk     = IndexP1;
                startk     = VecStart.vec(Indexk);
                endk       = VecEnd.vec(Indexk);
                nk         = VecN.vec(Indexk);
                
                if(Class_Utils::ifelse(startk,0,1,0)!=1)
                {
                    IndexL1     = VecPrec.Pvec(Indexk)[0];
                    startL1     = VecStart.vec(IndexL1);
                    endL1       = VecEnd.vec(IndexL1);
                    nL1         = VecN.vec(IndexL1);
                }
                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                {
                    IndexP1     = VecSuc.vec(Indexk);
                    startP1     = VecStart.vec(IndexP1);
                    endP1       = VecEnd.vec(IndexP1);
                    nP1         = VecN.vec(IndexP1);
                }
                
                if((Class_Utils::ifelse(startk,0,1,0)==1) & (Class_Utils::ifelse(endk,nObs-1,1,0)==1))
                {
                    StopMerge = 1;
                }
                
                
            }
            
            
            
        }
        
        if(ControllWhile>Kobs*Kobs)
        {
            error("CONTROLLARE WHILE LOOP");
        }
        
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        
        Clusters->update_EmptyAndNonEmptyClusters();
        
        
        
        
        
        
        //Clusters->update_EmptyAndNonEmptyClusters();
        
    }
    
    
    
    
    void samp_stChangePointSplit_withPimarg_TODELETE(int lengths,int isp, Matrix<double> *logBeta2, double alpha)
    {
        //Rprintf("Split\n");
        int ErrorNumberClusters = 0;
        int CheckError = 0;
        int Kobs;
        //int KobsStar;
        int Kempty;
        //int k;
        int k0;
        int k0prec;
        int kK;
        
        
        
        
        int kNew;
        int i,j;
        int samp;
        //int knext;
        int KmaxObs;
        int KFirstObs;
        int KsecondObs;
        int KmaxObsL1;
        int kSeq;
        int Kvoid;
        double *logProbL1;
        double *logProbP1;
        //double *logProbNew;
        double *logProbk;
        
        double logProb_P[3];
        Vector<double> logProb(3,logProb_P);
        logProbL1   = logProb.Pvec(0);
        logProbk    = logProb.Pvec(1);
        //logProbNew  = logProb.Pvec(2);
        logProbP1   = logProb.Pvec(2);
        
        double appProb;
        
        //double LogLikeL1 = 0.0;
        //double LogLikeP1 = 0.0;
        //double LogLikek_New = 0.0;
        double LogLikek_k = 0.0;
        double LogLikek_P1 = 0.0;
        double LogLikek_L1 = 0.0;
        
        int startL1 = 0;
        int startk = 0;
        int startP1 = 0;
        int startL1pre = 0;
        int endL1 = 0;
        int endL1pre = 0;
        int endk = 0;
        int endP1 = 0;
        int nL1 = 0;
        int nL1pre = 0;
        int nk = 0;
        int nP1 = 0;
        int IndexL1 = 0;
        int IndexL1pre = 0;
        int IndexP1 = 0;
        int Indexk = 0;
        //int IndexNew = 0;
        
        //        double gammaP1 = 0.0;
        //        double gammaL1 = 0.0;
        //        double gammak = 0.0;
        //        double gammaL1k = 0.0;
        //        double gammaP1k = 0.0;
        
        
        
        
        Vector<double> ObsY(nVars,Y.Pmat(0,0));
        
        Kobs = Clusters->nNonEmpty;
        Kvoid = Clusters->nEmpty;
        Kempty = Clusters->nEmpty;
        
        
        
        
        
        k0 = 1;
        kK = 0;
        kNew = 0;
        
        //        deltaP1 = 0;
        //        deltaL1 = 0;
        //        deltak = 0;
        
        k0prec = 1;
        
        //
        
        
        
        //KobsStar = Kobs;
        KmaxObs = Clusters->NonEmptyC.vec(Kobs-1);
        KFirstObs = Clusters->NonEmptyC.vec(0);
        
        if(Kobs>1)
        {
            KmaxObsL1 = Clusters->NonEmptyC.vec(Kobs-2);
            KsecondObs = Clusters->NonEmptyC.vec(1);
        }else{
            KmaxObsL1 = KmaxObs;
            KsecondObs = KFirstObs;
        }
        
        
        
        //if(Kobs>1)
        //{
        
        kSeq                = 0;
        IndexL1             = Clusters->NonEmptyC.vec(kSeq);
        IndexL1pre = IndexL1;
        if(Kobs>1)
        {
            IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
        }else{
            IndexP1             = IndexL1;
        }
        Indexk              = Clusters->EmptyC.vec(kNew);
        
        
        startk      = 0;
        startL1     = 0;
        startL1pre     = startL1;
        
        
        endL1       = startL1;
        endL1pre = endL1;
        endk        = startL1+Clusters->NObsInClust.vec(IndexL1)-1;
        
        
        nL1         = endL1-startL1+1;
        nL1pre         = nL1;
        nk          = endk-startk+1; //
        
        if(Kobs>1)
        {
            //Rprintf("MMM %i \n",Kobs);
            startP1     = startL1+Clusters->NObsInClust.vec(IndexL1);
            endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
            nP1         = endP1-startP1+1;
        }
        
        if(Clusters->nEmpty==0)
        {
            ErrorNumberClusters = 1;
            CheckError = 1;
            //Rprintf("Inizia con il numero max di stati\n");
        }
        
        for(int hhh5=0;hhh5<Clusters->Zeta.nElem;hhh5++)
        {
            REprintf("%i %f %f %f\n",Clusters->Zeta.vec(hhh5),Y.mat(hhh5,0),Y.mat(hhh5,1),Y.mat(hhh5,2));
        }
        
        //        Clusters->NObsInClust.Print("NObsInClust");
        //        Clusters->NObsInClust.Print("NObsInClust");
        //Rprintf("\nSPLIT\n");
        
        
        
        /**** nuovi parametri ****/
        double probxiL1;
        double probxiP1;
        double probxiK;
        
        
        
        
        vector <int> ClustIndex;
        vector <int> ClustN;
        vector <int> ClustNK;
        vector <int> ClustNL1;
        vector <int> ClustNP1;
        
        
        
        ClustIndex.push_back(Clusters->Zeta.vec(0));
        ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[0]));
        ClustNK.push_back(ClustN[ClustN.size()-1]);
        ClustNL1.push_back(ClustN[ClustN.size()-1]);
        ClustNP1.push_back(ClustN[ClustN.size()-1]);
        for(i=1;i<nObs;i++)
        {
            //REprintf("%i \n",Clusters->Zeta.vec(i));
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                ClustIndex.push_back(Clusters->Zeta.vec(i));
                ClustN.push_back( Clusters->NObsInClust.vec(ClustIndex[ClustIndex.size()-1]));
                ClustNK.push_back(ClustN[ClustN.size()-1]);
                ClustNL1.push_back(ClustN[ClustN.size()-1]);
                ClustNP1.push_back(ClustN[ClustN.size()-1]);
            }
        }
        
        
        //vector <double> logPI;
        //vector <double> NologPI;
        vector <double> logBetaVecK;
        vector <double> logBetaVecL1;
        vector <double> logBetaVecP1;
        for(int k=0;k<ClustIndex.size();k++)
        {
            logBetaVecK.push_back(logBeta2->mat(isp,ClustIndex[k]));
            logBetaVecL1.push_back(logBeta2->mat(isp,ClustIndex[k]));
            logBetaVecP1.push_back(logBeta2->mat(isp,ClustIndex[k]));
        }
        
        int kL1 = 0;
        
        //        /**** nuovi parametri  END ****/
        //        REprintf("L1\n");
        //        for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
        //        {
        //            REprintf("%i ",ClustNL1[hhh]);
        //        }
        //        REprintf("\n");
        //        for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
        //        {
        //            REprintf("%f ",logBetaVecL1[hhh]);
        //        }
        //        REprintf("\n");
        //
        //
        //        REprintf("K\n");
        //        for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
        //        {
        //            REprintf("%i ",ClustNK[hhh]);
        //        }
        //        REprintf("\n");
        //        for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
        //        {
        //            REprintf("%f ",logBetaVecK[hhh]);
        //        }
        //        REprintf("\n");
        //
        //        REprintf("P1\n");
        //        for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
        //        {
        //            REprintf("%i ",ClustNP1[hhh]);
        //        }
        //        REprintf("\n");
        //        for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
        //        {
        //            REprintf("%f ",logBetaVecP1[hhh]);
        //        }
        //        REprintf("\n\n\n");
        //
        
        for(int hhh4=0;hhh4<12;hhh4++)
        {
            REprintf("GP %f %f %f \n", Container[Indexk].GPVec[0][0].vec((hhh4%12)),Container[Indexk].GPVec[1][0].vec((hhh4%12)),Container[Indexk].GPVec[2][0].vec((hhh4%12)));
        }
        
        
        Container[Indexk].VectorCont->VectorAcc.Pvec(0)[0] =   Container[IndexL1].VectorCont->VectorAcc.Pvec(0)[0];
        Container[Indexk].VectorCont->VectorAcc.Pvec(2)[0] =   Container[IndexL1].VectorCont->VectorAcc.Pvec(2)[0];
        Container[Indexk].VectorCont->VectorAcc.Pvec(4)[0] =   Container[IndexL1].VectorCont->VectorAcc.Pvec(4)[0];
        
        for(int hhh6=0;hhh6<3;hhh6++)
        {
            for(int hhh7=0;hhh7<3;hhh7++)
            {
                Container[Indexk].PDmat[0].SigmaAccInv.Pmat(hhh6,hhh7)[0] =  Container[IndexL1].PDmat[0].SigmaAccInv.Pmat(hhh6,hhh7)[0];
            }
            Container[Indexk].PDmat[0].logdetAcc = Container[IndexL1].PDmat[0].logdetAcc;
        }
        
        Container[Indexk].VectorCont->VectorAcc.Pvec(0)[0] = 1.0;
        Container[Indexk].VectorCont->VectorAcc.Pvec(2)[0] = 0.8;
        Container[Indexk].VectorCont->VectorAcc.Pvec(4)[0] = -1.0;
        
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(0,0)[0] = 5.1763316;
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(0,1)[0] = 2.706754;
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(0,2)[0] = -0.3647139;
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(1,0)[0] = 2.7067539;
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(1,1)[0] = 30.150798;
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(1,2)[0] = 3.6386338;
        
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(2,0)[0] = -0.3647139 ;
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(2,1)[0] = 3.638634;
        Container[Indexk].PDmat[0].SigmaAccInv.Pmat(2,2)[0] = 30.9750457;
        
        
        Container[Indexk].PDmat[0].logdetAcc = -8.417953;
        
        for(i=0;i<nObs;i++)
        {
            REprintf("\n\n%i\n",i);
            if(ErrorNumberClusters==1)
            {
                if(CheckError==0)
                {
                    //Rprintf("K may be non well estimated\n");
                    CheckError = 1;
                }
                
            }else{
                if((startL1==startk)&(nk>0))
                {
                    //Rprintf("Nuovo codice");
                    
                    LogLikek_k = 0.0;
                    LogLikek_P1 = 0.0;
                    LogLikek_L1 = 0.0;
                    
                    
                    j = startk;
                    ObsY.P = Y.Pmat(j,0);
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                    LogLikek_k += appProb;
                    
                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                    LogLikek_L1 += appProb;
                    
                    if(IndexL1!=IndexL1pre)
                    {
                        Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1pre],j);
                        LogLikek_P1 += appProb;
                    }
                    
                    
                    /***********/
                    //K
                    ClustNK[kL1] = ClustNK[kL1]-1;
                    ClustNK.insert(ClustNK.begin()+kL1, 1);
                    logBetaVecK.insert(logBetaVecK.begin()+kL1, logBeta2->mat(isp,Indexk));
                    probxiK = gammaWithBetaAlphaCP(&ClustNK, &logBetaVecK, lengths, alpha, 0);
                    
                    //L1
                    probxiL1 = gammaWithBetaAlphaCP(&ClustNL1, &logBetaVecL1, lengths, alpha, 0);
                    
                    //P1
                    probxiP1 = 0.0;
                    if(IndexL1!=IndexL1pre)
                    {
                        ClustNP1[kL1] = ClustNP1[kL1]-1;
                        ClustNP1[kL1-1] = ClustNP1[kL1-1]+1;
                        probxiP1 = gammaWithBetaAlphaCP(&ClustNP1, &logBetaVecP1, lengths, alpha, 0);
                    }
                    
                    /***********/
                    
                    logProbL1[0]        = LogLikek_L1+probxiL1;
                    logProbP1[0]        = LogLikek_P1+probxiP1;
                    logProbk[0]         = LogLikek_k+probxiK;
                    
                    //REprintf("PREV %f %f %f\n", logProbL1[0] ,logProbk[0],logProbP1[0]  );
                    if(IndexL1!=IndexL1pre)
                    {
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                        //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                    }else{
                        samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                        //Rprintf("SAmpione su 2, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                    }
                    if(1<lengths)
                    {
                        samp = 0;
                    }
                    if(nL1==1)
                    {
                        samp = 0;
                    }
                    
                    
                    REprintf("samp-1\n %i\n probxiL1 %f,probxiK %f,probxiP1 %f, kL1 %i \n   logProbL1[0]  %f,logProbk[0]  %f,logProbP1[0]  %f \n  %i %i %i \n  ",samp,probxiL1,probxiK,probxiP1, kL1,
                             LogLikek_L1,LogLikek_k,LogLikek_P1 ,nL1,nk,nL1pre);
                    REprintf("L1 %f %f %f \n K %f %f %f\n  L1pre %f %f %f \n", Container[IndexL1].VectorCont->VectorAcc.vec(0), Container[IndexL1].VectorCont->VectorAcc.vec(2), Container[IndexL1].VectorCont->VectorAcc.vec(4),
                        Container[Indexk].VectorCont->VectorAcc.vec(0),     Container[Indexk].VectorCont->VectorAcc.vec(2),      Container[Indexk].VectorCont->VectorAcc.vec(4),
                             Container[IndexL1pre].VectorCont->VectorAcc.vec(0),     Container[IndexL1pre].VectorCont->VectorAcc.vec(2),      Container[IndexL1pre].VectorCont->VectorAcc.vec(4)
                            );
                    Container[IndexL1].PDmat[0].SigmaAcc.Print("IndexL1");
                    Container[Indexk].PDmat[0].SigmaAcc.Print("Indexk");
                    Container[IndexL1pre].PDmat[0].SigmaAcc.Print("IndexL1pre");
                    
                    REprintf("GP %f %f %f \n", Container[Indexk].GPVec[0][0].vec((j%12)),Container[Indexk].GPVec[1][0].vec((j%12)),Container[Indexk].GPVec[2][0].vec((j%12)));
                    //
                    //                    REprintf("L1\n");
                    //                    for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
                    //                    {
                    //                        REprintf("%i ",ClustNL1[hhh]);
                    //                    }
                    //                    REprintf("\n");
                    //                    for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
                    //                    {
                    //                        REprintf("%f ",logBetaVecL1[hhh]);
                    //                    }
                    //                    REprintf("\n");
                    //
                    //
                    //                    REprintf("K\n");
                    //                    for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
                    //                    {
                    //                        REprintf("%i ",ClustNK[hhh]);
                    //                    }
                    //                    REprintf("\n");
                    //                    for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
                    //                    {
                    //                        REprintf("%f ",logBetaVecK[hhh]);
                    //                    }
                    //                    REprintf("\n");
                    //
                    //                    REprintf("P1\n");
                    //                    for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
                    //                    {
                    //                        REprintf("%i ",ClustNP1[hhh]);
                    //                    }
                    //                    REprintf("\n");
                    //                    for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
                    //                    {
                    //                        REprintf("%f ",logBetaVecP1[hhh]);
                    //                    }
                    //                    REprintf("\n\n\n");
                    
                    if(samp==0)
                    {
                        ClustNK  = ClustNL1;
                        ClustNP1 = ClustNL1;
                        logBetaVecK = logBetaVecL1;
                        logBetaVecP1 = logBetaVecL1;
                    }
                    if(samp==1)
                    {
                        ClustNL1 = ClustNK;
                        ClustNP1 = ClustNK;
                        
                        logBetaVecL1 = logBetaVecK;
                        logBetaVecP1 = logBetaVecK;
                        
                        kL1++;
                    }
                    if(samp==2)
                    {
                        ClustNK  = ClustNP1;
                        ClustNL1 = ClustNP1;
                        
                        logBetaVecK = logBetaVecP1;
                        logBetaVecL1 = logBetaVecP1;
                    }
                    if(samp==0)
                    {
                        // rimando su dove ero
                        //                    Rprintf("\nS0\n");
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        // NO_ERROR Indexk      = Indexk;
                        
                        // NO_ERROR startL1     = startL1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        // NO_ERROR endL1pre       = endL1pre;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                    }
                    if(samp==1)
                    {
                        // cmapiono k
                        //                    Rprintf("\nS1\n");
                        //
                        //                    Rprintf("%f %f %f \n", logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j=startk;
                        Clusters->Zeta.Pvec(j)[0]  = Indexk;
                        
                        startL1pre     = startk;
                        endL1pre       = startk;
                        nL1pre         = endL1pre-startL1pre+1;
                        IndexL1pre     = Indexk;
                        
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        startk      = startL1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                    }
                    if(samp==2)
                    {
                        // passo a quello prima
                        //                    Rprintf("\nS2\n");
                        //                    Rprintf("%f %f \n", logProbL1[0],logProbk[0]);
                        //                    Rprintf("%e %e %e\n",logProbL1[0],logProbk[0],logProbP1[0]);
                        //                    Rprintf("%f %f %f %f %f\n",LogLikeL1,LogLikeP1,LogLikek_k,LogLikek_L1,LogLikek_P1 );
                        //                    Rprintf("AA %e %e %e %e %e\n",gammaL1k,gammaP1,LogLikek_L1,LogLikeL1,LogLikeP1 );
                        
                        j= startk;
                        Clusters->Zeta.Pvec(j)[0]  = IndexL1pre;
                        
                        
                        // NO_ERROR startL1pre     = startL1pre;
                        endL1pre       = endL1pre+1;
                        nL1pre         = endL1pre-startL1pre+1;
                        // NO_ERROR IndexL1pre      = IndexL1pre;
                        
                        startL1     = startL1+1;
                        endL1       = startL1;
                        nL1         = endL1-startL1+1;
                        // NO_ERROR IndexL1      = IndexL1;
                        
                        
                        // NO_ERROR startP1     = startP1;
                        // NO_ERROR endP1       = endP1;
                        nP1         = endP1-startP1+1;
                        // NO_ERROR IndexP1      = IndexP1;
                        
                        startk      = startk+1;
                        // NO_ERROR endk        = endk;
                        nk          = endk-startk+1; //
                        kNew++;
                        if(kNew>=(Kvoid-2))
                        {
                            ErrorNumberClusters=1;
                        }else{
                            
                            Indexk              = Clusters->EmptyC.vec(kNew);
                        }
                    }
                    
                    
                    
                }else{
                    if((nk!=0))
                    {
                        //Rprintf("Vecchio codice\n");
                        
                        
                        if(nL1==1)
                        {
                            LogLikek_k = 0.0;
                            LogLikek_P1 = 0.0;
                            LogLikek_L1 = 0.0;
                            
                            for(j=startk;j<=endk;j++)
                            {
                                ObsY.P = Y.Pmat(j,0);
                                //ObsY.Print("Y");
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                                LogLikek_k += appProb;
                                //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                                LogLikek_L1 += appProb;
                                //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                                
                                
                                if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                                {
                                    Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                    LogLikek_P1 += appProb;
                                    //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                                }
                            }
                            
                        }else{
                            j = startk-1;
                            
                            ObsY.P = Y.Pmat(j,0);
                            //ObsY.Print("Y");
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[Indexk],j);
                            LogLikek_k -= appProb;
                            //Rprintf("Ap k %f %f\n",appProb,LogLikek_k);
                            Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexL1],j);
                            LogLikek_L1 -= appProb;
                            //Rprintf("Ap l1 %f %f\n",appProb,LogLikek_L1);
                            
                            
                            if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                            {
                                Likelihood->computeLogDensityForLike(&appProb,&ObsY, &Container[IndexP1],j);
                                LogLikek_P1 -= appProb;
                                //Rprintf("Ap p1 %f %f \n",appProb,LogLikek_P1);
                            }
                        }
                        
                        
                        /***********/
                        
                        //K
                        ClustNK[kL1] = ClustNK[kL1]-nk;
                        ClustNK.insert(ClustNK.begin()+kL1+1, nk);
                        logBetaVecK.insert(logBetaVecK.begin()+kL1+1, logBeta2->mat(isp,Indexk));
                        probxiK = gammaWithBetaAlphaCP(&ClustNK, &logBetaVecK, lengths, alpha, 0);
                        
                        //L1
                        probxiL1 = gammaWithBetaAlphaCP(&ClustNL1, &logBetaVecL1, lengths, alpha, 0);
                        
                        //P1
                        probxiP1 = 0.0;
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            ClustNP1[kL1]   = ClustNP1[kL1]-nk;
                            ClustNP1[kL1+1] = ClustNP1[kL1+1]+nk;
                            probxiP1 = gammaWithBetaAlphaCP(&ClustNP1, &logBetaVecP1, lengths, alpha, 0);
                        }
                        
                        
                        /***********/
                        
                        
                        logProbL1[0]        = LogLikek_L1+probxiL1;
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            logProbP1[0]        = LogLikek_P1+probxiP1;
                        }
                        logProbk[0]         = LogLikek_k+probxiK;
                        
                        //REprintf("%f %f %f\n", logProbL1[0] ,logProbk[0],logProbP1[0]  );
                        
                        if(Class_Utils::ifelse(endk,nObs-1,1,0)!=1)
                        {
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 3);
                            //Rprintf("SAmpione su 3, z=%i %f %f %f\n",samp, logProb.vec(0), logProb.vec(1), logProb.vec(2));
                        }else{
                            samp = Class_Utils::sample_DiscreteVar(logProb.Pvec(0), 2);
                            //Rprintf("SAmpione su 2, z=%i %f %f\n",samp, logProb.vec(0), logProb.vec(1));
                        }
                        
                        
                        if((nk<lengths)||(nL1<lengths))
                        {
                            samp = 0;
                        }
                        
                        
                        REprintf("samp-2 \n %i\n probxiL1 %f,probxiK %f,probxiP1 %f, kL1 %i \n   logProbL1[0]  %f,logProbk[0]  %f,logProbP1[0]  %f \n %i %i %i \n   ",samp,probxiL1,probxiK,probxiP1, kL1, LogLikek_L1,LogLikek_k,LogLikek_P1, nL1, nk,nP1);
                        REprintf("L1 %f %f %f \n K %f %f %f \n P1  %f %f %f \n",
                                 Container[IndexL1].VectorCont->VectorAcc.vec(0), Container[IndexL1].VectorCont->VectorAcc.vec(2), Container[IndexL1].VectorCont->VectorAcc.vec(4),
                                 Container[Indexk].VectorCont->VectorAcc.vec(0),Container[Indexk].VectorCont->VectorAcc.vec(2), Container[Indexk].VectorCont->VectorAcc.vec(4),
                                  Container[IndexP1].VectorCont->VectorAcc.vec(0),     Container[IndexP1].VectorCont->VectorAcc.vec(2),      Container[IndexP1].VectorCont->VectorAcc.vec(4));
                        
                        
                        Container[IndexL1].PDmat[0].SigmaAcc.Print("IndexL1");
                        Container[Indexk].PDmat[0].SigmaAcc.Print("Indexk");
                        Container[IndexP1].PDmat[0].SigmaAcc.Print("IndexP1");
                        
                        REprintf("GP %f %f %f \n", Container[Indexk].GPVec[0][0].vec((j%12)),Container[Indexk].GPVec[1][0].vec((j%12)),Container[Indexk].GPVec[2][0].vec((j%12)));
                        //
                        //                        REprintf("L1\n");
                        //                        for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
                        //                        {
                        //                            REprintf("%i ",ClustNL1[hhh]);
                        //                        }
                        //                        REprintf("\n");
                        //                        for(int hhh=0;hhh<(int)ClustNL1.size();hhh++)
                        //                        {
                        //                            REprintf("%f ",logBetaVecL1[hhh]);
                        //                        }
                        //                        REprintf("\n");
                        //
                        //
                        //                        REprintf("K\n");
                        //                        for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
                        //                        {
                        //                            REprintf("%i ",ClustNK[hhh]);
                        //                        }
                        //                        REprintf("\n");
                        //                        for(int hhh=0;hhh<(int)ClustNK.size();hhh++)
                        //                        {
                        //                            REprintf("%f ",logBetaVecK[hhh]);
                        //                        }
                        //                        REprintf("\n");
                        //
                        //                        REprintf("P1\n");
                        //                        for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
                        //                        {
                        //                            REprintf("%i ",ClustNP1[hhh]);
                        //                        }
                        //                        REprintf("\n");
                        //                        for(int hhh=0;hhh<(int)ClustNP1.size();hhh++)
                        //                        {
                        //                            REprintf("%f ",logBetaVecP1[hhh]);
                        //                        }
                        //                        REprintf("\n\n\n");
                        
                        
                        if(samp==0)
                        {
                            ClustNK  = ClustNL1;
                            ClustNP1 = ClustNL1;
                            
                            logBetaVecK = logBetaVecL1;
                            logBetaVecP1 = logBetaVecL1;
                            
                        }
                        if(samp==1)
                        {
                            ClustNL1 = ClustNK;
                            ClustNP1 = ClustNK;
                            
                            logBetaVecP1 = logBetaVecK;
                            logBetaVecL1 = logBetaVecK;
                            kL1++;
                        }
                        if(samp==2)
                        {
                            ClustNK  = ClustNP1;
                            ClustNL1 = ClustNP1;
                            
                            logBetaVecK = logBetaVecP1;
                            logBetaVecL1 = logBetaVecP1;
                            kL1++;
                        }
                        
                        if(samp==0)
                        {
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            // NO_ERROR Indexk      = Indexk;
                            
                            
                            // NO_ERROR startL1     = startL1;
                            endL1       = endL1+1;
                            nL1         = endL1-startL1+1;
                            // NO_ERROR IndexL1      = IndexL1;
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            // NO_ERROR startL1pre     = startL1pre;
                            // NO_ERROR endL1pre       = endL1pre;
                            nL1pre         = endL1pre-startL1pre+1;
                            // NO_ERROR IndexL1pre      = IndexL1pre;
                            
                            
                            
                        }
                        if(samp==1)
                        {
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = Indexk;
                            }
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre          = nL1;
                            IndexL1pre      = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = Indexk;
                            
                            
                            
                            // NO_ERROR startP1     = startP1;
                            // NO_ERROR endP1       = endP1;
                            nP1         = endP1-startP1+1;
                            // NO_ERROR IndexP1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            // NO_ERROR endk        = endk;
                            nk          = endk-startk+1; //
                            kNew++;
                            if(kNew>=(Kvoid-2))
                            {
                                ErrorNumberClusters = 1;
                            }else{
                                
                                Indexk              = Clusters->EmptyC.vec(kNew);
                            }
                        }
                        if(samp==2)
                        {
                            
                            for(j=startk;j<=endk;j++)
                            {
                                Clusters->Zeta.Pvec(j)[0]  = IndexP1;
                            }
                            
                            startL1pre      = startL1;
                            endL1pre        = endL1;
                            nL1pre              = nL1;
                            IndexL1pre          = IndexL1;
                            
                            
                            startL1     = startk;
                            endL1       = startL1;
                            nL1         = endL1-startL1+1;
                            IndexL1      = IndexP1;
                            
                            
                            startk      = startk+1;
                            endk        = endP1;
                            nk          = endk-startk+1;
                            // NO_ERROR Indexk      = Indexk;
                            //                            kNew++;
                            //                            if(kNew>=(Kvoid-2))
                            //                            {
                            //                                ErrorNumberClusters = 1;
                            //                            }else{
                            //
                            //                                Indexk              = Clusters->EmptyC.vec(kNew);
                            //                            }
                            
                            
                            if(IndexL1!=KmaxObs)
                            {
                                kSeq++;
                                IndexP1      =  Clusters->NonEmptyC.vec(kSeq+1);
                                startP1     = endk+1;
                                endP1       = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                nP1         = endP1-startP1+1;
                            }
                            
                        }
                        
                        
                    }else{
                        if(IndexL1!=KmaxObs)
                        {
                            //Rprintf("Non campiono\n");
                            
                            kL1++;
                            startL1pre = startL1;
                            endL1pre = endL1;
                            nL1pre  = nL1;
                            IndexL1pre = IndexL1;
                            
                            IndexL1             = IndexP1;
                            startL1             = startP1;
                            endL1               = startP1;
                            nL1                 = endL1-startL1+1;
                            
                            
                            // NO_ERROR Indexk              = Indexk;
                            startk              = startL1;
                            endk                = endP1;
                            nk                  = endk-startk+1;
                            
                            if(IndexP1!=KmaxObs)
                            {
                                kSeq++;
                                //Rprintf("\nSstar1\n");
                                IndexP1             = Clusters->NonEmptyC.vec(kSeq+1);
                                //Rprintf("\nSstar2\n");
                                startP1             = startL1+Clusters->NObsInClust.vec(IndexL1);
                                //Rprintf("\nSsta3\n");
                                endP1               = startP1+Clusters->NObsInClust.vec(IndexP1)-1;
                                //Rprintf("\nSstar5\n");
                                nP1                 = endP1-startP1+1;
                            }
                        }
                        
                    }
                }
            }
            
            
            
            
            
        }
        // check
        int IndexCheck_P[Kmax];
        Vector <int>IndexCheck(Kmax,IndexCheck_P);
        IndexCheck.Init(0);
        
        IndexCheck.Pvec(Clusters->Zeta.vec(0))[0]++;
        for(i=1;i<nObs;i++)
        {
            if(Clusters->Zeta.vec(i)!=Clusters->Zeta.vec(i-1))
            {
                IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]++;
                if(IndexCheck.Pvec(Clusters->Zeta.vec(i))[0]>1)
                {
                    Rprintf("\n\n Errore in K %i \n\n", i);
                    Clusters->Zeta.Print("ZetaPost");
                    error("Stop");
                }
            }
        }
        
        //Clusters->Zeta.Print("ZetaPost");
        
        //Clusters->Zeta.Print("Zeta");
        
        //error("STOP");
        Clusters->update_EmptyAndNonEmptyClusters();
        
        Clusters->Zeta.Print("Zeta");
    }
    
    
    
};

typedef Class_Mixture_TODELETE_PERCLIMA Class_Mixture;
#endif

