#include <iostream>
#include <string>
#include <list>
#include <vector>
#ifdef _OPENMP
#include <omp.h>
#endif
#include <boost/numeric/odeint.hpp>

#include <R.h>//TTT
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>

#include "MatricesAndVectors.h"
#include "AdaptiveMH.h"
#include "Mixture.h"
#include "ODE.h"//
//#include <Rcpp.h>

extern "C" {


SEXP ODE_T2Random(
SEXP nInits_r,
SEXP Inits_r,
SEXP NamePrior_r,
SEXP nParameters_r,
SEXP Prior_r,
SEXP nSd_r,
SEXP Sd_r,
SEXP MCMC_r,
SEXP Adaptpar_r,
SEXP Data_r,
SEXP indices_r,
SEXP indicesDouble_r,
SEXP IndexNotNA_r,
SEXP TEXT_r
           ){

  /*****************************************
          UTILS
   *****************************************/
  GetRNGstate();


  int i,j;
  double      *appPointDouble;
  int         *appPointInteger;

  int indexPriorParameters;
  int indexInit;
  string Name;
  string appName;

  int UserControlledMemory = 1;
  /*****************************************
           NAMES
   *****************************************/

  /********** Init Values ************/
  const int nInitsVector_R                    = 16;
  string  InitsVector_R[nInitsVector_R ]      = {
    "Beta0",
    "Beta1",
    "sigma2",
    "Y0",
    "MinK",
    "EtaK1",
    "EtaK2",
    "MeanK",
    "VarK",
    "DPpar",
    "stMat",
    "piMat",
    "RegCoef",
    "sigmaMat",
		"SH",
      "Void"
  };

  vector <string> Names_ParametersInit;
  for(int i=0;i<nInitsVector_R;i++)
  {
      Names_ParametersInit.push_back(InitsVector_R[i]);
  }

  /********** Parameters ************/
  const int nParametersVector_R                           = 14;
  string ParametersVector_R[nParametersVector_R ]         = {
    "Beta0",
    "Beta1",
    "sigma2",
    "Y0",
    "MinK",
    "EtaK1",
    "EtaK2",
    "MeanK",
    "VarK",
    "DPpar",
    "RegCoef",
    "sigmaMat",
      "Void"
  };
  vector <string> Names_ParametersPrior;
  for(int i=0;i<nParametersVector_R;i++)
  {
      Names_ParametersPrior.push_back(ParametersVector_R[i]);
  }


  /********** Priors ************/
  const int nPriorsVector_R                   = 11;
  string PriorsVector_R[nPriorsVector_R]      = {
      "NoPrior",
      "Normal",
      "Gamma",
      "InverseGamma",
      "Uniform",
      "InverseWishart",
      "HuangWand",
      "Dirichlet",
      "PositiveTruncatedNormal",
    "TruncatedNormal",
      "Void"};
  vector <string> Names_Priors;
  for(int i=0;i<nPriorsVector_R;i++)
  {
      Names_Priors.push_back(PriorsVector_R[i]);
  }

  /********** SD Adapt ************/
  const int nSdVector_R                           = 14;
  string SdVector_R[nSdVector_R ]         = {
    "Beta0",
    "Beta1",
    "General",
    "MinK",
    "EtaK1",
    "EtaK2",
    "MeanK",
    "VarK",
    "Y0",
    "DPpar",
    "RegCoef",
    "sigmaMat",
	  "SF",
      "Void"
  };
  vector <string> Names_Sd;
  for(int i=0;i<nSdVector_R;i++)
  {
      Names_Sd.push_back(SdVector_R[i]);
  }

  /*****************************************
   Indices
   *****************************************/

  int *indices                     = INTEGER(indices_r);

  i = 0;
  int nvar        = indices[i];i++;
  int nobsTOT     = indices[i];i++;
  int nG          = indices[i];i++;
  int nt          = indices[i];i++;
  int nrep        = indices[i];i++;
  int IterShow    = indices[i];i++;
  int DoParallel  = indices[i];i++;
  int Nthreads    = indices[i];i++;
  int Verbose     = indices[i];i++;
  int nlatentk    = indices[i];i++;
  int nstep       = indices[i];i++;
  int saveODE     = indices[i];i++;
  int nNotna      = indices[i];i++;
  int Rparam      = indices[i];i++;
  int sample_Var  = indices[i];i++;
  int sample_Ode  = indices[i];i++;
  int SampleOdeType = indices[i];i++;
  int Kmax        = indices[i];i++;
  int ClustType   = indices[i];i++;
  int sample_RandomPar= indices[i];i++;
  int sample_Pi    = indices[i];i++;
  int sample_DpPar = indices[i];i++;
  int  sample_st   = indices[i];i++;
	int IterStartRandom = indices[i];i++;
	int addStartRandom =  indices[i];i++;
	int Use_pi       =  indices[i];i++;
	int Spike       =  indices[i];i++;
	int Do_MergeSplit =  indices[i];i++;
	int TypeK =  indices[i];i++;


  double *indicesD                     = REAL(indicesDouble_r);
  i = 0;
  double tmin        = indicesD[i];i++;
  double tmax        = indicesD[i];i++;
  double deltat      = indicesD[i];i++;
  double abs_err    = indicesD[i];i++;
  double rel_err    = indicesD[i];i++;
	double LimSpike    = indicesD[i];i++;
	double LimC    = indicesD[i];i++;
	double ExpMolt = indicesD[i];i++;
	double ExpLambda = indicesD[i];i++;
	double MoltSF = indicesD[i];i++;

  /*****************************************
   ParallelComp
   *****************************************/


  #ifdef _OPENMP
  if(DoParallel==1)
  {
    omp_set_num_threads(min(Nthreads,omp_get_num_procs()));
  }else{
    omp_set_num_threads(1);
  }
  if(Verbose==1)
  {
    REprintf("ParmeterNthreads: %i\n",Nthreads);
    REprintf("NumberOfProcessors: %i\n ",omp_get_num_procs());
    REprintf("MaxNumberOfThreads: %i\n\n",omp_get_max_threads());
    # pragma omp parallel
    {
      REprintf("CheckThread: %i\n", omp_get_thread_num());
    }
    REprintf("\n");
  }
  #else
  if(DoParallel==1)
  {
    if(Verbose==1)
    {
      REprintf("OPENMP - not possible\n\n");
    }

  }
  #endif
  /*****************************************
   MCMC and ADAPT
   *****************************************/

  appPointInteger             = INTEGER(MCMC_r);
  int MCMCiter                = appPointInteger[0];
  int MCMCburnin              = appPointInteger[1];
  int MCMCthin                = appPointInteger[2];
  int MCMCiter_noTandB        = appPointInteger[3];
  int nSamples_save           = MCMCiter_noTandB+1;

  i=0;
  appPointDouble              = REAL(Adaptpar_r);
  int     AdaptStart          = (int)appPointDouble[i];i++;
  int     AdaptEnd            = (int)appPointDouble[i];i++;
  double  AdaptExp            = appPointDouble[i];i++;
  double  AdaptAcc            = appPointDouble[i];i++;
  int     AdaptBatch          = (int)appPointDouble[i];i++;
  double  AdaptEps            = appPointDouble[i];i++;
  double  AdaptLambda         = appPointDouble[i];i++;

  Class_AdaptPar      AdaptParameters(AdaptStart,AdaptEnd, AdaptExp, AdaptAcc, AdaptBatch);

  if(Verbose==1)
  {
    REprintf("MCMC parameters:\n");
    REprintf("Iterations=%i Burnin=%i Thin=%i SampleSave=%i\n\n", MCMCiter,MCMCburnin,MCMCthin , nSamples_save);

    REprintf("Adapt parameters:\n");
    REprintf("Start=%i End=%i AccRatio=%f \nBatch=%i Epsilon=%f Exponent=%f \n\n",AdaptStart,AdaptEnd ,AdaptAcc,AdaptBatch,AdaptEps,AdaptExp);
  }
  /*****************************************
  Parameters
  *****************************************/

	#pragma mark Par SF

	Name                 = "SH";
	//indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
	indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

	//double *SF_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
	//string SF_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
	double *SF_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));
	REprintf("SF\n");


	vector<Poly_Prior* >            SF_Prior;
	vector< vector< Class_Parameter > >         SF_MCMC;

//	i = 0;
//	SF_Prior.push_back(new Class_NoPrior);
//	SF_Prior[i]->create_FullObject(UserControlledMemory);
//
	for(i=0;i<nNotna;i++)
	{
		SF_Prior.push_back(new Class_Gamma);
		SF_Prior[i]->create_FullObject(UserControlledMemory);
	}
	for(i=0;i<nNotna;i++)
	{
		int k=0;
		SF_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = 1.0;
		SF_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = 1.0;

		k=1;
		SF_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = 1.0*MoltSF;
		SF_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = 1.0*MoltSF;
	}


	for(int k=0;k<3;k++)
	{
		SF_MCMC.push_back(vector<Class_Parameter>());
		for(i=0;i<nNotna;i++)
		{
			 SF_MCMC[k].push_back(Class_Parameter());
			 appName = (("SF_")+to_string(i));
			 SF_MCMC[k][i].create_FullObject(SF_InitParameters[k*nNotna+i]*MoltSF, appName,  SF_Prior[i]);
		}
	}

  for(int k=0;k<3;k++)
	{
		for(i=0;i<nNotna;i++)
		{
			SF_MCMC[k][i].add_Pointerparameters_InVector();
		}
   }

	REprintf("SF-end\n");

  #pragma mark Par Beta

  Name                 = "Beta1";
   indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
   indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

   double *Beta1_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
   string Beta1_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
   double *Beta1_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


   vector<Poly_Prior* >            Beta1_Prior;
   vector<Class_Parameter>         Beta1_MCMC;

   if(Beta1_PriorName=="NoPrior")
   {
     for(i=0;i<nvar;i++)
     {
         Beta1_Prior.push_back(new Class_NoPrior);
         Beta1_Prior[i]->create_FullObject(UserControlledMemory);
     }
   }else{
     if(Beta1_PriorName=="Uniform")
     {
         for(i=0;i<nvar;i++)
         {
             Beta1_Prior.push_back(new Class_Uniform);
             Beta1_Prior[i]->create_FullObject(UserControlledMemory);
         }

     }else{
       if(Beta1_PriorName=="Normal")
       {
         for(i=0;i<nvar;i++)
         {
           Beta1_Prior.push_back(new Class_Normal);
           Beta1_Prior[i]->create_FullObject(UserControlledMemory);
         }
       }else{
			 if(Beta1_PriorName=="Gamma")
			 {
				for(i=0;i<nvar;i++)
				{
				  Beta1_Prior.push_back(new Class_Gamma);
				  Beta1_Prior[i]->create_FullObject(UserControlledMemory);
				}
			 }else{
				  error("Prior on Beta1 not well specified");
			 }

       }
     }
   }


   for(i=0;i<nvar;i++)
   {
       for(int k=0;k<Beta1_Prior[i]->nHyperparams;k++)
       {
           Beta1_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = Beta1_PriorParameters[k*nvar+i];
           Beta1_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = Beta1_PriorParameters[k*nvar+i];
       }
   }
   for(i=0;i<nvar;i++)
   {
       Beta1_MCMC.push_back(Class_Parameter());
       appName = (("Beta1_")+to_string(i));
       Beta1_MCMC[i].create_FullObject(Beta1_InitParameters[i], appName,  Beta1_Prior[i]);
   }
   for(i=0;i<nvar;i++)
   {
       Beta1_MCMC[i].add_Pointerparameters_InVector();
   }


  Name                 = "Beta0";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

  double *Beta0_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string Beta0_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *Beta0_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  vector<Poly_Prior* >            Beta0_Prior;
  vector<Class_Parameter>         Beta0_MCMC;

  if(Beta0_PriorName=="NoPrior")
  {
    for(i=0;i<nvar;i++)
    {
        Beta0_Prior.push_back(new Class_NoPrior);
        Beta0_Prior[i]->create_FullObject(UserControlledMemory);
    }
  }else{
    if(Beta0_PriorName=="Uniform")
    {
        for(i=0;i<nvar;i++)
        {
            Beta0_Prior.push_back(new Class_Uniform);
            Beta0_Prior[i]->create_FullObject(UserControlledMemory);
        }

    }else{
      if(Beta0_PriorName=="Normal")
      {
        for(i=0;i<nvar;i++)
        {
          Beta0_Prior.push_back(new Class_Normal);
          Beta0_Prior[i]->create_FullObject(UserControlledMemory);
        }
      }else{
        error("Prior on Beta0 not well specified");
      }
    }
  }


  for(i=0;i<nvar;i++)
  {
      for(int k=0;k<Beta0_Prior[i]->nHyperparams;k++)
      {
          Beta0_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = Beta0_PriorParameters[k*nvar+i];
          Beta0_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = Beta0_PriorParameters[k*nvar+i];
      }
  }
  for(i=0;i<nvar;i++)
  {
      Beta0_MCMC.push_back(Class_Parameter());
      appName = (("Beta0_")+to_string(i));
      Beta0_MCMC[i].create_FullObject(Beta0_InitParameters[i], appName,  Beta0_Prior[i]);
  }
  for(i=0;i<nvar;i++)
  {
      Beta0_MCMC[i].add_Pointerparameters_InVector();
  }

  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/
  #pragma mark Par MinK

  Name                 = "MinK";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

  double *MinK_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string MinK_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *MinK_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  vector<vector<Poly_Prior* >   >            MinK_Prior; // uno per i k
  vector< vector <Class_Parameter > >        MinK_MCMC; // k/nvar/cluster
  if(MinK_PriorName=="Normal")
  {
    for(int g=0;g<nG;g++)
    {
      MinK_Prior.push_back(vector<Poly_Prior* >());
      for(i=0;i<nlatentk;i++)
      {
        MinK_Prior[g].push_back(new Class_Normal);
        MinK_Prior[g][i]->create_FullObject(UserControlledMemory);
      }
    }
  }else{
    if(MinK_PriorName=="NoPrior")
    {
      for(int g=0;g<nG;g++)
      {
        MinK_Prior.push_back(vector<Poly_Prior* >());
        for(i=0;i<nlatentk;i++)
        {
          MinK_Prior[g].push_back(new Class_NoPrior);
          MinK_Prior[g][i]->create_FullObject(UserControlledMemory);
        }
      }
    }else{
      if(MinK_PriorName=="Uniform")
      {
        for(int g=0;g<nG;g++)
        {
          MinK_Prior.push_back(vector<Poly_Prior* >());
          for(i=0;i<nlatentk;i++)
          {
            MinK_Prior[g].push_back(new Class_Uniform);
            MinK_Prior[g][i]->create_FullObject(UserControlledMemory);
          }
        }
      }else{
        if(MinK_PriorName=="InverseGamma")
        {
          for(int g=0;g<nG;g++)
          {
            MinK_Prior.push_back(vector<Poly_Prior* >());
            for(i=0;i<nlatentk;i++)
            {
              MinK_Prior[g].push_back(new Class_InverseGamma);
              MinK_Prior[g][i]->create_FullObject(UserControlledMemory);
            }
          }

        }else{
          if(MinK_PriorName=="TruncatedNormal")
          {
            for(int g=0;g<nG;g++)
            {
              MinK_Prior.push_back(vector<Poly_Prior* >());
              for(i=0;i<nlatentk;i++)
              {
                MinK_Prior[g].push_back(new Class_TruncatedNormal);
                MinK_Prior[g][i]->create_FullObject(UserControlledMemory);
              }
            }
          }else{
            error("Prior on MinK not well specified");
          }

        }
      }
    }

  }

  for(int g=0;g<nG;g++)
  {
    for(i=0;i<nlatentk;i++)
    {
      for(int k=0;k<MinK_Prior[g][i]->nHyperparams;k++)
      {
        MinK_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = MinK_PriorParameters[k*nlatentk+i];
        MinK_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = MinK_PriorParameters[k*nlatentk+i];
      }
    }
  }


  for(i=0;i<nG;i++)
  {
    MinK_MCMC.push_back(vector<Class_Parameter >());
    for(j=0;j<nlatentk;j++)
    {
      MinK_MCMC[i].push_back(Class_Parameter());
      appName = (("MinK_")+to_string(i)+to_string(j));
      MinK_MCMC[i][j].create_FullObject(MinK_InitParameters[i*nlatentk+j], appName,  MinK_Prior[i][j]);
    }
  }
  for(i=0;i<nG;i++)
  {
    for(j=0;j<nlatentk;j++)
    {
      MinK_MCMC[i][j].add_Pointerparameters_InVector();
    }
  }






  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/
  #pragma mark Par EtaK1

  Name                 = "EtaK1";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

  double *EtaK1_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string EtaK1_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *EtaK1_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  vector<vector<Poly_Prior* >   >               EtaK1_Prior; // uno per i k
  vector< vector <Class_Parameter > >   EtaK1_MCMC; // k/nvar/cluster
  if(EtaK1_PriorName=="Normal")
  {
    for(int g=0;g<nG;g++)
    {
      EtaK1_Prior.push_back(vector<Poly_Prior* >());
      for(i=0;i<nlatentk;i++)
      {
        EtaK1_Prior[g].push_back(new Class_Normal);
        EtaK1_Prior[g][i]->create_FullObject(UserControlledMemory);
      }
    }
  }else{

    if(EtaK1_PriorName=="NoPrior")
    {
      for(int g=0;g<nG;g++)
      {
        EtaK1_Prior.push_back(vector<Poly_Prior* >());
        for(i=0;i<nlatentk;i++)
        {
          EtaK1_Prior[g].push_back(new Class_NoPrior);
          EtaK1_Prior[g][i]->create_FullObject(UserControlledMemory);
        }
      }
    }else{
      if(EtaK1_PriorName=="Uniform")
      {
        for(int g=0;g<nG;g++)
        {
          EtaK1_Prior.push_back(vector<Poly_Prior* >());
          for(i=0;i<nlatentk;i++)
          {
            EtaK1_Prior[g].push_back(new Class_Uniform);
            EtaK1_Prior[g][i]->create_FullObject(UserControlledMemory);
          }
        }
      }else{
        if(EtaK1_PriorName=="InverseGamma")
        {
          for(int g=0;g<nG;g++)
          {
            EtaK1_Prior.push_back(vector<Poly_Prior* >());
            for(i=0;i<nlatentk;i++)
            {
              EtaK1_Prior[g].push_back(new Class_InverseGamma);
              EtaK1_Prior[g][i]->create_FullObject(UserControlledMemory);
            }
          }

        }else{
          if(EtaK1_PriorName=="TruncatedNormal")
          {
            for(int g=0;g<nG;g++)
            {
              EtaK1_Prior.push_back(vector<Poly_Prior* >());
              for(i=0;i<nlatentk;i++)
              {
                EtaK1_Prior[g].push_back(new Class_TruncatedNormal);
                EtaK1_Prior[g][i]->create_FullObject(UserControlledMemory);
              }
            }
          }else{
            error("Prior on EtaK1 not well specified");
          }

        }
      }
    }

  }

  for(int g=0;g<nG;g++)
  {
    for(i=0;i<nlatentk;i++)
    {
      for(int k=0;k<EtaK1_Prior[g][i]->nHyperparams;k++)
      {
        EtaK1_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = EtaK1_PriorParameters[k*nlatentk+i];
        EtaK1_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = EtaK1_PriorParameters[k*nlatentk+i];
      }
    }
  }


  for(i=0;i<nG;i++)
  {
    EtaK1_MCMC.push_back(vector<Class_Parameter >());
    for(j=0;j<nlatentk;j++)
    {
      EtaK1_MCMC[i].push_back(Class_Parameter());
      appName = (("EtaK1_")+to_string(i)+to_string(j));
      EtaK1_MCMC[i][j].create_FullObject(EtaK1_InitParameters[i*nlatentk+j], appName,  EtaK1_Prior[i][j]);

    }
  }
  for(i=0;i<nG;i++)
  {
    for(j=0;j<nlatentk;j++)
    {
      EtaK1_MCMC[i][j].add_Pointerparameters_InVector();
      //EtaK1_MCMC[i][j].PrintObject("Eta");
    }
  }

  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/
  #pragma mark Par EtaK2

  Name                 = "EtaK2";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

  double *EtaK2_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string EtaK2_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *EtaK2_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  vector<vector<Poly_Prior* >   >               EtaK2_Prior; // uno per i k
  vector< vector <Class_Parameter > >   EtaK2_MCMC; // k/nvar/cluster
  if(EtaK2_PriorName=="Normal")
  {
    for(int g=0;g<nG;g++)
    {
      EtaK2_Prior.push_back(vector<Poly_Prior* >());
      for(i=0;i<nlatentk;i++)
      {
        EtaK2_Prior[g].push_back(new Class_Normal);
        EtaK2_Prior[g][i]->create_FullObject(UserControlledMemory);
      }
    }
  }else{

    if(EtaK2_PriorName=="NoPrior")
    {
      for(int g=0;g<nG;g++)
      {
        EtaK2_Prior.push_back(vector<Poly_Prior* >());
        for(i=0;i<nlatentk;i++)
        {
          EtaK2_Prior[g].push_back(new Class_NoPrior);
          EtaK2_Prior[g][i]->create_FullObject(UserControlledMemory);
        }
      }
    }else{
      if(EtaK2_PriorName=="Uniform")
      {
        for(int g=0;g<nG;g++)
        {
          EtaK2_Prior.push_back(vector<Poly_Prior* >());
          for(i=0;i<nlatentk;i++)
          {
            EtaK2_Prior[g].push_back(new Class_Uniform);
            EtaK2_Prior[g][i]->create_FullObject(UserControlledMemory);
          }
        }
      }else{
        if(EtaK2_PriorName=="InverseGamma")
        {
          for(int g=0;g<nG;g++)
          {
            EtaK2_Prior.push_back(vector<Poly_Prior* >());
            for(i=0;i<nlatentk;i++)
            {
              EtaK2_Prior[g].push_back(new Class_InverseGamma);
              EtaK2_Prior[g][i]->create_FullObject(UserControlledMemory);
            }
          }
        }else{
          if(EtaK2_PriorName=="TruncatedNormal")
          {
            for(int g=0;g<nG;g++)
            {
              EtaK2_Prior.push_back(vector<Poly_Prior* >());
              for(i=0;i<nlatentk;i++)
              {
                EtaK2_Prior[g].push_back(new Class_TruncatedNormal);
                EtaK2_Prior[g][i]->create_FullObject(UserControlledMemory);
              }
            }
          }else{
            error("Prior on EtaK2 not well specified");
          }

        }
      }
    }

  }

  for(int g=0;g<nG;g++)
  {
    for(i=0;i<nlatentk;i++)
    {
      for(int k=0;k<EtaK2_Prior[g][i]->nHyperparams;k++)
      {
        EtaK2_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = EtaK2_PriorParameters[k*nlatentk+i];
        EtaK2_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = EtaK2_PriorParameters[k*nlatentk+i];
      }
    }
  }


  for(i=0;i<nG;i++)
  {
    EtaK2_MCMC.push_back(vector<Class_Parameter >());
    for(j=0;j<nlatentk;j++)
    {
      EtaK2_MCMC[i].push_back(Class_Parameter());
      appName = (("EtaK2_")+to_string(i)+to_string(j));
      EtaK2_MCMC[i][j].create_FullObject(EtaK2_InitParameters[i*nlatentk+j], appName,  EtaK2_Prior[i][j]);


    }
  }
  for(i=0;i<nG;i++)
  {
    for(j=0;j<nlatentk;j++)
    {
      EtaK2_MCMC[i][j].add_Pointerparameters_InVector();
    }
  }

  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/
  #pragma mark Par MeanK


  Name                 = "MeanK";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

  double *MeanK_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string MeanK_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *MeanK_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  vector<vector<Poly_Prior* >   >               MeanK_Prior; // uno per i k
  vector< vector <Class_Parameter > >   MeanK_MCMC; // k/nvar/cluster
  if(MeanK_PriorName=="Normal")
  {
    for(int g=0;g<nG;g++)
    {
      MeanK_Prior.push_back(vector<Poly_Prior* >());
      for(i=0;i<nlatentk;i++)
      {
        MeanK_Prior[g].push_back(new Class_Normal);
        MeanK_Prior[g][i]->create_FullObject(UserControlledMemory);
      }
    }
  }else{
//    if(RandomEffect==1)
//    {
//      error("If RandomEffect true, prior on MeanK must be normal");
//    }
    if(MeanK_PriorName=="NoPrior")
    {
      for(int g=0;g<nG;g++)
      {
        MeanK_Prior.push_back(vector<Poly_Prior* >());
        for(i=0;i<nlatentk;i++)
        {
          MeanK_Prior[g].push_back(new Class_NoPrior);
          MeanK_Prior[g][i]->create_FullObject(UserControlledMemory);
        }
      }
    }else{

      if(MeanK_PriorName=="Uniform")
      {
        for(int g=0;g<nG;g++)
        {
          MeanK_Prior.push_back(vector<Poly_Prior* >());
          for(i=0;i<nlatentk;i++)
          {
            MeanK_Prior[g].push_back(new Class_Uniform);
            MeanK_Prior[g][i]->create_FullObject(UserControlledMemory);
          }
        }
      }else{
        if(MeanK_PriorName=="InverseGamma")
        {
          for(int g=0;g<nG;g++)
          {
            MeanK_Prior.push_back(vector<Poly_Prior* >());
            for(i=0;i<nlatentk;i++)
            {
              MeanK_Prior[g].push_back(new Class_InverseGamma);
              MeanK_Prior[g][i]->create_FullObject(UserControlledMemory);
            }
          }

        }else{
          if(MeanK_PriorName=="TruncatedNormal")
          {
            for(int g=0;g<nG;g++)
            {
              MeanK_Prior.push_back(vector<Poly_Prior* >());
              for(i=0;i<nlatentk;i++)
              {
                MeanK_Prior[g].push_back(new Class_TruncatedNormal);
                MeanK_Prior[g][i]->create_FullObject(UserControlledMemory);
              }
            }
          }else{
            error("Prior on MeanK not well specified");
          }

        }
      }
    }

  }

  for(int g=0;g<nG;g++)
  {
    for(i=0;i<nlatentk;i++)
    {
      for(int k=0;k<MeanK_Prior[g][i]->nHyperparams;k++)
      {
        MeanK_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = MeanK_PriorParameters[k*nlatentk+i];
        MeanK_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = MeanK_PriorParameters[k*nlatentk+i];
      }
    }
  }


  for(i=0;i<nG;i++)
  {
    MeanK_MCMC.push_back(vector<Class_Parameter >());
    for(j=0;j<nlatentk;j++)
    {
      MeanK_MCMC[i].push_back(Class_Parameter());
      appName = (("MeanK_")+to_string(i)+to_string(j));
      MeanK_MCMC[i][j].create_FullObject(MeanK_InitParameters[i*nlatentk+j], appName,  MeanK_Prior[i][j]);

//      if(RandomEffect==1)
//      {
//        MeanK_MCMC[i][j].add_RandomHyper(&MeanKMean_MCMC[j], 0);
//        MeanK_MCMC[i][j].add_RandomHyper(&MeanKVar_MCMC[j], 0);
//      }
    }
  }
  for(i=0;i<nG;i++)
  {
    for(j=0;j<nlatentk;j++)
    {
      MeanK_MCMC[i][j].add_Pointerparameters_InVector();
    }
  }

 /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/
 #pragma mark Par VarK


 Name                 = "VarK";
 indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
 indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

 double *VarK_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
 string VarK_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
 double *VarK_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


 vector<vector<Poly_Prior* >   >               VarK_Prior; // uno per i k
 vector< vector <Class_Parameter > >   VarK_MCMC; // k/nvar/cluster
 if(VarK_PriorName=="Normal")
 {
   for(int g=0;g<nG;g++)
   {
     VarK_Prior.push_back(vector<Poly_Prior* >());
     for(i=0;i<nlatentk;i++)
     {
       VarK_Prior[g].push_back(new Class_Normal);
       VarK_Prior[g][i]->create_FullObject(UserControlledMemory);
     }
   }
 }else{
//   if(RandomEffect==1)
//   {
//     error("If RandomEffect true, prior on VarK must be normal");
//   }
   if(VarK_PriorName=="NoPrior")
   {
     for(int g=0;g<nG;g++)
     {
       VarK_Prior.push_back(vector<Poly_Prior* >());
       for(i=0;i<nlatentk;i++)
       {
         VarK_Prior[g].push_back(new Class_NoPrior);
         VarK_Prior[g][i]->create_FullObject(UserControlledMemory);
       }
     }
   }else{
     if(VarK_PriorName=="Uniform")
     {
       for(int g=0;g<nG;g++)
       {
         VarK_Prior.push_back(vector<Poly_Prior* >());
         for(i=0;i<nlatentk;i++)
         {
           VarK_Prior[g].push_back(new Class_Uniform);
           VarK_Prior[g][i]->create_FullObject(UserControlledMemory);
         }
       }
     }else{
       if(VarK_PriorName=="InverseGamma")
       {
         for(int g=0;g<nG;g++)
         {
           VarK_Prior.push_back(vector<Poly_Prior* >());
           for(i=0;i<nlatentk;i++)
           {
             VarK_Prior[g].push_back(new Class_InverseGamma);
             VarK_Prior[g][i]->create_FullObject(UserControlledMemory);
           }
         }

       }else{
         if(VarK_PriorName=="TruncatedNormal")
         {
           for(int g=0;g<nG;g++)
           {
             VarK_Prior.push_back(vector<Poly_Prior* >());
             for(i=0;i<nlatentk;i++)
             {
               VarK_Prior[g].push_back(new Class_TruncatedNormal);
               VarK_Prior[g][i]->create_FullObject(UserControlledMemory);
             }
           }
         }else{
           error("Prior on VarK not well specified");
         }

       }
     }
   }

 }

 for(int g=0;g<nG;g++)
 {
   for(i=0;i<nlatentk;i++)
   {
     for(int k=0;k<VarK_Prior[g][i]->nHyperparams;k++)
     {
       VarK_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = VarK_PriorParameters[k*nlatentk+i];
       VarK_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = VarK_PriorParameters[k*nlatentk+i];
     }
   }
 }


 for(i=0;i<nG;i++)
 {
   VarK_MCMC.push_back(vector<Class_Parameter >());
   for(j=0;j<nlatentk;j++)
   {
     VarK_MCMC[i].push_back(Class_Parameter());
     appName = (("VarK_")+to_string(i)+to_string(j));
     VarK_MCMC[i][j].create_FullObject(VarK_InitParameters[i*nlatentk+j], appName,  VarK_Prior[i][j]);

//     if(RandomEffect==1)
//     {
//       VarK_MCMC[i][j].add_RandomHyper(&VarKMean_MCMC[j], 0);
//       VarK_MCMC[i][j].add_RandomHyper(&VarKVar_MCMC[j], 0);
//     }
   }
 }
 for(i=0;i<nG;i++)
 {
   for(j=0;j<nlatentk;j++)
   {
     VarK_MCMC[i][j].add_Pointerparameters_InVector();
   }
 }


  REprintf("AA0\n");


  //vector <   vector< vector <Class_Parameter > > *  >  AllParamRandom;
  //vector <   vector <Class_Parameter >  *  >  AllParamRandomMean;
  //vector <   vector <Class_Parameter >  *  >  AllParamRandomVar;

  //AllParamRandom.push_back(&MeanK_MCMC);
  //AllParamRandom.push_back(&VarK_MCMC);
  //AllParamRandom.push_back(&EtaK1_MCMC);
  //AllParamRandom.push_back(&EtaK2_MCMC);


  vector <   vector< Class_Parameter > *>     AllBeta;

  AllBeta.push_back(&Beta0_MCMC);
  AllBeta.push_back(&Beta1_MCMC);

//  AllParamRandomMean.push_back(&MeanKMean_MCMC);
//  AllParamRandomMean.push_back(&VarKMean_MCMC);
//  AllParamRandomMean.push_back(&EtaK1Mean_MCMC);
//  AllParamRandomMean.push_back(&EtaK2Mean_MCMC);
//
//  AllParamRandomVar.push_back(&MeanKVar_MCMC);
//  AllParamRandomVar.push_back(&VarKVar_MCMC);
//  AllParamRandomVar.push_back(&EtaK1Var_MCMC);
//  AllParamRandomVar.push_back(&EtaK2Var_MCMC);

  /*****************************************
     Observations
     *****************************************/
  #pragma mark Observations
    REprintf("A1 \n");

    Matrix<double> ObsMatTot(nobsTOT,nvar,REAL(Data_r));
    vector <vector < Matrix <double> > > Obs;
    for(i=0;i<nG;i++)
    {
      Obs.push_back(vector < Matrix <double> >());
      for(j=0;j<nrep;j++)
      {
        int Ind = i*nrep*nt+j*nt;
        Obs[i].push_back(Matrix <double>(nt,nvar,ObsMatTot.Pmat(Ind,0)));
      }
    }

    Vector <int> IndexNotNA(nNotna,INTEGER(IndexNotNA_r));


  double SigmaMat_P[nG*nvar*nt];
  double SigmaMatProp_P[nG*nvar*nt];
  vector<Matrix <double> > SigmaMat;
  vector<Matrix <double> > SigmaMatProp;
  for(i=0;i<nG;i++)
  {
    SigmaMat.push_back(Matrix<double>(nt,nvar,&SigmaMat_P[i*nvar*nt]));
    SigmaMatProp.push_back(Matrix<double>(nt,nvar,&SigmaMatProp_P[i*nvar*nt]));
  }


  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/

  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/

  REprintf("AA0B1\n");
  Name                 = "Y0";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

  double *Y0_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string Y0_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
//double *Y0_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  vector<vector<Poly_Prior* > >                  Y0_Prior; // uno per i k
  vector<  vector< Class_Parameter> >    Y0_MCMC; // k/nvar/cluster

  if(Y0_PriorName=="TruncatedNormal")
  {
    for(int g=0;g<nG;g++)
    {
      Y0_Prior.push_back(vector<Poly_Prior*>());
      for(i=0;i<nvar-1;i++)
      {
        Y0_Prior[g].push_back(new Class_TruncatedNormal);
        Y0_Prior[g][i]->create_FullObject(UserControlledMemory);
      }
		 i = nvar-1;
		 Y0_Prior[g].push_back(new Class_NoPrior);
		 Y0_Prior[g][i]->create_FullObject(UserControlledMemory);

    }
  }else{
    if(Y0_PriorName=="NoPrior")
    {
      for(int g=0;g<nG;g++)
      {
        Y0_Prior.push_back(vector<Poly_Prior*>());
        for(i=0;i<nvar-1;i++)
        {
          Y0_Prior[g].push_back(new Class_NoPrior);
          Y0_Prior[g][i]->create_FullObject(UserControlledMemory);
        }
			i = nvar-1;
			Y0_Prior[g].push_back(new Class_NoPrior);
			Y0_Prior[g][i]->create_FullObject(UserControlledMemory);
      }
    }else{
      if(Y0_PriorName=="Uniform")
		{
		  for(int g=0;g<nG;g++)
		  {
			 Y0_Prior.push_back(vector<Poly_Prior*>());
			 for(i=0;i<nvar-1;i++)
			 {
				Y0_Prior[g].push_back(new Class_Uniform);
				Y0_Prior[g][i]->create_FullObject(UserControlledMemory);
			 }
			  i = nvar-1;
			  Y0_Prior[g].push_back(new Class_NoPrior);
			  Y0_Prior[g][i]->create_FullObject(UserControlledMemory);
		  }
		}else{
		  error("Prior on Y0 not well specified");
		}
    }

  }

	double MeanY0app;
  for(int g=0;g<nG;g++)
  {
    for(i=0;i<nvar-1;i++)
    {

      int k = 0;
      Y0_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = 0.0;
      Y0_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = 0.0;
      for(int j=0;j<nrep;j++)
      {
        Y0_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] += Obs[g][j].mat(0,i)/nrep;
        Y0_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  += Obs[g][j].mat(0,i)/nrep;
      }
      MeanY0app = Y0_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0];
		 if(Y0_PriorName=="TruncatedNormal")
		 {
			 k = 1;
			 Y0_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = Y0_PriorParameters[k*nvar+i];
          Y0_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = Y0_PriorParameters[k*nvar+i];

			 k = 2; //limite sinistro
			 Y0_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = max(0.0,Y0_Prior[g][i]->HyperparametersProp.Pvec(0)[0][0]+ Y0_PriorParameters[k*nvar+i]);
          Y0_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = max(0.0,Y0_Prior[g][i]->HyperparametersProp.Pvec(0)[0][0]+ Y0_PriorParameters[k*nvar+i]);

			 k = 3; //limite destro
			 Y0_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = Y0_Prior[g][i]->HyperparametersProp.Pvec(0)[0][0]+Y0_PriorParameters[k*nvar+i];
          Y0_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = Y0_Prior[g][i]->HyperparametersProp.Pvec(0)[0][0]+Y0_PriorParameters[k*nvar+i];

			 k = 4; //limite destro
			 Y0_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = 2.0;
			 Y0_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = 2.0;

		 }else{
			 if(Y0_PriorName=="NoPrior")
			 {

			 }else{
				 if(Y0_PriorName=="Uniform")
				 {
					 MeanY0app = 0.0;
					 for(int j=0;j<nrep;j++)
					 {
						MeanY0app += Obs[g][j].mat(0,i)/nrep;
					 }

					 k = 0;
					 Y0_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0] = max(0.0, MeanY0app+ Y0_PriorParameters[k*nvar+i]);
					 Y0_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0]=max(0.0,MeanY0app+ Y0_PriorParameters[k*nvar+i]);

					 k = 1;
					 Y0_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0] = MeanY0app+ Y0_PriorParameters[k*nvar+i];
					 Y0_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = MeanY0app+ Y0_PriorParameters[k*nvar+i];



				 }else{
					  error("Prior Y0 wrong");
				 }
			 }
		 }
//      if(Y0_PriorName!="NoPrior")
//      {
//        for(k=1;k<Y0_Prior[g][i]->nHyperparams;k++)
//        {
//          Y0_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = Y0_PriorParameters[k*nvar+i];
//          Y0_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = Y0_PriorParameters[k*nvar+i];
//        }
//      }


      //Y0_Prior[g][i]->PrintObject("Yo");
    }
  }
  //error("");


  for(i=0;i<nG;i++)
  {
    Y0_MCMC.push_back(vector<Class_Parameter> ());
    for(j=0;j<nvar-1;j++)
    {
      Y0_MCMC[i].push_back(Class_Parameter());
      appName = (("Y0_")+to_string(i)+to_string(j));
		 double MeanY0app = 0.0;
		 for(int jjj=0;jjj<nrep;jjj++)
		 {
			MeanY0app += Obs[i][jjj].mat(0,j)/nrep;
		 }
      Y0_MCMC[i][j].create_FullObject(MeanY0app, appName,  Y0_Prior[i][j]);
    }
	  j = nvar-1;
	  Y0_MCMC[i].push_back(Class_Parameter());
	  appName = (("Y0_")+to_string(i)+to_string(j));
	  Y0_MCMC[i][j].create_FullObject(5.0, appName,  Y0_Prior[i][j]);
  }
   for(i=0;i<nG;i++)
   {
     for(j=0;j<nvar;j++)
     {
       Y0_MCMC[i][j].add_Pointerparameters_InVector();
       //Y0_MCMC[i][j].PrintObject("Y");
     }
   }
  //error("AA\n");

  /*****************************************
   Latent ODE
   *****************************************/
#pragma mark Latent ODE
  REprintf("A0 \n");


  //LimSpike
  // function k
  vector< vector < Function_K_T2 > > vecFK;
  for(int g=0;g<nG;g++)
  {
    vecFK.push_back(vector < Function_K_T2 >());
    for(i=0;i<nlatentk;i++)
    {
		 if(Spike==0)
		 {
			 vecFK[g].push_back(Function_K_T2(&VarK_MCMC[g][i], &MinK_MCMC[g][i], &MeanK_MCMC[g][i], &EtaK1_MCMC[g][i],&EtaK2_MCMC[g][i],0));
		 }else{
			 vecFK[g].push_back(Function_K_T2(&VarK_MCMC[g][i], &MinK_MCMC[g][i], &MeanK_MCMC[g][i], &EtaK1_MCMC[g][i],&EtaK2_MCMC[g][i],2+(TypeK-1),LimSpike));
		 }

    }
  }





  vector < vector<ODE_FURLAN_T2> > LatentODE;
  for(int g=0;g<nG;g++)
  {
    LatentODE.push_back(vector<ODE_FURLAN_T2>());
    int j = 0;
    LatentODE[g].push_back(ODE_FURLAN_T2(nt,nvar,&vecFK[g], tmin, tmax, deltat, nstep,&Y0_MCMC[g], abs_err, rel_err));
    for(j=1;j<nrep;j++)
    {
      LatentODE[g].push_back(ODE_FURLAN_T2(nt,nvar,&vecFK[g], tmin, tmax, deltat, nstep,&Y0_MCMC[g], &LatentODE[g][0], abs_err, rel_err));
    }
  }

  for(int g=0;g<nG;g++)
  {
    int j = 0;
    LatentODE[g][j].ODE_compute_V3();
    //REprintf("%i \n",g);
    //LatentODE[g][j].ODEMAT.Print("Ode");

  }
  //Class_Utils::WriteMatrix("TEST","DD.R", &LatentODE[0][0].ODEMAT );
  //error("StopGene");


  /*****************************************
   ADAPT par
   *****************************************/
 #pragma mark AdaptPar

  /*****************************************
   Adapt Param Like
   *****************************************/
  string NameAdapt;

  REprintf("A2 \n");
  int indexSd;

	Name                      = "General";
	indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
	double *SdGeneral           = REAL(VECTOR_ELT(Sd_r, indexSd));

  Name                      = "Y0";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdY0           = REAL(VECTOR_ELT(Sd_r, indexSd));

  Name                      = "MinK";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdMinK           = REAL(VECTOR_ELT(Sd_r, indexSd));

  Name                      = "MeanK";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdMeanK          = REAL(VECTOR_ELT(Sd_r, indexSd));

  Name                      = "VarK";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdVarK           = REAL(VECTOR_ELT(Sd_r, indexSd));

  Name                      = "EtaK1";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdEtaK1          = REAL(VECTOR_ELT(Sd_r, indexSd));

  Name                      = "EtaK2";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdEtaK2           = REAL(VECTOR_ELT(Sd_r, indexSd));


  Name                      = "Beta1";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdBeta1           = REAL(VECTOR_ELT(Sd_r, indexSd));

  Name                      = "Beta0";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdBeta0           = REAL(VECTOR_ELT(Sd_r, indexSd));

	Name                      = "SF";
	indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
	double *SdSF           = REAL(VECTOR_ELT(Sd_r, indexSd));






	vector<Poly_Adapt* >        AdaptSH;
	for(int k=0;k<3;k++)
	{
		AdaptSH.push_back(new Class_AdaptHaario());
		appName = ("SH")+to_string(k);
		AdaptSH[k]->add_name(appName);
		for(i=0;i<nNotna;i++)
		{
			AdaptSH[k]->add_parameters(&SF_MCMC[k][i]);
		}
		AdaptSH[k]->add_finalizedConstruct_OnlyOneSd(AdaptEps, SdSF, AdaptLambda, 1, &AdaptParameters);
		AdaptSH[k]->CheckMultiUpdate();
	}

//
//	for(i=0;i<nvar;i++)
//	{
//		isdBeta = 0;
//		AdaptBeta.push_back(new Class_AdaptHaario());
//		appName = ("beta")+to_string(i);
//		AdaptBeta[i]->add_name(appName);
//		addsdBeta = AdaptBeta[i]->add_parameters(&Beta0_MCMC[i]);
//		if(addsdBeta==1)
//		{
//			SDvecBeta[isdBeta] = SdBeta0[0];
//			isdBeta++;
//		}
//		addsdBeta = AdaptBeta[i]->add_parameters(&Beta1_MCMC[i]);
//		if(addsdBeta==1)
//		{
//			SDvecBeta[isdBeta] = SdBeta1[0];
//			isdBeta++;
//		}
//		AdaptBeta[i]->add_finalizedConstruct(AdaptEps, SDvecBeta, AdaptLambda , 1, &AdaptParameters);
//		AdaptBeta[i]->CheckMultiUpdate();
//	}



  int addsdBeta;
  int isdBeta;
  double SDvecBeta[50];
  vector<Poly_Adapt* >        AdaptBeta;

  for(i=0;i<nvar;i++)
  {
    isdBeta = 0;
    AdaptBeta.push_back(new Class_AdaptHaario());
    appName = ("beta")+to_string(i);
    AdaptBeta[i]->add_name(appName);
    addsdBeta = AdaptBeta[i]->add_parameters(&Beta0_MCMC[i]);
    if(addsdBeta==1)
    {
      SDvecBeta[isdBeta] = SdBeta0[0];
      isdBeta++;
    }
    addsdBeta = AdaptBeta[i]->add_parameters(&Beta1_MCMC[i]);
    if(addsdBeta==1)
    {
      SDvecBeta[isdBeta] = SdBeta1[0];
      isdBeta++;
    }
    AdaptBeta[i]->add_finalizedConstruct(AdaptEps, SDvecBeta, AdaptLambda , 1, &AdaptParameters);
    AdaptBeta[i]->CheckMultiUpdate();
  }



  int addsd;
  int isd;
  double SDvec[50];
  vector< Poly_Adapt* >        AdaptLikeAllParam;
  for(i=0;i<nG;i++)
  {
    isd = 0;
    AdaptLikeAllParam.push_back(new Class_AdaptHaario());
    appName = ("AllPAram")+to_string(i);
    AdaptLikeAllParam[i]->add_name(appName);


    for(j=0;j<nlatentk;j++)
    {
      addsd = AdaptLikeAllParam[i]->add_parameters(&MinK_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdMinK[0];
        isd++;
      }
      addsd = AdaptLikeAllParam[i]->add_parameters(&MeanK_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdMeanK[0];
        isd++;
      }
      addsd = AdaptLikeAllParam[i]->add_parameters(&VarK_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdVarK[0];
        isd++;
      }
      addsd = AdaptLikeAllParam[i]->add_parameters(&EtaK1_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdEtaK1[0];
        isd++;
      }
      addsd = AdaptLikeAllParam[i]->add_parameters(&EtaK2_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdEtaK2[0];
        isd++;
      }

    }
    for(int h=0;h<nvar;h++)
    {
      addsd = AdaptLikeAllParam[i]->add_parameters(&Y0_MCMC[i][h]);
      if(addsd==1)
      {
        SDvec[isd] = SdY0[0];
        isd++;
      }
    }
    AdaptLikeAllParam[i]->add_finalizedConstruct(AdaptEps, SDvec, AdaptLambda , 1, &AdaptParameters);
    AdaptLikeAllParam[i]->CheckMultiUpdate();
  }



  /*****************/




  vector<vector< Poly_Adapt* > >       AdaptkDivisi;
  for(i=0;i<nG;i++)
  {

    AdaptkDivisi.push_back(vector< Poly_Adapt* >());


    for(j=0;j<nlatentk;j++)
    {
      isd = 0;
      AdaptkDivisi[i].push_back(new Class_AdaptHaario());
      appName = ("AdaptkDivisi")+to_string(i)+to_string(j);
      AdaptkDivisi[i][j]->add_name(appName);

      addsd = AdaptkDivisi[i][j]->add_parameters(&MinK_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdMinK[0];
        isd++;
      }
      addsd = AdaptkDivisi[i][j]->add_parameters(&MeanK_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdMeanK[0];
        isd++;
      }
      addsd = AdaptkDivisi[i][j]->add_parameters(&VarK_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdVarK[0];
        isd++;
      }
      addsd = AdaptkDivisi[i][j]->add_parameters(&EtaK1_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdEtaK1[0];
        isd++;
      }
      addsd = AdaptkDivisi[i][j]->add_parameters(&EtaK2_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdEtaK2[0];
        isd++;
      }
      AdaptkDivisi[i][j]->add_finalizedConstruct(AdaptEps, SDvec, AdaptLambda , 1, &AdaptParameters);
      AdaptkDivisi[i][j]->CheckMultiUpdate();
    }



    isd = 0;
    AdaptkDivisi[i].push_back(new Class_AdaptHaario());
    appName = ("AdaptkDivisi")+to_string(i)+to_string(nlatentk);
    AdaptkDivisi[i][nlatentk]->add_name(appName);
    for(int h=0;h<nvar;h++)
    {
      addsd = AdaptkDivisi[i][nlatentk]->add_parameters(&Y0_MCMC[i][h]);
      if(addsd==1)
      {
        SDvec[isd] = SdY0[0];
        isd++;
      }
    }
    AdaptkDivisi[i][nlatentk]->add_finalizedConstruct(AdaptEps, SDvec, AdaptLambda , 1, &AdaptParameters);
    AdaptkDivisi[i][nlatentk]->CheckMultiUpdate();
  }
  /*****************************************
    MIXTURE MODEL
    *****************************************/
#pragma mark MIXTURE MODEL
	REprintf("Randm1\n");
	int nc;
	int DimC_P[15];
	Vector<int>DimC(1,&DimC_P[0]);
   if(ClustType==0)
   {
		nc = 1;
		DimC.nElem = nc;
		DimC.Pvec(0)[0] = 5;
	}else{
		if(ClustType==1)
		{
			nc = 2;
			DimC.nElem = nc;
			DimC.Pvec(0)[0] = 4;
			DimC.Pvec(1)[0] = 1;
		}else{
		  error("ClustType wrong");
		}
	}


  #pragma mark Sigma
	/** Sigma **/
	Name                   = "sigmaMat";
	indexPriorParameters   =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
	indexInit              =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

	double *Sigma_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
	string Sigma_PriorName         = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
	double *Sigma_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));

	vector< vector< Matrix<double> > >                                 Psi;
	vector< vector< Poly_PriorPDmatrix*  > >                           Sigma_Prior;
	vector< vector< vector <Matrix<double> >  > >                      SIGMA;
	vector< vector< vector<Class_Parameter_PDMatrixUnivSamp >   > >    SigmaMCMC;

	//SIGMA[i][j].push_back(Matrix<double>(DimC.vec(j),DimC.vec(j), &Sigma_InitParameters[k*nvars*nvars]));
//	double PsiApp_P[5*5*3];
//	int Hs;
//	for(i=0;i<nlatentk;i++)
//	{
//		Hs = 0;
//		Psi.push_back(vector<Matrix<double> >());
//		for(int k=0;k<nc;k++)
//		{
//			Psi[i].push_back(Matrix<double>(DimC.vec(k),DimC.vec(k),&PsiApp_P[i*(5*5)+Hs*Hs]));
//			Psi[i][k].Init(0.0);
//			for(int g=0;g<DimC.vec(k);g++)
//			{
//				Psi[i][k].Pmat(g,g)[0] = Sigma_PriorParameters[3+i*(5*5)+(g+Hs)*5+(g+Hs)];
//			}
//			Hs += DimC.vec(k);
//		}
//	}
	REprintf("Randm2\n");


	for(i=0;i<nlatentk;i++)
	{
		Sigma_Prior.push_back(vector< Poly_PriorPDmatrix*  > ());
		for(int k=0;k<nc;k++)
		{
			Sigma_Prior[i].push_back(new Class_InverseWishart);
			Sigma_Prior[i][k]->create_FullObject(UserControlledMemory, DimC.vec(k));
			if(Sigma_PriorName=="InverseWishart")
			{

			}else{
				 error("Prior for CoregSigma not well specified");
			}

			Sigma_Prior[i][k]->PsiAcc[0].Init(0.0);
			Sigma_Prior[i][k]->PsiProp[0].Init(0.0);
			int sumS = 0;
			for(int i2=0;i2<DimC.vec(k);i2++)
			{
				//REprintf("%i %i %f \n",i2,sumS+i2,Sigma_PriorParameters[3+(sumS+i2)*5+(sumS+i2)]);
//				 Sigma_Prior[i][k]->PsiAcc[0].Pmat(i,i)[0]     = Psi[i][k].mat(i,i);
//				 Sigma_Prior[i][k]->PsiProp[0].Pmat(i,i)[0]    = Psi[i][k].mat(i,i);
				Sigma_Prior[i][k]->PsiAcc[0].Pmat(i2,i2)[0]     = Sigma_PriorParameters[3+(sumS+i2)*5+(sumS+i2)];
				Sigma_Prior[i][k]->PsiProp[0].Pmat(i2,i2)[0]    = Sigma_PriorParameters[3+(sumS+i2)*5+(sumS+i2)];

			}
			sumS += DimC.vec(k);
			Sigma_Prior[i][k]->nuAcc[0]      = round(Sigma_PriorParameters[i]);
			Sigma_Prior[i][k]->nuProp[0]     = round(Sigma_PriorParameters[i]);
			if(Sigma_PriorParameters[i]<0)
			{
				Sigma_Prior[i][k]->nuAcc[0]      = 0.0;
				Sigma_Prior[i][k]->nuProp[0]     = 0.0;
			}
			//Sigma_Prior[i][k]->PsiAcc[0].Print("s");
		}
	}
	double Sigma_InitP[5*5];
   for(i=0;i<nlatentk;i++)
	{
		SigmaMCMC.push_back(vector< vector<Class_Parameter_PDMatrixUnivSamp >   > ());
		for(int j=0;j<nc;j++)
		{
			Matrix <double>SigmaIn(DimC.vec(j),DimC.vec(j),&Sigma_InitP[0]);
			SigmaIn.Init(0.0);
			for(int tt=0;tt<DimC.vec(j);tt++)
			{
				SigmaIn.Pmat(tt,tt)[0] = runif(0.01,1.5);
			}
			SigmaMCMC[i].push_back(vector<Class_Parameter_PDMatrixUnivSamp >());

			for(int k=0;k<Kmax;k++)
			{
				 SigmaMCMC[i][j].push_back(Class_Parameter_PDMatrixUnivSamp());

				 SigmaMCMC[i][j][k].create_FullObjectNoCompanion(&SigmaIn, "SigmaCoreg", Sigma_Prior[i][j], UserControlledMemory);
			}
		}
	}
	for(i=0;i<nlatentk;i++)
	{
		for(int j=0;j<nc;j++)
		{
			for(int k=0;k<Kmax;k++)
			{
				 SigmaMCMC[i][j][k].add_Pointerparameters_InVector();
				 SigmaMCMC[i][j][k].compute_InvAccAndChol();
				//SigmaMCMC[i][j][k].PriorParameter->PsiAcc->Print("Psi");

			}
		}
	}


   REprintf("Randm3\n");

   #pragma mark Beta
   /** Beta **/
	double Covariates_P[nG*5*5*nc*nlatentk];
	vector<vector<Matrix<double> >  > Covariates;//(nobs*nvars, ncovs,REAL(covariates_r));
	for(int ik=0;ik<nlatentk;ik++)
	{
		Covariates.push_back(vector<Matrix<double> >());
		for(int j=0;j<nc;j++)
		{
			Covariates[ik].push_back( Matrix<double>(nG*DimC.vec(j),DimC.vec(j),&Covariates_P[ ik*(nc*nG*5*5)+j* nG*5*5]));
			Covariates[ik][j].Init(0.0);
			for(int g=0;g<nG;g++)
			{
				for(int g1=0;g1<DimC.vec(j);g1++)
				{
					Covariates[ik][j].Pmat(g*DimC.vec(j)+g1,g1)[0] = 1.0;
				}
			}
			//Covariates[j].Print("Cov");
		}
	}


	Name                 = "RegCoef";
	indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
	indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

	double *RegCoef_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
	string RegCoef_PriorName         = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
	double *RegCoef_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


   vector<vector<vector<Poly_Prior*  >  > >                     Beta_Prior;
   vector<vector<vector<vector<Class_Parameter > >   > >        BetaMCMC;
   vector<vector<vector<VectorParameters> > >     BetaVecMCMC;


	for(i=0;i<nlatentk;i++)
	{
		Beta_Prior.push_back(vector<vector<Poly_Prior*  >  >());
		int j = 0;
		Beta_Prior[i].push_back(vector<Poly_Prior*  > ());
		for(int h=0;h<Covariates[i][j].nCols;h++)
		{
			Beta_Prior[i][j].push_back(new Class_Normal);
			Beta_Prior[i][j][h]->create_FullObject(UserControlledMemory);
			for(int k=0;k<Beta_Prior[i][j][h]->nHyperparams;k++)
			{
				//Beta_Prior[i][j][h]->HyperparametersProp.Pvec(k)[0][0] = RegCoef_PriorParameters[k*3+i];
				//Beta_Prior[i][j][h]->HyperparametersAcc.Pvec(k)[0][0]  = RegCoef_PriorParameters[k*3+i];

				Beta_Prior[i][j][h]->HyperparametersProp.Pvec(k)[0][0] = RegCoef_PriorParameters[k*5+h];
				Beta_Prior[i][j][h]->HyperparametersAcc.Pvec(k)[0][0]  = RegCoef_PriorParameters[k*5+h];
			}

		}
		j = 1;
		Beta_Prior[i].push_back(vector<Poly_Prior*  > ());
		for(int h=0;h<Covariates[i][j].nCols;h++)
		{
			Beta_Prior[i][j].push_back(new Class_Normal);
			Beta_Prior[i][j][h]->create_FullObject(UserControlledMemory);
			for(int k=0;k<Beta_Prior[i][j][h]->nHyperparams;k++)
			{
				//Beta_Prior[i][j][h]->HyperparametersProp.Pvec(k)[0][0] = RegCoef_PriorParameters[k*3+i];
				//Beta_Prior[i][j][h]->HyperparametersAcc.Pvec(k)[0][0]  = RegCoef_PriorParameters[k*3+i];

				Beta_Prior[i][j][h]->HyperparametersProp.Pvec(k)[0][0] = RegCoef_PriorParameters[k*5+4+h];
				Beta_Prior[i][j][h]->HyperparametersAcc.Pvec(k)[0][0]  = RegCoef_PriorParameters[k*5+4+h];
			}

		}

//		for(int j=0;j<nc;j++)
//		{
//			Beta_Prior[i].push_back(vector<Poly_Prior*  > ());
//			for(int h=0;h<Covariates[i][j].nCols;h++)
//			{
//				Beta_Prior[i][j].push_back(new Class_Normal);
//				Beta_Prior[i][j][h]->create_FullObject(UserControlledMemory);
//				for(int k=0;k<Beta_Prior[i][j][h]->nHyperparams;k++)
//				{
//					//Beta_Prior[i][j][h]->HyperparametersProp.Pvec(k)[0][0] = RegCoef_PriorParameters[k*3+i];
//					//Beta_Prior[i][j][h]->HyperparametersAcc.Pvec(k)[0][0]  = RegCoef_PriorParameters[k*3+i];
//
//					Beta_Prior[i][j][h]->HyperparametersProp.Pvec(k)[0][0] = RegCoef_PriorParameters[k*5+h];
//					Beta_Prior[i][j][h]->HyperparametersAcc.Pvec(k)[0][0]  = RegCoef_PriorParameters[k*5+h];
//				}
//
//			}
//		}
	}
	for(i=0;i<nlatentk;i++)
	{
		BetaMCMC.push_back(vector<vector<vector<Class_Parameter > >   >  ());
		for(int j=0;j<nc;j++)
		{
			BetaMCMC[i].push_back(vector<vector<Class_Parameter > >  ());
			for(int k=0;k<Kmax;k++)
			{
				BetaMCMC[i][j].push_back(vector<Class_Parameter >  ());
				for(int h=0;h<Covariates[i][j].nCols;h++)
				{
					appName = ("BetaMCMC_");
					BetaMCMC[i][j][k].push_back(Class_Parameter());
					BetaMCMC[i][j][k][h].create_FullObject(RegCoef_InitParameters[k*5+h], appName,  Beta_Prior[i][j][h]);
				}
			}

		}
	}
	for(i=0;i<nlatentk;i++)
	{
		for(int j=0;j<nc;j++)
		{
			for(int k=0;k<Kmax;k++)
			{
				for(int h=0;h<Covariates[i][j].nCols;h++)
				{
					BetaMCMC[i][j][k][h].add_Pointerparameters_InVector();
				}
			}
		}
	}
	REprintf("Randm4\n");
	for(i=0;i<nlatentk;i++)
	{
		BetaVecMCMC.push_back(vector<vector<VectorParameters> >());
		for(int j=0;j<nc;j++)
		{
			BetaVecMCMC[i].push_back(vector<VectorParameters>());
			for(int k=0;k<Kmax;k++)
			{
				appName = (Name+"Vector_");
				BetaVecMCMC[i][j].push_back(VectorParameters());
				BetaVecMCMC[i][j][k].create_FullObject(Covariates[i][j].nCols, appName, &BetaMCMC[i][j][k],&Beta_Prior[i][j],  UserControlledMemory);
			}
		}
	}



  /*****************************************
   DP parameters
   *****************************************/
  REprintf("V");
  #pragma mark DPpar


  REprintf("Randm5\n");

  /************ eta ************/
  Name   = "DPpar";

  indexPriorParameters    =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit               =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);


  double *DPpar_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string DPpar_PriorName         = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *DPpar_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  Poly_Prior                      *DPpar_Prior   = 0;
  vector< vector<Class_Parameter > >      DPparMCMC;

  if(DPpar_PriorName=="Gamma")
  {
      DPpar_Prior    = new Class_Gamma;
  }else{
      error("Prior on DPpar not well specified");
  }
  DPpar_Prior->create_FullObject(UserControlledMemory);
  for(i=0;i<DPpar_Prior->nHyperparams;i++)
  {
      DPpar_Prior->HyperparametersProp.Pvec(i)[0][0] = DPpar_PriorParameters[i];
      DPpar_Prior->HyperparametersAcc.Pvec(i)[0][0]  = DPpar_PriorParameters[i];
  }

  for(i=0;i<nlatentk;i++)
  {

    DPparMCMC.push_back(vector<Class_Parameter >());
    for(int k=0;k<nc;k++)
    {
      DPparMCMC[i].push_back(Class_Parameter());
      appName = (("DPpar_")+to_string(k));
      DPparMCMC[i][k].create_FullObject(DPpar_InitParameters[i*nc+k], appName,  DPpar_Prior);
    }
  }


  for(i=0;i<nlatentk;i++)
  {
      for(int k=0;k<nc;k++)
      {
          DPparMCMC[i][k].add_Pointerparameters_InVector();
			 //DPparMCMC[i][k].PrintObject("DPpar");
      }
  }
REprintf("Randm6\n");
//  for(i=0;i<nlatentk;i++)
//  {
//      for(int k=0;k<nc;k++)
//      {
//			 DPparMCMC[i][k].PrintObject("DPpar");
//      }
//  }
  /*****************************************
   Prob Vectors
   *****************************************/
  Rprintf("B\n");
  #pragma mark DEF xi
  Name   = "piMat";

  indexInit               =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);


  double *pi_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));

  vector<vector<vector<Poly_Prior*>  > >      pi_Prior;
  vector<vector<vector<Class_Parameter> > >  piMCMC;
  vector<vector<VectorParameters> >          piVecMCMC;

  for(i=0;i<nlatentk;i++)
  {
    pi_Prior.push_back(vector<vector<Poly_Prior*> >());
    for(int k=0;k<nc;k++)
    {
      pi_Prior[i].push_back(vector<Poly_Prior*>());
      pi_Prior[i][k].push_back(new Class_DirichletProcess);
      pi_Prior[i][k][0]->create_FullObject(UserControlledMemory);
    }
  }
  for(i=0;i<nlatentk;i++)
  {
    for(int k=0;k<nc;k++)
    {
      pi_Prior[i][k][0]->HyperparametersProp.Pvec(0)[0][0] = DPparMCMC[i][k].ParameterAcc;
      pi_Prior[i][k][0]->HyperparametersAcc.Pvec(0)[0][0]  = DPparMCMC[i][k].ParameterAcc;
    }
  }

  int IncOp;
  IncOp = 0;
  for(i=0;i<nlatentk;i++)
  {
    piMCMC.push_back(vector<vector<Class_Parameter> >());
    for(int h=0;h<nc;h++)
    {
      piMCMC[i].push_back(vector<Class_Parameter>());
      for(int k=0;k<Kmax;k++)
      {

        appName = (("piMCMC_")+to_string(i)+to_string(h)+to_string(k));
        piMCMC[i][h].push_back(Class_Parameter());
        piMCMC[i][h][k].create_FullObject(pi_InitParameters[IncOp], appName,  pi_Prior[i][h][0]);
        IncOp++;
      }
    }
  }
  for(i=0;i<nlatentk;i++)
  {
    for(int h=0;h<nc;h++)
    {
      for(int k=0;k<Kmax;k++)
      {
        piMCMC[i][h][k].add_Pointerparameters_InVector();
      }
    }
  }
REprintf("Randm8\n");
  appName = (Name+"Vector_");
  for(i=0;i<nlatentk;i++)
  {
    piVecMCMC.push_back(vector<VectorParameters>());
    for(int h=0;h<nc;h++)
    {
      piVecMCMC[i].push_back(VectorParameters());
      piVecMCMC[i][h].create_FullObject(Kmax, appName, &piMCMC[i][h],&pi_Prior[i][h],  UserControlledMemory);
    }
  }
  for(i=0;i<nlatentk;i++)
  {
    for(int h=0;h<nc;h++)
    {
      piVecMCMC[i][h].add_RandomHyper(&DPparMCMC[i][h], 0, 0);;
    }
  }

  /*****************************************
   The clustering
   *****************************************/

  #pragma mark Clustering Object
REprintf("Randm9\n");
  Name   = "stMat";
  indexInit               =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);
  double *st_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


	int st_P[nG*nc*nlatentk];
  vector<vector< Vector <int> > > st;
  for(i=0;i<nlatentk;i++)
  {
    st.push_back(vector< Vector <int> >());
    for(int h=0;h<nc;h++)
    {
       st[i].push_back(Vector <int>(nG,&st_P[(i*nc+h)*nG]));
    }
  }

  IncOp = 0;
  for(i=0;i<nlatentk;i++)
  {
    for(int h=0;h<nc;h++)
    {
      for(int g=0;g<nG;g++)
      {
        st[i][h].Pvec(g)[0] = (int)round(st_InitParameters[IncOp])-1;
        IncOp++;
      }
    }
  }

  vector<vector< MixtureDP > >    MixtureDPModel;
  for(i=0;i<nlatentk;i++)
  {
    MixtureDPModel.push_back(vector< MixtureDP >());
    for(int h=0;h<nc;h++)
    {
      MixtureDPModel[i].push_back(MixtureDP());
      MixtureDPModel[i][h].create_FullObject(Kmax, UserControlledMemory,&piVecMCMC[i][h]);
    }
  }


  // e poi si crea la clusterizzazione
  vector<vector<ClusterIndex_V2> > Clustering;
  for(i=0;i<nlatentk;i++)
  {
    Clustering.push_back(vector< ClusterIndex_V2 >());
    for(int h=0;h<nc;h++)
    {
      Clustering[i].push_back(ClusterIndex_V2());
      Clustering[i][h].create_FullObject(&MixtureDPModel[i][h], &st[i][h], UserControlledMemory);
    }
  }

  /*****************************************
   Likelihood object
   *****************************************/
  //REprintf("Randm10\n");

  #pragma mark Likelihood Object
	vector< vector<Poly_Density*>  >   LikelihoodDensity;
	for(i=0;i<nlatentk;i++)
	{
	  LikelihoodDensity.push_back(vector<Poly_Density*>());
	  for(int h=0;h<nc;h++)
	  {
		  LikelihoodDensity[i].push_back(new Class_MultivariateNormal);
		  LikelihoodDensity[i][h]->create_FullObject(DimC.vec(h));
	  }
	}

	double OBS_P[nG*5*nc*nlatentk];
	vector< vector<Matrix <double> > > OBS;
	vector< vector<Class_Mixture_V3> >    MixModel;
	for(i=0;i<nlatentk;i++)
	{
	  OBS.push_back(vector<Matrix <double> >());
	  for(int h=0;h<nc;h++)
	  {
		  OBS[i].push_back(Matrix <double> (nG,DimC.vec(h),&OBS_P[nG*5*(i*nc+h)]));
	  }
	}


	int App_P[10];
	Vector<int> IndexNA(0,&App_P[0]);
	vector<Vector <int> > NAposTOT;
	NAposTOT.push_back(Vector<int>(0,&App_P[1]));

	int NAposTOTlongRev_P[5*nG*nc];
	vector <  vector<Vector <int> > > NAposTOTlongRev;
	for(int h=0;h<nc;h++)
	{
		NAposTOTlongRev.push_back(vector<Vector <int> >());
		for(int g=0;g<nG;g++)
		{
			NAposTOTlongRev[h].push_back(Vector <int>(DimC.vec(h),&NAposTOTlongRev_P[h*nG*5+g*5]));
		}
	}

	for(i=0;i<nlatentk;i++)
	{
		MixModel.push_back(vector<Class_Mixture_V3>());
		for(int h=0;h<nc;h++)
		{
			MixModel[i].push_back(Class_Mixture_V3());
			MixModel[i][h].create_fullObject( &OBS[i][h], &Clustering[i][h], LikelihoodDensity[i][h], UserControlledMemory);
			MixModel[i][h].add_RegCoefVarmat(&BetaVecMCMC[i][h],&SigmaMCMC[i][h],&Covariates[i][h]);
			MixModel[i][h].add_MissinObject(&NAposTOT, &NAposTOTlongRev[h],&IndexNA);
			//MixModel[i][h].set_SampParGIBBS_MultiNormal();
			MixModel[i][h].set_SampFromPrior_MultiNormal_NIW();
			MixModel[i][h].set_ComputeDensityPrior_MultiNormal_NIW();
			MixModel[i][h].set_SampParGIBBS_MultiNormal_OnlyOcc();
		}
	}


  /*****************************************
   FROM C++ to R
   *****************************************/
#pragma mark FROM C++ to R
  //REprintf("A4 \n");

  int nProtect = 0;




  SEXP MinK_out_r;
  PROTECT(MinK_out_r    = allocMatrix(REALSXP, nG*nlatentk, nSamples_save)); nProtect++;
  double *MinK_out_P    = REAL(MinK_out_r);

  SEXP VarK_out_r;
  PROTECT(VarK_out_r    = allocMatrix(REALSXP, nG*nlatentk, nSamples_save)); nProtect++;
  double *VarK_out_P    = REAL(VarK_out_r);

  SEXP MeanK_out_r;
  PROTECT(MeanK_out_r    = allocMatrix(REALSXP, nG*nlatentk, nSamples_save)); nProtect++;
  double *MeanK_out_P    = REAL(MeanK_out_r);

  SEXP EtaK1_out_r;
  PROTECT(EtaK1_out_r    = allocMatrix(REALSXP, nG*nlatentk, nSamples_save)); nProtect++;
  double *EtaK1_out_P    = REAL(EtaK1_out_r);

  SEXP EtaK2_out_r;
  PROTECT(EtaK2_out_r    = allocMatrix(REALSXP, nG*nlatentk, nSamples_save)); nProtect++;
  double *EtaK2_out_P    = REAL(EtaK2_out_r);


  SEXP Beta1_out_r;
  PROTECT(Beta1_out_r    = allocMatrix(REALSXP, nvar, nSamples_save)); nProtect++;
  double *Beta1_out_P    = REAL(Beta1_out_r);

  SEXP Beta0_out_r;
  PROTECT(Beta0_out_r    = allocMatrix(REALSXP, nvar, nSamples_save)); nProtect++;
  double *Beta0_out_P    = REAL(Beta0_out_r);

  SEXP Y0_out_r;
  PROTECT(Y0_out_r    = allocMatrix(REALSXP, nG*nvar, nSamples_save)); nProtect++;
  double *Y0_out_P    = REAL(Y0_out_r);



  int nY = 0;
  if(saveODE==1)
  {
    nY  = nG*nNotna*nvar;
  }else{
    nY = 2;
  }
  SEXP Y_out_r;
  PROTECT(Y_out_r    = allocMatrix(REALSXP, nY, nSamples_save)); nProtect++;
  double *Y_out_P    = REAL(Y_out_r);



	SEXP DPpar_out_r;
	PROTECT(DPpar_out_r    = allocMatrix(REALSXP, nc*3, nSamples_save)); nProtect++;
	double *DPpar_out_P    = REAL(DPpar_out_r);

	int dd;
	// k1 primo clust

	dd = 1;
	SEXP Sigma_32_out_r;
	PROTECT(Sigma_32_out_r    = allocMatrix(REALSXP, dd*dd*Kmax, nSamples_save)); nProtect++;
	double *Sigma_32_out_P    = REAL(Sigma_32_out_r);

	SEXP Beta_32_out_r;
	PROTECT(Beta_32_out_r    = allocMatrix(REALSXP, dd*Kmax, nSamples_save)); nProtect++;
	double *Beta_32_out_P    = REAL(Beta_32_out_r);

	SEXP pi_32_out_r;
	PROTECT(pi_32_out_r    = allocMatrix(REALSXP, Kmax, nSamples_save)); nProtect++;
	double *pi_32_out_P    = REAL(pi_32_out_r);

	SEXP st_32_out_r;
	PROTECT(st_32_out_r    = allocMatrix(INTSXP, nG, nSamples_save)); nProtect++;
	int *st_32_out_P    = INTEGER(st_32_out_r);


	SEXP Sigma_22_out_r;
	PROTECT(Sigma_22_out_r    = allocMatrix(REALSXP, dd*dd*Kmax, nSamples_save)); nProtect++;
	double *Sigma_22_out_P    = REAL(Sigma_22_out_r);

	SEXP Beta_22_out_r;
	PROTECT(Beta_22_out_r    = allocMatrix(REALSXP, dd*Kmax, nSamples_save)); nProtect++;
	double *Beta_22_out_P    = REAL(Beta_22_out_r);

	SEXP pi_22_out_r;
	PROTECT(pi_22_out_r    = allocMatrix(REALSXP, Kmax, nSamples_save)); nProtect++;
	double *pi_22_out_P    = REAL(pi_22_out_r);

	SEXP st_22_out_r;
	PROTECT(st_22_out_r     = allocMatrix(INTSXP, nG, nSamples_save)); nProtect++;
	int *st_22_out_P        = INTEGER(st_22_out_r);

	SEXP Sigma_12_out_r;
	PROTECT(Sigma_12_out_r    = allocMatrix(REALSXP, dd*dd*Kmax, nSamples_save)); nProtect++;
	double *Sigma_12_out_P    = REAL(Sigma_12_out_r);

	SEXP Beta_12_out_r;
	PROTECT(Beta_12_out_r    = allocMatrix(REALSXP, dd*Kmax, nSamples_save)); nProtect++;
	double *Beta_12_out_P    = REAL(Beta_12_out_r);

	SEXP pi_12_out_r;
	PROTECT(pi_12_out_r    = allocMatrix(REALSXP, Kmax, nSamples_save)); nProtect++;
	double *pi_12_out_P    = REAL(pi_12_out_r);

	SEXP st_12_out_r;
	PROTECT(st_12_out_r    = allocMatrix(INTSXP, nG, nSamples_save)); nProtect++;
	int *st_12_out_P    = INTEGER(st_12_out_r);


	dd = 4;
	SEXP Sigma_31_out_r;
	PROTECT(Sigma_31_out_r    = allocMatrix(REALSXP, dd*dd*Kmax, nSamples_save)); nProtect++;
	double *Sigma_31_out_P    = REAL(Sigma_31_out_r);

	SEXP Beta_31_out_r;
	PROTECT(Beta_31_out_r    = allocMatrix(REALSXP, dd*Kmax, nSamples_save)); nProtect++;
	double *Beta_31_out_P    = REAL(Beta_31_out_r);

	SEXP pi_31_out_r;
	PROTECT(pi_31_out_r    = allocMatrix(REALSXP, Kmax, nSamples_save)); nProtect++;
	double *pi_31_out_P    = REAL(pi_31_out_r);

	SEXP st_31_out_r;
	PROTECT(st_31_out_r    = allocMatrix(INTSXP, nG, nSamples_save)); nProtect++;
	int *st_31_out_P    = INTEGER(st_31_out_r);


	SEXP Sigma_21_out_r;
	PROTECT(Sigma_21_out_r    = allocMatrix(REALSXP, dd*dd*Kmax, nSamples_save)); nProtect++;
	double *Sigma_21_out_P    = REAL(Sigma_21_out_r);

	SEXP Beta_21_out_r;
	PROTECT(Beta_21_out_r    = allocMatrix(REALSXP, dd*Kmax, nSamples_save)); nProtect++;
	double *Beta_21_out_P    = REAL(Beta_21_out_r);

	SEXP pi_21_out_r;
	PROTECT(pi_21_out_r    = allocMatrix(REALSXP, Kmax, nSamples_save)); nProtect++;
	double *pi_21_out_P    = REAL(pi_21_out_r);

	SEXP st_21_out_r;
	PROTECT(st_21_out_r    = allocMatrix(INTSXP, nG, nSamples_save)); nProtect++;
	int *st_21_out_P    = INTEGER(st_21_out_r);

	SEXP Sigma_11_out_r;
	PROTECT(Sigma_11_out_r    = allocMatrix(REALSXP, dd*dd*Kmax, nSamples_save)); nProtect++;
	double *Sigma_11_out_P    = REAL(Sigma_11_out_r);

	SEXP Beta_11_out_r;
	PROTECT(Beta_11_out_r    = allocMatrix(REALSXP, dd*Kmax, nSamples_save)); nProtect++;
	double *Beta_11_out_P    = REAL(Beta_11_out_r);

	SEXP pi_11_out_r;
	PROTECT(pi_11_out_r    = allocMatrix(REALSXP, Kmax, nSamples_save)); nProtect++;
	double *pi_11_out_P    = REAL(pi_11_out_r);

	SEXP st_11_out_r;
	PROTECT(st_11_out_r    = allocMatrix(INTSXP, nG, nSamples_save)); nProtect++;
	int *st_11_out_P    = INTEGER(st_11_out_r);



	SEXP SF_1_out_r;
	PROTECT(SF_1_out_r    = allocMatrix(REALSXP, 11, nSamples_save)); nProtect++;
	double *SF_1_out_P    = REAL(SF_1_out_r);
	SEXP SF_2_out_r;
	PROTECT(SF_2_out_r    = allocMatrix(REALSXP, 11, nSamples_save)); nProtect++;
	double *SF_2_out_P    = REAL(SF_2_out_r);
	SEXP SF_3_out_r;
	PROTECT(SF_3_out_r    = allocMatrix(REALSXP, 11, nSamples_save)); nProtect++;
	double *SF_3_out_P    = REAL(SF_3_out_r);



  /*****************************************
  MCMC UPDATES
  *****************************************/
	
	
	
#pragma mark MCMCupdates





  /****************** ComputeSigma ***********************/
  class MCMCupdates_ComputeSigmaMat
  {
  public:
      virtual void ComputeWitBetaAcc(Matrix<double> &ODE,vector <   vector< Class_Parameter > *>  &Betapar, Matrix<double> *SigmaAcc ,Vector <int> *NonNA, int ivar , int iter)
      {
          error("MCMCupdates_sigma2");
      }
    virtual void ComputeWitBetaProp(Matrix<double> &ODE,vector <   vector< Class_Parameter > *>  &Betapar, Matrix<double> *SigmaAcc,Vector <int> *NonNA, int ivar  , int iter)
    {
        error("MCMCupdates_sigma2");
    }

  };

  class MCMCupdates_ComputeSigmaMat_Type1: public MCMCupdates_ComputeSigmaMat
  {
  public:
      void ComputeWitBetaAcc(Matrix<double> &ODE,vector <   vector< Class_Parameter > *>  &Betapar, Matrix<double> *Sigma ,Vector <int> *NonNA, int ivar ,int iter) override
      {
        int nNotna = NonNA->nElem;

        for(int t1=0;t1<nNotna;t1++)
        {
          int i = NonNA[0].vec(t1);
          Sigma[0].Pmat(i,ivar)[0] = exp(Betapar[0][0][ivar].ParameterAcc+ Betapar[1][0][ivar].ParameterAcc*log(ODE.mat(i,ivar)));
        }
      }
    void ComputeWitBetaProp(Matrix<double> &ODE,vector <   vector< Class_Parameter > *>  &Betapar, Matrix<double> *Sigma,Vector <int> *NonNA , int ivar ,int iter) override
    {
      int nNotna = NonNA->nElem;

      for(int t1=0;t1<nNotna;t1++)
      {
        int i = NonNA[0].vec(t1);
        Sigma[0].Pmat(i,ivar)[0] = exp(Betapar[0][0][ivar].ParameterProp+ Betapar[1][0][ivar].ParameterProp*log(ODE.mat(i,ivar)));
      }
    }
  };


  /****************** SIGMA2 ***********************/
  class MCMCupdates_sigma2
  {
  public:
      virtual void sample(
		vector< vector< Class_Parameter > >         *SF,
       MCMCupdates_ComputeSigmaMat *SigmaCompute,
       vector<Poly_Adapt* > *Adapt,
       vector <   vector< Class_Parameter > *>  *Betapar,
      vector< Matrix<double> >*SigmaAcc,
       vector<Matrix<double> > *SigmaProp,
       vector<vector <Matrix <double> > > *Y ,
       vector < vector<ODE_FURLAN_T2> >  *LatODE ,
       Vector <int> *NonNA  ,
       int iter,  double moltsf
       )
      {
          error("MCMCupdates_sigma2");
      }

  };
  class MCMCupdates_sigma2_NoUpdate: public MCMCupdates_sigma2
  {
  public:
      void sample(
		vector< vector< Class_Parameter > >         *SF,
       MCMCupdates_ComputeSigmaMat *SigmaCompute,
       vector<Poly_Adapt* > *Adapt,
       vector <   vector< Class_Parameter > *>  *Betapar,
      vector< Matrix<double> >*SigmaAcc,
       vector<Matrix<double> > *SigmaProp,
       vector<vector <Matrix <double> > > *Y ,
       vector < vector<ODE_FURLAN_T2> >  *LatODE ,
       Vector <int> *NonNA  ,
       int iter,  double moltsf
       )override
      {

      }
  };
  class MCMCupdates_sigma2_Type1: public MCMCupdates_sigma2
  {
  public:
      void sample(
						vector< vector< Class_Parameter > >         *SF,
                  MCMCupdates_ComputeSigmaMat *SigmaCompute,
                  vector<Poly_Adapt* > *Adapt,
                  vector <   vector< Class_Parameter > *>  *Betapar,
                 vector< Matrix<double> >*SigmaAcc,
                  vector<Matrix<double> > *SigmaProp,
                  vector<vector <Matrix <double> > > *Y ,
                  vector < vector<ODE_FURLAN_T2> >  *LatODE ,
                  Vector <int> *NonNA  ,
                  int iter, double moltsf
                  ) override
      {
        int nvar   = (int)Y[0][0][0].nCols;
        int nG     = (int)Y[0].size();
        int nrep   = (int)Y[0][0].size();
        int nNotna = NonNA->nElem;

			

        for(int i=0;i<nvar;i++)
        {

          Adapt[0][i]->Samp();

          double MH = Adapt[0][i]->get_logDensityParameterWithLogJacobian_DiffPropAcc();
          //REprintf("%f ",MH);
          for(int g=0;g<nG;g++)
          {
            SigmaCompute->ComputeWitBetaProp(LatODE[0][g][0].ODEMAT, Betapar[0], &SigmaProp[0][g], NonNA,i,iter);

            for(int j=0;j<nrep;j++)
            {
              for(int t1=0;t1<nNotna;t1++)
              {
                int t = NonNA[0].vec(t1);

					  if(i!=2)
					  {
						  MH +=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), LatODE[0][g][j].ODEMAT.mat(t,i), sqrt(SigmaProp[0][g].mat(t,i)), 0.0);
						  MH -=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), LatODE[0][g][j].ODEMAT.mat(t,i), sqrt(SigmaAcc[0][g].mat(t,i)), 0.0);
					  }else{

						  MH +=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), SF[0][j][t1].ParameterAcc*LatODE[0][g][j].ODEMAT.mat(t,i)/moltsf, sqrt(SigmaProp[0][g].mat(t,i)), 0.0);
						  MH -=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), SF[0][j][t1].ParameterAcc*LatODE[0][g][j].ODEMAT.mat(t,i)/moltsf, sqrt(SigmaAcc[0][g].mat(t,i)), 0.0);
					  }

              }
            }

          }

          //SF[0][j][t].ParameterAcc

          double alphaRatio = min(1.0,exp(MH));
          if(runif(0.0,1.0)<alphaRatio)
          {
            Adapt[0][i]->UpdateIfAccepted();
            for(int g=0;g<nG;g++)
            {
              for(int t1=0;t1<nNotna;t1++)
              {
                int t = NonNA[0].vec(t1);
                SigmaAcc[0][g].Pmat(t,i)[0] = SigmaProp[0][g].Pmat(t,i)[0];
              }
            }
          }
          Adapt[0][i]->PostSamp(alphaRatio);
        }
      }
  };


	/****************** SH ***********************/
	class MCMCupdates_SF
	{
	public:
		 virtual void sample(
		 vector< vector< Class_Parameter > >         *SF,
		  MCMCupdates_ComputeSigmaMat *SigmaCompute,
		  vector<Poly_Adapt* > *Adapt,
		  vector <   vector< Class_Parameter > *>  *Betapar,
		 vector< Matrix<double> >*SigmaAcc,
		  vector<Matrix<double> > *SigmaProp,
		  vector<vector <Matrix <double> > > *Y ,
		  vector < vector<ODE_FURLAN_T2> >  *LatODE ,
		  Vector <int> *NonNA  ,
		  int iter,  double moltsf
		  )
		 {
			  error("MCMCupdates_sigma2");
		 }

	};
	class MCMCupdates_SF_NoUpdate: public MCMCupdates_SF
	{
	public:
		 void sample(
		 vector< vector< Class_Parameter > >         *SF,
		  MCMCupdates_ComputeSigmaMat *SigmaCompute,
		  vector<Poly_Adapt* > *Adapt,
		  vector <   vector< Class_Parameter > *>  *Betapar,
		 vector< Matrix<double> >*SigmaAcc,
		  vector<Matrix<double> > *SigmaProp,
		  vector<vector <Matrix <double> > > *Y ,
		  vector < vector<ODE_FURLAN_T2> >  *LatODE ,
		  Vector <int> *NonNA  ,
		  int iter, double moltsf
		  )override
		 {

		 }
	};
	class MCMCupdates_SF_Type1: public MCMCupdates_SF
	{
	public:
		 void sample(
						 vector< vector< Class_Parameter > >         *SF,
						 MCMCupdates_ComputeSigmaMat *SigmaCompute,
						 vector<Poly_Adapt* > *Adapt,
						 vector <   vector< Class_Parameter > *>  *Betapar,
						vector< Matrix<double> >*SigmaAcc,
						 vector<Matrix<double> > *SigmaProp,
						 vector<vector <Matrix <double> > > *Y ,
						 vector < vector<ODE_FURLAN_T2> >  *LatODE ,
						 Vector <int> *NonNA  ,
						 int iter, double moltsf
						 ) override
		 {
			int nvar   = (int)Y[0][0][0].nCols;
			int nG     = (int)Y[0].size();
			int nrep   = (int)Y[0][0].size();
			int nNotna = NonNA->nElem;

			 int i = 2;

			 for(int j=0;j<nrep;j++)
			 {
				 Adapt[0][j]->Samp();
				 double MH = Adapt[0][j]->get_logDensityParameterWithLogJacobian_DiffPropAcc();
				 for(int g=0;g<nG;g++)
				 {
					 for(int t1=0;t1<nNotna;t1++)
					 {
						int t = NonNA[0].vec(t1);

						 MH +=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), SF[0][j][t1].ParameterProp*LatODE[0][g][j].ODEMAT.mat(t,i)/moltsf, sqrt(SigmaAcc[0][g].mat(t,i)), 0.0);
						 MH -=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), SF[0][j][t1].ParameterAcc*LatODE[0][g][j].ODEMAT.mat(t,i)/moltsf, sqrt(SigmaAcc[0][g].mat(t,i)), 0.0);
					 }
				 }
				// REprintf("%f\n", MH);
				// Adapt[0][j]->PrintObject("Pre");
				 
				 // REprintf("SFpar\n");
				 // for(int t1=0;t1<nNotna;t1++)
				 //{
				// 	 REprintf("%f %f \n",SF[0][j][t1].ParameterAcc,SF[0][j][t1].ParameterProp);
				 // }
				 // REprintf("%f %f \n",MH,Adapt[0][j]->AcceptedRatio);
					 
				 double alphaRatio = min(1.0,exp(MH));
				 if(runif(0.0,1.0)<alphaRatio)
				 {
					 // REprintf("Acc\n");
					Adapt[0][j]->UpdateIfAccepted();
				 }
	
				 //Adapt[0][j]->PrintObject("Prost");
				 Adapt[0][j]->PostSamp(alphaRatio);
			 }
		 }
	};

  /****************** ODEPAR ***********************/
  class MCMCupdates_OdeParameters
  {
  public:
      virtual void sample(
								  vector< vector< Class_Parameter > >         *SF,
								  vector< vector<Class_Mixture_V3> >    *MixModel,
								  vector< vector< Poly_Adapt*  > > *AdaptDivisi,
                          MCMCupdates_ComputeSigmaMat *SigmaCompute,
                           vector <   vector< Class_Parameter > *>  *Betapar,
                          vector< Matrix<double> >*SigmaAcc,
                           vector<Matrix<double> > *SigmaProp,
                          vector<vector <Matrix <double> > > *Y ,vector < vector<ODE_FURLAN_T2> >  *LatODE ,Vector <int> *NonNA , vector< Poly_Adapt* > *Adapt , int iter,  int IterStartRandom, int addStartRandom, double LimC, double ExpMolt, double ExpLambda, double moltsf)
      {
          error("MCMCupdates_Ode");
      }

  };
  class MCMCupdates_OdeParameters_NoUpdate: public MCMCupdates_OdeParameters
  {
  public:
      void sample(vector< vector< Class_Parameter > >         *SF,
						vector< vector<Class_Mixture_V3> >    *MixModel,
						vector< vector< Poly_Adapt*  > > *AdaptDivisi,
                  MCMCupdates_ComputeSigmaMat *SigmaCompute,
                   vector <   vector< Class_Parameter > *>  *Betapar,
                  vector< Matrix<double> >*SigmaAcc,
                   vector<Matrix<double> > *SigmaProp,
                  vector<vector <Matrix <double> > > *Y ,vector < vector<ODE_FURLAN_T2> >  *LatODE ,Vector <int> *NonNA , vector< Poly_Adapt* > *Adapt  ,int iter,  int IterStartRandom, int addStartRandom, double LimC, double ExpMolt, double ExpLambda, double moltsf) override
      {

      }
  };
  class MCMCupdates_OdeParameters_Adapt_Type1: public MCMCupdates_OdeParameters
  {
  public:
      void sample(
						vector< vector< Class_Parameter > >         *SF,
						vector< vector<Class_Mixture_V3> >    *MixModel,
						vector< vector< Poly_Adapt*  > > *AdaptDivisi,
                  MCMCupdates_ComputeSigmaMat *SigmaCompute,
                   vector <   vector< Class_Parameter > *>  *Betapar,
                  vector< Matrix<double> >*SigmaAcc,
                   vector<Matrix<double> > *SigmaProp,
                  vector <vector < Matrix <double> > > *Y ,vector < vector<ODE_FURLAN_T2> >  *LatODE ,Vector <int> *NonNA , vector< Poly_Adapt* > *Adapt  ,int iter,  int IterStartRandom, int addStartRandom, double LimC, double ExpMolt, double ExpLambda, double moltsf) override
      {

        int nvar   = (int)Y[0][0][0].nCols;
        int nG     = (int)Y[0].size();
        int nrep   = (int)Y[0][0].size();
        int nNotna = NonNA->nElem;

        int OUTVEC[nG];
			int DoAlpha;
		  #pragma omp parallel default (none) shared(Adapt,OUTVEC,LatODE,SigmaCompute,Betapar,SigmaProp,NonNA,iter,nvar,nG)
		  {
			  #pragma omp for
			  for(int g=0;g<nG;g++)
			  {
				  int j = 0;
				  Adapt[0][g]->Samp();
				  OUTVEC[g] = LatODE[0][g][j].ODE_compute_V3_Prop();

				  for(int i=0;i<nvar;i++)
				  {
					 SigmaCompute->ComputeWitBetaAcc(LatODE[0][g][0].ODEMATProp, Betapar[0], &SigmaProp[0][g], NonNA,i,iter);
				  }
			  }
		  }

        for(int g=0;g<nG;g++)
        {
			  DoAlpha = 0;
			  double MH = 0.0;

			  //int OutOfBound = 0;
			  if(iter>=(IterStartRandom+addStartRandom))
			  {
				 MH = Adapt[0][g]->get_LogJacobian_DiffPropAcc();
				  for(int kf=0;kf<3;kf++)
				  {
					  for(int ic=0;ic<2;ic++)
					  {
						  int k       = MixModel[0][kf][ic].Clusters[0].Zeta.vec(g);
						  Matrix<double> *Sinv   = &MixModel[0][kf][ic].Container[k].PDmat[0].SigmaAccInv;
						  //Matrix<double> *Cov    = &MixModel[0][kf][ic].Container[k].Cov[0];
						  Vector<double> *Mean  = &MixModel[0][kf][ic].Container[k].VectorCont[0].VectorAcc;
						  double logdet          = MixModel[0][kf][ic].Container[k].PDmat[0].logdetAcc;

						  double ObsAcc_P[Sinv->nRows];
						  Vector <double> ObsAcc(Sinv->nRows,ObsAcc_P);

						  double ObsProp_P[Sinv->nRows];
						  Vector <double> ObsProp(Sinv->nRows,ObsProp_P);

						  if(ic==0)
						  {
							  ObsProp.Pvec(0)[0] = LatODE[0][g][0].FuncsParams[0][kf].EtaK1->ParameterProp;
							  ObsProp.Pvec(1)[0] = LatODE[0][g][0].FuncsParams[0][kf].EtaK2->ParameterProp;
							  ObsProp.Pvec(2)[0] = LatODE[0][g][0].FuncsParams[0][kf].VarK->ParameterProp;
							  ObsProp.Pvec(3)[0] = LatODE[0][g][0].FuncsParams[0][kf].MeanK->ParameterProp;

							  ObsAcc.Pvec(0)[0] = LatODE[0][g][0].FuncsParams[0][kf].EtaK1->ParameterAcc;
							  ObsAcc.Pvec(1)[0] = LatODE[0][g][0].FuncsParams[0][kf].EtaK2->ParameterAcc;
							  ObsAcc.Pvec(2)[0] = LatODE[0][g][0].FuncsParams[0][kf].VarK->ParameterAcc;
							  ObsAcc.Pvec(3)[0] = LatODE[0][g][0].FuncsParams[0][kf].MeanK->ParameterAcc;
							  //4-2*1*(-log(0.1))^0.5

							  double mu  = LatODE[0][g][0].FuncsParams[0][kf].MeanK->ParameterProp;
							  double var = LatODE[0][g][0].FuncsParams[0][kf].VarK->ParameterProp;
							  double eta1  = LatODE[0][g][0].FuncsParams[0][kf].EtaK1->ParameterProp;
							  double eta2 = LatODE[0][g][0].FuncsParams[0][kf].EtaK2->ParameterProp;

							  double LimEta = LatODE[0][g][0].FuncsParams[0][kf].LimEta;
							  if((eta1>(-1.0*LimEta) )&& (eta1<LimEta))
							  {
								  eta1 = 0.0;
							  }else{
								  if(eta1>=LimEta)
								  {
									  eta1 = eta1-LimEta;
								  }else{
									  eta1 = eta1+LimEta;
								  }
							  }
							  if((eta2>(-1.0*LimEta) )&& (eta2<LimEta))
							  {
								  eta2 = 0.0;
							  }else{
								  if(eta2>=LimEta)
								  {
									  eta2 = eta2-LimEta;
								  }else{
									  eta2 = eta2+LimEta;
								  }
							  }
							  double molt0 = 1.0;
							  double molt16 = 1.0;
							  if((eta1*eta2)<= 0.0)
							  {
								  if((eta1==0.0)&&(eta2==0.0))
								  {
									  molt0 = 0.0;
									  molt16 = 0.0;
								  }else{
									  molt0 = fabs( eta1/(eta1-eta2)   );
									  molt16 = fabs( eta2/(eta1-eta2)   );
								  }
							  }


							  if(var <= 0.0)
							  {
								  DoAlpha = 1;
							  }
							  if((mu-molt0*pow(-2.0*log(LimC)*var,0.5) )<0.0)
							  {
								  //MH += log(ExpMolt)-ExpLambda*(-1.0*(mu-pow(-2.0*log(LimC)*var,0.5) ));
								  DoAlpha = 1;

							  }else{
								  if((mu+molt16*pow(-2.0*log(LimC)*var,0.5) )>16.0)
								  {
									  //MH += log(ExpMolt)-ExpLambda*((mu+pow(-2.0*log(LimC)*var,0.5) )-16);
									  DoAlpha = 1;
								  }

							  }


							  mu  = LatODE[0][g][0].FuncsParams[0][kf].MeanK->ParameterAcc;
							  var = LatODE[0][g][0].FuncsParams[0][kf].VarK->ParameterAcc;
//							  if((mu-pow(-2.0*log(LimC)*var,0.5) )<0)
//							  {
//								  MH -= log(ExpMolt)-ExpLambda*(-1.0*(mu-pow(-2.0*log(LimC)*var,0.5) ));
//							  }else{
//								  if((mu+pow(-2.0*log(LimC)*var,0.5) )>16)
//								  {
//									  MH -= log(ExpMolt)-ExpLambda*((mu+pow(-2.0*log(LimC)*var,0.5) )-16);
//								  }
//							  }


						  }
						  if(ic==1)
						  {
							  double minK = LatODE[0][g][0].FuncsParams[0][kf].MinK->ParameterProp;
							  ObsProp.Pvec(0)[0] = fabs( LatODE[0][g][0].FuncsParams[0][kf].MinK->ParameterProp);

							  ObsAcc.Pvec(0)[0] = fabs(LatODE[0][g][0].FuncsParams[0][kf].MinK->ParameterAcc) ;
							  if(minK  <= 0.0)
							  {
								  DoAlpha = 1;
							  }
						  }
						  MH += Class_MultivariateNormal::Class_MultivariateNormal::external_compute_LogDensity_forCovMat( Sinv->nRows, &ObsProp,Mean, Sinv, &logdet);
						  MH -= Class_MultivariateNormal::Class_MultivariateNormal::external_compute_LogDensity_forCovMat( Sinv->nRows, &ObsAcc,Mean, Sinv, &logdet);
					  }
				  }
			  }else{

				  for(int kf=0;kf<3;kf++)
				  {
					  double mu  = LatODE[0][g][0].FuncsParams[0][kf].MeanK->ParameterProp;
					  double var = LatODE[0][g][0].FuncsParams[0][kf].VarK->ParameterProp;
					  double minK = LatODE[0][g][0].FuncsParams[0][kf].MinK->ParameterProp;
					  double eta1  = LatODE[0][g][0].FuncsParams[0][kf].EtaK1->ParameterProp;
					  double eta2 = LatODE[0][g][0].FuncsParams[0][kf].EtaK2->ParameterProp;
					  double molt0 = 1.0;
					  double molt16 = 1.0;
					  double LimEta = LatODE[0][g][0].FuncsParams[0][kf].LimEta;
					  if((eta1>(-1.0*LimEta) )&& (eta1<LimEta))
					  {
						  eta1 = 0.0;
					  }else{
						  if(eta1>=LimEta)
						  {
							  eta1 = eta1-LimEta;
						  }else{
							  eta1 = eta1+LimEta;
						  }
					  }
					  if((eta2>(-1.0*LimEta) )&& (eta2<LimEta))
					  {
						  eta2 = 0.0;
					  }else{
						  if(eta2>=LimEta)
						  {
							  eta2 = eta2-LimEta;
						  }else{
							  eta2 = eta2+LimEta;
						  }
					  }
					  if((eta1*eta2)<= 0.0)
					  {
						  if((eta1==0.0)&&(eta2==0.0))
						  {
							  molt0 = 0.0;
							  molt16 = 0.0;
						  }else{
							  molt0 = fabs( eta1/(eta1-eta2)   );
							  molt16 = fabs( eta2/(eta1-eta2)   );
						  }
					  }

					  if(var <= 0.0)
					  {
						  DoAlpha = 1;
					  }
					  if(minK <= 0.0)
					  {
						  DoAlpha = 1;
					  }


					  if((mu-molt0*pow(-2.0*log(LimC)*var,0.5) )<0.0)
					  {
						  //MH += log(ExpMolt)-ExpLambda*(-1.0*(mu-pow(-2.0*log(LimC)*var,0.5) ));
						  DoAlpha = 1;
						  //REprintf("Less");
					  }else{
						  if((mu+molt16*pow(-2.0*log(LimC)*var,0.5) )>16.0)
						  {
							  //MH += log(ExpMolt)-ExpLambda*((mu+pow(-2.0*log(LimC)*var,0.5) )-16);
							  DoAlpha = 1;
							 // REprintf("Great");
						  }
					  }




				  }

				  MH += Adapt[0][g]->get_logDensityParameterWithLogJacobian_DiffPropAcc();
			  }





          int j = 0;
          int OUT = OUTVEC[g];



          for(j=0;j<nrep;j++)
          {
            for(int t1=0;t1<nNotna;t1++)
            {
              int t = NonNA[0].vec(t1);

              for(int i=0;i<nvar;i++)
              {
					  if(i!=2)
					  {
						  MH +=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), LatODE[0][g][j].ODEMATProp.mat(t,i), sqrt(SigmaProp[0][g].mat(t,i)), 0.0);
						  MH -=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), LatODE[0][g][j].ODEMAT.mat(t,i), sqrt(SigmaAcc[0][g].mat(t,i)), 0.0);
					  }else{
						  MH +=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), SF[0][j][t1].ParameterAcc*LatODE[0][g][j].ODEMATProp.mat(t,i)/moltsf, sqrt(SigmaProp[0][g].mat(t,i)), 0.0);
						  MH -=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), SF[0][j][t1].ParameterAcc*LatODE[0][g][j].ODEMAT.mat(t,i)/moltsf, sqrt(SigmaAcc[0][g].mat(t,i)), 0.0);

					  }

              }
            }
          }





			  //
          double alphaRatio = min(1.0,exp(MH));

          if(OUT!=0)
          {
            alphaRatio = 0.0;
          }
			  if( DoAlpha==1)
			  {
				  alphaRatio = 0.0;
			  }

//			  if(OutOfBound!=0)
//			  {
//				  alphaRatio = 0.0;
//			  }
          if(runif(0.0,1.0)<alphaRatio)
          {
            //REprintf("ACC \n");
            Adapt[0][g]->UpdateIfAccepted();
            j = 0;
            LatODE[0][g][j].copyFromODEMATPropToAcc();
            for(int i=0;i<nvar;i++)
            {
              for(int t1=0;t1<nNotna;t1++)
              {
                int t = NonNA[0].vec(t1);
                SigmaAcc[0][g].Pmat(t,i)[0] = SigmaProp[0][g].Pmat(t,i)[0];
              }
            }
          }
          Adapt[0][g]->PostSamp(alphaRatio);

        }
      }
  };


	class MCMCupdates_OdeParameters_Adapt_Type1_Rparam: public MCMCupdates_OdeParameters
  {
  public:
		void sample(
						vector< vector< Class_Parameter > >         *SF,
						vector< vector<Class_Mixture_V3> >    *MixModel,
						vector< vector< Poly_Adapt*  > > *AdaptDivisi,
						MCMCupdates_ComputeSigmaMat *SigmaCompute,
						 vector <   vector< Class_Parameter > *>  *Betapar,
						vector< Matrix<double> >*SigmaAcc,
						 vector<Matrix<double> > *SigmaProp,
						vector <vector < Matrix <double> > > *Y ,vector < vector<ODE_FURLAN_T2> >  *LatODE ,Vector <int> *NonNA , vector< Poly_Adapt* > *Adapt  ,int iter,  int IterStartRandom, int addStartRandom, double LimC, double ExpMolt, double ExpLambda, double moltsf) override
		{
			error("Not Tested - Calcolo LIm mu-sigma sbagliato");
//		  int nvar   = (int)Y[0][0][0].nCols;
//		  int nG     = (int)Y[0].size();
//		  int nrep   = (int)Y[0][0].size();
//		  int nNotna = NonNA->nElem;
//
//			int OUTVEC[nG];
//			#pragma omp parallel default (none) shared(Adapt,OUTVEC,LatODE,SigmaCompute, Betapar,SigmaProp,NonNA,iter,nvar,nG)
//			{
//				#pragma omp for
//				for(int g=0;g<nG;g++)
//				{
//					int j = 0;
//					Adapt[0][g]->Samp();
//					OUTVEC[g] = LatODE[0][g][j].ODE_compute_V3_Prop();
//
//					for(int i=0;i<nvar;i++)
//					{
//					  SigmaCompute->ComputeWitBetaAcc(LatODE[0][g][0].ODEMATProp, Betapar[0], &SigmaProp[0][g], NonNA,i,iter);
//					}
//				}
//			}
//
//
//
//		  for(int g=0;g<nG;g++)
//		  {
//
//			  double MH = 0.0;
//			  //int OutOfBound = 0;
//			  if(iter>=(IterStartRandom))
//			  {
//				  for(int kf=0;kf<3;kf++)
//				  {
//					  for(int ic=0;ic<2;ic++)
//					  {
//						  int k       = MixModel[0][kf][ic].Clusters[0].Zeta.vec(g);
//						  Matrix<double> *Sinv   = &MixModel[0][kf][ic].Container[k].PDmat[0].SigmaAccInv;
//						  //Matrix<double> *Cov    = &MixModel[0][kf][ic].Container[k].Cov[0];
//						  Vector<double> *Mean  = &MixModel[0][kf][ic].Container[k].VectorCont[0].VectorAcc;
//						  double logdet          = MixModel[0][kf][ic].Container[k].PDmat[0].logdetAcc;
//
//						  double ObsAcc_P[Sinv->nRows];
//						  Vector <double> ObsAcc(Sinv->nRows,ObsAcc_P);
//
//						  double ObsProp_P[Sinv->nRows];
//						  Vector <double> ObsProp(Sinv->nRows,ObsProp_P);
//
//						  if(ic==0)
//						  {
//							  ObsProp.Pvec(0)[0] = LatODE[0][g][0].FuncsParams[0][kf].EtaK1->ParameterProp;
//							  ObsProp.Pvec(1)[0] = LatODE[0][g][0].FuncsParams[0][kf].EtaK2->ParameterProp;
//							  ObsProp.Pvec(2)[0] = log(LatODE[0][g][0].FuncsParams[0][kf].VarK->ParameterProp);
//							  ObsProp.Pvec(3)[0] = log(LatODE[0][g][0].FuncsParams[0][kf].MeanK->ParameterProp);
//
//							  ObsAcc.Pvec(0)[0] = LatODE[0][g][0].FuncsParams[0][kf].EtaK1->ParameterAcc;
//							  ObsAcc.Pvec(1)[0] = LatODE[0][g][0].FuncsParams[0][kf].EtaK2->ParameterAcc;
//							  ObsAcc.Pvec(2)[0] = log(LatODE[0][g][0].FuncsParams[0][kf].VarK->ParameterAcc);
//							  ObsAcc.Pvec(3)[0] = log(LatODE[0][g][0].FuncsParams[0][kf].MeanK->ParameterAcc);
//
//							  double mu  = LatODE[0][g][0].FuncsParams[0][kf].MeanK->ParameterProp;
//							  double var = LatODE[0][g][0].FuncsParams[0][kf].VarK->ParameterProp;
//							  if((mu-2.0*var*pow(-1.0*log(LimC),0.5) )<0)
//							  {
//								  MH += log(ExpMolt)-ExpLambda*(-1.0*(mu-2.0*var*pow(-1.0*log(LimC),0.5) ));
//							  }
//							  if((mu+2.0*var*pow(-1.0*log(LimC),0.5) )>16)
//							  {
//								  MH += log(ExpMolt)-ExpLambda*((mu+2.0*var*pow(-1.0*log(LimC),0.5) )-16);
//							  }
//
//							  mu  = LatODE[0][g][0].FuncsParams[0][kf].MeanK->ParameterAcc;
//							  var = LatODE[0][g][0].FuncsParams[0][kf].VarK->ParameterAcc;
//							  if((mu-2.0*var*pow(-1.0*log(LimC),0.5) )<0)
//							  {
//								  MH -= log(ExpMolt)-ExpLambda*(-1.0*(mu-2.0*var*pow(-1.0*log(LimC),0.5) ));
//							  }
//							  if((mu+2.0*var*pow(-1.0*log(LimC),0.5) )>16)
//							  {
//								  MH -= log(ExpMolt)-ExpLambda*((mu+2.0*var*pow(-1.0*log(LimC),0.5) )-16);
//							  }
//
//						  }
//						  if(ic==1)
//						  {
//							  ObsProp.Pvec(0)[0] = log(LatODE[0][g][0].FuncsParams[0][kf].MinK->ParameterProp);
//
//							  ObsAcc.Pvec(0)[0] = log(LatODE[0][g][0].FuncsParams[0][kf].MinK->ParameterAcc);
//						  }
//						  MH += Class_MultivariateNormal::external_compute_LogDensity_forCovMat( Sinv->nRows, &ObsProp,Mean, Sinv, &logdet);
//						  MH -= Class_MultivariateNormal::external_compute_LogDensity_forCovMat( Sinv->nRows, &ObsAcc,Mean, Sinv, &logdet);
//
//
//
//					  }
//				  }
//			  }else{
//				  for(int kf=0;kf<3;kf++)
//				  {
//					  for(int ic=0;ic<2;ic++)
//					  {
//						  double mu;
//						  double sd;
//						  double obsAcc;
//						  double obsProp;
//						  Class_Parameter *Par;
//
//						  if(ic==0)
//						  {
//							  Par      = LatODE[0][g][0].FuncsParams[0][kf].EtaK1;
//							  mu       = Par->PriorParameter->HyperparametersAcc.vec(0)[0];
//							  sd       = pow(Par->PriorParameter->HyperparametersAcc.vec(1)[0], 0.5);
//							  obsAcc   = Par->ParameterAcc;
//							  obsProp  = Par->ParameterProp;
//							  MH       += dnorm(obsProp,mu,sd,1)-dnorm(obsAcc,mu,sd,1);
//
//							  Par      = LatODE[0][g][0].FuncsParams[0][kf].EtaK2;
//							  mu       = Par->PriorParameter->HyperparametersAcc.vec(0)[0];
//							  sd       = pow(Par->PriorParameter->HyperparametersAcc.vec(1)[0], 0.5);
//							  obsAcc   = Par->ParameterAcc;
//							  obsProp  = Par->ParameterProp;
//							  MH += dnorm(obsProp,mu,sd,1)-dnorm(obsAcc,mu,sd,1);
//
//							  Par      = LatODE[0][g][0].FuncsParams[0][kf].VarK;
//							  mu       = Par->PriorParameter->HyperparametersAcc.vec(0)[0];
//							  sd       = pow(Par->PriorParameter->HyperparametersAcc.vec(1)[0], 0.5);
//							  obsAcc   = log(Par->ParameterAcc);
//							  obsProp  = log(Par->ParameterProp);
//							  MH += dnorm(obsProp,mu,sd,1)-dnorm(obsAcc,mu,sd,1);
//
//							  Par      = LatODE[0][g][0].FuncsParams[0][kf].MeanK;
//							  mu       = Par->PriorParameter->HyperparametersAcc.vec(0)[0];
//							  sd       = pow(Par->PriorParameter->HyperparametersAcc.vec(1)[0], 0.5);
//							  obsAcc   = log(Par->ParameterAcc);
//							  obsProp  = log(Par->ParameterProp);
//							  MH += dnorm(obsProp,mu,sd,1)-dnorm(obsAcc,mu,sd,1);
//
//							  double mu  = LatODE[0][g][0].FuncsParams[0][kf].MeanK->ParameterProp;
//							  double var = LatODE[0][g][0].FuncsParams[0][kf].VarK->ParameterProp;
//							  if((mu-2.0*var*pow(-1.0*log(LimC),0.5) )<0)
//							  {
//								  MH += log(ExpMolt)-ExpLambda*(-1.0*(mu-2.0*var*pow(-1.0*log(LimC),0.5) ));
//							  }
//							  if((mu+2.0*var*pow(-1.0*log(LimC),0.5) )>16)
//							  {
//								  MH += log(ExpMolt)-ExpLambda*((mu+2.0*var*pow(-1.0*log(LimC),0.5) )-16);
//							  }
//
//							  mu  = LatODE[0][g][0].FuncsParams[0][kf].MeanK->ParameterAcc;
//							  var = LatODE[0][g][0].FuncsParams[0][kf].VarK->ParameterAcc;
//							  if((mu-2.0*var*pow(-1.0*log(LimC),0.5) )<0)
//							  {
//								  MH -= log(ExpMolt)-ExpLambda*(-1.0*(mu-2.0*var*pow(-1.0*log(LimC),0.5) ));
//							  }
//							  if((mu+2.0*var*pow(-1.0*log(LimC),0.5) )>16)
//							  {
//								  MH -= log(ExpMolt)-ExpLambda*((mu+2.0*var*pow(-1.0*log(LimC),0.5) )-16);
//							  }
//
//						  }
//						  if(ic==1)
//						  {
//							  Par      = LatODE[0][g][0].FuncsParams[0][kf].MinK;
//							  mu       = Par->PriorParameter->HyperparametersAcc.vec(0)[0];
//							  sd       = pow(Par->PriorParameter->HyperparametersAcc.vec(1)[0], 0.5);
//							  obsAcc   = log(Par->ParameterAcc);
//							  obsProp  = log(Par->ParameterProp);
//							  MH += dnorm(obsProp,mu,sd,1)-dnorm(obsAcc,mu,sd,1);
//						  }
//					  }
//				  }
//			  }
//
//
//
//
//
//			 int j = 0;
//
//
//			 for(j=0;j<nrep;j++)
//			 {
//				for(int t1=0;t1<nNotna;t1++)
//				{
//				  int t = NonNA[0].vec(t1);
//
//				  for(int i=0;i<nvar;i++)
//				  {
//
//					 MH +=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), LatODE[0][g][j].ODEMATProp.mat(t,i), sqrt(SigmaProp[0][g].mat(t,i)), 0.0);
//					 MH -=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), LatODE[0][g][j].ODEMAT.mat(t,i), sqrt(SigmaAcc[0][g].mat(t,i)), 0.0);
//
//
//				  }
//				}
//			 }
//
//			 double alphaRatio = min(1.0,exp(MH));
//
//			  int OUT = OUTVEC[g];
//			 if(OUT!=0)
//			 {
//				alphaRatio = 0.0;
//			 }
//
//			 if(runif(0.0,1.0)<alphaRatio)
//			 {
//				//REprintf("ACC \n");
//				Adapt[0][g]->UpdateIfAccepted();
//				j = 0;
//				LatODE[0][g][j].copyFromODEMATPropToAcc();
//				for(int i=0;i<nvar;i++)
//				{
//				  for(int t1=0;t1<nNotna;t1++)
//				  {
//					 int t = NonNA[0].vec(t1);
//					 SigmaAcc[0][g].Pmat(t,i)[0] = SigmaProp[0][g].Pmat(t,i)[0];
//				  }
//				}
//			 }
//			 Adapt[0][g]->PostSamp(alphaRatio);
//
//		  }
		}
  };





	/****** LIKE  */

	  class MCMCupdates_LikeParam
	  {
	  public:
		  virtual void sample( vector< vector <Class_Mixture_V3 > > *TheModel, int iter, int IterStartRandom)
		  {
			  error("Not overrided MCMCupdates_LikeParam");
		  }

	  };
	  class MCMCupdates_LikeParam_NoUpdate: public MCMCupdates_LikeParam
	  {
	  public:
		  void sample( vector< vector <Class_Mixture_V3 > > *TheModel, int iter, int IterStartRandom) override
		  {

		  }
	  };
	  class MCMCupdates_LikeParam_GIBBS: public MCMCupdates_LikeParam
	  {
		  void sample( vector< vector <Class_Mixture_V3 > > *TheModel, int iter, int IterStartRandom) override
		  {
			  if(iter>=IterStartRandom)
			  {

				  int jpar = (int)TheModel[0][0].size();
				  for(int i=0;i<TheModel[0].size();i++)
				  {
					  for(int j=0;j<jpar;j++)
					  {
						  TheModel[0][i][j].SampParGIBBS_OnlyOcc();
					  }
				  }

//				  #pragma omp parallel for default(none) schedule(dynamic) shared(jpar,TheModel)
//				  for(int Count=0;Count<TheModel[0].size()*jpar;Count++)
//				  {
//					  int j = Count%jpar;
//					  int i = Count/jpar;
//					  TheModel[0][i][j].SampParGIBBS();
//				  }
			  }
		  }
	  };


	  /****** PI  */

	  class MCMCupdates_xi
	  {
	  public:
		  virtual void sample( vector< vector<MixtureDP> > *mixDP,  vector< vector<ClusterIndex_V2> > *Clust, int iter, int IterStartRandom, int addStartRandom)
		  {
			  error("Not overrided MCMCupdates_xi");
		  }
	  };
	  class MCMCupdates_xi_NoUpdate: public MCMCupdates_xi
	  {
	  public:
		  void sample( vector< vector<MixtureDP> > *mixDP,  vector< vector<ClusterIndex_V2> > *Clust, int iter, int IterStartRandom, int addStartRandom) override
		  {

		  }
	  };

	  class MCMCupdates_xi_MixtureDP: public MCMCupdates_xi
	  {
		  void sample( vector< vector<MixtureDP> > *mixDP,  vector< vector<ClusterIndex_V2> > *Clust, int iter, int IterStartRandom, int addStartRandom) override
		  {
			  if(iter>=IterStartRandom)
			  {
				  int jpar = (int)mixDP[0][0].size();

				  if(iter>=(IterStartRandom+addStartRandom))
				  {
					  #pragma omp parallel for default(none) schedule(dynamic) shared(jpar,Clust,mixDP) collapse(2)
					  for(int i=0;i<mixDP[0].size();i++)
					  {
						  for(int j=0;j<jpar;j++)
						  {
							  Clust[0][i][j].samplePi(&mixDP[0][i][j]);
						  }
					  }
				  }
			  }

		  }
	  };

	/****** st  */


	  class MCMCupdates_st
	  {
	  public:
		  virtual void sample(vector< vector < Class_Parameter> > *eta, vector< vector< Class_Mixture_V3> > *TheModel, int iter, int IterStartRandom, int addStartRandom)
		  {
			  error("Not overrided MCMCupdates_st");
		  }
	  };
	  class MCMCupdates_st_NoUpdate: public MCMCupdates_st
	  {
	  public:
		  void sample(vector< vector < Class_Parameter> > *eta,vector< vector< Class_Mixture_V3> > *TheModel, int iter, int IterStartRandom, int addStartRandom) override
		  {

		  }
	  };
	  class MCMCupdates_st_MixtureDP: public MCMCupdates_st
	  {
		  void sample( vector< vector < Class_Parameter> > *eta,vector< vector< Class_Mixture_V3> > *TheModel, int iter, int IterStartRandom, int addStartRandom) override
		  {

			  if(iter>=IterStartRandom)
			  {
				  int jpar = (int)TheModel[0][0].size();

				  if(iter>=(IterStartRandom))
				  {
					  //#pragma omp parallel for default(none) schedule(static) shared(jpar,TheModel,eta) collapse(2)
					  for(int i=0;i<TheModel[0].size();i++)
					  {
						  for(int j=0;j<jpar;j++)
						  {

							  if(runif(0.0,1.0)<0.5)
							  {
								  TheModel[0][i][j].samp_stMixtureDP_CheckLastElement_Metropolis(&eta[0][i][j]);
							  }else{
								  TheModel[0][i][j].samp_stMixtureDP_CheckLastElement_Metropolis_Type2(&eta[0][i][j]);
							  }



						  }
					  }
				  }


			  }

		  }
	  };



	class MCMCupdates_st_SplitMerg
	{
	public:
		virtual void sample(vector< vector < Class_Parameter> > *eta, vector< vector< Class_Mixture_V3> > *TheModel, int iter, int IterStartRandom, int addStartRandom)
		{
			error("Not overrided MCMCupdates_st");
		}
	};
	class MCMCupdates_st_SplitMerg_NoUpdate: public MCMCupdates_st_SplitMerg
	{
	public:
		void sample(vector< vector < Class_Parameter> > *eta,vector< vector< Class_Mixture_V3> > *TheModel, int iter, int IterStartRandom, int addStartRandom) override
		{

		}
	};
	class MCMCupdates_st_SplitMerg_MixtureDP: public MCMCupdates_st_SplitMerg
	{
		void sample( vector< vector < Class_Parameter> > *eta,vector< vector< Class_Mixture_V3> > *TheModel, int iter, int IterStartRandom, int addStartRandom) override
		{

			if(iter>=IterStartRandom)
			{
				int jpar = (int)TheModel[0][0].size();

				if(iter>=(IterStartRandom))
				{
					//#pragma omp parallel for default(none) schedule(static) shared(jpar,TheModel,eta) collapse(2)
					for(int i=0;i<TheModel[0].size();i++)
					{
						for(int j=0;j<jpar;j++)
						{

							TheModel[0][i][j].samp_stMixtureDP_CheckLastElement_MergeSplit(&eta[0][i][j]);

						}
					}
				}


			}

		}
	};



	  /******* ETA */

	  class MCMCupdates_eta
	  {
	  public:
		  virtual void sample( vector< vector <Class_Mixture_V3 > >*TheModel,vector< vector < Class_Parameter> > *eta, int iter, int IterStartRandom, int addStartRandom)
		  {
			  error("Not overrided MCMCupdates_eta");
		  }
	  };
	  class MCMCupdates_eta_NoUpdate: public MCMCupdates_eta
	  {
	  public:
		  void sample(  vector< vector <Class_Mixture_V3 > >*TheModel,vector< vector < Class_Parameter> > *eta, int iter, int IterStartRandom, int addStartRandom) override
		  {

		  }
	  };
	  class MCMCupdates_eta_MixtureDP_GammaPrior: public MCMCupdates_eta
	  {
		  void sample(  vector< vector <Class_Mixture_V3 > >*TheModel,vector< vector < Class_Parameter> > *eta, int iter, int IterStartRandom, int addStartRandom) override
		  {
			  if(iter>=(IterStartRandom))
			  {
				  int jpar = (int)TheModel[0][0].size();

				  #pragma omp parallel for default(none) schedule(dynamic) shared(jpar,TheModel,eta) collapse(2)
				  for(int i=0;i<TheModel[0].size();i++)
				  {
					  for(int j=0;j<jpar;j++)
					  {
						  Class_DirichletProcess::sample_DPparameterGammaPrior(&eta[0][i][j].ParameterAcc,  eta[0][i][j].PriorParameter->HyperparametersAcc.vec(0)[0],  eta[0][i][j].PriorParameter->HyperparametersAcc.vec(1)[0],   TheModel[0][i][j].Clusters->nNonEmpty,  TheModel[0][i][j].nObs);
					  }
				  }
			  }


		  }
	  };


	/******* ETA */

	 class MCMCupdates_CopyPar
	 {
	 public:
		 virtual void copy(vector < vector<ODE_FURLAN_T2> >  *LatODE,  vector< vector <Class_Mixture_V3 > >*TheModel, int iter, int IterStartRandom)
		 {
			 error("Not overrided MCMCupdates_CopyPar");
		 }
	 };
	 class MCMCupdates_CopyPar_Type1: public MCMCupdates_CopyPar
	 {
		 void copy(vector < vector<ODE_FURLAN_T2> >  *LatODE,  vector< vector <Class_Mixture_V3 > >*TheModel, int iter, int IterStartRandom) override
		 {
			 if(iter>=IterStartRandom)
			 {
				 for(int ik=0;ik<TheModel[0].size();ik++)
				 {
					 //DimC.Pvec(0)[0] = 4;
					 //DimC.Pvec(1)[0] = 1;

					 int j = 0;
					 for(int g=0;g<TheModel[0][ik][j].Y.nRows;g++)
					 {
						 TheModel[0][ik][j].Y.Pmat(g,0)[0] = LatODE[0][g][0].FuncsParams[0][ik].EtaK1->ParameterAcc;
						 TheModel[0][ik][j].Y.Pmat(g,1)[0] = LatODE[0][g][0].FuncsParams[0][ik].EtaK2->ParameterAcc;
						 TheModel[0][ik][j].Y.Pmat(g,2)[0] = LatODE[0][g][0].FuncsParams[0][ik].VarK->ParameterAcc;
						 TheModel[0][ik][j].Y.Pmat(g,3)[0] = LatODE[0][g][0].FuncsParams[0][ik].MeanK->ParameterAcc;
					 }
					 j = 1;
					 for(int g=0;g<TheModel[0][ik][j].Y.nRows;g++)
					 {
						 TheModel[0][ik][j].Y.Pmat(g,0)[0] = LatODE[0][g][0].FuncsParams[0][ik].MinK->ParameterAcc;
					 }

					 //TheModel[0][ik][0].Y.Print("S");
					 //TheModel[0][ik][1].Y.Print("S");

				 }
			 }

		 }
	 };


	class MCMCupdates_CopyPar_Type1_Rparam: public MCMCupdates_CopyPar
	{
		void copy(vector < vector<ODE_FURLAN_T2> >  *LatODE,  vector< vector <Class_Mixture_V3 > >*TheModel, int iter, int IterStartRandom) override
		{
			for(int ik=0;ik<TheModel[0].size();ik++)
			{
				//DimC.Pvec(0)[0] = 4;
				//DimC.Pvec(1)[0] = 1;

				int j = 0;
				for(int g=0;g<TheModel[0][ik][j].Y.nRows;g++)
				{
					TheModel[0][ik][j].Y.Pmat(g,0)[0] = LatODE[0][g][0].FuncsParams[0][ik].EtaK1->ParameterAcc;
					TheModel[0][ik][j].Y.Pmat(g,1)[0] = LatODE[0][g][0].FuncsParams[0][ik].EtaK2->ParameterAcc;
					TheModel[0][ik][j].Y.Pmat(g,2)[0] = log(LatODE[0][g][0].FuncsParams[0][ik].VarK->ParameterAcc);
					TheModel[0][ik][j].Y.Pmat(g,3)[0] = log(LatODE[0][g][0].FuncsParams[0][ik].MeanK->ParameterAcc);


				}

				j = 1;
				for(int g=0;g<TheModel[0][ik][j].Y.nRows;g++)
				{
					TheModel[0][ik][j].Y.Pmat(g,0)[0] = log(LatODE[0][g][0].FuncsParams[0][ik].MinK->ParameterAcc);
					//TheModel[0][ik][j].Y.Print("Y");
				}
			}

		}
	};




  /*****************************************
   MCMC UPDATES - SET
   *****************************************/



	MCMCupdates_CopyPar *CopyPar = 0;
	if(ClustType==1)
	{
		if(Rparam==0)
		{
			CopyPar = new MCMCupdates_CopyPar_Type1;
		}else{
			CopyPar = new MCMCupdates_CopyPar_Type1_Rparam;
		}

	}else{
		error("ClustType non implementato");

	}




	MCMCupdates_eta * DPpar_UPDATE = 0;
	if(sample_DpPar==1)
	{
		DPpar_UPDATE = new MCMCupdates_eta_MixtureDP_GammaPrior;
	}else{
		DPpar_UPDATE = new MCMCupdates_eta_NoUpdate;
	}


	MCMCupdates_st *st_UPDATE = 0;

	if(sample_st==1)
	{
		st_UPDATE = new MCMCupdates_st_MixtureDP;

	}else{
		st_UPDATE = new MCMCupdates_st_NoUpdate;

	}

	MCMCupdates_st_SplitMerg *st_SplitMerg_UPDATE = 0;
	if(Do_MergeSplit==1)
	{
		st_SplitMerg_UPDATE = new MCMCupdates_st_SplitMerg_MixtureDP;
	}else{
		st_SplitMerg_UPDATE = new MCMCupdates_st_SplitMerg_NoUpdate;
	}
	MCMCupdates_LikeParam *RandomPar_UPDATE = 0;
	if(sample_RandomPar==1)
	{
		RandomPar_UPDATE = new MCMCupdates_LikeParam_GIBBS;
	}else{
		RandomPar_UPDATE = new MCMCupdates_LikeParam_NoUpdate;
	}


	MCMCupdates_xi * Pi_UPDATE = 0;
	if(sample_Pi==1)
	{
		Pi_UPDATE = new MCMCupdates_xi_MixtureDP;
	}else{
		Pi_UPDATE = new MCMCupdates_xi_NoUpdate;
	}

  MCMCupdates_ComputeSigmaMat *ComputeSigma = 0;
  ComputeSigma = new MCMCupdates_ComputeSigmaMat_Type1;


	MCMCupdates_SF *SF_UPDATE;
	SF_UPDATE = new MCMCupdates_SF_Type1;

  MCMCupdates_sigma2 *sigma2_UPDATE = 0;
  if(sample_Var==1)
  {
    sigma2_UPDATE = new MCMCupdates_sigma2_Type1;
  }else{
    sigma2_UPDATE = new MCMCupdates_sigma2_NoUpdate;
  }



  MCMCupdates_OdeParameters *OdeParameters_UPDATE = 0;
  if(sample_Ode==1)
  {
	  if(ClustType==1)
	  {
		  if(Rparam==0)
		  {
			  OdeParameters_UPDATE = new MCMCupdates_OdeParameters_Adapt_Type1;
		  }else{
			  OdeParameters_UPDATE = new MCMCupdates_OdeParameters_Adapt_Type1_Rparam;
		  }

	  }else{
		  error("sampleode");
	  }

  }else{
    OdeParameters_UPDATE = new MCMCupdates_OdeParameters_NoUpdate;
  }


  /*****************************************
   PreMCMC
   *****************************************/

	 CopyPar->copy(&LatentODE , &MixModel, 0, IterStartRandom);
	 RandomPar_UPDATE->sample(&MixModel, 0, IterStartRandom);
	 Pi_UPDATE->sample(&MixtureDPModel, &Clustering, 0, IterStartRandom,addStartRandom);
	 DPpar_UPDATE->sample(&MixModel, &DPparMCMC, 0, IterStartRandom,addStartRandom);

  for(int g=0;g<nG;g++)
  {
    for(int ivar=0;ivar<nvar;ivar++)
    {
      ComputeSigma->ComputeWitBetaAcc(LatentODE[g][0].ODEMAT, AllBeta, &SigmaMat[g],&IndexNotNA,ivar, 0);
      ComputeSigma->ComputeWitBetaProp(LatentODE[g][0].ODEMATProp, AllBeta, &SigmaMatProp[g], &IndexNotNA,ivar,0);
    }

  }

  const char *TEXT = CHAR(STRING_ELT(TEXT_r,0));

  /*****************************************
   MCMC
   *****************************************/
  REprintf("R4wwA");
  int iterations = 0;
  int iMCMC_app = MCMCburnin;
  for(int iMCMC1=0;iMCMC1<nSamples_save;iMCMC1++)
  {

    for(int iMCMC2=0;iMCMC2<iMCMC_app;iMCMC2++)
    {
      R_CheckUserInterrupt();

      /************* Print *********************/
      if((iterations%IterShow)==0)
      {
        REprintf("Iterations %i \n", iterations);

			for(int iii=0;iii<Clustering.size();iii++)
			{
				for(int jjj=0;jjj<Clustering[iii].size();jjj++)
				{
					REprintf("%i ",Clustering[iii][jjj].nNonEmpty);
				}
			}
			REprintf("\n");

        if(Verbose==1)
        {
         FILE * (file);
         file = fopen(TEXT,"wt");
         fprintf(file, "Iterations %i \n", iterations);
         fclose (file);
        }
      }
      /**********************************/
      iterations ++;
      AdaptParameters.Update(iterations);

		/************* DP par  *********************/
		//REprintf("C4\n");
		DPpar_UPDATE->sample(&MixModel, &DPparMCMC, iterations, IterStartRandom,addStartRandom);
		 /************* st  *********************/
		//REprintf("C3\n");
		 st_UPDATE->sample( &DPparMCMC,&MixModel, iterations, IterStartRandom,addStartRandom);
		 //REprintf("C3-2\n");
		 st_SplitMerg_UPDATE->sample( &DPparMCMC,&MixModel, iterations, IterStartRandom,addStartRandom);
		 /************* Pi *********************/
		//REprintf("C2\n");
		 Pi_UPDATE->sample(&MixtureDPModel, &Clustering, iterations, IterStartRandom,addStartRandom);




		 /************* Randompar *********************/
		//REprintf("C1\n");
		 CopyPar->copy(&LatentODE , &MixModel, iterations, IterStartRandom);
		//REprintf("C12\n");
		 RandomPar_UPDATE->sample(&MixModel, iterations, IterStartRandom);




      /************* OdeParam *********************/
      //REprintf("ODE\n");
      OdeParameters_UPDATE->sample(&SF_MCMC,  &MixModel,&AdaptkDivisi,  ComputeSigma,   &AllBeta, &SigmaMat,&SigmaMatProp,&Obs ,&LatentODE , &IndexNotNA , &AdaptLikeAllParam, iterations,IterStartRandom,addStartRandom,LimC, ExpMolt, ExpLambda,MoltSF);


      /************* sigma2 *********************/
      //REprintf("SIgma2\n");
      sigma2_UPDATE->sample(&SF_MCMC,ComputeSigma, &AdaptBeta,  &AllBeta, &SigmaMat,&SigmaMatProp, &Obs ,&LatentODE , &IndexNotNA ,iterations,MoltSF);

		 //REprintf("Sf\n");
		 SF_UPDATE->sample(&SF_MCMC,ComputeSigma, &AdaptSH,  &AllBeta, &SigmaMat,&SigmaMatProp, &Obs ,&LatentODE , &IndexNotNA ,iterations,MoltSF);


//		for(i=0;i<nlatentk;i++)
//		{
//			 for(int k=0;k<nc;k++)
//			 {
//				  DPparMCMC[i][k].PrintObject("DPpar");
//			 }
//		}
      /************* *********************/
    }

    iMCMC_app = MCMCthin;

    /*****************************************
     From C++ To R (2)
     *****************************************/

//    for(int jj=0;jj<nvar;jj++)
//    {
//      sigma2_out_P[iMCMC1*nvar+jj] = sigma2_MCMC[jj].ParameterAcc;
//    }

    for(int ii=0;ii<nG;ii++)
    {
      for(int jj=0;jj<nlatentk;jj++)
      {

        MinK_out_P[iMCMC1*nG*nlatentk+nlatentk*ii+jj]    = fabs(MinK_MCMC[ii][jj].ParameterAcc);
        VarK_out_P[iMCMC1*nG*nlatentk+nlatentk*ii+jj]    = fabs(VarK_MCMC[ii][jj].ParameterAcc);
        MeanK_out_P[iMCMC1*nG*nlatentk+nlatentk*ii+jj]   = fabs(MeanK_MCMC[ii][jj].ParameterAcc);;

			if(Spike==0)
			{
				EtaK1_out_P[iMCMC1*nG*nlatentk+nlatentk*ii+jj]   = EtaK1_MCMC[ii][jj].ParameterAcc;
				EtaK2_out_P[iMCMC1*nG*nlatentk+nlatentk*ii+jj]   = EtaK2_MCMC[ii][jj].ParameterAcc;
			}else{
				double eta1 = EtaK1_MCMC[ii][jj].ParameterAcc;
				double eta2 = EtaK2_MCMC[ii][jj].ParameterAcc;
				double LimEta = LimSpike;
				if((eta1>(-1.0*LimEta) )&& (eta1<LimEta))
				{
					eta1 = 0.0;
				}else{
					if(eta1>=LimEta)
					{
						eta1 = eta1-LimEta;
					}else{
						eta1 = eta1+LimEta;
					}
				}
				if((eta2>(-1.0*LimEta) )&& (eta2<LimEta))
				{
					eta2 = 0.0;
				}else{
					if(eta2>=LimEta)
					{
						eta2 = eta2-LimEta;
					}else{
						eta2 = eta2+LimEta;
					}
				}
				EtaK1_out_P[iMCMC1*nG*nlatentk+nlatentk*ii+jj]   = eta1;
				EtaK2_out_P[iMCMC1*nG*nlatentk+nlatentk*ii+jj]   = eta2;
			}




      }
      for(int jj=0;jj<nvar;jj++)
      {
         Y0_out_P[iMCMC1*nG*nvar+nvar*ii+jj]   = Y0_MCMC[ii][jj].ParameterAcc;;
      }
    }
    for(int jj=0;jj<nvar;jj++)
    {
      Beta0_out_P[iMCMC1*nvar+jj]   = Beta0_MCMC[jj].ParameterAcc;;
      Beta1_out_P[iMCMC1*nvar+jj]   = Beta1_MCMC[jj].ParameterAcc;;
    }

    //int nrepApp = 1;
    if(saveODE==1)
    {
      for(int ii=0;ii<nG;ii++)
      {
        for(int t1=0;t1<nNotna;t1++)
        {
          int ir = IndexNotNA.vec(t1);
          for(int ic=0;ic<nvar;ic++)
          {
            Y_out_P[iMCMC1*nG*nNotna*nvar+ii*nNotna*nvar+t1*nvar+ic] =  LatentODE[ii][0].ODEMAT.mat(ir,ic);
          }
        }
      }

    }else{

    }

	  /******** CLUSTERING ****/

	  // K1
	  int ik = 0;
	  int ic = 0;
	  for(int k=0;k<Kmax;k++)
	  {
		  ik = 0;
		  ic = 0;
		  i  = 0;
		  Beta_11_out_P[4*Kmax*iMCMC1+k*4+i] = BetaMCMC[ik][ic][k][i].ParameterAcc;
		  i = 1;
		  Beta_11_out_P[4*Kmax*iMCMC1+k*4+i] = BetaMCMC[ik][ic][k][i].ParameterAcc;
		  i = 2;
		  Beta_11_out_P[4*Kmax*iMCMC1+k*4+i] = BetaMCMC[ik][ic][k][i].ParameterAcc;
		  i = 3;
		  Beta_11_out_P[4*Kmax*iMCMC1+k*4+i] = BetaMCMC[ik][ic][k][i].ParameterAcc;

		  i  = 0;
		  ic = 1;
		  Beta_12_out_P[1*Kmax*iMCMC1+k*1+i] = BetaMCMC[ik][ic][k][i].ParameterAcc;



		  ik = 1;
		  ic = 0;
		  i  = 0;
		  Beta_21_out_P[4*Kmax*iMCMC1+k*4+i] = BetaMCMC[ik][ic][k][i].ParameterAcc;
		  i = 1;
		  Beta_21_out_P[4*Kmax*iMCMC1+k*4+i] = BetaMCMC[ik][ic][k][i].ParameterAcc;
		  i = 2;
		  Beta_21_out_P[4*Kmax*iMCMC1+k*4+i] = BetaMCMC[ik][ic][k][i].ParameterAcc;
		  i = 3;
		  Beta_21_out_P[4*Kmax*iMCMC1+k*4+i] = BetaMCMC[ik][ic][k][i].ParameterAcc;

		  i  = 0;
		  ic = 1;
		  Beta_22_out_P[1*Kmax*iMCMC1+k*1+i] = BetaMCMC[ik][ic][k][i].ParameterAcc;


		  ik = 2;
		  ic = 0;
		  i  = 0;
		  Beta_31_out_P[4*Kmax*iMCMC1+k*4+i] = BetaMCMC[ik][ic][k][i].ParameterAcc;
		  i = 1;
		  Beta_31_out_P[4*Kmax*iMCMC1+k*4+i] = BetaMCMC[ik][ic][k][i].ParameterAcc;
		  i = 2;
		  Beta_31_out_P[4*Kmax*iMCMC1+k*4+i] = BetaMCMC[ik][ic][k][i].ParameterAcc;
		  i = 3;
		  Beta_31_out_P[4*Kmax*iMCMC1+k*4+i] = BetaMCMC[ik][ic][k][i].ParameterAcc;

		  i  = 0;
		  ic = 1;
		  Beta_32_out_P[1*Kmax*iMCMC1+k*1+i] = BetaMCMC[ik][ic][k][i].ParameterAcc;


		  ic = 0;
		  ik = 0;
		  for(i=0;i<4;i++)
		  {
				for(j=i;j<4;j++)
				{
					 Sigma_11_out_P[4*4*Kmax*iMCMC1+k*(4*4)+i*4+j] = SigmaMCMC[ik][ic][k].SigmaAcc.mat(i,j);
					 Sigma_11_out_P[4*4*Kmax*iMCMC1+k*(4*4)+j*4+i] = SigmaMCMC[ik][ic][k].SigmaAcc.mat(i,j);
				}

		  }
		  ic = 1;
		  ik = 0;
		  for(i=0;i<1;i++)
		  {
				for(j=i;j<1;j++)
				{
					 Sigma_12_out_P[1*1*Kmax*iMCMC1+k*(1*1)+i*1+j] = SigmaMCMC[ik][ic][k].SigmaAcc.mat(i,j);
					 Sigma_12_out_P[1*1*Kmax*iMCMC1+k*(1*1)+j*1+i] = SigmaMCMC[ik][ic][k].SigmaAcc.mat(i,j);
				}

		  }

		  ic = 0;
		  ik = 1;
		  for(i=0;i<4;i++)
		  {
				for(j=i;j<4;j++)
				{
					 Sigma_21_out_P[4*4*Kmax*iMCMC1+k*(4*4)+i*4+j] = SigmaMCMC[ik][ic][k].SigmaAcc.mat(i,j);
					 Sigma_21_out_P[4*4*Kmax*iMCMC1+k*(4*4)+j*4+i] = SigmaMCMC[ik][ic][k].SigmaAcc.mat(i,j);
				}

		  }
		  ic = 1;
		  ik = 1;
		  for(i=0;i<1;i++)
		  {
				for(j=i;j<1;j++)
				{
					 Sigma_22_out_P[1*1*Kmax*iMCMC1+k*(1*1)+i*1+j] = SigmaMCMC[ik][ic][k].SigmaAcc.mat(i,j);
					 Sigma_22_out_P[1*1*Kmax*iMCMC1+k*(1*1)+j*1+i] = SigmaMCMC[ik][ic][k].SigmaAcc.mat(i,j);
				}

		  }

		  ic = 0;
		  ik = 2;
		  for(i=0;i<4;i++)
		  {
				for(j=i;j<4;j++)
				{
					 Sigma_31_out_P[4*4*Kmax*iMCMC1+k*(4*4)+i*4+j] = SigmaMCMC[ik][ic][k].SigmaAcc.mat(i,j);
					 Sigma_31_out_P[4*4*Kmax*iMCMC1+k*(4*4)+j*4+i] = SigmaMCMC[ik][ic][k].SigmaAcc.mat(i,j);
				}

		  }
		  ic = 1;
		  ik = 2;
		  for(i=0;i<1;i++)
		  {
				for(j=i;j<1;j++)
				{
					 Sigma_32_out_P[1*1*Kmax*iMCMC1+k*(1*1)+i*1+j] = SigmaMCMC[ik][ic][k].SigmaAcc.mat(i,j);
					 Sigma_32_out_P[1*1*Kmax*iMCMC1+k*(1*1)+j*1+i] = SigmaMCMC[ik][ic][k].SigmaAcc.mat(i,j);
				}

		  }



	  }
	  ik = 0;
	  ic = 0;
	  for(int k=0;k<Kmax;k++)
	  {
			pi_11_out_P[Kmax*iMCMC1+k] = piMCMC[ik][ic][k].ParameterAcc;
	  }
	  for(i=0;i<nG;i++)
	  {
		  st_11_out_P[iMCMC1*nG+i] = Clustering[ik][ic].Zeta.vec(i);
	  }

	  ik = 0;
	  ic = 1;
	  for(int k=0;k<Kmax;k++)
	  {
			pi_12_out_P[Kmax*iMCMC1+k] = piMCMC[ik][ic][k].ParameterAcc;
	  }
	  for(i=0;i<nG;i++)
	  {
		  st_12_out_P[iMCMC1*nG+i] = Clustering[ik][ic].Zeta.vec(i);
	  }



	  ik = 1;
	  ic = 0;
	  for(int k=0;k<Kmax;k++)
	  {
			pi_21_out_P[Kmax*iMCMC1+k] = piMCMC[ik][ic][k].ParameterAcc;
	  }
	  for(i=0;i<nG;i++)
	  {
		  st_21_out_P[iMCMC1*nG+i] = Clustering[ik][ic].Zeta.vec(i);
	  }

	  ik = 1;
	  ic = 1;
	  for(int k=0;k<Kmax;k++)
	  {
			pi_22_out_P[Kmax*iMCMC1+k] = piMCMC[ik][ic][k].ParameterAcc;
	  }
	  for(i=0;i<nG;i++)
	  {
		  st_22_out_P[iMCMC1*nG+i] = Clustering[ik][ic].Zeta.vec(i);
	  }



	  ik = 2;
	  ic = 0;
	  for(int k=0;k<Kmax;k++)
	  {
			pi_31_out_P[Kmax*iMCMC1+k] = piMCMC[ik][ic][k].ParameterAcc;
	  }
	  for(i=0;i<nG;i++)
	  {
		  st_31_out_P[iMCMC1*nG+i] = Clustering[ik][ic].Zeta.vec(i);
	  }

	  ik = 2;
	  ic = 1;
	  for(int k=0;k<Kmax;k++)
	  {
			pi_32_out_P[Kmax*iMCMC1+k] = piMCMC[ik][ic][k].ParameterAcc;
	  }
	  for(i=0;i<nG;i++)
	  {
		  st_32_out_P[iMCMC1*nG+i] = Clustering[ik][ic].Zeta.vec(i);
	  }

	  for(i=0;i<nlatentk;i++)
	  {
		 for(int k=0;k<nc;k++)
		 {
			 DPpar_out_P[iMCMC1*nlatentk*nc+i*nc+k] = DPparMCMC[i][k].ParameterAcc;
		 }
	  }

	  for(i=0;i<11;i++)
	  {
		  SF_1_out_P[iMCMC1*11+i] = SF_MCMC[0][i].ParameterAcc/MoltSF;
		  SF_2_out_P[iMCMC1*11+i] = SF_MCMC[1][i].ParameterAcc/MoltSF;
		  SF_3_out_P[iMCMC1*11+i] = SF_MCMC[2][i].ParameterAcc/MoltSF;
	  }


    /*****************************************
     Here, the second MCMC parentheses end
     *****************************************/
  }
  /*****************************************
  Final print
  *****************************************/




  /*****************************************
   From C++ to R
   *****************************************/

  SEXP result,resultNames;
  int nResultListObjs = nProtect;

  PROTECT(result = allocVector(VECSXP, nResultListObjs)); nProtect++;
  PROTECT(resultNames = allocVector(VECSXP, nResultListObjs)); nProtect++;

  i=0;

  SET_VECTOR_ELT(result, i, MinK_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("MinK"));i++;
  SET_VECTOR_ELT(result, i, VarK_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("VarK"));i++;
  SET_VECTOR_ELT(result, i, MeanK_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("MeanK"));i++;
  SET_VECTOR_ELT(result, i, EtaK1_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("EtaK1"));i++;
  SET_VECTOR_ELT(result, i, EtaK2_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("EtaK2"));i++;

  SET_VECTOR_ELT(result, i, Y0_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("Y0"));i++;

  SET_VECTOR_ELT(result, i, Y_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("Y"));i++;

  SET_VECTOR_ELT(result, i, Beta0_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("Beta0"));i++;
  SET_VECTOR_ELT(result, i, Beta1_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("Beta1"));i++;


	SET_VECTOR_ELT(result, i, DPpar_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("DPpar_out"));i++;



	SET_VECTOR_ELT(result, i, Sigma_12_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("Sigma_12"));i++;
	SET_VECTOR_ELT(result, i, Beta_12_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("Beta_12"));i++;
	SET_VECTOR_ELT(result, i, pi_12_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("pi_12"));i++;
	SET_VECTOR_ELT(result, i, st_12_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("st_12"));i++;

	SET_VECTOR_ELT(result, i, Sigma_11_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("Sigma_11"));i++;
	SET_VECTOR_ELT(result, i, Beta_11_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("Beta_11"));i++;
	SET_VECTOR_ELT(result, i, pi_11_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("pi_11"));i++;
	SET_VECTOR_ELT(result, i, st_11_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("st_11"));i++;


	SET_VECTOR_ELT(result, i, Sigma_22_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("Sigma_22"));i++;
	SET_VECTOR_ELT(result, i, Beta_22_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("Beta_22"));i++;
	SET_VECTOR_ELT(result, i, pi_22_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("pi_22"));i++;
	SET_VECTOR_ELT(result, i, st_22_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("st_22"));i++;

	SET_VECTOR_ELT(result, i, Sigma_21_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("Sigma_21"));i++;
	SET_VECTOR_ELT(result, i, Beta_21_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("Beta_21"));i++;
	SET_VECTOR_ELT(result, i, pi_21_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("pi_21"));i++;
	SET_VECTOR_ELT(result, i, st_21_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("st_21"));i++;


	SET_VECTOR_ELT(result, i, Sigma_32_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("Sigma_32"));i++;
	SET_VECTOR_ELT(result, i, Beta_32_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("Beta_32"));i++;
	SET_VECTOR_ELT(result, i, pi_32_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("pi_32"));i++;
	SET_VECTOR_ELT(result, i, st_32_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("st_32"));i++;

	SET_VECTOR_ELT(result, i, Sigma_31_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("Sigma_31"));i++;
	SET_VECTOR_ELT(result, i, Beta_31_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("Beta_31"));i++;
	SET_VECTOR_ELT(result, i, pi_31_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("pi_31"));i++;
	SET_VECTOR_ELT(result, i, st_31_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("st_31"));i++;

	SET_VECTOR_ELT(result, i, SF_1_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("SF_1"));i++;
	SET_VECTOR_ELT(result, i, SF_2_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("SF_2"));i++;
	SET_VECTOR_ELT(result, i, SF_3_out_r);
	SET_VECTOR_ELT(resultNames, i, mkChar("SF_3"));i++;




  namesgets(result, resultNames);

  UNPROTECT(nProtect);
  PutRNGstate();


  return(result);

  //PutRNGstate();
  //return(R_NilValue);


}
}
