#ifndef DensityPriorParam_H
#define DensityPriorParam_H

#include <iostream>
#ifdef _OPENMP
#include <omp.h>
#endif
#include "MatricesAndVectors.h"
//#include "Gaussian.h"
#include <string>
#include <vector>
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>
#include "Functions.h"
using namespace std;

double compute_LogJacobian_BASE_R_To_R(double *variable,Vector <double*> hyper);
double compute_LogJacobian_BASE_Rplus_To_R(double *variable,Vector <double*> hyper);
double compute_LogJacobian_BASE_Segment_To_R(double *variable,Vector <double*> hyper);


double fromParameterToTransParameter_BASE_R_To_R(double *variable,Vector <double*> hyper);
double fromParameterToTransParameter_BASE_Rplus_To_R(double *variable,Vector <double*> hyper);
double fromParameterToTransParameter_BASE_Segment_To_R(double *variable,Vector <double*> hyper);

double fromTransParameterToParameter_BASE_R_To_R(double *transvariable,Vector <double*> hyper);
double fromTransParameterToParameter_BASE_R_To_Rplus(double *transvariable,Vector <double*> hyper);
double fromTransParameterToParameter_BASE_R_To_Segment(double *transvariable,Vector <double*> hyper);




int  get_nHyperparams_R();
int  get_nHyperparams_Rplus();
int  get_nHyperparams_Segment();


int                 get_Discrete_Discrete();
int                 get_Discrete_NoDiscrete();
int                 get_Circular_Circular();
int                 get_Circular_NoCircular();

vector<string>      get_NameHyperparams_R();
vector<string>      get_NameHyperparams_Rplus();
vector<string>      get_NameHyperparams_Segment();

string              get_NameDistr_R();
string              get_NameDistr_Rplus();
string              get_NameDistr_Segment();





/*****************************************
Global variable
 ****************************************/

static bool PrintNAMulti = TRUE;
static bool PrintNAIWP = TRUE;

/*****************************************
 Polymorphism Desnity
 ****************************************/

class Poly_Prior
{ 
private:
    
public:
  
    
    int UserControlledMemory;
    int nHyperparams;
    Vector <double*> HyperparametersAcc;
    Vector <double*> HyperparametersProp;
    string NamePrior;
    vector <string> NameParameters;
    

    
    
    // COSTRUCTORs
    Poly_Prior(): UserControlledMemory(1), nHyperparams(0){};
    
    //DESTRUCTORs
    ~Poly_Prior(){}


    // PrintObject
    void PrintObject(string ToPrint)
    {
        Rprintf("\n\n %s \n", ToPrint.c_str());
        Rprintf("Prior: %s\n",NamePrior.c_str());
        Rprintf("Number parameters = %i\n", nHyperparams);
        Rprintf("HyperparametersAcc: ");
        for(int i=0;i<NameParameters.size();i++)
        {
            Rprintf("%s = %f ", NameParameters[i].c_str(),HyperparametersAcc.vec(i)[0]);
        }
        Rprintf("\n HyperparametersProp: ");
        for(int i=0;i<NameParameters.size();i++)
        {
            Rprintf("%s = %f ", NameParameters[i].c_str(),HyperparametersProp.vec(i)[0]);
        }
      Rprintf("\n ");
    }
    
    // GET
    virtual int                 get_nHyperparams(){
        error("Use of a non-overrided virtual function in Poly_Prior: get_nHyperparams()");
        return(1);
    };
    virtual string              get_NameDistr(){
        error("Use of a non-overrided virtual function in Poly_Prior: get_NameDistr()");
        return("a");
    };
    virtual vector<string>      get_NameHyperparams(){
        error("Use of a non-overrided virtual function in Poly_Prior:  get_NameHyperparams()");
        vector <string> app;
        return(app);
    };
    virtual int                 get_nHyperparams(int k){
        error("Use of a non-overrided virtual function in Poly_Prior: get_nHyperparams(int k)");
        return(1);
    };
    virtual string              get_NameDistr(int k){
        error("Use of a non-overrided virtual function in Poly_Prior: get_NameDistr(int k)");
        return("a");
    };
    virtual vector<string>      get_NameHyperparams(int k){
        error("Use of a non-overrided virtual function in Poly_Prior:  get_NameHyperparams(int k)");
        vector <string> app;
        return(app);
    };
    
    
    virtual int get_discrete()
    {
        error("Use of a non-overrided virtual function in Poly_Prior");
        return(1.0);
    }
    virtual int get_circular()
    {
        error("Use of a non-overrided virtual function in Poly_Prior");
        return(1.0);
    }
    
    //double
    virtual double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper){
        error("Use of a non-overrided virtual function in Poly_Prior1");
        return(1.0);
    };
    virtual double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper){
        error("Use of a non-overrided virtual function in Poly_Prior2");
        return(1.0);
    };
    virtual double compute_LogJacobian_BASE(double *variable,Vector <double*> hyper){
        error("Use of a non-overrided virtual function in Poly_Prior3");
        return(1.0);
    };
    
    // FUNCTIONS
    virtual double fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper){
        error("Use of a non-overrided virtual function in Poly_Prior4");
        return(1.0);
    };;
    virtual double fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper){
        error("Use of a non-overrided virtual function in Poly_Prior5");
        return(1.0);
    };
    // int
    virtual double compute_NoNormlogDensity_forVariable_BASE(int n,int *variable,Vector <double*> hyper){
        error("Use of a non-overrided virtual function in Poly_Prior6");
        return(1.0);
    };
    virtual double compute_NoNormlogDensity_forVariable_BASE(int *variable,Vector <double*> hyper){
        error("Use of a non-overrided virtual function in Poly_Prior7");
        return(1.0);
    };
    
    // CREATES
    void create_FullObject(int usr)
    {
        
        //UsercontrolledMemory    = usr;
        nHyperparams            = get_nHyperparams();
        NameParameters          = get_NameHyperparams();
        NamePrior               = get_NameDistr();
        
        HyperparametersAcc      = Vector <double*>(nHyperparams,UserControlledMemory);
        
        //HyperparametersAcc.Init(0);
        HyperparametersProp      = Vector <double*>(nHyperparams,UserControlledMemory);
        
      // ma serve questo? non dovrebbe essere HyperparametersAcc
        //for(int i=0;i<NameParameters.size();i++)
        for(int i=0;i<HyperparametersAcc.nElem;i++)
        {
            
            HyperparametersAcc.Pvec(i)[0]   = new double;
            HyperparametersProp.Pvec(i)[0]  = new double;
//            Rprintf("T5\n");
//            HyperparametersAcc.Pvec(i)[0]   = nullptr;
//            HyperparametersProp.Pvec(i)[0]  = nullptr;
        }
    }
    // for variables wirth non fixed number of parameters
    void create_FullObject(int usr, int nparam)
    {
        
        //UsercontrolledMemory    = usr;
        nHyperparams            = nparam;
        NameParameters          = get_NameHyperparams();
        NamePrior               = get_NameDistr();
        
        HyperparametersAcc      = Vector <double*>(nHyperparams,UserControlledMemory);
        
        //HyperparametersAcc.Init(0);
        HyperparametersProp      = Vector <double*>(nHyperparams,UserControlledMemory);
        
        //for(int i=0;i<NameParameters.size();i++)
        for(int i=0;i<HyperparametersAcc.nElem;i++)
        {
            
            HyperparametersAcc.Pvec(i)[0]   = new double;
            HyperparametersProp.Pvec(i)[0]  = new double;
            //            Rprintf("T5\n");
            //            HyperparametersAcc.Pvec(i)[0]   = nullptr;
            //            HyperparametersProp.Pvec(i)[0]  = nullptr;
        }
    }
    /*
     getire double &hyper non  facile dato che deve puntare ad un vettore di indirizzi double
    void create_FullObjectHyperFixed(int usr, double &hyper)
    {
        UsercontrolledMemory        = usr;
        nHyperparams                = get_nHyperparams();
        NameParameters              = get_NameHyperparams();
        HyperparametersAcc          = Vector <double*>(nHyperparams,hyper);
        HyperparametersProp         = Vector <double*>(nHyperparams,hyper);
        
    }
     */
//    void create_FullObjectHyperRandom(int usr, double &hyperAcc, double &hyperProp)
//    {
//        
//        // USARE QUELLA DEI PARAMETRI
//        UsercontrolledMemory        = usr;
//        nHyperparams                = get_nHyperparams();
//        NameParameters              = get_NameHyperparams();
//        HyperparametersAcc          = Vector <double*>(nHyperparams,hyperAcc);
//        HyperparametersProp         = Vector <double*>(nHyperparams,hyperProp);
//        
//    }
//    
//    void create_FullObjectHyperRandom(int usr, Vector<double*> *hyperAcc, Vector<double*> *hyperProp)
//    {
//        // USARE QUELLA DEI PARAMETRI
//        UsercontrolledMemory        = usr;
//        nHyperparams                = get_nHyperparams();
//        NameParameters              = get_NameHyperparams();
//        HyperparametersAcc.P          = hyperAcc->P;
//        HyperparametersProp.P         = hyperProp->P;
//        
//    }
    
//    virtual double compute_logDensity_BASE(int *variable,Vector <double*> hyper){
//        error("Use of a non-overrided virtual function in Poly_Prior7");
//        return(1.0);
//    };
    
    virtual double compute_logDensity_BASE(double *variable,Vector <double*> hyper){
        error("Use of a non-overrided virtual function in Poly_Prior7");
        return(1.0);
    };
    
//    virtual double compute_logCumulative_BASE(int *variable,Vector <double*> hyper){
//        error("Use of a non-overrided virtual function in Poly_Prior7");
//        return(1.0);
//    };
    
    virtual double compute_logCumulative_BASE(double *variable,Vector <double*> hyper){
        error("Use of a non-overrided virtual function in Poly_Prior7");
        return(1.0);
    };
    
    virtual void set_Rvariable()
    {
         error("Use of a non-overrided virtual function in Rvariable");
    }
    virtual void set_Rplusvariable()
    {
        error("Use of a non-overrided virtual function in _Rplusvariable");
    }
    virtual void set_Segmentvariable()
    {
        error("Use of a non-overrided virtual function in Segmentvariable");
    }
    virtual void set_Circularvariable()
    {
        error("Use of a non-overrided virtual function in Circularvariable");
    }
    virtual void set_RplusvariableDiscrete()
    {
        error("Use of a non-overrided virtual function in _Rplusvariable");
    }
    virtual void set_CircularDiscretevariable()
    {
        error("Use of a non-overrided virtual function in Circularvariable");
    }
    
//    virtual double compute_LogDensity(double *x, double * hyper){
//        error("Use of a non-overrided virtual function in Poly_Density");
//        return(1.0);
//    };
//    virtual double compute_LogDensity(int *x, double * hyper){
//        error("Use of a non-overrided virtual function in Poly_Density");
//        return(1.0);
//    };
//
//    virtual double compute_LogCumulative(double *x, double * hyper){
//        error("Use of a non-overrided virtual function in Cumulative");
//        return(1.0);
//    };
//    virtual double compute_LogCumulative(int *x, double * hyper){
//        error("Use of a non-overrided virtual function in Cumulative");
//        return(1.0);
//    };
    
	virtual double sample()
	{
		 error("Use of a non-overrided virtual function in sample");
		return(0.0);
	}
    
};

/*****************************************
Univariate - 
****************************************/

// TO be used for NA on  likelihood observations and MH on processes elements
class Class_UnSpecifiedPrior: public Poly_Prior
{
private:
    

    
public:
    
   

    
    
    //
    double (*compute_LogJacobian_BASE_P)(double *,Vector <double*> );
    double (*fromParameterToTransParameter_BASE_P)(double *,Vector <double*> );
    double (*fromTransParameterToParameter_BASE_P)(double *,Vector <double*> );
    
    int (*get_Discrete_P)();
    int (*get_Circular_P)();
    int (*get_nHyperparams_P)();
    vector<string> (*get_NameHyperparams_P)();
    
    
    // CONSTRUCTORS
    Class_UnSpecifiedPrior():Poly_Prior(),
    compute_LogJacobian_BASE_P(0),
    fromParameterToTransParameter_BASE_P(0),
    fromTransParameterToParameter_BASE_P(0),
    get_Discrete_P(0),
    get_Circular_P(0),
    get_nHyperparams_P(0),
    get_NameHyperparams_P(0){
        
        
    }
    
    // DESTRUCTORS
    ~Class_UnSpecifiedPrior(){};
  

    
    
    // set
    void set_Rvariable() override
    {
        compute_LogJacobian_BASE_P                = &compute_LogJacobian_BASE_R_To_R;
        fromParameterToTransParameter_BASE_P      = &fromParameterToTransParameter_BASE_R_To_R;
        fromTransParameterToParameter_BASE_P       = &fromTransParameterToParameter_BASE_R_To_R;
        get_nHyperparams_P                        = &get_nHyperparams_R;
        get_NameHyperparams_P                     = &get_NameHyperparams_R;
        get_Discrete_P                            = &get_Discrete_NoDiscrete;
        get_Circular_P                            = &get_Circular_NoCircular;
    }
    void set_Rplusvariable() override
    {
        compute_LogJacobian_BASE_P                = &compute_LogJacobian_BASE_Rplus_To_R;
        fromParameterToTransParameter_BASE_P      = &fromParameterToTransParameter_BASE_Rplus_To_R;
        fromTransParameterToParameter_BASE_P       = &fromTransParameterToParameter_BASE_R_To_Rplus;
        get_nHyperparams_P                        = &get_nHyperparams_Rplus;
        get_NameHyperparams_P                     = &get_NameHyperparams_Rplus;
        get_Discrete_P                            = &get_Discrete_NoDiscrete;
        get_Circular_P                            = &get_Circular_NoCircular;
    }
    void set_Segmentvariable()override
    {
        compute_LogJacobian_BASE_P                = &compute_LogJacobian_BASE_Segment_To_R;
        fromParameterToTransParameter_BASE_P      = &fromParameterToTransParameter_BASE_Segment_To_R;
        fromTransParameterToParameter_BASE_P       = &fromTransParameterToParameter_BASE_R_To_Segment;
        get_nHyperparams_P                        = &get_nHyperparams_Segment;
        get_NameHyperparams_P                     = &get_NameHyperparams_Segment;
        get_Discrete_P                            = &get_Discrete_NoDiscrete;
        get_Circular_P                            = &get_Circular_NoCircular;
    }
    void set_Circularvariable()override
    {
        compute_LogJacobian_BASE_P                = &compute_LogJacobian_BASE_R_To_R;
        fromParameterToTransParameter_BASE_P      = &fromParameterToTransParameter_BASE_R_To_R;
        fromTransParameterToParameter_BASE_P       = &fromTransParameterToParameter_BASE_R_To_R;
        get_nHyperparams_P                        = &get_nHyperparams_R;
        get_NameHyperparams_P                     = &get_NameHyperparams_R;
        get_Discrete_P                            = &get_Discrete_NoDiscrete;
        get_Circular_P                            = &get_Circular_Circular;
    }
    void set_RplusvariableDiscrete() override
    {
        //
        compute_LogJacobian_BASE_P                = &compute_LogJacobian_BASE_Rplus_To_R;
        fromParameterToTransParameter_BASE_P      = &fromParameterToTransParameter_BASE_Rplus_To_R;
        fromTransParameterToParameter_BASE_P       = &fromTransParameterToParameter_BASE_R_To_Rplus;
        get_nHyperparams_P                        = &get_nHyperparams_Rplus;
        get_NameHyperparams_P                     = &get_NameHyperparams_Rplus;
        get_Discrete_P                            = &get_Discrete_Discrete;
        get_Circular_P                            = &get_Circular_NoCircular;
    }
    void set_CircularDiscretevariable()override
    {
        compute_LogJacobian_BASE_P                = &compute_LogJacobian_BASE_R_To_R;
        fromParameterToTransParameter_BASE_P      = &fromParameterToTransParameter_BASE_R_To_R;
        fromTransParameterToParameter_BASE_P       = &fromTransParameterToParameter_BASE_R_To_R;
        get_nHyperparams_P                        = &get_nHyperparams_R;
        get_NameHyperparams_P                     = &get_NameHyperparams_R;
        get_Discrete_P                            = &get_Discrete_Discrete;
        get_Circular_P                            = &get_Circular_Circular;
    }
    
    // GET
    
    string get_NameDistr() override
    {
        string name = "UnSpecifiedPrior";
        return(name);
        
    }
    
    
    int  get_nHyperparams() override
    {
        return(get_nHyperparams_P());
    }

    vector<string>      get_NameHyperparams() override
    {
        return(get_NameHyperparams_P());
    }
    int get_discrete() override
    {
        return(get_Discrete_P());
    }
    int get_circular()  override
    {
        return(get_Circular_P());
    }
    
    
    double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper) override
    {
        return(0.0);
    }
    double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper) override
    {
        return(0.0);
    }
    double compute_LogJacobian_BASE(double *variable,Vector <double*> hyper) override
    {
        return(compute_LogJacobian_BASE_P(variable,hyper));
    }

   
    
    
    // FUNCTIONS
    double fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper) override
    {
        return(fromParameterToTransParameter_BASE_P(variable,hyper));
    }
    double fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper) override
    {
        return(fromTransParameterToParameter_BASE_P(transvariable,hyper));
    }
    double compute_LogDensity(double *x, double * hyper)
    {
        return(-1.0*INFINITY);
    }
	
//	virtual double sample() override
//	{
//		return(0.0);
//	}
    
    
};



class Class_NoPrior: public Poly_Prior
{
private:
    
    
    
public:
    
    // CONSTRUCTORS
    Class_NoPrior(): Poly_Prior(){}
    
    // DESTRUCTORS
    ~Class_NoPrior(){};

    // GET
    double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper) override;
    double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper) override;
    double compute_LogJacobian_BASE(double *variable,Vector <double*> hyper) override;
    
    Matrix<int> get_DimPar()
    {
        Matrix<int> app = Matrix<int>(1,2,0);
        return(app);
    }
    int  get_nHyperparams() override
    {
        return(1);
    }
    string get_NameDistr() override
    {
        string name = "NoPrior";
        return(name);
  
    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "Hyper_VOID";
        vector <string> ret;
        ret.push_back(par1);
        return(ret);
    }
    
    int get_discrete() override
    {
        return(0);
    }
    int get_circular() override
    {
        return(0);
    }
    
    
    // FUNCTIONS
    double fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper) override;
    double fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper) override;
    double compute_LogDensity(double *x, double * hyper);
    
//	virtual double sample() override
//	{
//		return(0.0);
//	}
    
};


class Class_WrappedNormal: public Poly_Prior
{
private:
    
    
    
public:
    
    // CONSTRUCTORS
    Class_WrappedNormal(): Poly_Prior(){}
    
    // DESTRUCTORS
    ~Class_WrappedNormal(){};

    
    // GET
    double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper) override;
    double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper) override;
    double compute_LogJacobian_BASE(double *variable,Vector <double*> hyper) override;
    
    int  get_nHyperparams() override
    {
        return(2);
    }
    string get_NameDistr() override
    {
        string name = "WrappedNormal";
        return(name);
        
    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "Hyper_mu";
        string par2 = "Hyper_sigma2";
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        return(ret);
    }
    Matrix<int> get_DimPar()
    {
        Matrix<int> app = Matrix<int>(2,2,0);
        app.Pmat(0,0)[0]   = 1;
        app.Pmat(0,1)[0]   = 1;
        
        app.Pmat(1,0)[0]   = 1;
        app.Pmat(1,1)[0]   = 1;
        return(app);
    }
    int get_discrete() override
    {
        return(0);
    }
    int get_circular() override
    {
        return(0);
    }
    
    // FUNCTIONS
    double fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper) override;
    double fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper) override;
    double compute_LogDensity(double *x, double * hyper);
	
	virtual double sample() override
	{
		double par1 = HyperparametersAcc.vec(0)[0];
		double par2 = HyperparametersAcc.vec(1)[0];
		return( Class_Utils::ModOp(rnorm(par1, pow(par2,0.5)), 2.0*M_PI));
	}
};




class Class_CircularUniform: public Poly_Prior
{
private:
    
    
    
public:
    
    // CONSTRUCTORS
    Class_CircularUniform(): Poly_Prior(){}
    
    // DESTRUCTORS
    ~Class_CircularUniform(){};
    
    
    // GET
    double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper) override;
    double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper) override;
    double compute_LogJacobian_BASE(double *variable,Vector <double*> hyper) override;
    
    int  get_nHyperparams() override
    {
        return(2);
    }
    string get_NameDistr() override
    {
        string name = "Class_CircularUniform";
        return(name);
        
    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "Lim1";
        string par2 = "Lim2";
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        return(ret);
    }
    Matrix<int> get_DimPar()
    {
        Matrix<int> app = Matrix<int>(2,2,0);
        app.Pmat(0,0)[0]   = 1;
        app.Pmat(0,1)[0]   = 1;
        
        app.Pmat(1,0)[0]   = 1;
        app.Pmat(1,1)[0]   = 1;
        return(app);
    }
    int get_discrete() override
    {
        return(0);
    }
    int get_circular() override
    {
        return(1);
    }
    
    // FUNCTIONS
    double fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper) override;
    double fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper) override;
    double compute_LogDensity(double *x, double * hyper);
	
	virtual double sample() override
	{
		return( runif(0.0,2.0*M_PI));
	}
};



class Class_Normal: public Poly_Prior
{
private:
    
    
    
public:
    
    // CONSTRUCTORS
    Class_Normal(): Poly_Prior(){}
    
    // DESTRUCTORS
    ~Class_Normal(){};

    
    // GET
    double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper) override;
    double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper) override;
    double compute_LogJacobian_BASE(double *variable,Vector <double*> hyper) override;
    int  get_nHyperparams() override
    {
        return(2);
    }
    string get_NameDistr() override
    {
        string name = "Normal";
        return(name);
        
    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "Hyper_mu";
        string par2 = "Hyper_sigma2";
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        return(ret);
    }
    Matrix<int> get_DimPar()
    {
        Matrix<int> app = Matrix<int>(2,2,0);
        app.Pmat(0,0)[0]   = 1;
        app.Pmat(0,1)[0]   = 1;
        
        app.Pmat(1,0)[0]   = 1;
        app.Pmat(1,1)[0]   = 1;
        return(app);
    }
    int get_discrete() override
    {
        return(0);
    }
    int get_circular() override
    {
        return(0);
    }
    
    // FUNCTIONS
    double fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper) override;
    double fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper) override;
    double compute_LogDensity(double *x, double * hyper);
	
	virtual double sample() override
	{
		double par1 = HyperparametersAcc.vec(0)[0];
		double par2 = HyperparametersAcc.vec(1)[0];
		return( rnorm(par1,pow(par2,0.5)));
	}
};



class Class_Binomial: public Poly_Prior
{
private:
    
    
    
public:
    
    // CONSTRUCTORS
    Class_Binomial(): Poly_Prior(){}
    
    // DESTRUCTORS
    ~Class_Binomial(){};
    
    
    // GET
    double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper) override;
    double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper) override;
    //double compute_LogJacobian_BASE(double *variable,Vector <double*> hyper) override;
    int  get_nHyperparams() override
    {
        return(2);
    }
    string get_NameDistr() override
    {
        string name = "Binomial";
        return(name);
        
    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "n";
        string par2 = "prob";
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        return(ret);
    }
    Matrix<int> get_DimPar()
    {
        Matrix<int> app = Matrix<int>(2,2,0);
        app.Pmat(0,0)[0]   = 1;
        app.Pmat(0,1)[0]   = 1;
        
        app.Pmat(1,0)[0]   = 1;
        app.Pmat(1,1)[0]   = 1;
        return(app);
    }
    int get_discrete() override
    {
        return(1);
    }
    int get_circular() override
    {
        return(0);
    }
    
    // FUNCTIONS
    //double fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper) override;
    //double fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper) override;
    double compute_LogDensity(double *x, double * hyper);
	virtual double sample() override
	{
		double par1 = HyperparametersAcc.vec(0)[0];
		double par2 = HyperparametersAcc.vec(1)[0];
		return( rbinom(par1,par2));
	}
};



class Class_Beta: public Poly_Prior
{
private:
    
    
    
public:
    
    // CONSTRUCTORS
    Class_Beta(): Poly_Prior(){}
    
    // DESTRUCTORS
    ~Class_Beta(){};

    
    // GET
    double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper) override;
    double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper) override;
    double compute_LogJacobian_BASE(double *variable,Vector <double*> hyper) override;
    int  get_nHyperparams() override
    {
        return(2);
    }
    string get_NameDistr() override
    {
        string name = "Beta";
        return(name);
        
    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "Hyper_a";
        string par2 = "Hyper_b";
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        return(ret);
    }
    Matrix<int> get_DimPar()
    {
        Matrix<int> app = Matrix<int>(2,2,0);
        app.Pmat(0,0)[0]   = 1;
        app.Pmat(0,1)[0]   = 1;
        
        app.Pmat(1,0)[0]   = 1;
        app.Pmat(1,1)[0]   = 1;
        return(app);
    }
    int get_discrete() override
    {
        return(0);
    }
    int get_circular() override
    {
        return(0);
    }
    
    // FUNCTIONS
    double fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper) override;
    double fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper) override;
    double compute_LogDensity(double *x, double * hyper);
	virtual double sample() override
	{
		double par1 = HyperparametersAcc.vec(0)[0];
		double par2 = HyperparametersAcc.vec(1)[0];
		return( rbeta(par1,par2));
	}
};






class Class_Gamma: public Poly_Prior
{
private:
    
public:
    // CONSTRUCTORS
    Class_Gamma(): Poly_Prior(){}
    
    // DESTRUCTORS
    ~Class_Gamma(){};

    
    // ADDS
    // GET
    double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper) override;
    double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper) override;
    double compute_LogJacobian_BASE(double *variable,Vector <double*> hyper) override;
    int  get_nHyperparams() override
    {
        return(2);
    }
    string get_NameDistr() override
    {
        string name = "Gamma";
        return(name);
        
    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "Hyper_alpha";
        string par2 = "Hyper_beta";
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        return(ret);
    }
    Matrix<int> get_DimPar()
    {
        Matrix<int> app = Matrix<int>(2,2,0);
        app.Pmat(0,0)[0]   = 1;
        app.Pmat(0,1)[0]   = 1;
        
        app.Pmat(1,0)[0]   = 1;
        app.Pmat(1,1)[0]   = 1;
        return(app);
    }
    
    int get_discrete() override
    {
        return(0);
    }
    int get_circular() override
    {
        return(0);
    }
    
    
    // FUNCTIONS
    double fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper) override;
    double fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper) override;
    double compute_LogDensity(double *x, double * hyper);
	virtual double sample() override
	{
		double par1 = HyperparametersAcc.vec(0)[0];
		double par2 = HyperparametersAcc.vec(1)[0];
		return( rgamma(par1,1.0/par2));
	}
};







class Class_InverseGamma: public Poly_Prior
{
private:
    
public:
    // CONSTRUCTORS
    Class_InverseGamma(): Poly_Prior(){}
    
    // DESTRUCTORS
    ~Class_InverseGamma(){};

    
    // ADDS
    // GET
    double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper) override;
    double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper) override;
    double compute_LogJacobian_BASE(double *variable,Vector <double*> hyper) override;
    int  get_nHyperparams() override
    {
        return(2);
    }
    string get_NameDistr() override
    {
        string name = "InverseGamma";
        return(name);
        
    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "Hyper_alpha";
        string par2 = "Hyper_beta";
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        return(ret);
    }
    Matrix<int> get_DimPar()
    {
        Matrix<int> app = Matrix<int>(2,2,0);
        app.Pmat(0,0)[0]   = 1;
        app.Pmat(0,1)[0]   = 1;
        
        app.Pmat(1,0)[0]   = 1;
        app.Pmat(1,1)[0]   = 1;
        return(app);
    }
    
    int get_discrete() override
    {
        return(0);
    }
    int get_circular() override
    {
        return(0);
    }
    
    
    // FUNCTIONS
    double fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper) override;
    double fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper) override;
    double compute_LogDensity(double *x, double * hyper);
	
	virtual double sample() override
	{
		double par1 = HyperparametersAcc.vec(0)[0];
		double par2 = HyperparametersAcc.vec(1)[0];
		return( 1.0/rgamma(par1,1.0/par2));
	}
};



class Class_TruncatedNormal: public Poly_Prior
{
private:
    
public:
    // CONSTRUCTORS
    Class_TruncatedNormal(): Poly_Prior(){}
    
    // DESTRUCTORS
    ~Class_TruncatedNormal(){};

    
    
  
  double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper) override;
  double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper) override;
  double compute_LogJacobian_BASE(double *variable,Vector <double*> hyper) override;
  
  int  get_nHyperparams() override
  {
      return(5);
  }
  string get_NameDistr() override
  {
      string name = "TruncatedNormal";
      return(name);
      
  }
  vector<string>      get_NameHyperparams() override
  {
    
    string par1 = "Hyper_mu";
    string par2 = "Hyper_sigma2";
    string par3 = "Hyper_a";
    string par4 = "Hyper_b";
    string par5 = "Hyper_type"; //0 left, 1, right, 2 both
    vector <string> ret;
    ret.push_back(par1);
    ret.push_back(par2);
    ret.push_back(par3);
    ret.push_back(par4);
    ret.push_back(par5);
    return(ret);
  }
  Matrix<int> get_DimPar()
  {
      Matrix<int> app = Matrix<int>(5,2,0);
      app.Pmat(0,0)[0]   = 1;
      app.Pmat(0,1)[0]   = 1;
      
      app.Pmat(1,0)[0]   = 1;
      app.Pmat(1,1)[0]   = 1;
    
    app.Pmat(2,0)[0]   = 1;
    app.Pmat(2,1)[0]   = 1;
    
    app.Pmat(3,0)[0]   = 1;
    app.Pmat(3,1)[0]   = 1;
    
    app.Pmat(4,0)[0]   = 1;
    app.Pmat(4,1)[0]   = 1;
      return(app);
  }
  
  int get_discrete() override
  {
      return(0);
  }
  int get_circular() override
  {
      return(0);
  }
  
  
  // FUNCTIONS
  double fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper) override;
  double fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper) override;
  double compute_LogDensity(double *x, double * hyper);
  
  
    //
    
    static double  sample(double mu, double sd, double trunc, int left_trunc);
    static double a_sample(double mu, double sd, double trunc)
    {
        return(sample(mu, sd, trunc, 1));
    }
    static double b_sample(double mu, double sd, double trunc)
    {
        return(sample(mu, sd, trunc, 0));
    }
    static double ab_sample(double mu, double sd, double a, double b);
    //static double truncated_normal_ab_sample ( double mu, double sigma, double a, double b,
     //                                  int &seed )
  
  
  static double compute_LogDensity_a(double x, double mu, double sd, double a)
  {
    return( dnorm(x,mu,sd,1)-pnorm(a,mu,sd,0,1));
  }
	
	virtual double sample() override
	{
		double par1 = HyperparametersAcc.vec(0)[0];
		double par2 = HyperparametersAcc.vec(1)[0];
		double par3 = HyperparametersAcc.vec(2)[0];
		double par4 = HyperparametersAcc.vec(3)[0];
		double par5 = HyperparametersAcc.vec(4)[0];
		if(par5<0.5)
		{
			return(a_sample(par1, pow(par2,0.5),par3));
		}else{
			if(par5>1.5)
			{
				return(b_sample(par1, pow(par2,0.5),par4));
			}else{
				return(ab_sample(par1, pow(par2,0.5),par3,par4));
			}
		}
		
	}

};




class Class_Uniform: public Poly_Prior
{
private:
    
public:
    // CONSTRUCTORS
    Class_Uniform(): Poly_Prior(){}
    
    // DESTRUCTORS
    ~Class_Uniform(){};

    
    // ADDS
    // GET
    double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper) override;
    double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper) override;
    double compute_LogJacobian_BASE(double *variable,Vector <double*> hyper) override;
    int  get_nHyperparams() override
    {
        return(2);
    }
    string get_NameDistr() override
    {
        string name = "Uniform";
        return(name);
        
    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "Hyper_min";
        string par2 = "Hyper_max";
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        return(ret);
    }
    Matrix<int> get_DimPar()
    {
        Matrix<int> app = Matrix<int>(2,2,0);
        app.Pmat(0,0)[0]   = 1;
        app.Pmat(0,1)[0]   = 1;
        
        app.Pmat(1,0)[0]   = 1;
        app.Pmat(1,1)[0]   = 1;
        return(app);
    }
    
    int get_discrete() override
    {
        return(0);
    }
    int get_circular() override
    {
        return(0);
    }
    
    
    // FUNCTIONS
    double fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper) override;
    double fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper) override;
    double compute_LogDensity(double *x, double * hyper);
	 virtual double sample() override
	 {
		 double par1 = HyperparametersAcc.vec(0)[0];
		 double par2 = HyperparametersAcc.vec(1)[0];
		 return( runif(par1,par2));
	 }
};





class Class_DiscreteUniformInteger: public Poly_Prior
{
private:
    
public:
    // CONSTRUCTORS
    Class_DiscreteUniformInteger(): Poly_Prior(){}
    
    // DESTRUCTORS
    ~Class_DiscreteUniformInteger(){};

    
    string get_NameDistr()  override
    {
        string name = "DiscreteUniformInteger";
        return(name);
        
    }
    int  get_nHyperparams() override
    {
        return(3);
    }

    
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "Min";
        string par2 = "Max";
        string par3 = "Nval";
        
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        ret.push_back(par3);
        return(ret);
    }

    int get_discrete() override
    {
        return(1);
    }
    int get_circular() override
    {
        return(0);
    }
    
    double compute_NoNormlogDensity_forVariable_BASE(int n,int *variable,Vector <double*> hyper) override;
    double compute_NoNormlogDensity_forVariable_BASE(int *variable,Vector <double*> hyper) override;
    double compute_LogDensity(int *x, double * hyper);
    double compute_LogCumulative(int *x, double * hyper);
    
    double compute_logDensity_BASE(double *variable,Vector <double*> hyper) override;
    double compute_logCumulative_BASE(double *variable,Vector <double*> hyper) override;
	
    
};


class Class_Poisson: public Poly_Prior
{
private:
    
public:
    // CONSTRUCTORS
    Class_Poisson(): Poly_Prior(){}
    
    // DESTRUCTORS
    ~Class_Poisson(){};
  
    
    int  get_nHyperparams() override
    {
        return(1);
    }
    string get_NameDistr()  override
    {
        string name = "Poisson";
        return(name);
        
    }

    vector<string>      get_NameHyperparams() override
    {
        string par1 = "Lambda";
        vector <string> ret;
        ret.push_back(par1);
        return(ret);
    }
    
    int get_discrete() override
    {
        return(1);
    }
    int get_circular() override
    {
        return(0);
    }
    double compute_NoNormlogDensity_forVariable_BASE(int n,int *variable,Vector <double*> hyper) override;
    double compute_NoNormlogDensity_forVariable_BASE(int *variable,Vector <double*> hyper) override;
    double compute_LogDensity(int *x, double * hyper);
    double compute_LogCumulative(int *x, double * hyper);
    
    double compute_logDensity_BASE(double *variable,Vector <double*> hyper) override;
    double compute_logCumulative_BASE(double *variable,Vector <double*> hyper) override;
	
	virtual double sample() override
	{
		double par1 = HyperparametersAcc.vec(0)[0];
		return( rpois((par1)));
	}
    
};



class Class_Geometric: public Poly_Prior
{
private:
    
public:
    // CONSTRUCTORS
    Class_Geometric(): Poly_Prior(){}
    
    // DESTRUCTORS
    ~Class_Geometric(){};

    
    int  get_nHyperparams() override
    {
        return(1);
    }
    
    string get_NameDistr()  override
    {
        string name = "Poisson";
        return(name);
        
    }
    
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "Pi";
        vector <string> ret;
        ret.push_back(par1);
        return(ret);
    }
    
    int get_discrete() override
    {
        return(1);
    }
    int get_circular() override
    {
        return(0);
    }
    double compute_NoNormlogDensity_forVariable_BASE(int n,int *variable,Vector <double*> hyper) override;
    double compute_NoNormlogDensity_forVariable_BASE(int *variable,Vector <double*> hyper) override;
    double compute_LogDensity(int *x, double * hyper);
    double compute_LogCumulative(int *x, double * hyper);
    
    double compute_logDensity_BASE(double *variable,Vector <double*> hyper) override;
    double compute_logCumulative_BASE(double *variable,Vector <double*> hyper) override;
};




class Class_ChiSquared: public Poly_Prior
{
private:
    
public:
    // CONSTRUCTORS
    Class_ChiSquared(): Poly_Prior(){}
    
    // DESTRUCTORS
    ~Class_ChiSquared(){};

    // ADDS
    // GET
    
    double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper) override;
    double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper) override;
    double compute_LogJacobian_BASE(double *variable,Vector <double*> hyper) override;
    int  get_nHyperparams() override
    {
        return(1);
    }
    string get_NameDistr()  override
    {
        string name = "ChiSquared";
        return(name);
        
    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "D.o.f.";
        vector <string> ret;
        ret.push_back(par1);
        return(ret);
    }
    Matrix<int> get_DimPar()
    {
        Matrix<int> app = Matrix<int>(2,2,0);
        app.Pmat(0,0)[0]   = 1;
        app.Pmat(0,1)[0]   = 1;
        
        app.Pmat(1,0)[0]   = 1;
        app.Pmat(1,1)[0]   = 1;
        return(app);
    }
    
    
    int get_discrete() override
    {
        return(0);
    }
    int get_circular() override
    {
        return(0);
    }
    
    
    // FUNCTIONS
    double fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper) override;
    double fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper) override;
    double compute_LogDensity(double *x, double * hyper);
    
};









class Class_Categorial: public Poly_Prior
{
private:
    
public:
    
    int nClasses;
    
    // CONSTRUCTORS
    Class_Categorial(): Poly_Prior(){
       // nClasses = 0;
    }
    
    // DESTRUCTORS
    ~Class_Categorial(){};

    // ADDS
    void add_nClasses(int k)
    {
        nClasses = k;
    }
    
    // GET
    double compute_NoNormlogDensity_forVariable_BASE(int n,int *variable,Vector <double*> hyper) override;
    double compute_NoNormlogDensity_forVariable_BASE(int *variable,Vector <double*> hyper) override;

    int  get_nHyperparams(int k)  override
    {
        return(k);
    }
    string get_NameDistr(int k) override
    {
        string name = "Categorial";
        return(name);
        
    }
    vector<string>      get_NameHyperparams(int k) override;
    Matrix<int> get_DimPar(int k)
    {
        Matrix<int> app = Matrix<int>(k,2,0);
        for(int i=0;i<k;i++)
        {
            app.Pmat(i,0)[0]   = 1;
            app.Pmat(i,1)[0]   = 1;
        }
        return(app);
    }
    // FUNCTIONS
    double compute_LogDensity(int *x, double * hyper);
    
    
    
    //
    static int external_sampleCatagorial(double *logprob_NonNormalized, int K)
    {
        int k;
        double sum = 0.0;;
        double prob[K];
        Class_Utils::log_sum_exp(&sum, K, logprob_NonNormalized);
        
        for(k=0;k<K;k++)
        {
            prob[k] = exp(logprob_NonNormalized[k]-sum);
        }
        
        double u = runif(0.0,1.0);
        //Rprintf("u %f ",u);
        sum = 0.0;
        k = -1;
        do{
            k++;
            sum += prob[k];
            //Rprintf("%f ",sum );
        }while(sum<u);
        
        //Rprintf("K=%i\n",k);
        return(k);
    }
    
};












/*****************************************
 Parameters
 ****************************************/

class Class_Parameter
{
private:
    
public:
    double ParameterAcc;
    double ParameterProp;
    
    int isDiscrete;
    int isCircular;
    
    string NameParameter;
    
    Poly_Prior *PriorParameter;
    
    double *AddressAccExt;
    double *AddressPropExt;
    
    // OCSTRUCTORS
    Class_Parameter():
    ParameterAcc(0.0),
    ParameterProp(0.0),
    isDiscrete(0),
    isCircular(0),
    PriorParameter(0),
    AddressAccExt(0),
    AddressPropExt(0)
    {

    };
    
    // DESTROCTORS
    ~Class_Parameter(){};


    // PrintObject
    void PrintObject(string ToPrint)
    {
        Rprintf("\n\n\n%s\n",ToPrint.c_str());
        Rprintf("Parameter %s\n", NameParameter.c_str());
        Rprintf("Acc %f Prop %f\n",ParameterAcc,ParameterProp);
        Rprintf("AccExt %f PropExt %f\n",AddressAccExt[0],AddressPropExt[0]);
        Rprintf("Acc %p Prop %p\n",&ParameterAcc,&ParameterProp);
         Rprintf("AccExt %p PropExt %p\n",AddressAccExt,AddressPropExt);
        PriorParameter->PrintObject("Prior");
    }
    
    // CREATE
    void create_FullObject(double par,const string name, Poly_Prior *prior)
    {
        // ricordarsi che la whishart no usa l costruttore create_FullObject
        ParameterAcc        = par;
        ParameterProp       = par;
        
        PriorParameter      = prior;
        NameParameter       = name;

        
        AddressPropExt      = &ParameterProp;
        AddressAccExt       = &ParameterAcc;
        
        
        isDiscrete          = PriorParameter->get_discrete();
        isCircular          = PriorParameter->get_circular();
      // Rprintf("%p %p\n", AddressPropExt, &ParameterProp);
        
    }
//    void create_FullObject(double par, string name, Poly_Prior *prior, double *accext, double *propext)
//    {
//        // ricordarsi che la whishart no usa l costruttore create_FullObject
//        // Ma serve?? funziona??
//
//        ParameterAcc        = par;
//        ParameterProp       = par;
//
//        PriorParameter      = prior;
//        NameParameter       = name;
//
//
//        AddressPropExt      = propext;
//        AddressAccExt       = accext;
//
//        isDiscrete          = PriorParameter->get_discrete();
//        isCircular          = PriorParameter->get_circular();
//    }
    
//    void create_FullObject(double &AddressParAcc, string name, Poly_Prior *prior)
//    {
//        
//
//        ParameterAcc        = AddressParAcc;
//        ParameterProp       = *AddressParAcc;
//        
//        PriorParameter      = prior;
//        NameParameter       = name;
//        
//        
////        AddressPropExt      = propext;
////        AddressAccExt       = accext;
//        
//        isDiscrete          = PriorParameter->get_discrete();
//        isCircular          = PriorParameter->get_circular();
//    }

    
    
    void add_Pointerparameters_InVector()
    {
        AddressPropExt      = &ParameterProp;
        AddressAccExt       = &ParameterAcc;
    }
    
    
    // ADDS
    void add_RandomHyper(Class_Parameter *hyperprior, int n_hyper)
    {
        PriorParameter[0].NameParameters[n_hyper] = PriorParameter[0].NameParameters[n_hyper]+"_Random";
        PriorParameter->HyperparametersAcc.Pvec(n_hyper)[0] = &(hyperprior->ParameterAcc);
        PriorParameter->HyperparametersProp.Pvec(n_hyper)[0] = &(hyperprior->ParameterProp);
    }
    
    // GET
    double compute_NoNormlogDensity_forVariable_DiffPropLessAcc();
    double compute_LogJacobian_DiffPropLessAcc();
    
    double compute_logDensityAcc();
    double compute_logCumulativeAcc();
    
    double compute_logDensityProp();
    double compute_logCumulativeProp();
    
    double compute_logDensityAccHyperProp();
    double compute_logCumulativeAccHyperProp();
    
    //**** update
    void update_ParameterAcc_FromTransParameterAcc(double *transvariable);
    void update_ParameterProp_FromTransParameterProp(double *transvariable);
    void update_TransParameterAcc_FromParameterAcc(double *transvariable);
    void update_TransParameterProp_FromParameterProp(double *transvariable);
	
	void sample()
	{
		ParameterAcc = PriorParameter->sample();
	}
   // double fromParameterToTransParameterProp(double *variable,Vector <double*> hyper);
    
};






/*****************************************
 Covariance matrices
 ****************************************/


class Poly_PriorPDmatrix
{
private:
    
public:
    int UserControlledMemory;
    int Dim;
    
    int nHyperparams;
    double                      *nuAcc;
    Matrix <double>*            PsiAcc;
    
    Vector <double>*            Par1Acc;
    Vector <double>*            Par2Acc;

    
    double                      *nuProp;
    Matrix <double>                *PsiProp;
    
    Vector <double>*            Par1Prop;
    Vector <double>*            Par2Prop;
    
    string NamePrior;
    vector <string> NameParameters;
    
    //CONSTRUCTORS
    Poly_PriorPDmatrix(): UserControlledMemory(1){}
    
    //DESTRUCTORS
    ~Poly_PriorPDmatrix(){};

    
    
    void create_FullObject(int usr, int dim)
    {
        Dim                     = dim;
        for(int i=1;i<Dim;i++)
        {
            
        }
        //UserControlledMemory    = usr;
        nHyperparams            = get_nHyperparams();
        NameParameters          = get_NameHyperparams();
        NamePrior               = get_NameDistr();
        
        PsiAcc                  = new Matrix<double>(Dim,Dim,UserControlledMemory);
        PsiProp                 = new Matrix<double>(Dim,Dim,UserControlledMemory);

        nuAcc                   = new double;
        nuProp                   = new double;
        
        Par1Acc                  = new Vector<double>(Dim,UserControlledMemory);
        Par2Acc                 = new Vector<double>(Dim,UserControlledMemory);
        
        Par1Prop                  = new Vector<double>(Dim,UserControlledMemory);
        Par2Prop                 = new Vector<double>(Dim,UserControlledMemory);
    }

    //virtual void get_CompanionParameters(double *hyperalpha)=0;
//    {
//        error("Use of a non-overrided virtual function in Poly_PriorPDmatrix");
//    }
    
    
    // GET
    virtual int                 get_nHyperparams(){
        error("Use of a non-overrided virtual function in Poly_PriorPDmatrix");
        return(1);
    };
    virtual string              get_NameDistr(){
        error("Use of a non-overrided virtual function in Poly_PriorPDmatrix");
        return("a");
    };
    virtual vector<string>      get_NameHyperparams(){
        error("Use of a non-overrided virtual function in Poly_PriorPDmatrix");
        vector <string> app;
        return(app);
    };
    
    
    
};

class Class_Ind_InvGamma: public Poly_PriorPDmatrix
{
private:
    
public:
    
    //CONSTRUCTORS
    Class_Ind_InvGamma(): Poly_PriorPDmatrix(){}
    
    //DESTRUCTORS
    ~Class_Ind_InvGamma(){};
    
    int  get_nHyperparams() override
    {
        return(2);
    }
    string get_NameDistr()  override
    {
        string name = "Ind_InvGamma";
        return(name);
        
    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "a";
        string par2 = "b";
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        return(ret);
    }
    
};

class Class_InverseWishart: public Poly_PriorPDmatrix
{
private:
    
public:

    //CONSTRUCTORS
    Class_InverseWishart(): Poly_PriorPDmatrix(){}
    
    //DESTRUCTORS
    ~Class_InverseWishart(){};
    
    
    int  get_nHyperparams() override
    {
        return(2);
    }
    string get_NameDistr()  override
    {
        string name = "InverseWishart";
        return(name);
        
    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "nu";
        string par2 = "Psi";
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        return(ret);
    }
    
    
//    static void  sampleInvWishart(int dim,Matrix<double> *des, Matrix<double> *desInv, Matrix<double> *MatPar, double parscal)
//    {
//        
////        Class_InverseWishart::sampleInvWishart(nVars,&CovMat[0][k].SigmaAcc,&CovMat[0][k].SigmaAccInv, &CovMat[0][k].PriorParameter->PsiAcc[0], CovMat[0][k].PriorParameter->nuAcc[0]);
//        /*
//         Inverse wishart simulation
//         
//         */
//        
//        int i,j,t;
//        //int info;
//        //int powdim = dim*dim;
//        double Done = 1.0;
//        int Ione = 1;
//        
//        
//        double AppWish_P[dim];
//        Vector<double> AppWish(dim,AppWish_P);
//        
//        double ZeroMean_P[dim];
//        Vector<double> ZeroMean(dim,ZeroMean_P);
//        ZeroMean.Init(0.0);
//        //Rprintf("Col0\n");
//        Class_Utils::external_computeCholesky(MatPar);
//        Class_Utils::external_computeInverseFromCholesky(MatPar);
//        Class_Utils::external_computeCholesky(MatPar);
//        //Rprintf("Col1\n");
//        for(i=0;i<dim;i++)
//        {
//            for(j=0;j<dim;j++)
//            {
//                desInv->Pmat(i,j)[0] = 0.0;
//            }
//        }
//        for(t=0;t<parscal+dim;t++)
//        {
//            //double Done = 1.0;
//            //int Ione = 1;
//            for(i=0;i<AppWish.nElem;i++)
//            {
//                AppWish.Pvec(i)[0] = rnorm(0.0,1.0);
//            }
////AppWish.Print("App0");
//            F77_NAME(dtrmv)("L", "N", "N", &AppWish.nElem, MatPar->P, &AppWish.nElem, AppWish.P, &Ione);
//            //AppWish.Print("App");
//            F77_NAME(daxpy)(&AppWish.nElem, &Done, ZeroMean.P, &Ione, AppWish.P, &Ione);
////AppWish.Print("App2");
//
//            for(i=0;i<dim;i++)
//            {
//                for(j=i;j<dim;j++)
//                {
//                    desInv->Pmat(i,j)[0] += AppWish.vec(i)*AppWish.vec(j);
//                }
//            }
//        }
//        //Rprintf("Col3\n");
//        for(i=0;i<dim;i++)
//        {
//            for(j=i;j<dim;j++)
//            {
//                des->Pmat(i,j)[0] = desInv->Pmat(i,j)[0];
//            }
//        }
////        des->Print("Des");
////        Rprintf("Col4\n");
//        Class_Utils::external_computeCholesky(des);
//        Class_Utils::external_computeInverseFromCholesky(des);
//        //Rprintf("Col5\n");
//        
//        
//    }
	
	
	static void  sampleInvWishartPsiDiag(int dim,Matrix<double> *des, Matrix<double> *desInv, Matrix<double> *MatPar_MotMod, double parscal)
		  {
				
			  
			  
//	 string NAMEdir = "/work/gmastrantonio/ODE/lancio/";
//	 #ifdef _OPENMP
//	 string appNamedir = (NAMEdir+to_string(omp_get_thread_num())+"IWDIAG.txt");
//	 #else
//	 string appNamedir = (NAMEdir+to_string(0)+".txt");
//	 #endif
//	 FILE * (file);
//	 time_t my_time = time(NULL);
//	 
//	 file = fopen(appNamedir.c_str(),"wt");
//	 fprintf(file,"%s", ctime(&my_time)); 
//	 fprintf(file, "start\n \n");
//	 fclose (file);
				
				int i,j,t;
				//int info;
				//int powdim = dim*dim;
				double Done = 1.0;
				int Ione = 1;
				
				
				double AppWish_P[dim];
				Vector<double> AppWish(dim,AppWish_P);
				
				//double ZeroMean_P[dim];
				//Vector<double> ZeroMean(dim,ZeroMean_P);
				//ZeroMean.Init(0.0);
				//Rprintf("Col0\n");
			  
			  double MatPar_P[dim*dim];
			  Matrix <double>MatPar(dim,dim,&MatPar_P[0]);
			  MatPar.Init(0.0);
			 
			  
				//Class_Utils::external_computeCholesky(MatPar);
				//Class_Utils::external_computeInverseFromCholesky(MatPar);
				//Class_Utils::external_computeCholesky(MatPar);
			  
				//Rprintf("Col1\n");
				for(i=0;i<dim;i++)
				{
					 for(j=0;j<dim;j++)
					 {
						  desInv->Pmat(i,j)[0] = 0.0;
					 }
					MatPar.Pmat(i,i)[0] = 1.0/pow(MatPar_MotMod->Pmat(i,i)[0],0.5);
				}
				for(t=0;t<floor(parscal+0.5)+dim;t++)
				{
					 //double Done = 1.0;
					 //int Ione = 1;
					 for(i=0;i<AppWish.nElem;i++)
					 {
						  AppWish.Pvec(i)[0] = rnorm(0.0,1.0);
					 }
	 //AppWish.Print("App0");
					 F77_NAME(dtrmv)("L", "N", "N", &AppWish.nElem, MatPar.P, &AppWish.nElem, AppWish.P, &Ione);
					 //AppWish.Print("App");
					 //F77_NAME(daxpy)(&AppWish.nElem, &Done, ZeroMean.P, &Ione, AppWish.P, &Ione);
	 //AppWish.Print("App2");

					 for(i=0;i<dim;i++)
					 {
						  for(j=i;j<dim;j++)
						  {
								desInv->Pmat(i,j)[0] += AppWish.vec(i)*AppWish.vec(j);
						  }
					 }
				}
				//Rprintf("Col3\n");
				for(i=0;i<dim;i++)
				{
					 for(j=i;j<dim;j++)
					 {
						  des->Pmat(i,j)[0] = desInv->Pmat(i,j)[0];
					 }
				}

			  Class_Utils::external_computeCholesky(des);
//			  int info;
//			  Matrix<double> * Sigma = des;
//			  F77_NAME(dpotrf)("L",&Sigma->nCols, Sigma->P, &Sigma->nCols, &info);
//			  if(info != 0)
//			  {
//					if(Sigma->nRows==1)
//					{
//						 Sigma->Pmat(0,0)[0] = pow(Sigma->Pmat(0,0)[0],0.5);
//					}else{
//						des->Print("des");
//						desInv->Print("desInv");
//						MatPar.Print("MatPar");
//						AppWish.Print("AppWish");
//						 error("Cpp error Cholesky failed - function: external_computeCholesk TEST1 \n %i %i %f %i %p %p %p %p ",Sigma->nRows,Sigma->nCols,parscal,dim, des,des->P, Sigma,Sigma->P);
//					}
//					
//			  }
				Class_Utils::external_computeInverseFromCholesky(des);
				//Rprintf("Col5\n");
			 
			  
//			  file = fopen(appNamedir.c_str(),"wt");
//			  fprintf(file,"%s", ctime(&my_time)); 
//			  fprintf(file, "end\n \n");
//			  fclose (file);
				
		  }
	
	
	static void  sampleInvWishart(int dim,Matrix<double> *des, Matrix<double> *desInv, Matrix<double> *MatPar, double parscal)
		 {
			  
			 
//			 
//	string NAMEdir = "/work/gmastrantonio/ODE/lancio/";
//	#ifdef _OPENMP
//	string appNamedir = (NAMEdir+to_string(omp_get_thread_num())+"IW.txt");
//	#else
//	string appNamedir = (NAMEdir+to_string(0)+".txt");
//	#endif
//	FILE * (file);
//	time_t my_time = time(NULL);
	
//	file = fopen(appNamedir.c_str(),"wt");
//	fprintf(file,"%s", ctime(&my_time)); 
//	fprintf(file, "start\n \n");
//	fclose (file);
			  
			  int i,j,t;
			  //int info;
			  //int powdim = dim*dim;
			  double Done = 1.0;
			  int Ione = 1;
			  
			  
			  double AppWish_P[dim];
			  Vector<double> AppWish(dim,AppWish_P);
			  
			  double ZeroMean_P[dim];
			  Vector<double> ZeroMean(dim,ZeroMean_P);
			  ZeroMean.Init(0.0);
			  //Rprintf("Col0\n");
			  Class_Utils::external_computeCholesky(MatPar);
			  Class_Utils::external_computeInverseFromCholesky(MatPar);
			  Class_Utils::external_computeCholesky(MatPar);
			 
			  //Rprintf("Col1\n");
			  for(i=0;i<dim;i++)
			  {
					for(j=0;j<dim;j++)
					{
						 desInv->Pmat(i,j)[0] = 0.0;
					}
			  }
			  for(t=0;t<parscal+dim;t++)
			  {
					//double Done = 1.0;
					//int Ione = 1;
					for(i=0;i<AppWish.nElem;i++)
					{
						 AppWish.Pvec(i)[0] = rnorm(0.0,1.0);
					}
	//AppWish.Print("App0");
					F77_NAME(dtrmv)("L", "N", "N", &AppWish.nElem, MatPar->P, &AppWish.nElem, AppWish.P, &Ione);
					//AppWish.Print("App");
					//F77_NAME(daxpy)(&AppWish.nElem, &Done, ZeroMean.P, &Ione, AppWish.P, &Ione);
	//AppWish.Print("App2");

					for(i=0;i<dim;i++)
					{
						 for(j=i;j<dim;j++)
						 {
							  desInv->Pmat(i,j)[0] += AppWish.vec(i)*AppWish.vec(j);
						 }
					}
			  }
			  //Rprintf("Col3\n");
			  for(i=0;i<dim;i++)
			  {
					for(j=i;j<dim;j++)
					{
						 des->Pmat(i,j)[0] = desInv->Pmat(i,j)[0];
					}
			  }
	//        des->Print("Des");
	//        Rprintf("Col4\n");
			  Class_Utils::external_computeCholesky(des);
			  Class_Utils::external_computeInverseFromCholesky(des);
			  //Rprintf("Col5\n");
			
//			 
//			 file = fopen(appNamedir.c_str(),"wt");
//			 fprintf(file,"%s", ctime(&my_time)); 
//			 fprintf(file, "end\n \n");
//			 fclose (file);
			  
		 }
  
  
  
  static void  sampleInvWishart(int dim,Matrix<double> *des, Matrix<double> *desInv,Matrix<double> *desChol,double *logDet, Matrix<double> *MatPar, double parscal)
      {
			
			
			
          //      SS = riwish(10,diag(1,3))
          //      SSinv = solve(SS)
          //      chol(SS)
          //      t(solve(chol(SSinv[3:1,3:1]))[3:1,3:1])
  //        
          
          int i,j,t;
          //int info;
          //int powdim = dim*dim;
          double Done = 1.0;
          int Ione = 1;
          
          
          double AppWish_P[dim];
          Vector<double> AppWish(dim,AppWish_P);
          
          //double ZeroMean_P[dim];
          //Vector<double> ZeroMean(dim,ZeroMean_P);
          //ZeroMean.Init(0.0);
          //Rprintf("Col0\n");
          Class_Utils::external_computeCholesky(MatPar);
          Class_Utils::external_computeInverseFromCholesky(MatPar);
          Class_Utils::external_computeCholesky(MatPar);
          //Rprintf("Col1\n");
          for(i=0;i<dim;i++)
          {
              for(j=0;j<dim;j++)
              {
                  desInv->Pmat(i,j)[0] = 0.0;
              }
          }
          for(t=0;t<parscal+dim;t++)
          {
              //double Done = 1.0;
              //int Ione = 1;
              for(i=0;i<AppWish.nElem;i++)
              {
                  AppWish.Pvec(i)[0] = rnorm(0.0,1.0);
              }
  //AppWish.Print("App0");
              F77_NAME(dtrmv)("L", "N", "N", &AppWish.nElem, MatPar->P, &AppWish.nElem, AppWish.P, &Ione);
              //AppWish.Print("App");
              //F77_NAME(daxpy)(&AppWish.nElem, &Done, ZeroMean.P, &Ione, AppWish.P, &Ione);
  //AppWish.Print("App2");

              for(i=0;i<dim;i++)
              {
                  for(j=i;j<dim;j++)
                  {
                      desInv->Pmat(i,j)[0] += AppWish.vec(i)*AppWish.vec(j);
                  }
              }
          }
          //Rprintf("Col3\n");
          for(i=0;i<dim;i++)
          {
              for(j=i;j<dim;j++)
              {
                  des->Pmat(i,j)[0] = desInv->Pmat(i,j)[0];
              }
          }
  //        des->Print("Des");
  //        Rprintf("Col4\n");
          Class_Utils::external_computeCholesky(des);
          Class_Utils::external_computeInverseFromCholesky(des);
          //Rprintf("Col5\n");
          
          
      }
    // hyperalpha is a fake parameters
   // void get_CompanionParameters(double *hyperalpha);
	static void  compute_logdensity_noNorm(double *ret,Matrix<double> &Sigma, Matrix<double> &SigmaInv, double &logdet, Matrix<double> &Psi,double &nu)
	{
		// psi diagonale
		int p = Sigma.nRows;
		ret[0] = -0.5*(p+nu-1)*logdet;
		for(int i=0;i<p;i++)
		{
			ret[0] += -0.5*Psi.mat(i,i)*SigmaInv.mat(i,i);
		}
	}
    
};




class Class_HuangWand: public Poly_PriorPDmatrix
{
private:
    
public:
    
    //CONSTRUCTORS
    Class_HuangWand(): Poly_PriorPDmatrix(){}
    
    //DESTRUCTORS
    ~Class_HuangWand(){};
    
    int  get_nHyperparams() override
    {
        return(2);
    }
    string get_NameDistr()  override
    {
        string name = "HuangWand";
        return(name);
        
    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "nu";
        string par2 = "Psi";
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        return(ret);
    }
    
   // void get_CompanionParameters(double *hyperalpha);
    
    
    
    
};




/****/


class Class_Parameter_Matrix{
private:
    
public:
    int UserControlledMemory;
    int Dim;
    Matrix<double> SigmaAcc;
    Matrix<double> SigmaProp;
    
    
    
    string NameParameter;
    Poly_PriorPDmatrix  *PriorParameter;
    
    // COSTRUCTORS
    Class_Parameter_Matrix(): UserControlledMemory(1){};
    
    // DESTROCTORS
    ~Class_Parameter_Matrix(){};

    
    // CREATE
    void create_FullObject(Matrix<double>*sigma, const string name, Poly_PriorPDmatrix *prior, int usr)
    {
        //UserControlledMemory    = usr;
        PriorParameter          = prior;
        NameParameter           = name;
        Dim                     = prior->Dim;
        
        
        SigmaAcc            = Matrix <double> (Dim,Dim,UserControlledMemory);
        SigmaProp           = Matrix <double> (Dim,Dim,UserControlledMemory);
        
        for(int i=0;i<Dim;i++)
        {
            for(int j=0;j<Dim;j++)
            {
                SigmaAcc.Pmat(i,j)[0]   = sigma[0].mat(i,j);
                SigmaProp.Pmat(i,j)[0]  = sigma[0].mat(i,j);
            }
        }
    }
    //
    //    // UPDATE
    //    update_parGammaparAlpha_fromExternalSigmaparAlpha_BASE(Vector<double> *parsigma2, Vector<double> *pargamma,Vector<double> *paralpha, Matrix<double> *matrixA, Matrix<double>  *matrixL, Matrix<double> *sigma, Matrix<double> * chol, Matrix<double> *inv, double *logdet, double *sigmaext);
    
    
    
};



class Class_Parameter_PDMatrix{
private:
    
public:
    int UserControlledMemory;
    int Dim;
    Matrix<double> SigmaAcc;
    Matrix<double> SigmaProp;
    Matrix<double> SigmaAccInv;
    Matrix<double> SigmaPropInv;
    Matrix<double> SigmaCholAcc;
    Matrix<double> SigmaCholProp;
    
    double logdetAcc;
    double logdetProp;
    
    
    
    string NameParameter;
    Poly_PriorPDmatrix  *PriorParameter;
    
    // COSTRUCTORS
    Class_Parameter_PDMatrix(): UserControlledMemory(1){};
    
    // DESTROCTORS
    ~Class_Parameter_PDMatrix(){};

    
    // CREATE
    void create_FullObject(Matrix<double>*sigma, const string name, Poly_PriorPDmatrix *prior, int usr)
    {
        //UserControlledMemory    = usr;
        PriorParameter          = prior;
        NameParameter           = name;
        Dim                     = prior->Dim;
    
        
        SigmaAcc            = Matrix <double> (Dim,Dim,UserControlledMemory);
        SigmaProp           = Matrix <double> (Dim,Dim,UserControlledMemory);
        
        SigmaCholAcc            = Matrix <double> (Dim,Dim,UserControlledMemory);
        SigmaCholProp           = Matrix <double> (Dim,Dim,UserControlledMemory);
        
        SigmaAccInv            = Matrix <double> (Dim,Dim,UserControlledMemory);
        SigmaPropInv           = Matrix <double> (Dim,Dim,UserControlledMemory);
        
        for(int i=0;i<Dim;i++)
        {
            for(int j=0;j<Dim;j++)
            {
                SigmaAcc.Pmat(i,j)[0]   = sigma[0].mat(i,j);
                SigmaProp.Pmat(i,j)[0]  = sigma[0].mat(i,j);
            }
        }
    }

    void compute_InvAcc()
    {
        for(int i=0;i<Dim;i++)
        {
            for(int j=i;j<Dim;j++)
            {
                SigmaAccInv.Pmat(i,j)[0]   = SigmaAcc.Pmat(i,j)[0];
            }
        }
        Class_Utils::external_computeCholesky(&SigmaAccInv);
        logdetAcc = 0;
        for(int i =0;i<Dim;i++)
        {
            logdetAcc += 2.0*log(SigmaAccInv.mat(i,i));
        }
        
        Class_Utils::external_computeInverseFromCholesky(&SigmaAccInv);
    }
    void compute_InvAccAndChol()
    {
        for(int i=0;i<Dim;i++)
        {
            for(int j=i;j<Dim;j++)
            {
                SigmaAccInv.Pmat(i,j)[0]   = SigmaAcc.Pmat(i,j)[0];
            }
        }
		 
        Class_Utils::external_computeCholesky(&SigmaAccInv);
		 
		 
        for(int i=0;i<Dim;i++)
        {
            for(int j=i;j<Dim;j++)
            {
                SigmaCholAcc.Pmat(i,j)[0]   = SigmaAccInv.Pmat(i,j)[0];
            }
        }

        logdetAcc = 0;
        for(int i =0;i<Dim;i++)
        {
            logdetAcc += 2.0*log(SigmaAccInv.mat(i,i));
        }
        
        Class_Utils::external_computeInverseFromCholesky(&SigmaAccInv);
    }
    
    void compute_InvAccAndChol_TODELETE()
    {
        SigmaAcc.Print("Sigma");
        for(int i=0;i<Dim;i++)
        {
            for(int j=i;j<Dim;j++)
            {
                SigmaAccInv.Pmat(i,j)[0]   = SigmaAcc.Pmat(i,j)[0];
            }
        }
        Class_Utils::external_computeCholesky(&SigmaAccInv);
        for(int i=0;i<Dim;i++)
        {
            for(int j=i;j<Dim;j++)
            {
                SigmaCholAcc.Pmat(i,j)[0]   = SigmaAccInv.Pmat(i,j)[0];
            }
        }
        SigmaCholAcc.Print("Chol");
        logdetAcc = 0;
        for(int i =0;i<Dim;i++)
        {
            logdetAcc += 2.0*log(SigmaAccInv.mat(i,i));
        }
        
        Class_Utils::external_computeInverseFromCholesky(&SigmaAccInv);
        SigmaAccInv.Print("Inv");
    }
    
    void compute_InvProp()
    {
        for(int i=0;i<Dim;i++)
        {
            for(int j=i;j<Dim;j++)
            {
                SigmaPropInv.Pmat(i,j)[0]   = SigmaProp.Pmat(i,j)[0];
            }
        }
        Class_Utils::external_computeCholesky(&SigmaPropInv);
        Class_Utils::external_computeInverseFromCholesky(&SigmaPropInv);
    }
    //
    //    // UPDATE
    //    update_parGammaparAlpha_fromExternalSigmaparAlpha_BASE(Vector<double> *parsigma2, Vector<double> *pargamma,Vector<double> *paralpha, Matrix<double> *matrixA, Matrix<double>  *matrixL, Matrix<double> *sigma, Matrix<double> * chol, Matrix<double> *inv, double *logdet, double *sigmaext);
    
    
    
};


class Class_Parameter_PDMatrixUnivSamp: public Class_Parameter_PDMatrix
{
    
private:
    
public:
    //int UserControlledMemory;
    int DimGamma;

    
    vector<Class_Parameter*>    parSigma2;
    vector<Class_Parameter*>    parGamma;
    vector<Class_Parameter*>    parAlpha;
    

    vector<Poly_Prior*>          parSigma2_Prior;
    vector<Poly_Prior*>          parGamma_Prior;
    vector<Poly_Prior*>          parAlpha_Prior;
    
    Matrix<double> *MatrixLAcc;
    Matrix<double> *MatrixAAcc;
    
    Matrix<double> *MatrixLProp;
    Matrix<double> *MatrixAProp;
    
    
    
    void PrintObject()
    {
        for(int i=0;i<parSigma2.size();i++)
        {
            parSigma2[i]->PrintObject("Sigma");
        }
        for(int i=0;i<parGamma.size();i++)
        {
            parGamma[i]->PrintObject("Gamma");
        }
        for(int i=0;i<parAlpha.size();i++)
        {
            parAlpha[i]->PrintObject("Alpha");
        }
        
        MatrixLAcc->Print("MatrixLAcc");
        MatrixAAcc->Print("MatrixAAcc");
        MatrixLProp->Print("MatrixLProp");
        MatrixAProp->Print("MatrixAProp");
    }
	void PrintObjectNoCompanion()
	{
		 for(int i=0;i<parSigma2.size();i++)
		 {
			  parSigma2[i]->PrintObject("Sigma");
		 }
		 for(int i=0;i<parGamma.size();i++)
		 {
			  parGamma[i]->PrintObject("Gamma");
		 }
		 for(int i=0;i<parAlpha.size();i++)
		 {
			  parAlpha[i]->PrintObject("Alpha");
		 }
		 
		 MatrixLAcc->Print("MatrixLAcc");
		 MatrixAAcc->Print("MatrixAAcc");
		 MatrixLProp->Print("MatrixLProp");
		 MatrixAProp->Print("MatrixAProp");
	}
    
    
    //COSTRUCTOR
    Class_Parameter_PDMatrixUnivSamp(): Class_Parameter_PDMatrix(){
    
        
    };
    
    //DESTRUCTORS
    ~Class_Parameter_PDMatrixUnivSamp(){};
    
    
    
    void add_Pointerparameters_InVector()
    {
        for(int i=0;i<parSigma2.size();i++)
        {
            parSigma2[0][i].add_Pointerparameters_InVector();
        }
        for(int i=0;i<parGamma.size();i++)
        {
            parGamma[0][i].add_Pointerparameters_InVector();
        }
        for(int i=0;i<parAlpha.size();i++)
        {
            parAlpha[0][i].add_Pointerparameters_InVector();
        }
    }
    void create_FullObject(Matrix<double>*sigma, string name, Poly_PriorPDmatrix *prior, int usr,double *hyperalpha)
    {
        //UserControlledMemory = usr;
        
        Class_Parameter_PDMatrix::create_FullObject(sigma, name, prior, usr);
        
        get_CompanionParameters(hyperalpha);
    }
    void create_FullObjectNoCompanion(Matrix<double>*sigma, string name, Poly_PriorPDmatrix *prior, int usr)
    {
        //UserControlledMemory = usr;
        
        Class_Parameter_PDMatrix::create_FullObject(sigma, name, prior, usr);

    }

    /***** GET *******/
    void get_CompanionParameters(double *hyperalpha);
    
    
    /****** ADD ******/

    //*******FUNCTION ****/
    void UpdateIfAcceptedNoChol()
    {
        double * app;
         app = SigmaAcc.P;
        SigmaAcc.P = SigmaProp.P;
        SigmaProp.P = app;
        
        app = MatrixLAcc[0].P;
        MatrixLAcc[0].P = MatrixLProp[0].P;
        MatrixLProp[0].P = app;
        
        app = MatrixAAcc[0].P;
        MatrixAAcc[0].P = MatrixAProp[0].P;
        MatrixAProp[0].P = app;
    }
    
    //***** UPDATES ***///
    void update_allMatricesAcc();
    void update_allMatricesProp();
    
    
    //update_parGammaparAlpha_(Vector<double> *parsigma2, Vector<double> *pargamma,Vector<double> *paralpha, Matrix<double> *matrixA, Matrix<double>  *matrixL, Matrix<double> *sigma, Matrix<double> * chol, Matrix<double> *inv, double *logdet, double *sigmaext);
    
    
};



class VectorParameters
{
private:
    
public:
    int UserControlledMemory;
    int Dim;
    string NameParameter;
    
    vector<Class_Parameter>    *Parameters;
    vector<VectorParameters>    *VecParameters;
    // non usare pià vector <vector<Poly_Prior*>>
    vector<Poly_Prior*>         *PriorParameters;

    
    //Vector<double> *VectorAccPoint;
    //Vector<double> *VectorPropPoint;
    Vector<double> VectorAcc;
    Vector<double> VectorProp;
    
    
    ~VectorParameters(){};

    
    
    void create_FullObject(int dim,const string name, vector<Class_Parameter> *parameters, vector<Poly_Prior*> *priorparameters,  int usr)
    {
        
        UserControlledMemory    = usr;
        Parameters              = parameters;
        PriorParameters         = priorparameters;
        NameParameter           = name;
        Dim                     = dim;

//        VectorAcc               = Vector <double> (Dim,UserControlledMemory);
//        VectorProp              = Vector <double> (Dim,UserControlledMemory);
//
        VectorAcc               = Vector <double> (Dim,UserControlledMemory);
        VectorProp              = Vector <double> (Dim,UserControlledMemory);
        
        for(int i=0;i<Dim;i++)
        {
            VectorAcc.Pvec(i)[0]    = Parameters[0][i].ParameterAcc;
            VectorProp.Pvec(i)[0]   = Parameters[0][i].ParameterProp;
        }
    }
    
    void create_FullObject(int dim,const string name, vector<Class_Parameter> *parameters, vector<Poly_Prior*> *priorparameters, vector<VectorParameters> * VecPar, int usr)
    {
        
        // NON SERVE
        
        UserControlledMemory    = usr;
        Parameters              = parameters;
        VecParameters           = VecPar;
        PriorParameters         = priorparameters;
        NameParameter           = name;
        Dim                     = dim;
        
        VectorAcc               = Vector <double> (Dim,UserControlledMemory);
        VectorProp              = Vector <double> (Dim,UserControlledMemory);
        
        for(int i=0;i<Dim;i++)
        {
            VectorAcc.Pvec(i)[0]    = Parameters[0][i].ParameterAcc;
            VectorProp.Pvec(i)[0]   = Parameters[0][i].ParameterProp;
        }
    }
//    void create_FullObject(int dim, string name, vector<Class_Parameter> *parameters,  int usr)
//    {
//        UserControlledMemory    = usr;
//        Parameters              = parameters;
//        NameParameter           = name;
//        Dim                     = dim;
//        
//        VectorAcc               = Vector <double> (Dim,UserControlledMemory);
//        VectorProp              = Vector <double> (Dim,UserControlledMemory);
//        
//        for(int i=0;i<Dim;i++)
//        {
//            VectorAcc.Pvec(i)[0]    = Parameters[0][i].ParameterAcc;
//            VectorProp.Pvec(i)[0]   = Parameters[0][i].ParameterProp;
//        }
//    }
    
    void update_ParameterAcc()
    {
        // questa
        for(int k=0;k<Dim;k++)
        {
            Parameters[0][k].ParameterAcc = VectorAcc.vec(k);
        }
        
    }
    void update_VectorAcc()
    {
        for(int k=0;k<Dim;k++)
        {
            VectorAcc.Pvec(k)[0] = Parameters[0][k].ParameterAcc;
        }
    }
    void update_ParameterProp()
    {
        // questa
        for(int k=0;k<Dim;k++)
        {
            Parameters[0][k].ParameterProp = VectorProp.vec(k);
        }
        
    }
    void update_VectorProp()
    {
        for(int k=0;k<Dim;k++)
        {
            VectorProp.Pvec(k)[0] = Parameters[0][k].ParameterProp;
        }
    }
    
    void add_RandomHyper(Class_Parameter *hyperprior,int nvector, int n_hyper)
    {
        PriorParameters[0][nvector]->NameParameters[n_hyper] = PriorParameters[0][nvector]->NameParameters[n_hyper]+"_Random";
        PriorParameters[0][nvector]->HyperparametersAcc.Pvec(n_hyper)[0] = &(hyperprior->ParameterAcc);
        PriorParameters[0][nvector]->HyperparametersProp.Pvec(n_hyper)[0] = &(hyperprior->ParameterProp);
    
    }
    
    
};

/*****************************************
 ProbVector
 ****************************************/

class Class_Dirichlet:Poly_Prior
{
private:
    
public:
    //int UserControlledMemory;
    int Dim;
    
    //int nHyperparams;
    Vector <double*>             BetaAcc;
    Vector <double*>             BetaProp;
    
    
    //string NamePrior;
    //vector <string> NameParameters;
    
    //CONSTRUCTORS
    Class_Dirichlet(){}
    
    //DESTRUCTORS
    ~Class_Dirichlet(){};

    
    void create_FullObject(int usr, int dim)
    {
        Dim                     = dim;
        
        //UserControlledMemory    = usr;
        nHyperparams            = Dim;
        NameParameters          = get_NameHyperparams();
        NamePrior               = get_NameDistr();
        
        BetaAcc                  = Vector<double*>(Dim,UserControlledMemory);
        BetaProp                 = Vector<double*>(Dim,UserControlledMemory);
        
        for(int i=0;i<BetaProp.nElem;i++)
        {
            
            BetaProp.Pvec(i)[0]   = new double;
            BetaAcc.Pvec(i)[0]  = new double;
        }
        
    }
    
    
    // GET
    int  get_nHyperparams() override
    {
        return(Dim);
    }
    string get_NameDistr()  override
    {
        string name = "Dirichlet";
        return(name);
        
    }
    vector<string>      get_NameHyperparams() override
    {
        vector <string> ret;
        for(int i=0;i<Dim;i++)
        {
            string par = ("beta")+ to_string(i);
            ret.push_back(par);
        }
        return(ret);
    }
    
    
//    static void external_SampleDirichlet(Vector<double> *par,  Vector<double> *ret)
//    {
//        Vector <double> GammaVar(ret->nElem,1);
//        double tot = 0;
//        for(int i=0;i<ret->nElem;i++)
//        {
//            GammaVar.Pvec(i)[0] = rgamma(par->vec(i),1);
//            tot                 += GammaVar.Pvec(i)[0];
//        }
//        for(int i=0;i<ret->nElem;i++)
//        {
//            ret->Pvec(i)[0] = GammaVar.Pvec(i)[0] /tot;
//        }
//        GammaVar.Destroy();
//    }
   
    static void external_SampleDirichlet_Stick(Vector<double> *par1,Vector<double> *par2,  Vector<double> *ret)
    {
        double app;
        ret[0].Pvec(0)[0] = rbeta(par1->vec(0),par2->vec(0));
        app = 1.0-ret[0].Pvec(0)[0];
        
        int k;
        for(k=1;k<par1->nElem-1;k++)
        {
            ret[0].Pvec(k)[0] = rbeta(par1->vec(k),par2->vec(k))*app;
            app -= ret[0].Pvec(k)[0] ;
        }
        k = par1->nElem-1;
        ret[0].Pvec(k)[0] = app;
    }
    static void external_SampleDirichlet_Stick(Vector<double> *par1,Vector<double> *par2,  Vector<double> *ret, Vector <int> * order)
    {
        double app;
        int k,i;
        i = 0;
        k = order->vec(i);
        ret[0].Pvec(k)[0] = rbeta(par1->vec(k),par2->vec(k));
        app = 1.0-ret[0].Pvec(k)[0];
        
        
        for(i=1;i<par1->nElem-1;i++)
        {
            k = order->vec(i);
            ret[0].Pvec(k)[0] = rbeta(par1->vec(k),par2->vec(k))*app;
            app -= ret[0].Pvec(k)[0] ;
        }
        i = par1->nElem-1;
        k = order->vec(i);
        ret[0].Pvec(k)[0] = app;
    }
    static void external_SampleDirichlet_Stick(Vector<double> *par1,Vector<double> *par2,  Vector<double> *ret, Vector <int> * order, double MoltProb)
    {
        //printf("SAMP\n");
        double app;
        int k,i;
        i = 0;
        k = order->vec(i);
        ret[0].Pvec(k)[0] = rbeta(par1->vec(k),par2->vec(k));
        
        app = 1.0-ret[0].Pvec(k)[0];
        //printf("%f %f %f %f\n", ret[0].Pvec(k)[0],par1->vec(k),par2->vec(k),app);
        
        
        for(i=1;i<par1->nElem-1;i++)
        {
            k = order->vec(i);
            ret[0].Pvec(k)[0] = rbeta(par1->vec(k),par2->vec(k))*app;
            app -= ret[0].Pvec(k)[0] ;
            //printf("%f %f %f %f\n", ret[0].Pvec(k)[0],par1->vec(k),par2->vec(k),app);
        }
        i = par1->nElem-1;
        k = order->vec(i);
        ret[0].Pvec(k)[0] = app;
        //printf("%f %f %f %f\n", ret[0].Pvec(k)[0],par1->vec(0),par2->vec(0),app);
        
        
        for(i=0;i<par1->nElem;i++)
        {
            k = order->vec(i);
            ret[0].Pvec(k)[0] = ret[0].Pvec(k)[0]*(1.0*MoltProb);
        }
        
        
    }
    
    
    
    static void external_SampleDirichlet_Stick_Log(Vector<double> *par1,Vector<double> *par2,  Vector<double> *ret, Vector <int> * order)
    {
        //printf("SAMP\n");
        double app;
        int k,i;
        i = 0;
        double StickLog_P[ret->nElem];
        Vector <double> StickLog(ret->nElem,StickLog_P);
        
        double Stick1l_Log_P[ret->nElem];
        Vector <double> Stick1l_Log(ret->nElem,Stick1l_Log_P);
        
        for(i=0;i<par1->nElem-1;i++)
        {
            k = order->vec(i);
            StickLog.Pvec(k)[0]     = log(rbeta(par1->vec(k),par2->vec(k)));
            Stick1l_Log.Pvec(k)[0]  = Class_Utils::log1mexp(StickLog.Pvec(k)[0]);
        }
        
        
        
        i=0;
        k = order->vec(i);
        ret[0].Pvec(k)[0] = StickLog.Pvec(k)[0];
        app = Stick1l_Log.Pvec(k)[0];
        for(i=1;i<par1->nElem-1;i++)
        {
            k = order->vec(i);
            ret[0].Pvec(k)[0] = StickLog.Pvec(k)[0]+app;
            app += Stick1l_Log.Pvec(k)[0];
        }
        i = par1->nElem-1;
        k = order->vec(i);
        ret[0].Pvec(k)[0] = app;
        
        
        
        
    }
    
};



// de tipo Dir()
class Class_DirichletProcess: public Poly_Prior
{
private:
    
public:
    
//    int UserControlledMemory;
//    int Dim;
//
//    int nHyperparams;
//    Vector <double*>             BetaAcc;
//    Vector <double*>             BetaProp;
//    double*                      alphaAcc;
//    double*                      alphaProp;


    //string NamePrior;
    //vector <string> NameParameters;
    
    //CONSTRUCTORS
    Class_DirichletProcess(): Poly_Prior(){}
    
    //DESTRUCTORS
    ~Class_DirichletProcess(){};

    // ADDS
    // GET
//    double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper);
//    double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper);
//    double compute_LogJacobian_BASE(double *variable,Vector <double*> hyper);
    int  get_nHyperparams() override
    {
        return(1);
    }
    string get_NameDistr()  override
    {
        string name = "DirichletProcess";
        return(name);
        
    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "Hyper_beta";
        vector <string> ret;
        ret.push_back(par1);
        return(ret);
    }
    Matrix<int> get_DimPar()
    {
        Matrix<int> app = Matrix<int>(1,2,0);
        app.Pmat(0,0)[0]   = 1; // righe colonne
        app.Pmat(0,1)[0]   = 1;
        return(app);
    }
    
    int get_discrete() override
    {
        return(0);
    }
    int get_circular() override
    {
        return(0);
    }
    
    static void sample_DPparameterGammaPrior(double *ret, double par1, double par2, int k, int n)
    {
        double x;
        double Prob;
        x = rbeta(ret[0]+1,1.0*n );

        Prob = (par1+k-1)/( par1+k-1+ n*( par2-log(x)  ) );;
        if(runif(0.0,1.0)<Prob)
        {
            ret[0] = rgamma(par1+k,1/(par2-log(x))  );
        }else{
            ret[0] = rgamma(par1+k-1,1/(par2-log(x))  );
        }
        //sample_DPparameterGammaPrior(&eta->ParameterAcc,eta->PriorParameter->HyperparametersAcc.vec(0)[0], eta->PriorParameter->HyperparametersAcc.vec(1)[0], TheModel->Clusters->nNonEmpty, TheModel->nObs);
    }
   
   
};

//class Class_DirichletProcessFirstLevel: public Poly_Prior
//{
//private:
//    
//public:
//    
//    //    int UserControlledMemory;
//    //    int Dim;
//    //
//    //    int nHyperparams;
//    //    Vector <double*>             BetaAcc;
//    //    Vector <double*>             BetaProp;
//    //    double*                      alphaAcc;
//    //    double*                      alphaProp;
//    
//    
//    string NamePrior;
//    vector <string> NameParameters;
//    
//    //CONSTRUCTORS
//    Class_DirichletProcessFirstLevel(){};
//    
//    //DESTRUCTORS
//    ~Class_DirichletProcessFirstLevel(){};
//    
//    // ADDS
//    // GET
//    //    double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper);
//    //    double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper);
//    //    double compute_LogJacobian_BASE(double *variable,Vector <double*> hyper);
//    int  get_nHyperparams()
//    {
//        return(1);
//    }
//    string get_NameDistr()
//    {
//        string name = "DirichletProcessFirstLevel";
//        return(name);
//        
//    }
//    vector<string>      get_NameHyperparams()
//    {
//        string par1 = "Hyper_beta";
//        vector <string> ret;
//        ret.push_back(par1);
//        return(ret);
//    }
//    Matrix<int> get_DimPar()
//    {
//        Matrix<int> app = Matrix<int>(1,2,0);
//        app.Pmat(0,0)[0]   = 1; // righe colonne
//        app.Pmat(0,1)[0]   = 1;
//        return(app);
//    }
//    
//    int get_discrete()
//    {
//        return(0);
//    }
//    int get_circular()
//    {
//        return(0);
//    }
//    
////    static void sample_DPparameterGammaPrior(double *ret, double par1, double par2, int k, int n)
////    {
////        double x;
////        double Prob;
////        x = rbeta(ret[0]+1,n );
////
////        Prob = (par1+k-1)/( par1+k-1+ n*( par2-log(x)  ) );;
////        if(runif(0.0,1.0)<Prob)
////        {
////            ret[0] = rgamma(par1+k,1/(par2-log(x))  );
////        }else{
////            ret[0] = rgamma(par1+k-1,1/(par2-log(x))  );
////        }
////        //sample_DPparameterGammaPrior(&eta->ParameterAcc,eta->PriorParameter->HyperparametersAcc.vec(0)[0], eta->PriorParameter->HyperparametersAcc.vec(1)[0], TheModel->Clusters->nNonEmpty, TheModel->nObs);
////    }
//    
//    
//};



//class Dirichlet_ForCP: public Class_Dirichlet
//{
//private:
//
//public:
//    //CONSTRUCTORS
//    Dirichlet_ForCP(){}
//
//    //DESTRUCTORS
//    ~Dirichlet_ForCP(){};
//
//
//};

//
//class Class_ProbVec
//{
//private:
//
//public:
//
//    Vector <double>  Parameter;
//
//    Vector <double>  ParameterAcc;
//    Vector <double>  ParameterProp;
//    string NameParameter;
//
//    int Dim;
//
//    Class_Dirichlet *Prior;
//
//
//    //CONSTRUCTORS
//    Class_ProbVec(){}
//
//    //DESTRUCTORS
//    ~Class_ProbVec(){};
//
//
//
//    void create_FullObject(int dim, double *par, string name, Class_Dirichlet *prior, int usr)
//    {
//        Prior   = prior;
//        Dim     = dim;
//        NameParameter    = name;
//
//        Parameter   = Vector<double>(Dim, usr);
//        ParameterAcc   = Vector<double>(Dim, usr);
//        ParameterProp   = Vector<double>(Dim, usr);
//        for(int i=0;i<Dim;i++)
//        {
//            Parameter.Pvec(i)[0] = par[i];
//            ParameterAcc.Pvec(i)[0] = par[i];
//            ParameterProp.Pvec(i)[0] = par[i];
//        }
//    }
//
//    void create_FullObject(double *par, string name, Class_Dirichlet *prior, int usr)
//    {
//        Prior   = prior;
//        Dim     = prior->Dim;
//        NameParameter    = name;
//
//        Parameter   = Vector<double>(Dim, usr);
//        ParameterAcc   = Vector<double>(Dim, usr);
//        ParameterProp   = Vector<double>(Dim, usr);
//        for(int i=0;i<Dim;i++)
//        {
//            Parameter.Pvec(i)[0] = par[i];
//            ParameterAcc.Pvec(i)[0] = par[i];
//            ParameterProp.Pvec(i)[0] = par[i];
//        }
//    }
//
//    static void check_prob_zero(int dim, Vector<double> *Prob, double eps )
//    {
//
//        int     Indexbelow[dim];
//        int     Indexabove[dim];
//        int     nBelow;
//        int     nAbove;
//        double diff;
//        nBelow = 0;
//        nAbove = 0;
//
//        for(int k=0;k<dim;k++)
//        {
//            if(Prob->vec(k)<eps)
//            {
//                Indexbelow[nBelow] = k;
//                nBelow++;
//            }else{
//                Indexabove[nAbove] = k;
//                nAbove++;
//            }
//        }
//        diff = 0.0;
//        if( nBelow>0)
//        {
//            for(int k=0;k<nBelow;k++)
//            {
//                diff += eps-Prob->Pvec(Indexbelow[k])[0];
//                Prob->Pvec(Indexbelow[k])[0] = eps;
//            }
//            for(int k=0;k<nAbove;k++)
//            {
//                Prob->Pvec(Indexabove[k])[0] = Prob->Pvec(Indexabove[k])[0]-diff/nAbove;
//            }
//        }
//
//
//
//    };
//
//
//    static void check_prob_one(int dim, Vector<double> *Prob, double eps )
//    {
//
//        int     Indexbelow[dim];
//        int     Indexabove[dim];
//        int     nBelow;
//        int     nAbove;
//        double diff;
//        nBelow = 0;
//        nAbove = 0;
//
//        for(int k=0;k<dim;k++)
//        {
//            if(Prob->vec(k)> (1.0-eps))
//            {
//                Indexabove[nAbove] = k;
//                nAbove++;
//
//            }else{
//                Indexbelow[nBelow] = k;
//                nBelow++;
//            }
//        }
//        diff = 0.0;
//        if( nAbove>0)
//        {
//            for(int k=0;k<nAbove;k++)
//            {
//                diff += Prob->Pvec(Indexbelow[k])[0]-(1.0-eps);
//                Prob->Pvec(Indexabove[k])[0] = 1.0-eps;
//            }
//            for(int k=0;k<nBelow;k++)
//            {
//                Prob->Pvec(Indexbelow[k])[0] = Prob->Pvec(Indexbelow[k])[0]+diff/nBelow;
//            }
//
//        }
//
//
//
//    };
//
//
//};


//class Mean_ToPass
//{
//private:
//
//public:
//    int UseControlledMemory;
//    int nObs;
//
//    Vector<double> *MeanAcc;
//    Vector<double> *MeanProp;
//
//    Matrix<double> XtInvX;
//    Vector<double> XtInvOmega;
//    Matrix<double> XtInv;
//    Vector<double> Simapp;
//
//    Mean_ToPass(){}
//
//    ~Mean_ToPass(){}
//
//
//};
//
//
//
//
//
//class Class_RegMean: public Mean_ToPass{
//private:
//
//public:
//
//    int nCovariates;
//    vector <Class_Parameter> *RegParameters;
//    Matrix<double> *Covariates;
//
//
//    int isGibbsPossible;
//
//    //COSTRUCTORS
//    Class_RegMean(){};
//    //DESTRUCTORS
//    ~Class_RegMean(){}
//
//
//    void creat_FullObject(vector <Class_Parameter> *parameter, Matrix<double> *covariates, int usr )
//    {
//        UseControlledMemory     = usr;
//        RegParameters   = parameter;
//        Covariates      = covariates;
//
//        nCovariates     = Covariates->nCols;
//        nObs            = Covariates->nRows;
//
//        MeanAcc             = new Vector<double>(nObs, UseControlledMemory );
//        MeanProp            = new  Vector<double>(nObs, UseControlledMemory );
//
//    }
//
//    void creat_FullObjectNoMean(vector <Class_Parameter> *parameter, Matrix<double> *covariates, int usr )
//    {
//        UseControlledMemory     = usr;
//        RegParameters   = parameter;
//        Covariates      = covariates;
//
//        nCovariates     = Covariates->nCols;
//        nObs            = Covariates->nRows;
//
//        //MeanAcc             = new Vector<double>(nObs, UseControlledMemory );
//        //MeanProp            = new  Vector<double>(nObs, UseControlledMemory );
//
//    }
//
//    // UPDATE
//    void update_MeanAcc()
//    {
//        MeanAcc->Init(0.0);
//        for(int i=0;i<nObs;i++)
//        {
//            for(int j=0;j<nCovariates;j++)
//            {
//                MeanAcc[0].Pvec(i)[0] += RegParameters[0][j].ParameterAcc*Covariates[0].mat(i,j);
//            }
//        }
//    }
//    void update_MeanProp()
//    {
//        MeanProp->Init(0.0);
//        for(int i=0;i<nObs;i++)
//        {
//            for(int j=0;j<nCovariates;j++)
//            {
//                MeanProp[0].Pvec(i)[0] += RegParameters[0][j].ParameterProp*Covariates[0].mat(i,j);
//            }
//        }
//    }
//    void UpdateIfAccepted()
//    {
//        double *app;
//        app = MeanAcc->P;
//        MeanAcc->P = MeanProp->P;
//        MeanProp->P = app;
//    }
//    void DoGibbs()
//    {
//        XtInvX          = Matrix<double>(nCovariates,nCovariates,UseControlledMemory);
//        XtInvOmega      = Vector<double>(nCovariates,UseControlledMemory);
//        XtInv           = Matrix<double>(nObs,nCovariates,UseControlledMemory);
//        Simapp           = Vector<double>(nCovariates,UseControlledMemory);
//
//    }
//
//    void sample_fullconditional(Matrix<double> *Inv, Vector<double> *omega)
//    {
//        //* ricordarsi di fare doGibbs (vedi sopra)
//        double Done    = 1.0;
//        double Dzero   = 0.0;
//        int Ione        = 1;
//        int info;
//
//
//
//
//        F77_NAME(dsymm)("R", "L", &nCovariates, &nObs, &Done, Inv->P, &nObs, Covariates->P, &nCovariates, &Dzero, XtInv.P, &nCovariates);
//
//        F77_NAME(dgemm)("N", "T", &nCovariates, &nCovariates, &nObs, &Done, XtInv.P, &nCovariates, Covariates->P, &nCovariates, &Dzero, XtInvX.P , &nCovariates);
//
//        F77_NAME(dgemv)("N", &nCovariates, &nObs,  &Done, XtInv.P, &nCovariates, omega->P, &Ione, &Dzero, XtInvOmega.P, &Ione);
//
//        // Add the priors
//        for(int i=0;i<nCovariates;i++)
//        {
//            XtInvOmega.Pvec(i)[0]     += RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(0)[0]/RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
//
//            XtInvX.Pmat(i,i)[0]     += 1.0/RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
//        }
//
//        F77_NAME(dpotrf)("L",&nCovariates, XtInvX.P, &nCovariates, &info);
//        if(info != 0)
//        {
//            error("Cpp error Cholesky failed - function: sample_fullconditional\n");
//        }
//
//        F77_NAME(dpotri)("L",&nCovariates, XtInvX.P, &nCovariates, &info);
//        if(info != 0)
//        {
//            error("Cpp error Cholesky inverse - function: sample_fullconditional\n");
//        }
//
//
//        F77_NAME(dsymv)("L", &nCovariates, &Done, XtInvX.P, &nCovariates, XtInvOmega.P, &Ione, &Dzero, XtInv.P, &Ione);
//
//
//
//
//
//
//
//        F77_NAME(dpotrf)("L",&nCovariates, XtInvX.P, &nCovariates, &info);
//        if(info != 0)
//        {
//            error("Cpp error Cholesky failed - function: sample_fullconditional\n");
//        }
//
//        for(int i=0;i<nCovariates;i++)
//        {
//            Simapp.Pvec(i)[0] = rnorm(0.0,1.0);
//        }
//        F77_NAME(dtrmv)("L", "N", "N", &nCovariates, XtInvX.P, &nCovariates, Simapp.P, &Ione);
//
//        F77_NAME(daxpy)(&nCovariates, &Done, XtInv.P, &Ione, Simapp.P, &Ione);
//
//        for(int i=0;i<nCovariates;i++)
//        {
//            RegParameters[0][i].ParameterAcc =   Simapp.Pvec(i)[0];
//        }
//
//
//
//
//    }
//
//
//
//
//
//    static void external_ParametersForFullConditioanlBeta_WithoutMolt(Matrix <double> *Covariate, Matrix<double> *Inv, Vector<double> *omega, Matrix <double> *retMat, Vector<double> *retVec)
//    {
//        // FINIRE DI SISTEMARE -  USARE QUELLA SOTTO
//
//        // t gives the values XS^-1X and XS^-1y
//
//        int nCov    = Covariate->nCols;
//        int nBeta   = Covariate->nRows;
//
//        double              A_XtInv_P[nBeta*nCov];
//        //Matrix<double>      A_XtInv(nBeta,nCov,A_XtInv_P);
//
//
//
//        // XtInvX          = Matrix<double>(nCovariates,nCovariates,UseControlledMemory);
//        // XtInvOmega      = Vector<double>(nCovariates,UseControlledMemory);
//
//        //Simapp           = Vector<double>(nCovariates,UseControlledMemory);
//
//
//
//        F77_NAME(dsymm)("R", "L", &nCov, &nBeta, &Class_ToLoad::Done, Inv->P, &nBeta, Covariate->P, &nCov, &Class_ToLoad::Dzero, &A_XtInv_P[0], &nCov);
//        F77_NAME(dgemm)("N", "T", &nCov, &nCov, &nBeta, &Class_ToLoad::Done, &A_XtInv_P[0], &nCov, Covariate->P, &nCov, &Class_ToLoad::Dzero, retMat->P , &nCov);
//
//        F77_NAME(dgemv)("N", &nCov, &nBeta,  &Class_ToLoad::Done, &A_XtInv_P[0], &nCov, omega->P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, retVec->P, &Class_ToLoad::Ione);
//
//    }
//
//    static void external_ParametersForFullConditioanlBeta_WithoutMolt(Matrix <double> *Covariate, Matrix<double> *Inv, Vector<double> *omega, Matrix <double> *retMat, Vector<double> *retVec, const double *AddOrNot)
//    {
//
//        // t gives the values XS^-1X and XS^-1y
//
//        int nCov    = Covariate->nCols;
//        int nBeta   = Covariate->nRows;
//
//        double              A_XtInv_P[nBeta*nCov];
//        //Matrix<double>      A_XtInv(nBeta,nCov,A_XtInv_P);
//
//
//        F77_NAME(dsymm)("R", "L", &nCov, &nBeta, &Class_ToLoad::Done, Inv->P, &nBeta, Covariate->P, &nCov, &Class_ToLoad::Dzero, &A_XtInv_P[0], &nCov);
//        F77_NAME(dgemm)("N", "T", &nCov, &nCov, &nBeta, &Class_ToLoad::Done, &A_XtInv_P[0], &nCov, Covariate->P, &nCov, AddOrNot, retMat->P , &nCov);
//
//        F77_NAME(dgemv)("N", &nCov, &nBeta,  &Class_ToLoad::Done, &A_XtInv_P[0], &nCov, omega->P, &Class_ToLoad::Ione, AddOrNot, retVec->P, &Class_ToLoad::Ione);
//
//    }
//
//    static void external_SampleFromFullConditionl(Vector<double> *ret, Matrix <double> *XtSminus1S, Vector <double> * XtSminus1Y)
//    {
//        double appMeanPar_P[XtSminus1Y->nElem];
//        Vector<double> appMeanPar(XtSminus1Y->nElem,appMeanPar_P);
//
//        Class_MultivariateNormal::external_computeCholesky(XtSminus1S);
//        Class_MultivariateNormal::external_computeInverseFromCholesky(XtSminus1S);
//        Class_MultivariateNormal::external_dsymv_MatMoltX(XtSminus1S, XtSminus1Y, &appMeanPar);
//        Class_MultivariateNormal::external_computeCholesky(XtSminus1S);
//        Class_MultivariateNormal::external_SampleMultivariate(ret, &appMeanPar, XtSminus1S);
//
//    }
//
//    void priorParameters_forGibbs(Matrix<double> *PriorVarInv, Vector<double> *PriorMuPriorVarInv)
//    {
//
//        PriorVarInv->Init(0.0);
//        for(int i=0;i<nCovariates;i++)
//        {
//            PriorMuPriorVarInv->Pvec(i)[0]     = RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(0)[0]/RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
//
//            PriorVarInv->Pmat(i,i)[0]     = 1.0/RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
//        }
//    }
//
//};
//
//
//
///********************************************
// Coregionalization matrix
// ********************************************/
//
//class CovMatrix_ToPass
//{
//private:
//
//public:
//
//    int DimCoreg; // attenzione, per la dimensione effettiva usare nTot/nObs
//    int nObs;
//    int nTot;
//    int UserControlledMemory;
//
//    double logdeterminantAcc;
//    double logdeterminantProp;
//
//    Matrix<double> SigmaCholAcc;
//    Matrix<double> SigmaAcc;
//    Matrix<double> SigmaInvAcc;
//
//
//    Matrix<double> SigmaCholProp;
//    Matrix<double> SigmaProp;
//    Matrix<double> SigmaInvProp;
//
//
//    CovMatrix_ToPass(){};
//
//    ~CovMatrix_ToPass(){};
//
//
//
//
//
//
//
//};
//

class ParametersContainer
{
private:
    
public:
    int UserControlledMemory;
    
    // MEMBERS
    Vector <int>                       *TypeLike;
    Class_Parameter_PDMatrixUnivSamp   *PDmat;
    VectorParameters                   *VectorCont;
    Matrix<double>                     *Cov;
    vector<Vector<double>* >           GPVec;
    vector<vector<Class_Parameter> * >           Params;
    // NA
    vector<Vector <int> >      *NAposTOT; /* il vector ha tanti elementi quanti i missin e il Vector dice quali sono missing*/
    vector<Vector <int> >    *NAposTOTlongRev; /* Contiene quali osservazioni sono Non NA, la lunghezza è uguale a n*/
    Vector<int>      *IndexNA; /* tanti elementi quanti gli na, se c'è i significa che la riga i-esima ha NA */
    
//	void sampleNA()
//		{
//			 #pragma omp parallel for default(none) 
//			 for(int  j=0;j<Container[0].IndexNA->nElem;j++)
//			 {
//				  int obs     = Container[0].IndexNA->vec(j);
//				  int k       = Clusters->Zeta.vec(obs);
//				  
//				  double omega_P[nVars];
//				  Vector <double> omega(nVars,omega_P);
//				  omega.P = Y.Pmat(obs,0);
//				  //REprintf("%i %i %i \n", j,obs,k);
//				  Likelihood->sample_SubsetOrAll(&Container[0].NAposTOT[0][j],obs, Container[k], &omega);
//			 }
//		}
		
	
	
    Vector<int>   *IndexFact; // dice quali colonne delle covariate sono fattori
    Vector<int>   *IndexNumb;

    
    // CONSTRUCTORS
    ParametersContainer():
    UserControlledMemory(1),
    TypeLike(0),
    PDmat(0),
    VectorCont(0),
    Cov(0)
    {};
    
    //DESTRUCTORS
    ~ParametersContainer(){};
    
    
};





/*****************************************
 Likelihood
 ****************************************/

class Poly_Density
{
private:
public:
    
    
    int     nParameters;
    
    string  NameDensity;
    Matrix<int>  DimPar; // DA ELIMINARE; NON SERVE
    int dimObs;
    
    
    double (Poly_Density::*linkFunction_P)(double *meanNoTtra);
    
    
    // COSTRUCTORs
    Poly_Density(){};
    
    //DESTRUCTORs
    ~Poly_Density(){}
    
    
    // PrintObject
    void PrintObject(string ToPrint)
    {
        Rprintf("\n\n %s \n", ToPrint.c_str());
        Rprintf("Type: %s\n NUmber of parameters = %i ",NameDensity.c_str(), nParameters);
    }
    
    // GET

    
    virtual string              get_NameDistr(){
        error("Use of a non-overrided virtual function in Poly_Density");
        return("a");
    };
    virtual vector<string>      get_NameHyperparams(){
        error("Use of a non-overrided virtual function in Poly_Density");
        vector <string> app;
        return(app);
    };
    virtual int                 get_nHyperparams(int nvars){
        error("Use of a non-overrided virtual function in Poly_Density");
        return(1);
    };
    

    virtual Matrix<int> get_DimPar(int nvar)
    {
        error("Use of a non-overrided virtual function in Poly_Density");
        Matrix<int> app;
        return(app);
    }
    
    
    
    // ELIMINARE IN FUTURO
        virtual string              get_NameDistr(int k){
            error("Use of a non-overrided virtual function in Poly_Density");
            return("a");
        };
    
        virtual vector<string>      get_NameHyperparams(int k){
            error("Use of a non-overrided virtual function in Poly_Density");
            vector <string> app;
            return(app);
        };
    
    
        virtual Matrix<int> get_DimPar()
        {
            error("Use of a non-overrided virtual function in Poly_Density");
            Matrix<int> app;
            return(app);
        }
        virtual int                 get_nHyperparams(){
            error("Use of a non-overrided virtual function in Poly_Density");
            return(1);
        };
    
    
    // get
    // CREATES
    void create_FullObject(int nob)
    {
        
        // USARE QUESTA E NON SOTTO
        REprintf("P1\n");
        nParameters             = get_nHyperparams(nob); // intero
        REprintf("P2\n");
        NameDensity             = get_NameDistr();
        REprintf("P3\n");
        //DimPar                  = get_DimPar(nob); // matrice
        dimObs                  = nob;
        REprintf("P4\n");
        linkFunction_P = &::Poly_Density::linkFunction_NoLink;
        REprintf("P5\n");
    
    }
    void create_FullObject()
    {
        // NON SERVE PRATICAMENTE A NIENTE
        REprintf("\nUSARE create_FullObject(int nob)\n");
        nParameters             = get_nHyperparams();
        NameDensity             = get_NameDistr();
        //DimPar                  = Matrix<int>(nParameters,2,0);
//        for(int i =0;i<nParameters;i++)
//        {
//            DimPar.Pmat(0,0)[0]   = 1;
//            DimPar.Pmat(0,1)[0]   = 1;
//        }
        
        linkFunction_P = &::Poly_Density::linkFunction_NoLink;
    }
    
    //function
    virtual double compute_LogDensityUni(int i,double *x, double * hyper){
        error("Use of a non-overrided virtual function in Poly_Density");
        return(1.0);
    };
    
    virtual double compute_LogDensity(double *x, double * hyper){
        error("Use of a non-overrided virtual function in Poly_Density");
        return(1.0);
    };
    virtual double compute_LogDensity(int *x, double * hyper){
        error("Use of a non-overrided virtual function in Poly_Density");
        return(1.0);
    };
    
    virtual double compute_LogCumulative(double *x, double * hyper){
        error("Use of a non-overrided virtual function in Cumulative");
        return(1.0);
    };
    virtual double compute_LogCumulative(int *x, double * hyper){
        error("Use of a non-overrided virtual function in Cumulative");
        return(1.0);
    };
    
    
    
    virtual void computeLogDensityForLike(double * ret, Vector<double> *Obs, ParametersContainer * Cont, int i)
    {
        error("Not overrided computeLogDensityForLike");
    }
    virtual void computeLogDensityForLike_WithoutNA(double * ret, Vector<double> *Obs, ParametersContainer * Cont, int i)
    {
        error("Not overrided computeLogDensityForLike_WithoutNA");
    }
    
    
    
    
    
    virtual  void sample_Multi(int obs, ParametersContainer &cont, Vector <double> * omega)
    {
        error("Not overrided virtual void sample_Multi)");
    }
    
    virtual void sample_uni(int icomp,int obs, ParametersContainer &cont, Vector <double> *omega)
    {
        error("Not overrided virtual sample_uni");
    }
    virtual void sample_SubsetOrAll(Vector<int> *MissComp,int obs, ParametersContainer &cont, Vector <double> *omega)
    {
        error("sample_SubsetOrAll");
    }
    // link
    double linkFunction_NoLink(double *meanNoTtra)
    {
        return(meanNoTtra[0]);
    }
    double linkFunction_EXP(double *meanNoTtra)
    {
        return(exp(meanNoTtra[0]));
    }
    double linkFunction_ARCTAN(double *meanNoTtra)
    {
        return(2.0*atan(meanNoTtra[0]));
    }
    
    
    double linkFunction(double *meanNoTtra)
    {
        //error("Not overrided virtual void linkFunction(double *ret, double *meanNoTtra)");
        return((this->*linkFunction_P)(meanNoTtra));
    }
    void change_link_EXP()
    {
        linkFunction_P = &::Poly_Density::linkFunction_EXP;
    }
    void change_link_ARCTAN()
    {
        linkFunction_P = &::Poly_Density::linkFunction_ARCTAN;
    }
    //**** pointerr
};



class Class_AbeLey:  public Poly_Density
{
private:

public:
    // CONSTRUCTORS
    Class_AbeLey(){}

    // DESTRUCTORS
    ~Class_AbeLey(){};


    // ADDS
    // GET

    int  get_nHyperparams() override
    {
        return(5);
    }
    string get_NameDistr()  override
    {
        string name = "AbeLey";
        return(name);

    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "alpha";
        string par2 = "beta";
        string par3 = "mu";
        string par4 = "kappa";
        string par5 = "lambda";
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        ret.push_back(par3);
        ret.push_back(par4);
        ret.push_back(par5);
        return(ret);
    }

    // FUNCTIONS
    //    double fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper);
    //    double fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper);
    double compute_LogDensity(double *x, double * hyper) override;
//    //function
//    virtual double compute_LogDensity(double *x, double * hyper){
//        error("Use of a non-overrided virtual function in Poly_Density");
//        return(1.0);
//    };
//    virtual double compute_LogDensity(int *x, double * hyper){
//        error("Use of a non-overrided virtual function in Poly_Density");
//        return(1.0);
//    };
//
//    virtual double compute_LogCumulative(double *x, double * hyper){
//        error("Use of a non-overrided virtual function in Cumulative");
//        return(1.0);
//    };
//    virtual double compute_LogCumulative(int *x, double * hyper){
//        error("Use of a non-overrided virtual function in Cumulative");
//        return(1.0);
//    };
//
//
//
//    virtual void computeLogDensityForLike(double * ret, Vector<double> *Obs, ParametersContainer * Cont, int i)
//    {
//        error("Not overrided computeLogDensityForLike");
//    }


};



class Class_InvariantWrappedPoissonReg: public Poly_Density
{
private:
    
public:
    
    int nClasses;
    
    // CONSTRUCTORS
    Class_InvariantWrappedPoissonReg(){
        // nClasses = 0;
    }
    
    // DESTRUCTORS
    ~Class_InvariantWrappedPoissonReg(){};
    
    
    // ADDS
    void add_nClasses(int k)
    {
        nClasses = k;
    }
    
    
    
    
    //update_EmptyAndNonEmptyClusters_P = &::ClusterIndex_V2::update_EmptyAndNonEmptyClusters_CP;
    
    
    
    
    // GET
    //double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <Matrix<double>*>* hyper);
    //double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <Matrix<double>*>* hyper);
    //    void create_FullObject(int k)
    //    {
    //        nParameters             = get_nHyperparams();
    //        NameDensity             = get_NameDistr();
    //        DimPar                  = get_DimPar(k);
    //    }
    int  get_nHyperparams(int nvar) override
    {
        return(6*nvar);
    }
    string get_NameDistr()  override
    {
        string name = "InvariantWrappedPoissonReg";
        return(name);
        
    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "link"; //Funzioni di covariate
        string par2 = "muCirc"; // Anche questo è funzioni di covariate
        string par3 = "sigma2Circ"; //
        string par4 = "xiCirc"; //
        string par5 = "Npoint"; //
        string par6 = "Approx"; //
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        ret.push_back(par3);
        ret.push_back(par4);
        ret.push_back(par5);
        ret.push_back(par6);
        
        return(ret);
    }
    Matrix<int> get_DimPar(int nvar) override
    {
        Matrix<int> app = Matrix<int>(6,1,0);
        app.Pmat(0,0)[0]   = INFINITY;
        app.Pmat(0,1)[0]   = 1;
        app.Pmat(1,0)[0]   = nvar;
        app.Pmat(1,1)[0]   = 1;
        app.Pmat(2,0)[0]   = nvar;
        app.Pmat(2,1)[0]   = 1;
        app.Pmat(3,0)[0]   = nvar;
        app.Pmat(3,1)[0]   = 1;
        app.Pmat(4,0)[0]   = 1;
        app.Pmat(4,1)[0]   = 1;
        app.Pmat(5,0)[0]   = 1;
        app.Pmat(5,1)[0]   = 1;
        
        
        
        
        return(app);
    }
    
    
//    static void compute_XbetaFact(Vector<double>* ret, int nVars,int obs, Matrix<double>*Cov, Vector<double>* Betas, Vector<int> * IndexFact)
//    {
//        compute_XbetaFactNum(ret, nVars,obs, Cov, Betas, IndexFact);
//    }
//
//    static void compute_XbetaNum(Vector<double>* ret, int nVars,int obs, Matrix<double>*Cov, Vector<double>* Betas, Vector<int> * IndexNum)
//    {
//        compute_XbetaFactNum(ret, nVars,obs, Cov, Betas, IndexNum);
//    }
    
    static void compute_XbetaFactNum(Vector<double>* ret, int nVars,int obs, Matrix<double>*Cov, Vector<double>* Betas, Vector<int> * Index)
    {
        //REprintf("COVARIATES\n");
        for(int h=0;h<nVars;h++)
        {
            ret->Pvec(h)[0] = 0.0;
            for(int j1 = 0; j1<Index->nElem;j1++)
            {
                int j = Index->vec(j1);
                ret->Pvec(h)[0] += Cov->mat(nVars*obs+h,j)*Betas->vec(j);
                //REprintf("%i %i %f %f\n",h,j,Cov->mat(nVars*obs+h,j),Betas->vec(j));
            }
            //REprintf("REs = %f\n",ret->Pvec(h)[0]);
        }
    }
    
    
    static double sample(double lambda, double delta, double xi, double Np)
    {
        return(Class_Utils::ModOp(delta*( ( rpois(lambda)*2*M_PI/Np)+xi), 2.0*M_PI ));
    }
    
    
    void sample_SubsetOrAll(Vector<int> *MissComp,int obs, ParametersContainer &cont, Vector <double> *omega) override
    {
        error("sample_SubsetOrAll IWP mai testata - implementare nuovo calcola lambda");
        int nVar = omega->nElem;
        int nCov = cont.Cov->nCols;
        
        double ret_P[MissComp->nElem];
        Vector <double> ret(MissComp->nElem,&ret_P[0]);
        
        double lambda_P[nVar];
        Vector <double> lambda(nVar,&lambda_P[0]);
        
        double xi_P[nVar];
        Vector <double> xi(nVar,&xi_P[0]);
        
        double Xbeta_P[nVar];
        Vector <double> Xbeta(nVar,Xbeta_P);
        //REprintf("T0\n");
        for(int h=0;h<nVar;h++)
        {
            Xbeta.Pvec(h)[0] = 0.0;
            for(int j = 0; j<nCov;j++)
            {
                Xbeta.Pvec(h)[0] += cont.Cov->mat(nVar*obs+h,j)*cont.VectorCont->VectorAcc.vec(j);
            }
        }
        //REprintf("T1\n");
        for(int h=0;h<nVar;h++)
        {
            double mucirc = cont.Params[0][0][h].ParameterAcc;
            double sigma2 = cont.Params[1][0][h].ParameterAcc;
            double delta = cont.Params[2][0][h].ParameterAcc;
            double Npoints = cont.Params[3][0][h].ParameterAcc;
            
            lambda.Pvec(h)[0] =  lambda_from_var(sigma2, Npoints);
            //xi.Pvec(h)[0]     =  xi_from_mean(lambda.vec(h), delta, mucirc, linkFunction(Xbeta.Pvec(h)), Npoints);
        }
        //REprintf("T2\n");
        for(int i=0;i<MissComp->nElem;i++)
        {
            int h = MissComp->vec(i);
            double delta = cont.Params[2][0][h].ParameterAcc;
            double Npoints = cont.Params[3][0][h].ParameterAcc;
            
            omega->Pvec(MissComp->vec(i))[0] = sample(lambda.vec(h), delta, xi.vec(h), Npoints);

        }
    }
    
    
    void computeLogDensityForLike_WithoutNA(double * ret,Vector<double> *Obs, ParametersContainer * Cont, int i) override
    {
        //error("computeLogDensityForLike_WithoutNA IWP mai testata - implementare nuovo calcola lambda");
//        double Mean_P[Obs->nElem];
//        Vector <double> Mean(Obs->nElem,Mean_P);
//
//        for(int h=0;h<Obs->nElem;h++)
//        {
//            Mean.Pvec(h)[0] = 0.0;
//            for(int j = 0; j<Cont->Cov->nCols;j++)
//            {
//                Mean.Pvec(h)[0] += Cont->Cov[0].mat(Obs->nElem*i+h,j)*Cont->VectorCont->VectorAcc.vec(j);
//            }
//
//        }
        
        double XbetaAccNum_P[Obs->nElem];
        Vector<double>XbetaAccNum (Obs->nElem,XbetaAccNum_P);

        
        double XbetaAccFact_P[Obs->nElem];
        Vector<double>XbetaAccFact(Obs->nElem,XbetaAccFact_P);

        
        Class_InvariantWrappedPoissonReg::compute_XbetaFactNum(&XbetaAccFact, Obs->nElem,i, Cont->Cov, &Cont->VectorCont->VectorAcc, Cont->IndexFact);
        
        Class_InvariantWrappedPoissonReg::compute_XbetaFactNum(&XbetaAccNum, Obs->nElem,i, Cont->Cov, &Cont->VectorCont->VectorAcc, Cont->IndexNumb);
        
        double mucirc;
        double sigma2;
        double delta;
        double Npoints;
        double approx;
        
        double par[6*Obs->nElem];
        
        int gg;
        gg = 0;
        for(int j=0;j<Obs->nElem;j++)
        {
            //link = hyper[i*nparUni+0];
            mucirc = Cont->Params[0][0][j].ParameterAcc;
            sigma2 = Cont->Params[1][0][j].ParameterAcc;
            delta = Cont->Params[2][0][j].ParameterAcc;
            Npoints = Cont->Params[3][0][j].ParameterAcc;
            approx = Cont->Params[4][0][j].ParameterAcc;
            
            gg = 0;
            
            par[j*6+gg] = linkFunction(XbetaAccNum.Pvec(j));
            gg++;
            par[j*6+gg] = Class_Utils::ModOp(XbetaAccFact.vec(j),2*M_PI);
            gg++;
            
            par[j*6+gg] = sigma2;
            gg++;
            
            par[j*6+gg] = delta;
            gg++;
            
            par[j*6+gg] = Npoints;
            gg++;
            
            par[j*6+gg] = approx;
            gg++;
        }

        //REprintf("%i %i \n",i,Cont->NAposTOTlongRev[0][i].nElem);
        ret[0] = 0.0;
        if(Cont->NAposTOTlongRev[0][i].nElem==Obs->nElem)
        {
            ret[0] += compute_LogDensity( Obs->Pvec(0), par);
        }else{
            if(Cont->NAposTOTlongRev[0][i].nElem!=0)
            {
                int nvarA = Cont->NAposTOTlongRev[0][i].nElem;
 
                for(int h=0;h<nvarA;h++)
                {
                    int j = Cont->NAposTOTlongRev[0][i].vec(h);
                    ret[0] += compute_LogDensityUni(j,Obs->Pvec(0),  par);
                }
                
            }else{
                ret[0] = 0.0;
            }
            
        }
        
        //Mean.Print("MEAN");
        //Cont->PDmat[0].SigmaAccInv.Print("SIGMAINV");
        
        //Rprintf("%f \n",ret[0]);
    }
    
    double compute_LogDensityUni(int i, double *x, double * hyper) override
    {
        
        double obs;
        int nparUni = 6;
        double link = hyper[i*nparUni+0];
        double mucirc = hyper[i*nparUni+1];
        double sigma2 = hyper[i*nparUni+2];
        double delta = hyper[i*nparUni+3];
        double Npoints = hyper[i*nparUni+4];
        int approx = (int)hyper[i*nparUni+5];
        
        int NpointsInt = (int)round(Npoints);
        
        double retVec[approx];
        double ret;
        
        double lambdaNonApprox;
        double xi;
        double lambda;
        
        lambdaNonApprox  =  lambda_from_var(sigma2, Npoints);
        xi      =  xi_from_meanAndlambda(lambdaNonApprox, delta, mucirc, link, Npoints);
        lambda  =  lambda_from_xiAndMean(xi,delta, mucirc, link, Npoints,lambdaNonApprox);
        
        obs     = Class_Utils::ModOp(delta*x[i]-xi,2.0*M_PI)*Npoints/(2.0*M_PI);
        obs     = Class_Utils::ModOp(round(obs),round(Npoints)) ;
        //REprintf("lNonAp %f mucirc %f link %f sigma %f lambda %f xi %f delta %f obs %f\n",lambdaNonApprox,mucirc, link,sigma2, lambda,xi,delta, obs);
        for(int h=0;h<approx;h++)
        {
            retVec[h] = dpois((int)round( obs+Npoints*h), lambda,1);
        }
        Class_Utils::log_sum_exp(&ret, approx, retVec);
        
        return(ret);
        
    };
    double compute_LogDensity( double *x, double * hyper) override
    {
        double ret = 0.0;
        
        for(int i=0;i<dimObs;i++)
        {
            ret += compute_LogDensityUni(i, x, hyper);
        }
        return(ret);
    };
    static double lambda_from_var(double var, double Np)
    {
        
        return(-1.0*log(1.0-var)/(1.0-cos(2.0*M_PI/Np)));
        
    }
    
    static double sigma2_from_lambda(double lambda, double Np)
    {
        double app;
        app = 1.0-exp(-1.0*lambda*cos(1.0-2*M_PI/Np));
        
        return(app);
    }
    static double lambda_from_xiAndMean(double xi, double delta, double mucirc,double link, double Np, double lambdaNonApprox)
    {
        double app;
        double molt;
        double s = sin(2.0*M_PI/Np);
        
        app = delta*(mucirc+link)- xi;
        app = Class_Utils::ModOp( app, 2.0*M_PI)/s;
        
        molt = round((s*lambdaNonApprox-app*s)/(2*M_PI));
        if(molt<0)
        {
            molt=0.0;
            REprintf("lambda_from_xiAndMean molt<0");
        }
        return(app+molt*2*M_PI/s);
    }
    static double xi_from_meanAndlambda(double lambda, double delta, double mucirc,double link, double Np)
    {
        double app;
        app = delta*(mucirc+link)- lambda*sin(2.0*M_PI/Np);
        //REprintf("app1 %f ",app);
        app = Class_Utils::ModOp(app,2.0*M_PI);
        //REprintf("app2 %f ",app);
        app = app*Np/(2.0*M_PI);
        //REprintf("app3 %f ",app);
        app = round(app);
        //REprintf("app4 %f ",app);
        app = app*2*M_PI/Np;
        //REprintf("app5 %f \n",app);
        return( Class_Utils::ModOp( app, 2.0*M_PI) );
    }
    
    
    
    
    
};

class Class_PoissonReg: public Poly_Density
{
private:
    
public:
    
    int nClasses;
    
    // CONSTRUCTORS
    Class_PoissonReg(){
        // nClasses = 0;
    }
    
    // DESTRUCTORS
    ~Class_PoissonReg(){};
    
    
    // ADDS
    void add_nClasses(int k)
    {
        nClasses = k;
    }
    
    
    
    
    //update_EmptyAndNonEmptyClusters_P = &::ClusterIndex_V2::update_EmptyAndNonEmptyClusters_CP;

    
    
    
    // GET
    //double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <Matrix<double>*>* hyper);
    //double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <Matrix<double>*>* hyper);
//    void create_FullObject(int k)
//    {
//        nParameters             = get_nHyperparams();
//        NameDensity             = get_NameDistr();
//        DimPar                  = get_DimPar(k);
//    }
    int  get_nHyperparams(int nvar) override
    {
        return(nvar);
    }
    string get_NameDistr()  override
    {
        string name = "PoissonReg";
        return(name);
        
    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "link"; //Xbeta
        vector <string> ret;
        ret.push_back(par1);

        return(ret);
    }
    Matrix<int> get_DimPar(int nvar) override
    {
        Matrix<int> app = Matrix<int>(1,1,0);
        app.Pmat(0,0)[0]   = INFINITY;
        app.Pmat(0,1)[0]   = 1;
        
  
        
        return(app);
    }
    
    
    void sample_SubsetOrAll(Vector<int> *MissComp,int obs, ParametersContainer &cont, Vector <double> *omega) override
    {
        int nVar = omega->nElem;
        int nCov = cont.Cov->nCols;
        
        double ret_P[MissComp->nElem];
        Vector <double> ret(MissComp->nElem,&ret_P[0]);
        
        double muA_P[MissComp->nElem];
        Vector <double> muA(MissComp->nElem,&muA_P[0]);
        
        double Xbeta_P[nVar];
        Vector <double> Xbeta(nVar,Xbeta_P);
        
        for(int h=0;h<nVar;h++)
        {
            Xbeta.Pvec(h)[0] = 0.0;
            for(int j = 0; j<nCov;j++)
            {
                Xbeta.Pvec(h)[0] += cont.Cov->mat(nVar*obs+h,j)*cont.VectorCont->VectorAcc.vec(j);
            }
        }
 
        for(int i=0;i<MissComp->nElem;i++)
        {
            omega->Pvec(MissComp->vec(i))[0] = rpois(linkFunction(Xbeta.Pvec(MissComp->vec(i))));
        }
    }
    void computeLogDensityForLike_WithoutNA(double * ret,Vector<double> *Obs, ParametersContainer * Cont, int i) override
    {
        
//        if(PrintNAIWP)
//        {
//            REprintf("computeLogDensityForLike_WithoutN funziona solo con univariate, sulle multivariate, se ci sono NA bisogna riscrivere la funzione\n");
//            PrintNAIWP = false;
//        }
     
        double Mean_P[Obs->nElem];
        Vector <double> Mean(Obs->nElem,Mean_P);
        
        for(int h=0;h<Obs->nElem;h++)
        {
            Mean.Pvec(h)[0] = 0.0;
            for(int j = 0; j<Cont->Cov->nCols;j++)
            {
                Mean.Pvec(h)[0] += Cont->Cov[0].mat(Obs->nElem*i+h,j)*Cont->VectorCont->VectorAcc.vec(j);
            }
            
        }
        //REprintf("%i %i \n",i,Cont->NAposTOTlongRev[0][i].nElem);
        ret[0] = 0.0;
        if(Cont->NAposTOTlongRev[0][i].nElem==Obs->nElem)
        {
            for(int j=0;j<Obs->nElem;j++)
            {
                double par = linkFunction(Mean.Pvec(j));
                ret[0] += compute_LogDensity(Obs->Pvec(j),&par);
            }

        }else{
            if(Cont->NAposTOTlongRev[0][i].nElem!=0)
            {
                int nvarA = Cont->NAposTOTlongRev[0][i].nElem;
                
                double muA_P[nvarA];
                Vector <double>muA(nvarA,muA_P);
                
                double omegaA_P[nvarA];
                Vector <double>omegaA(nvarA,omegaA_P);
                
                
                for(int h=0;h<nvarA;h++)
                {
                    muA.Pvec(h)[0] = Mean.vec(Cont->NAposTOTlongRev[0][i].vec(h));
                    double par = linkFunction(muA.Pvec(h));
                    ret[0] += compute_LogDensity( Obs->Pvec(Cont->NAposTOTlongRev[0][i].vec(h)), &par);
                }
                
            }else{
                ret[0] = 0.0;
            }
            
        }
        
        //Mean.Print("MEAN");
        //Cont->PDmat[0].SigmaAccInv.Print("SIGMAINV");
        
        //Rprintf("%f \n",ret[0]);
    }
    
//    //function
//    double compute_LogDensity(double *x, double * hyper) override
//    {
//        return(dpois(round(x[0]), hyper[0],1));
//        
//    };
    double compute_LogDensityUni(int i, double *x, double * hyper) override
    {
        return(dpois(round(x[i]), hyper[i],1));
        
    };
    double compute_LogDensity( double *x, double * hyper) override
    {
        double ret = 0.0;
        
        for(int i=0;i<dimObs;i++)
        {
            ret += compute_LogDensityUni(i, x, hyper);
        }
        return(ret);
    };
    
//    virtual double compute_LogDensity(int *x, double * hyper){
//        error("Use of a non-overrided virtual function in Poly_Density");
//        return(1.0);
//    };
//
//    virtual double compute_LogCumulative(double *x, double * hyper){
//        error("Use of a non-overrided virtual function in Cumulative");
//        return(1.0);
//    };
//    virtual double compute_LogCumulative(int *x, double * hyper){
//        error("Use of a non-overrided virtual function in Cumulative");
//        return(1.0);
//    };
//
//
//
//    virtual void computeLogDensityForLike(double * ret, Vector<double> *Obs, ParametersContainer * Cont, int i)
//    {
//        error("Not overrided computeLogDensityForLike");
//    }
    

    /****** EXTERNAL******/
    
    
    
    
};



class Class_IndNormal: public Poly_Density //DA TESTARE
{
private:
    
public:
    
    int nClasses;
    
    // CONSTRUCTORS
    Class_IndNormal(){
        // nClasses = 0;
		 //error("DA TESTARE");
    }
    
    // DESTRUCTORS
    ~Class_IndNormal(){};
    
    
    // ADDS
    void add_nClasses(int k)
    {
        nClasses = k;
    }
    
    
   
    int  get_nHyperparams(int nvar) override
    {
        return(nvar*2);
    }
    string get_NameDistr()  override
    {
        string name = "IndNormal";
        return(name);
        
    }
    vector<string>      get_NameHyperparams() override
    {
        string par1 = "link"; //Xbeta
        vector <string> ret;
        ret.push_back(par1);

        return(ret);
    }
    Matrix<int> get_DimPar(int nvar) override
    {
        Matrix<int> app = Matrix<int>(1,1,0);
        app.Pmat(0,0)[0]   = INFINITY;
        app.Pmat(0,1)[0]   = 1;
        
  
        
        return(app);
    }
    
    
    void sample_SubsetOrAll(Vector<int> *MissComp,int obs, ParametersContainer &cont, Vector <double> *omega) override
    {
        int nVar = omega->nElem;
        int nCov = cont.Cov->nCols;
        
        double ret_P[MissComp->nElem];
        Vector <double> ret(MissComp->nElem,&ret_P[0]);
        
        double muA_P[MissComp->nElem];
        Vector <double> muA(MissComp->nElem,&muA_P[0]);
        
        double Xbeta_P[nVar];
        Vector <double> Xbeta(nVar,Xbeta_P);
        
        for(int h=0;h<nVar;h++)
        {
            Xbeta.Pvec(h)[0] = 0.0;
            for(int j = 0; j<nCov;j++)
            {
                Xbeta.Pvec(h)[0] += cont.Cov->mat(nVar*obs+h,j)*cont.VectorCont->VectorAcc.vec(j);
            }
        }
 
        for(int i=0;i<MissComp->nElem;i++)
        {
            omega->Pvec(MissComp->vec(i))[0] = rpois(linkFunction(Xbeta.Pvec(MissComp->vec(i))));
        }
    }
    void computeLogDensityForLike_WithoutNA(double * ret,Vector<double> *Obs, ParametersContainer * Cont, int i) override
    {
        
//        if(PrintNAIWP)
//        {
//            REprintf("computeLogDensityForLike_WithoutN funziona solo con univariate, sulle multivariate, se ci sono NA bisogna riscrivere la funzione\n");
//            PrintNAIWP = false;
//        }
//     
        double Mean_P[Obs->nElem];
        Vector <double> Mean(Obs->nElem,Mean_P);
        
        for(int h=0;h<Obs->nElem;h++)
        {
            Mean.Pvec(h)[0] = 0.0;
            for(int j = 0; j<Cont->Cov->nCols;j++)
            {
                Mean.Pvec(h)[0] += Cont->Cov[0].mat(Obs->nElem*i+h,j)*Cont->VectorCont->VectorAcc.vec(j);
            }
            
        }
        //REprintf("%i %i \n",i,Cont->NAposTOTlongRev[0][i].nElem);
        ret[0] = 0.0;
        if(Cont->NAposTOTlongRev[0][i].nElem==Obs->nElem)
        {
            for(int j=0;j<Obs->nElem;j++)
            {
                double par = linkFunction(Mean.Pvec(j));
                ret[0] += compute_LogDensity(Obs->Pvec(j),&par);
            }

        }else{
            if(Cont->NAposTOTlongRev[0][i].nElem!=0)
            {
                int nvarA = Cont->NAposTOTlongRev[0][i].nElem;
                
                double muA_P[nvarA];
                Vector <double>muA(nvarA,muA_P);
                
                double omegaA_P[nvarA];
                Vector <double>omegaA(nvarA,omegaA_P);
                
                
                for(int h=0;h<nvarA;h++)
                {
                    muA.Pvec(h)[0] = Mean.vec(Cont->NAposTOTlongRev[0][i].vec(h));
                    double par = linkFunction(muA.Pvec(h));
                    ret[0] += compute_LogDensity( Obs->Pvec(Cont->NAposTOTlongRev[0][i].vec(h)), &par);
                }
                
            }else{
                ret[0] = 0.0;
            }
            
        }
        
        //Mean.Print("MEAN");
        //Cont->PDmat[0].SigmaAccInv.Print("SIGMAINV");
        
        //Rprintf("%f \n",ret[0]);
    }
    
//    //function
//    double compute_LogDensity(double *x, double * hyper) override
//    {
//        return(dpois(round(x[0]), hyper[0],1));
//        
//    };
    double compute_LogDensityUni(int i, double *x, double * hyper) override
    {
        return(dpois(round(x[i]), hyper[i],1));
        
    };
    double compute_LogDensity( double *x, double * hyper) override
    {
        double ret = 0.0;
        
        for(int i=0;i<dimObs;i++)
        {
            ret += compute_LogDensityUni(i, x, hyper);
        }
        return(ret);
    };
    
//    virtual double compute_LogDensity(int *x, double * hyper){
//        error("Use of a non-overrided virtual function in Poly_Density");
//        return(1.0);
//    };
//
//    virtual double compute_LogCumulative(double *x, double * hyper){
//        error("Use of a non-overrided virtual function in Cumulative");
//        return(1.0);
//    };
//    virtual double compute_LogCumulative(int *x, double * hyper){
//        error("Use of a non-overrided virtual function in Cumulative");
//        return(1.0);
//    };
//
//
//
//    virtual void computeLogDensityForLike(double * ret, Vector<double> *Obs, ParametersContainer * Cont, int i)
//    {
//        error("Not overrided computeLogDensityForLike");
//    }
    

    /****** EXTERNAL******/
    
    
    
    
};






class Class_MultivariateNormal: public Poly_Density
{
private:
    
public:
    
    int nClasses;
    
    // CONSTRUCTORS
    Class_MultivariateNormal(){
        // nClasses = 0;
    }
    
    // DESTRUCTORS
    ~Class_MultivariateNormal(){};
    
    
    // ADDS
    void add_nClasses(int k)
    {
        nClasses = k;
    }
    
    
    
    
    // GET
    //double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <Matrix<double>*>* hyper);
    //double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <Matrix<double>*>* hyper);
    
    int  get_nHyperparams(int nobs) override
    {
        return(2);
    }
    string get_NameDistr()  override
    {
        string name = "MultivariateNormal";
        return(name);
        
    }
    vector<string>      get_NameHyperparams(int k) override
    {
        string par1 = "Mu";
        string par2 = "Sigma";
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        return(ret);
    }
    Matrix<int> get_DimPar(int n) override
    {
        Matrix<int> app = Matrix<int>(2,2,0);
        app.Pmat(0,0)[0]   = n;
        app.Pmat(0,1)[0]   = 1;
        
        app.Pmat(1,0)[0]   = n;
        app.Pmat(1,1)[0]   = n;
        
        return(app);
    }
    
    void computeLogDensityForLike(double * ret,Vector<double> *Obs, ParametersContainer * Cont, int i) override
    {
        double Mean_P[Obs->nElem];
        Vector <double> Mean(Obs->nElem,Mean_P);
        
        for(int h=0;h<Obs->nElem;h++)
        {
            Mean.Pvec(h)[0] = 0.0;
            for(int j = 0; j<Cont->Cov->nCols;j++)
            {
                Mean.Pvec(h)[0] += Cont->Cov[0].mat(Obs->nElem*i+h,j)*Cont->VectorCont->VectorAcc.vec(j);
            }
           
        }
//Mean.Print("MEAN");
//Cont->PDmat[0].SigmaAccInv.Print("SIGMAINV");
        ret[0] = external_compute_LogDensity_forCovMat(Obs->nElem, Obs,&Mean, &Cont->PDmat[0].SigmaAccInv, &Cont->PDmat[0].logdetAcc);
         //Rprintf("%f \n",ret[0]);
    }
    
    void computeLogDensityForLike_WithoutNA(double * ret,Vector<double> *Obs, ParametersContainer * Cont, int i) override
    {
        double Mean_P[Obs->nElem];
        Vector <double> Mean(Obs->nElem,Mean_P);
        
        for(int h=0;h<Obs->nElem;h++)
        {
            Mean.Pvec(h)[0] = 0.0;
            for(int j = 0; j<Cont->Cov->nCols;j++)
            {
                Mean.Pvec(h)[0] += Cont->Cov[0].mat(Obs->nElem*i+h,j)*Cont->VectorCont->VectorAcc.vec(j);
            }
            
        }
        //REprintf("%i %i \n",i,Cont->NAposTOTlongRev[0][i].nElem);
        if(Cont->NAposTOTlongRev[0][i].nElem==Obs->nElem)
        {
			  
//			  		string NAMEdir = "/work/gmastrantonio/ODE/lancio/";
//			  		#ifdef _OPENMP
//			  		string appNamedir = (NAMEdir+to_string(omp_get_thread_num())+"All.txt");
//			  		#else
//			  		string appNamedir = (NAMEdir+to_string(0)+".txt");
//			  		#endif
//			  		FILE * (file);
//			  		time_t my_time = time(NULL);
//			  
//			  
//			  file = fopen(appNamedir.c_str(),"wt");
//			  fprintf(file,"%s", ctime(&my_time)); 
//			  fprintf(file, "A5\n %i %i \n",Cont->NAposTOTlongRev[0][i].nElem,Obs->nElem);
//			  fclose (file);
			  
            ret[0] = external_compute_LogDensity_forCovMat(Obs->nElem, Obs,&Mean, &Cont->PDmat[0].SigmaAccInv, &Cont->PDmat[0].logdetAcc);
        }else{
            if(Cont->NAposTOTlongRev[0][i].nElem!=0)
            {
					
//					string NAMEdir = "/work/gmastrantonio/ODE/lancio/";
//					#ifdef _OPENMP
//					string appNamedir = (NAMEdir+to_string(omp_get_thread_num())+"Some.txt");
//					#else
//					string appNamedir = (NAMEdir+to_string(0)+".txt");
//					#endif
//					FILE * (file);
//					time_t my_time = time(NULL);
//			  
//			  
//			  file = fopen(appNamedir.c_str(),"wt");
//			  fprintf(file,"%s", ctime(&my_time)); 
//			  fprintf(file, "A5\n %i %i \n",Cont->NAposTOTlongRev[0][i].nElem,Obs->nElem);
//			  fclose (file);
//					
					
					//REprintf("NA2\n");
                int nvarA = Cont->NAposTOTlongRev[0][i].nElem;
                
                double muA_P[nvarA];
                Vector <double>muA(nvarA,muA_P);
                
                double varA_P[nvarA*nvarA];
                Matrix <double>varA(nvarA,nvarA,varA_P);
                
                double omegaA_P[nvarA];
                Vector <double>omegaA(nvarA,omegaA_P);
                
                double logdet;
                
                for(int h=0;h<nvarA;h++)
                {
                    muA.Pvec(h)[0] = Mean.vec(Cont->NAposTOTlongRev[0][i].vec(h));
                    omegaA.Pvec(h)[0] = Obs->vec(Cont->NAposTOTlongRev[0][i].vec(h));
                    for(int j=0;j<nvarA;j++)
                    {
                        varA.Pmat(h,j)[0] = Cont->PDmat[0].SigmaAcc.mat(Cont->NAposTOTlongRev[0][i].vec(h),Cont->NAposTOTlongRev[0][i].vec(j));
                    }
                }

					Class_Utils::external_computeCholesky(&varA);
                logdet = Class_Utils::external_computeLogDetCholesky(&varA);
                Class_Utils::external_computeInverseFromCholesky(&varA);
                
                ret[0] = external_compute_LogDensity_forCovMat(nvarA,&omegaA,&muA, &varA, &logdet);
            }else{
					//REprintf("NA3\n");
                ret[0] = 0.0;
            }
            
        }
        
        //Mean.Print("MEAN");
        //Cont->PDmat[0].SigmaAccInv.Print("SIGMAINV");
        
        //Rprintf("%f \n",ret[0]);
    }
    
    
    
    // FUNCTIONS
//    double compute_LogDensity_forMean(int n, double *x, double* mean , double* sigmaInv)
//    {
//
//        double Done = 1.0;
//        double Dzero = 0.0;
//        int Ione = 1;
//
//        double des;
//
//        double ObsMinusMean[n];
//        double ObsMinusMeanInvCov[n];
//        for(int i=0;i<n;i++)
//        {
//            ObsMinusMean[i] = x[i]-mean[i];
//            //Rprintf("AA %f %f %f \n ",ObsMinusMean[i],x[i],mean[i]);
//        }
//
//
//        F77_NAME(dsymv)("L",&n, &Done,sigmaInv ,&n,&ObsMinusMean[0],&Ione, &Dzero, &ObsMinusMeanInvCov[0]  ,&Ione );
//        des = -0.5*F77_NAME(ddot)(&n,&ObsMinusMeanInvCov[0], &Ione, &ObsMinusMean[0], &Ione);
//
//        return( des  );
//    }
//    double compute_LogDensity_forCovMat(int n, double *x, double* mean , double* sigmaInv, double logdet)
//    {
//
//        double Done = 1.0;
//        double Dzero = 0.0;
//        int Ione = 1;
//
//        double des;
//
//        double ObsMinusMean[n];
//        double ObsMinusMeanInvCov[n];
//        for(int i=0;i<n;i++)
//        {
//            ObsMinusMean[i] = x[i]-mean[i];
//        }
//
//
//        F77_NAME(dsymv)("L",&n, &Done,sigmaInv ,&n,&ObsMinusMean[0],&Ione, &Dzero, &ObsMinusMeanInvCov[0]  ,&Ione );
//        des = -0.5*logdet-0.5*F77_NAME(ddot)(&n,&ObsMinusMeanInvCov[0], &Ione, &ObsMinusMean[0], &Ione);
//
//        return( des );
//    }
    
    /****** EXTERNAL******/
    
    static double external_compute_LogDensity_forCovMat(int n, Vector<double> *x,Vector<double>  *mean , Matrix<double> *sigmaInv, double *logdet);
    
    static double external_compute_LogDensity_forCovMatZeroMean(int n, Vector<double> *x, Matrix<double> *sigmaInv, double *logdet);
    
    static double external_compute_LogDensity_forCovMat(int n, double *x,double  *mean , double *sigmaInv, double *logdet);
    
    
    static void external_computeConditioanlMeanAndVariance(Vector<int> *IndexA,  Vector<double>* muA,  Matrix<double> *SigmaA, Matrix<double> *Sigma, Vector <double> * mu, Vector <double> * omega);
    static void external_computeConditioanlMeanAndVariance_uni(int index,  double *muA,  double *varA, Matrix<double> *SigmaInv, Vector <double> * mu, Vector <double> * omega);
    static void external_computeConditioanlMeanAndVariance_uni_ZeroMean(int index,  double *muA,  double *varA, Matrix<double> *SigmaInv,  Vector <double> * omega);
    
    
    
    static void external_SampleMultivariate(Vector<double>* ret,const Vector<double> * mu, const Matrix<double> *Chol);
    static void external_SampleMultivariate_ZeroMean(Vector<double>* ret,  const Matrix<double> *Chol);
    
    static void external_computeBandF_NNGP(Vector<int> *IndexA,  Matrix<double> *B,  Matrix<double> *F, Matrix<double> *Sigma);
    
    
    static void external_ParametersForFullConditioanlBeta_WithoutMolt(Matrix <double> *Covariate, Matrix<double> *Inv, Vector<double> *omega, Matrix <double> *retMat, Vector<double> *retVec)
    {
        // FINIRE DI SISTEMARE
        
        // t gives the values XS^-1X and XS^-1y
        
        int nCov    = Covariate->nCols;
        int nBeta   = Covariate->nRows;
        
        double              A_XtInv_P[nBeta*nCov];
        //Matrix<double>      A_XtInv(nBeta,nCov,A_XtInv_P);
        
        
        
        // XtInvX          = Matrix<double>(nCovariates,nCovariates,UseControlledMemory);
        // XtInvOmega      = Vector<double>(nCovariates,UseControlledMemory);
        
        //Simapp           = Vector<double>(nCovariates,UseControlledMemory);
        
        
        
        F77_NAME(dsymm)("R", "L", &nCov, &nBeta, &Class_ToLoad::Done, Inv->P, &nBeta, Covariate->P, &nCov, &Class_ToLoad::Dzero, &A_XtInv_P[0], &nCov);
        F77_NAME(dgemm)("N", "T", &nCov, &nCov, &nBeta, &Class_ToLoad::Done, &A_XtInv_P[0], &nCov, Covariate->P, &nCov, &Class_ToLoad::Dzero, retMat->P , &nCov);
        
        F77_NAME(dgemv)("N", &nCov, &nBeta,  &Class_ToLoad::Done, &A_XtInv_P[0], &nCov, omega->P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, retVec->P, &Class_ToLoad::Ione);
        
    }
    
    static void external_ParametersForFullConditioanlBeta_WithoutMolt(const Matrix <double> *Covariate,const  Matrix<double> *Inv,const  Vector<double> *omega, Matrix <double> *retMat, Vector<double> *retVec, const double *AddOrNot)
    {
        
        
        // t gives the values XS^-1X and XS^-1y
        
        int nCov    = Covariate->nCols;
        int nBeta   = Covariate->nRows;
        
        double              A_XtInv_P[nBeta*nCov];
        //Matrix<double>      A_XtInv(nBeta,nCov,A_XtInv_P);
        
        
        F77_NAME(dsymm)("R", "L", &nCov, &nBeta, &Class_ToLoad::Done, Inv->P, &nBeta, Covariate->P, &nCov, &Class_ToLoad::Dzero, &A_XtInv_P[0], &nCov);
        F77_NAME(dgemm)("N", "T", &nCov, &nCov, &nBeta, &Class_ToLoad::Done, &A_XtInv_P[0], &nCov, Covariate->P, &nCov, AddOrNot, retMat->P , &nCov);
        
        F77_NAME(dgemv)("N", &nCov, &nBeta,  &Class_ToLoad::Done, &A_XtInv_P[0], &nCov, omega->P, &Class_ToLoad::Ione, AddOrNot, retVec->P, &Class_ToLoad::Ione);
        
    }
    static void external_ParametersForFullConditioanlBeta_WithoutMolt(Matrix <double> *Covariate, Matrix<double> *Inv, Vector<double> *omega, Matrix <double> *retMat, Vector<double> *retVec, const double AddOrNot)
    {
        //usare sotto, toltopointer AddOrNot
        // t gives the values XS^-1X and XS^-1y
        
        int nCov    = Covariate->nCols;
        int nBeta   = Covariate->nRows;
        
        double              A_XtInv_P[nBeta*nCov];
        //Matrix<double>      A_XtInv(nBeta,nCov,A_XtInv_P);
        
        
        F77_NAME(dsymm)("R", "L", &nCov, &nBeta, &Class_ToLoad::Done, Inv->P, &nBeta, Covariate->P, &nCov, &Class_ToLoad::Dzero, &A_XtInv_P[0], &nCov);
        F77_NAME(dgemm)("N", "T", &nCov, &nCov, &nBeta, &Class_ToLoad::Done, &A_XtInv_P[0], &nCov, Covariate->P, &nCov, &AddOrNot, retMat->P , &nCov);
        
        F77_NAME(dgemv)("N", &nCov, &nBeta,  &Class_ToLoad::Done, &A_XtInv_P[0], &nCov, omega->P, &Class_ToLoad::Ione, &AddOrNot, retVec->P, &Class_ToLoad::Ione);
        
    }
//  static void compute_Sigma_Chol_LogDet_FromInverse(Matrix<double> *Inv, Matrix <double> *Retmat,Matrix <double> *RetChol, double *logDet)
//  {
//    
//    
//    for(int jj1=0;jj1<Inv->nRows;jj1++)
//    {
//      for(int jj2=0;jj2<Inv->nRows;jj2++)
//      {
//        Retmat->Pmat(Inv->nRows-1-jj1,Inv->nRows-1-jj2)[0] = Inv->mat(jj1,jj2);
//      }
//    }
//    
//    Class_Utils::external_computeCholesky(Retmat);
//    Class_Utils::external_computeInverseTriMatrix(Retmat);
//    
//    for(int jj1=0;jj1<Inv->nRows;jj1++)
//    {
//      for(int jj2=0;jj2<Inv->nRows;jj2++)
//      {
//        RetChol->Pmat(Inv->nRows-1-jj2,Inv->nRows-1-jj1)[0] = Retmat->mat(jj2,jj1);
//      }
//    }
//
//    logDet[0] = 0.0;
//    for(int jj1=0;jj1<Inv->nRows;jj1++)
//    {
//      logDet[0] += RetChol->mat(jj1,jj1);
//    }
//    logDet[0] = 2.0*logDet[0];
//    
//    for(int irow=0;irow<Inv->nRows;irow++)
//    {
//      for(int icol=irow;icol<Inv->nRows;icol++)
//      {
//        Retmat->Pmat(irow,icol)[0] = 0.0;
//        for(int istar=0;istar<irow+1;istar++)
//        {
//          Retmat->Pmat(irow,icol)[0] += RetChol->mat(irow,istar)*RetChol->mat(icol,istar);
//        }  
//      }
//    }
//  }
    static void external_finalizedRegFullConditional(Matrix<double> *XSigmaInvX, Vector<double> * XSigmainvOmega, int returnchol)
    {
        
        double App_P[XSigmainvOmega->nElem];
        Vector<double>App(XSigmainvOmega->nElem,App_P);
        
      
      double XSigmaInvX_APP_P[XSigmainvOmega->nElem*XSigmainvOmega->nElem];
      Matrix<double>XSigmaInvX_APP(XSigmainvOmega->nElem, XSigmainvOmega->nElem,XSigmaInvX_APP_P);
      
      double CHOL_XSigmaInvX_APP_P[XSigmainvOmega->nElem*XSigmainvOmega->nElem];
      Matrix<double>CHOL_XSigmaInvX_APP(XSigmainvOmega->nElem, XSigmainvOmega->nElem,CHOL_XSigmaInvX_APP_P);
      
      
      double appL;
      Class_Utils::compute_Sigma_Chol_LogDet_FromInverse(XSigmaInvX, &XSigmaInvX_APP,&CHOL_XSigmaInvX_APP, &appL);
          
      
      
        Class_Utils::external_dsymv_MatMoltX(&XSigmaInvX_APP, XSigmainvOmega, &App);
        for(int i=0;i<XSigmainvOmega->nElem;i++)
        {
            XSigmainvOmega->Pvec(i)[0] = App.vec(i);
        }

        if(returnchol==1)
        {
            for(int jj1=0;jj1<XSigmainvOmega->nElem;jj1++)
            {
              for(int jj2=jj1;jj2<XSigmainvOmega->nElem;jj2++)
              {
                XSigmaInvX->Pmat(jj1,jj2)[0] = CHOL_XSigmaInvX_APP.mat(jj2,jj1);
              }
            }
        }else{
          for(int jj1=0;jj1<XSigmainvOmega->nElem;jj1++)
          {
            for(int jj2=jj1;jj2<XSigmainvOmega->nElem;jj2++)
            {
              XSigmaInvX->Pmat(jj1,jj2)[0] = XSigmaInvX_APP.mat(jj1,jj2);
            }
          }
        }  
      
      
      //XSigmaInvX->Print("Chol");
      //XSigmaInvX_APP.Print("Sigma");
      //error("");
    }
  static void external_finalizedRegFullConditional_SAVE(Matrix<double> *XSigmaInvX, Vector<double> * XSigmainvOmega, int returnchol)
  {
      
      double App_P[XSigmainvOmega->nElem];
      Vector<double>App(XSigmainvOmega->nElem,App_P);
      
    
   
    
      Class_Utils::external_computeCholesky(XSigmaInvX);

      
      Class_Utils::external_computeInverseFromCholesky(XSigmaInvX);
      Class_Utils::external_dsymv_MatMoltX(XSigmaInvX, XSigmainvOmega, &App);
      for(int i=0;i<XSigmainvOmega->nElem;i++)
      {
          XSigmainvOmega->Pvec(i)[0] = App.vec(i);
      }
      if(returnchol==1)
      {
          Class_Utils::external_computeCholesky(XSigmaInvX);
      }  
    
 
  }
    
    
    //    static void external_SampleFromFullConditional(Vector<double> *ret, Matrix <double> *XtSminus1S, Vector <double> * XtSminus1Y)
    //    {
    //        double appMeanPar_P[XtSminus1Y->nElem];
    //        Vector<double> appMeanPar(XtSminus1Y->nElem,appMeanPar_P);
    //
    //        Class_Utils::external_computeCholesky(XtSminus1S);
    //        Class_Utils::external_computeInverseFromCholesky(XtSminus1S);
    //        Class_Utils::external_dsymv_MatMoltX(XtSminus1S, XtSminus1Y, &appMeanPar);
    //        Class_Utils::external_computeCholesky(XtSminus1S);
    //        Class_MultivariateNormal::external_SampleMultivariate(ret, &appMeanPar, XtSminus1S);
    //
    //    }
    
    //    void priorParameters_forGibbs(Matrix<double> *PriorVarInv, Vector<double> *PriorMuPriorVarInv)
    //    {
    //
    //        PriorVarInv->Init(0.0);
    //        for(int i=0;i<nCovariates;i++)
    //        {
    //            PriorMuPriorVarInv->Pvec(i)[0]     = RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(0)[0]/RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
    //
    //            PriorVarInv->Pmat(i,i)[0]     = 1.0/RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
    //        }
    //    }
    
    
    
    
    //    void priorParameters_forGibbs(Matrix<double> *PriorVarInv, Vector<double> *PriorMuPriorVarInv)
    //    {
    //
    //        PriorVarInv->Init(0.0);
    //        for(int i=0;i<nCovariates;i++)
    //        {
    //            PriorMuPriorVarInv->Pvec(i)[0]     = RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(0)[0]/RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
    //
    //            PriorVarInv->Pmat(i,i)[0]     = 1.0/RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
    //        }
    //    }
    
    void sample_Multi(int obs, ParametersContainer &cont, Vector <double> * omega) override
    {
        
        int nVar = omega->nElem;
        int nCov = cont.Cov->nCols;
        
        double Xbeta_P[nVar];
        Vector <double> Xbeta(nVar,Xbeta_P);
        
        for(int h=0;h<nVar;h++)
        {
            Xbeta.Pvec(h)[0] = 0.0;
            for(int j = 0; j<nCov;j++)
            {
                Xbeta.Pvec(h)[0] += cont.Cov->mat(nVar*obs+h,j)*cont.VectorCont->VectorAcc.vec(j);
            }
        }
        
        Class_MultivariateNormal::external_SampleMultivariate(omega, &Xbeta, &cont.PDmat->SigmaCholAcc);
    }
    
    void sample_uni(int icomp,int obs, ParametersContainer &cont, Vector <double> *omega) override
    {
        
        //        Container[k].VectorCont = &regCoef[0][k];
        //        Container[k].PDmat  = &covmat[0][k];
        
        int nVar = omega->nElem;
        int nCov = cont.Cov->nCols;
        
        double muA_P[1];
        Vector <double> muA(1,muA_P);
        
        double varA_P[1];
        Matrix <double> varA(1,1,varA_P);
        
        double Xbeta_P[nVar];
        Vector <double> Xbeta(nVar,Xbeta_P);
        
        
        
        for(int h=0;h<nVar;h++)
        {
            Xbeta.Pvec(h)[0] = 0.0;
            for(int j = 0; j<nCov;j++)
            {
                Xbeta.Pvec(h)[0] += cont.Cov->mat(nVar*obs+h,j)*cont.VectorCont->VectorAcc.vec(j);
            }
        }
        Class_MultivariateNormal::external_computeConditioanlMeanAndVariance_uni(icomp,  &muA_P[0],  &varA_P[0], &cont.PDmat->SigmaAccInv, &Xbeta, omega);
        
        omega->Pvec(icomp)[0] = rnorm(muA_P[0], pow(varA_P[0],0.5));
    }
    
    void sample_SubsetOrAll(Vector<int> *MissComp,int obs, ParametersContainer &cont, Vector <double> *omega) override
    {
        if(PrintNAMulti)
        {
            REprintf("SI può migliorare la stima degli NA, usando il fatto che la component di SigmaInv è l0inverse dalla condizionata: -Block matrix inversion https://en.wikipedia.org/wiki/Block_matrix#Block_matrix_inversion\n");
            PrintNAMulti = false;
        }
        
        
        //        Container[k].VectorCont = &regCoef[0][k];
        //        Container[k].PDmat  = &covmat[0][k];
        
        int nVar = omega->nElem;
        int nCov = cont.Cov->nCols;
        
        double ret_P[MissComp->nElem];
        Vector <double> ret(MissComp->nElem,&ret_P[0]);
        
        double muA_P[MissComp->nElem];
        Vector <double> muA(MissComp->nElem,&muA_P[0]);
        
        double varA_P[MissComp->nElem*MissComp->nElem];
        Matrix <double> varA(MissComp->nElem,MissComp->nElem,&varA_P[0]);
        
        double Xbeta_P[nVar];
        Vector <double> Xbeta(nVar,Xbeta_P);
        
        
        //REprintf("A1\n");
        for(int h=0;h<nVar;h++)
        {
            Xbeta.Pvec(h)[0] = 0.0;
            for(int j = 0; j<nCov;j++)
            {
                Xbeta.Pvec(h)[0] += cont.Cov->mat(nVar*obs+h,j)*cont.VectorCont->VectorAcc.vec(j);
            }
        }
        //REprintf("A2\n");
        //MissComp->Print("MissComp");
//        cont.PDmat->SigmaAcc.Print("cont.PDmat->SigmaAcc");
        //Xbeta.Print("Xbeta");
        //omega->Print("omega");
        //cont.PDmat->SigmaAcc.Print("SSS");
        Class_MultivariateNormal::external_computeConditioanlMeanAndVariance(MissComp,  &muA,  &varA, &cont.PDmat->SigmaAcc,  &Xbeta, omega);
        //REprintf("A3\n");
        
        //muA.Print("CondM");
        //varA.Print("CondV");
        Class_Utils::external_computeCholesky(&varA);
        //REprintf("A4\n");
        
        Class_MultivariateNormal::external_SampleMultivariate(&ret,&muA,  &varA);
        for(int i=0;i<MissComp->nElem;i++)
        {
            omega->Pvec(MissComp->vec(i))[0] = ret.vec(i);
        }
    }
    

    
    //Class_MultivariateNormal::external_computeConditioanlMeanAndVariance(Vector<int> *IndexA,  Vector<double>* muA,  Matrix<double> *SigmaA, Matrix<double> *Sigma, Vector <double> * mu, Vector <double> * omega)
    
    
    
};







class Class_MultivariateNormal_ModelClima: public Poly_Density
{
private:
    
public:
    
    int nClasses;
    
    // CONSTRUCTORS
    Class_MultivariateNormal_ModelClima(){
        // nClasses = 0;
    }
    
    // DESTRUCTORS
    ~Class_MultivariateNormal_ModelClima(){};
    
    
    // ADDS
    void add_nClasses(int k)
    {
        nClasses = k;
    }
    
    
    
    
    // GET
    //double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <Matrix<double>*>* hyper);
    //double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <Matrix<double>*>* hyper);
    
    int  get_nHyperparams() override
    {
        return(2);
    }
    string get_NameDistr()  override
    {
        string name = "MultivariateNormal";
        return(name);
        
    }
    vector<string>      get_NameHyperparams(int k) override
    {
        string par1 = "Mu";
        string par2 = "Sigma";
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        return(ret);
    }
    Matrix<int> get_DimPar(int n) override
    {
        Matrix<int> app = Matrix<int>(2,2,0);
        app.Pmat(0,0)[0]   = n;
        app.Pmat(0,1)[0]   = 1;
        
        app.Pmat(1,0)[0]   = n;
        app.Pmat(1,1)[0]   = n;
        
        return(app);
    }
    
    void computeLogDensityForLike(double * ret,Vector<double> *Obs, ParametersContainer * Cont, int i) override
    {
        
        //Container[k].TypeLike
        int Type;
        
        double Mean_P[Obs->nElem];
        Vector <double> Mean(Obs->nElem,Mean_P);
        
        
        double ObsA2_P[2];
        Vector <double> ObsA2(2,ObsA2_P);
        
        double MeanA2_P[2];
        Vector <double> MeanA2(2,MeanA2_P);
        
        double SigmaInvA2_P[4];
        Matrix <double> SigmaInvA2(2,2,SigmaInvA2_P);
        
        double MeanA1_P[1];
        Vector <double> MeanA1(1,MeanA1_P);
        
        double SigmaA1_P[1];
        Matrix <double> SigmaA1(1,1,SigmaA1_P);
        
        double LogDetA2;
        
        for(int h=0;h<Obs->nElem;h++)
        {
            Mean.Pvec(h)[0] = 0.0;
            for(int j = 0; j<Cont->Cov->nCols;j++)
            {
                Mean.Pvec(h)[0] += Cont->Cov[0].mat(Obs->nElem*i+h,j)*Cont->VectorCont->VectorAcc.vec(j);
            }
            
        }

        
        Type = Cont->TypeLike->vec(i);
        
        if(Type==0)
        {
            ret[0] = 0;
            
        }
        if(Type==1)
        {
            ret[0] = -3.0/2.0*log(2.0*M_PI)+Class_MultivariateNormal::external_compute_LogDensity_forCovMat(Obs->nElem, Obs,&Mean, &Cont->PDmat[0].SigmaAccInv, &Cont->PDmat[0].logdetAcc);
        }
        if(Type==2)
        {
            LogDetA2 = (Cont->PDmat[0].SigmaAcc.mat(0,0)*Cont->PDmat[0].SigmaAcc.mat(1,1) - pow(Cont->PDmat[0].SigmaAcc.mat(0,1),2.0));
            
            SigmaInvA2.Pmat(0,0)[0] = Cont->PDmat[0].SigmaAcc.mat(1,1)/LogDetA2;
            SigmaInvA2.Pmat(1,1)[0] = Cont->PDmat[0].SigmaAcc.mat(0,0)/LogDetA2;
            SigmaInvA2.Pmat(0,1)[0] = -1.0*Cont->PDmat[0].SigmaAcc.mat(0,1)/LogDetA2;
            SigmaInvA2.Pmat(1,0)[0] = -1.0*Cont->PDmat[0].SigmaAcc.mat(1,0)/LogDetA2;
            
            LogDetA2 = log(LogDetA2);
            
            MeanA2.Pvec(0)[0] = Mean.vec(0);
            MeanA2.Pvec(1)[0] = Mean.vec(1);
            
            ObsA2.Pvec(0)[0] = Obs->vec(0);
            ObsA2.Pvec(1)[0] = Obs->vec(1);
            
            ret[0] = -2.0/2.0*log(2.0*M_PI)+Class_MultivariateNormal::external_compute_LogDensity_forCovMat(2, &ObsA2,&MeanA2, &SigmaInvA2, &LogDetA2);
        }
        if(Type==3)
        {
            LogDetA2 = (Cont->PDmat[0].SigmaAcc.mat(0,0)*Cont->PDmat[0].SigmaAcc.mat(2,2) - pow(Cont->PDmat[0].SigmaAcc.mat(0,2),2.0));
            
            SigmaInvA2.Pmat(0,0)[0] = Cont->PDmat[0].SigmaAcc.mat(2,2)/LogDetA2;
            SigmaInvA2.Pmat(1,1)[0] = Cont->PDmat[0].SigmaAcc.mat(0,0)/LogDetA2;
            SigmaInvA2.Pmat(0,1)[0] = -1.0*Cont->PDmat[0].SigmaAcc.mat(0,2)/LogDetA2;
            SigmaInvA2.Pmat(1,0)[0] = -1.0*Cont->PDmat[0].SigmaAcc.mat(2,0)/LogDetA2;
            
            LogDetA2 = log(LogDetA2);
            
            MeanA2.Pvec(0)[0] = Mean.vec(0);
            MeanA2.Pvec(1)[0] = Mean.vec(2);
            
            ObsA2.Pvec(0)[0] = Obs->vec(0);
            ObsA2.Pvec(1)[0] = Obs->vec(2);
            
            ret[0] = -2.0/2.0*log(2.0*M_PI)+Class_MultivariateNormal::external_compute_LogDensity_forCovMat(2, &ObsA2,&MeanA2, &SigmaInvA2, &LogDetA2);
        }
        if(Type==5)
        {
            LogDetA2 = (Cont->PDmat[0].SigmaAcc.mat(1,1)*Cont->PDmat[0].SigmaAcc.mat(2,2) - pow(Cont->PDmat[0].SigmaAcc.mat(1,2),2.0));
            
            SigmaInvA2.Pmat(0,0)[0] = Cont->PDmat[0].SigmaAcc.mat(2,2)/LogDetA2;
            SigmaInvA2.Pmat(1,1)[0] = Cont->PDmat[0].SigmaAcc.mat(1,1)/LogDetA2;
            SigmaInvA2.Pmat(0,1)[0] = -1.0*Cont->PDmat[0].SigmaAcc.mat(1,2)/LogDetA2;
            SigmaInvA2.Pmat(1,0)[0] = -1.0*Cont->PDmat[0].SigmaAcc.mat(2,1)/LogDetA2;
            
            LogDetA2 = log(LogDetA2);
            
            MeanA2.Pvec(0)[0] = Mean.vec(1);
            MeanA2.Pvec(1)[0] = Mean.vec(2);
            
            ObsA2.Pvec(0)[0] = Obs->vec(1);
            ObsA2.Pvec(1)[0] = Obs->vec(2);
            
            ret[0] = -2.0/2.0*log(2.0*M_PI)+Class_MultivariateNormal::external_compute_LogDensity_forCovMat(2, &ObsA2,&MeanA2, &SigmaInvA2, &LogDetA2);
        }
        if(Type==4)
        {
            ret[0] = dnorm(Obs->vec(0),Mean.vec(0), pow(Cont->PDmat[0].SigmaAcc.mat(0,0),0.5),1 );
        }
        if(Type==6)
        {
            ret[0] = dnorm(Obs->vec(1),Mean.vec(1), pow(Cont->PDmat[0].SigmaAcc.mat(1,1),0.5),1 );
        }
        if(Type==7)
        {
            ret[0] = dnorm(Obs->vec(2),Mean.vec(2), pow(Cont->PDmat[0].SigmaAcc.mat(2,2),0.5),1 );
        }
        if(Type==8)
        {
            LogDetA2 = (Cont->PDmat[0].SigmaAcc.mat(1,1)*Cont->PDmat[0].SigmaAcc.mat(2,2) - pow(Cont->PDmat[0].SigmaAcc.mat(1,2),2.0));
            
            SigmaInvA2.Pmat(0,0)[0] = Cont->PDmat[0].SigmaAcc.mat(2,2)/LogDetA2;
            SigmaInvA2.Pmat(1,1)[0] = Cont->PDmat[0].SigmaAcc.mat(1,1)/LogDetA2;
            SigmaInvA2.Pmat(0,1)[0] = -1.0*Cont->PDmat[0].SigmaAcc.mat(1,2)/LogDetA2;
            SigmaInvA2.Pmat(1,0)[0] = -1.0*Cont->PDmat[0].SigmaAcc.mat(2,1)/LogDetA2;
            
            LogDetA2 = log(LogDetA2);
            
            MeanA2.Pvec(0)[0] = Mean.vec(1);
            MeanA2.Pvec(1)[0] = Mean.vec(2);
            
            ObsA2.Pvec(0)[0] = Obs->vec(1);
            ObsA2.Pvec(1)[0] = Obs->vec(2);
            
            Class_MultivariateNormal::external_computeConditioanlMeanAndVariance_uni(0,  MeanA1.P, SigmaA1.P, &Cont->PDmat[0].SigmaAccInv, &Mean, Obs);
            
            ret[0] = -2.0/2.0*log(2.0*M_PI)+Class_MultivariateNormal::external_compute_LogDensity_forCovMat(2, &ObsA2,&MeanA2, &SigmaInvA2, &LogDetA2)+pnorm(Obs->vec(0),MeanA1.vec(0), pow(SigmaA1.mat(0,0),0.5) ,1,1  );
        }
        if(Type==9)
        {
            MeanA1.Pvec(0)[0] = Mean.vec(0)+Cont->PDmat[0].SigmaAcc.mat(0,1)/Cont->PDmat[0].SigmaAcc.mat(1,1)*(Obs->vec(1)-Mean.vec(1));
            SigmaA1.Pmat(0,0)[0] = Cont->PDmat[0].SigmaAcc.mat(0,0)-Cont->PDmat[0].SigmaAcc.mat(0,1)/Cont->PDmat[0].SigmaAcc.mat(1,1)*Cont->PDmat[0].SigmaAcc.mat(0,1);
            
            ret[0] = dnorm(Obs->vec(1),Mean.vec(1), pow( Cont->PDmat[0].SigmaAcc.mat(1,1),0.5),1)+pnorm(Obs->vec(0),MeanA1.vec(0), pow( SigmaA1.mat(0,0),0.5) ,1,1  );
        }
        if(Type==10)
        {
            MeanA1.Pvec(0)[0] = Mean.vec(0)+Cont->PDmat[0].SigmaAcc.mat(0,2)/Cont->PDmat[0].SigmaAcc.mat(2,2)*(Obs->vec(2)-Mean.vec(2));
            SigmaA1.Pmat(0,0)[0] = Cont->PDmat[0].SigmaAcc.mat(0,0)-Cont->PDmat[0].SigmaAcc.mat(0,2)/Cont->PDmat[0].SigmaAcc.mat(2,2)*Cont->PDmat[0].SigmaAcc.mat(0,2);
            
            ret[0] = dnorm(Obs->vec(2),Mean.vec(2), pow( Cont->PDmat[0].SigmaAcc.mat(2,2),0.5),1)+pnorm(Obs->vec(0),MeanA1.vec(0), pow( SigmaA1.mat(0,0),0.5) ,1,1  );
        }
        if(Type==11)
        {
            ret[0] = pnorm(Obs->vec(0),Mean.vec(0), pow( Cont->PDmat[0].SigmaAcc.mat(0,0),0.5),1,1);
        }
//# 0; \ \ \
//# 1;  x x x
//# 2;  x x \
//# 3;  x \  x
//# 4;  x \  \
//# 5;  \ x  x
//# 6;  \ x  \
//# 7;  \ \  x
//        
//# 8;  0 x x
//# 9;  0 x \
//# 10;  0 \  x
//# 11;  0 \  \
//        //Mean.Print("MEAN");
//        //Cont->PDmat[0].SigmaAccInv.Print("SIGMAINV");
//        ret[0] = external_compute_LogDensity_forCovMat(Obs->nElem, Obs,&Mean, &Cont->PDmat[0].SigmaAccInv, &Cont->PDmat[0].logdetAcc);
        //Rprintf("%f \n",ret[0]);
    }
    
  
    
   
    
    
};






class Class_MultivariateNormal_ModelClimaSeason: public Poly_Density
{
private:
    
public:
    
    int nClasses;
    
    // CONSTRUCTORS
    Class_MultivariateNormal_ModelClimaSeason(){
        // nClasses = 0;
    }
    
    // DESTRUCTORS
    ~Class_MultivariateNormal_ModelClimaSeason(){};
    
    
    // ADDS
    void add_nClasses(int k)
    {
        nClasses = k;
    }
    
    
    
    
    // GET
    //double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <Matrix<double>*>* hyper);
    //double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <Matrix<double>*>* hyper);
    
    int  get_nHyperparams(int nvar) override
    {
        return(2);
    }
    string get_NameDistr()  override
    {
        string name = "MultivariateNormal";
        return(name);
        
    }
    vector<string>      get_NameHyperparams(int k) override
    {
        string par1 = "Mu";
        string par2 = "Sigma";
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        return(ret);
    }
    Matrix<int> get_DimPar(int n) override
    {
        Matrix<int> app = Matrix<int>(2,2,0);
        app.Pmat(0,0)[0]   = n;
        app.Pmat(0,1)[0]   = 1;
        
        app.Pmat(1,0)[0]   = n;
        app.Pmat(1,1)[0]   = n;
        
        return(app);
    }
    
    void computeLogDensityForLike(double * ret,Vector<double> *Obs, ParametersContainer * Cont, int i) override
    {
        
        //Container[k].TypeLike
        int Type;
        
        double Mean_P[Obs->nElem];
        Vector <double> Mean(Obs->nElem,Mean_P);
        
        
        double ObsA2_P[2];
        Vector <double> ObsA2(2,ObsA2_P);
        
        double MeanA2_P[2];
        Vector <double> MeanA2(2,MeanA2_P);
        
        double SigmaInvA2_P[4];
        Matrix <double> SigmaInvA2(2,2,SigmaInvA2_P);
        
        double MeanA1_P[1];
        Vector <double> MeanA1(1,MeanA1_P);
        
        double SigmaA1_P[1];
        Matrix <double> SigmaA1(1,1,SigmaA1_P);
        
        double LogDetA2;
        
        for(int h=0;h<Obs->nElem;h++)
        {
            Mean.Pvec(h)[0] = 0.0;
            for(int j = 0; j<Cont->Cov->nCols;j++)
            {
                Mean.Pvec(h)[0] += Cont->Cov[0].mat(Obs->nElem*i+h,j)*Cont->VectorCont->VectorAcc.vec(j);
            }
            //Mean.Pvec(h)[0] += Cont->GPVec->vec((i%12)+h);
            Mean.Pvec(h)[0] += Cont[0].GPVec[h][0].vec((i%12));
        }
        
        
        Type = Cont->TypeLike->vec(i);
        
        if(Type==0)
        {
            ret[0] = 0;
            
        }
        if(Type==1)
        {
            ret[0] = -3.0/2.0*log(2.0*M_PI)+Class_MultivariateNormal::external_compute_LogDensity_forCovMat(Obs->nElem, Obs,&Mean, &Cont->PDmat[0].SigmaAccInv, &Cont->PDmat[0].logdetAcc);
        }
        if(Type==2)
        {
            LogDetA2 = (Cont->PDmat[0].SigmaAcc.mat(0,0)*Cont->PDmat[0].SigmaAcc.mat(1,1) - pow(Cont->PDmat[0].SigmaAcc.mat(0,1),2.0));
            
            SigmaInvA2.Pmat(0,0)[0] = Cont->PDmat[0].SigmaAcc.mat(1,1)/LogDetA2;
            SigmaInvA2.Pmat(1,1)[0] = Cont->PDmat[0].SigmaAcc.mat(0,0)/LogDetA2;
            SigmaInvA2.Pmat(0,1)[0] = -1.0*Cont->PDmat[0].SigmaAcc.mat(0,1)/LogDetA2;
            SigmaInvA2.Pmat(1,0)[0] = -1.0*Cont->PDmat[0].SigmaAcc.mat(1,0)/LogDetA2;
            
            LogDetA2 = log(LogDetA2);
            
            MeanA2.Pvec(0)[0] = Mean.vec(0);
            MeanA2.Pvec(1)[0] = Mean.vec(1);
            
            ObsA2.Pvec(0)[0] = Obs->vec(0);
            ObsA2.Pvec(1)[0] = Obs->vec(1);
            
            ret[0] = -2.0/2.0*log(2.0*M_PI)+Class_MultivariateNormal::external_compute_LogDensity_forCovMat(2, &ObsA2,&MeanA2, &SigmaInvA2, &LogDetA2);
        }
        if(Type==3)
        {
            LogDetA2 = (Cont->PDmat[0].SigmaAcc.mat(0,0)*Cont->PDmat[0].SigmaAcc.mat(2,2) - pow(Cont->PDmat[0].SigmaAcc.mat(0,2),2.0));
            
            SigmaInvA2.Pmat(0,0)[0] = Cont->PDmat[0].SigmaAcc.mat(2,2)/LogDetA2;
            SigmaInvA2.Pmat(1,1)[0] = Cont->PDmat[0].SigmaAcc.mat(0,0)/LogDetA2;
            SigmaInvA2.Pmat(0,1)[0] = -1.0*Cont->PDmat[0].SigmaAcc.mat(0,2)/LogDetA2;
            SigmaInvA2.Pmat(1,0)[0] = -1.0*Cont->PDmat[0].SigmaAcc.mat(2,0)/LogDetA2;
            
            LogDetA2 = log(LogDetA2);
            
            MeanA2.Pvec(0)[0] = Mean.vec(0);
            MeanA2.Pvec(1)[0] = Mean.vec(2);
            
            ObsA2.Pvec(0)[0] = Obs->vec(0);
            ObsA2.Pvec(1)[0] = Obs->vec(2);
            
            ret[0] = -2.0/2.0*log(2.0*M_PI)+Class_MultivariateNormal::external_compute_LogDensity_forCovMat(2, &ObsA2,&MeanA2, &SigmaInvA2, &LogDetA2);
        }
        if(Type==5)
        {
            LogDetA2 = (Cont->PDmat[0].SigmaAcc.mat(1,1)*Cont->PDmat[0].SigmaAcc.mat(2,2) - pow(Cont->PDmat[0].SigmaAcc.mat(1,2),2.0));
            
            SigmaInvA2.Pmat(0,0)[0] = Cont->PDmat[0].SigmaAcc.mat(2,2)/LogDetA2;
            SigmaInvA2.Pmat(1,1)[0] = Cont->PDmat[0].SigmaAcc.mat(1,1)/LogDetA2;
            SigmaInvA2.Pmat(0,1)[0] = -1.0*Cont->PDmat[0].SigmaAcc.mat(1,2)/LogDetA2;
            SigmaInvA2.Pmat(1,0)[0] = -1.0*Cont->PDmat[0].SigmaAcc.mat(2,1)/LogDetA2;
            
            LogDetA2 = log(LogDetA2);
            
            MeanA2.Pvec(0)[0] = Mean.vec(1);
            MeanA2.Pvec(1)[0] = Mean.vec(2);
            
            ObsA2.Pvec(0)[0] = Obs->vec(1);
            ObsA2.Pvec(1)[0] = Obs->vec(2);
            
            ret[0] = -2.0/2.0*log(2.0*M_PI)+Class_MultivariateNormal::external_compute_LogDensity_forCovMat(2, &ObsA2,&MeanA2, &SigmaInvA2, &LogDetA2);
        }
        if(Type==4)
        {
            ret[0] = dnorm(Obs->vec(0),Mean.vec(0), pow(Cont->PDmat[0].SigmaAcc.mat(0,0),0.5),1 );
        }
        if(Type==6)
        {
            ret[0] = dnorm(Obs->vec(1),Mean.vec(1), pow(Cont->PDmat[0].SigmaAcc.mat(1,1),0.5),1 );
        }
        if(Type==7)
        {
            ret[0] = dnorm(Obs->vec(2),Mean.vec(2), pow(Cont->PDmat[0].SigmaAcc.mat(2,2),0.5),1 );
        }
        if(Type==8)
        {
            LogDetA2 = (Cont->PDmat[0].SigmaAcc.mat(1,1)*Cont->PDmat[0].SigmaAcc.mat(2,2) - pow(Cont->PDmat[0].SigmaAcc.mat(1,2),2.0));
            
            SigmaInvA2.Pmat(0,0)[0] = Cont->PDmat[0].SigmaAcc.mat(2,2)/LogDetA2;
            SigmaInvA2.Pmat(1,1)[0] = Cont->PDmat[0].SigmaAcc.mat(1,1)/LogDetA2;
            SigmaInvA2.Pmat(0,1)[0] = -1.0*Cont->PDmat[0].SigmaAcc.mat(1,2)/LogDetA2;
            SigmaInvA2.Pmat(1,0)[0] = -1.0*Cont->PDmat[0].SigmaAcc.mat(2,1)/LogDetA2;
            
            LogDetA2 = log(LogDetA2);
            
            MeanA2.Pvec(0)[0] = Mean.vec(1);
            MeanA2.Pvec(1)[0] = Mean.vec(2);
            
            ObsA2.Pvec(0)[0] = Obs->vec(1);
            ObsA2.Pvec(1)[0] = Obs->vec(2);
            
            Class_MultivariateNormal::external_computeConditioanlMeanAndVariance_uni(0,  MeanA1.P, SigmaA1.P, &Cont->PDmat[0].SigmaAccInv, &Mean, Obs);
            
            ret[0] = -2.0/2.0*log(2.0*M_PI)+Class_MultivariateNormal::external_compute_LogDensity_forCovMat(2, &ObsA2,&MeanA2, &SigmaInvA2, &LogDetA2)+pnorm(Obs->vec(0),MeanA1.vec(0), pow(SigmaA1.mat(0,0),0.5) ,1,1  );
        }
        if(Type==9)
        {
            MeanA1.Pvec(0)[0] = Mean.vec(0)+Cont->PDmat[0].SigmaAcc.mat(0,1)/Cont->PDmat[0].SigmaAcc.mat(1,1)*(Obs->vec(1)-Mean.vec(1));
            SigmaA1.Pmat(0,0)[0] = Cont->PDmat[0].SigmaAcc.mat(0,0)-Cont->PDmat[0].SigmaAcc.mat(0,1)/Cont->PDmat[0].SigmaAcc.mat(1,1)*Cont->PDmat[0].SigmaAcc.mat(0,1);
            
            ret[0] = dnorm(Obs->vec(1),Mean.vec(1), pow( Cont->PDmat[0].SigmaAcc.mat(1,1),0.5),1)+pnorm(Obs->vec(0),MeanA1.vec(0), pow( SigmaA1.mat(0,0),0.5) ,1,1  );
        }
        if(Type==10)
        {
            MeanA1.Pvec(0)[0] = Mean.vec(0)+Cont->PDmat[0].SigmaAcc.mat(0,2)/Cont->PDmat[0].SigmaAcc.mat(2,2)*(Obs->vec(2)-Mean.vec(2));
            SigmaA1.Pmat(0,0)[0] = Cont->PDmat[0].SigmaAcc.mat(0,0)-Cont->PDmat[0].SigmaAcc.mat(0,2)/Cont->PDmat[0].SigmaAcc.mat(2,2)*Cont->PDmat[0].SigmaAcc.mat(0,2);
            
            ret[0] = dnorm(Obs->vec(2),Mean.vec(2), pow( Cont->PDmat[0].SigmaAcc.mat(2,2),0.5),1)+pnorm(Obs->vec(0),MeanA1.vec(0), pow( SigmaA1.mat(0,0),0.5) ,1,1  );
        }
        if(Type==11)
        {
            ret[0] = pnorm(Obs->vec(0),Mean.vec(0), pow( Cont->PDmat[0].SigmaAcc.mat(0,0),0.5),1,1);
        }
        //# 0; \ \ \
        //# 1;  x x x
        //# 2;  x x \
        //# 3;  x \  x
        //# 4;  x \  \
        //# 5;  \ x  x
        //# 6;  \ x  \
        //# 7;  \ \  x
        //
        //# 8;  0 x x
        //# 9;  0 x \
        //# 10;  0 \  x
        //# 11;  0 \  \
        //        //Mean.Print("MEAN");
        //        //Cont->PDmat[0].SigmaAccInv.Print("SIGMAINV");
        //        ret[0] = external_compute_LogDensity_forCovMat(Obs->nElem, Obs,&Mean, &Cont->PDmat[0].SigmaAccInv, &Cont->PDmat[0].logdetAcc);
        //Rprintf("%f \n",ret[0]);
    }
    
    
    
    
    
    
};



class Class_NormalTrajectory: public Poly_Density
{
	// USARE LA MULTIVARIATA
    // le traiettorie sono solo spaziali (cioè due coordinate)
private:
    
public:
    
    int nClasses;
    
    // CONSTRUCTORS
    Class_NormalTrajectory(){
        // nClasses = 0;
    }
    
    // DESTRUCTORS
    ~Class_NormalTrajectory(){};
    
    
    // ADDS
    void add_nClasses(int k)
    {
        nClasses = k;
    }
    
    
    
    
    // GET
    //double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <Matrix<double>*>* hyper);
    //double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <Matrix<double>*>* hyper);
    
    int  get_nHyperparams() override
    {
        return(2);
    }
    string get_NameDistr()  override
    {
        string name = "NormalTrajectory";
        return(name);
        
    }
    vector<string>      get_NameHyperparams(int k) override
    {
        string par1 = "Mu";
        string par2 = "Sigma";
        //string par3 = "StartingAngle";
        //string par4 = "EndLocation";
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        //ret.push_back(par3);
        //ret.push_back(par4);
        return(ret);
    }
    Matrix<int> get_DimPar(int n) override
    {
        if(n!=2)
        {
            error("\n\nNormalTrajectory is valid only for bi-dimensional data\n\n");
        }
        Matrix<int> app = Matrix<int>(2,2,0);
        app.Pmat(0,0)[0]   = n;
        app.Pmat(0,1)[0]   = 1;
        
        app.Pmat(1,0)[0]   = n;
        app.Pmat(1,1)[0]   = n;
        
        //        app.Pmat(1,0)[0]   = 1;
        //        app.Pmat(1,1)[0]   = 1;
        
        //        app.Pmat(1,0)[0]   = n;
        //        app.Pmat(1,1)[0]   = 1;
        
        return(app);
    }
    
    static double external_compute_UnnormLogDensity(Vector <double>* Loc, Vector <double>* PrevLoc, Vector<double>  *mean , Matrix<double> *sigmaInv, double *logdet, Matrix<double> *R)
    {
        
        int     Itwo    = 2.0;
        double  Done    = 1.0;
        double  Dzero   = 0.0;
        int     Ione    = 1;
        
        
        
        double des;
        
        double ObsMinusMean[2];
        double InvCovMatrixApp[4];
        double InvCovMatrix[4];
        
        double ObsMinusMeanInvCov[2];
        
        ObsMinusMean[0] = Loc->vec(0) - ( PrevLoc->vec(0)+R->mat(0,0)*mean->vec(0)+R->mat(0,1)*mean->vec(1) );
        ObsMinusMean[1] = Loc->vec(1) - ( PrevLoc->vec(1)+R->mat(1,0)*mean->vec(0)+R->mat(1,1)*mean->vec(1) );
        
        
        sigmaInv->Pmat(1,0)[0] = sigmaInv->mat(0,1);
        
        // L'inversa di R è la sua trasposta
        // R^-1*SigmaInv
        InvCovMatrixApp[0] = R->mat(0,0)*sigmaInv->mat(0,0)+R->mat(1,0)*sigmaInv->mat(1,0);
        InvCovMatrixApp[1] = R->mat(0,0)*sigmaInv->mat(0,1)+R->mat(1,0)*sigmaInv->mat(1,1);
        InvCovMatrixApp[2] = R->mat(0,1)*sigmaInv->mat(0,0)+R->mat(1,1)*sigmaInv->mat(1,0);
        InvCovMatrixApp[3] = R->mat(0,1)*sigmaInv->mat(0,1)+R->mat(1,1)*sigmaInv->mat(1,1);
        
        // R*SigmaInv*R^-1T
        InvCovMatrix[0] = InvCovMatrixApp[0]*R->mat(0,0)+InvCovMatrixApp[1]*R->mat(1,0);
        InvCovMatrix[1] = InvCovMatrixApp[0]*R->mat(0,1)+InvCovMatrixApp[1]*R->mat(1,1);
        InvCovMatrix[2] = InvCovMatrixApp[2]*R->mat(0,0)+InvCovMatrixApp[3]*R->mat(1,0);
        InvCovMatrix[3] = InvCovMatrixApp[2]*R->mat(0,1)+InvCovMatrixApp[3]*R->mat(1,1);
        
        
        // P.S. The determinant of R is 1
        F77_NAME(dsymv)("L",&Itwo, &Done,&InvCovMatrix[0] ,&Itwo,&ObsMinusMean[0],&Ione, &Dzero, &ObsMinusMeanInvCov[0]  ,&Ione );
        des = -0.5*logdet[0]-0.5*F77_NAME(ddot)(&Itwo,&ObsMinusMeanInvCov[0], &Ione, &ObsMinusMean[0], &Ione);
        
        return( des );
    }
    
    
    static void external_Sample(Vector <double>* PrevLoc, Vector<double>  *mean , Matrix<double> *Chol, Matrix<double> *R, Vector<double> * ret)
    {
        
        double retApp_P[2];
        Vector<double>retApp(2,retApp_P);
        
        Class_MultivariateNormal::external_SampleMultivariate(&retApp,mean, Chol);
        
        ret->Pvec(0)[0] = R->mat(0,0)*retApp.vec(0)+R->mat(0,1)*retApp.vec(1)+PrevLoc->vec(0);
        ret->Pvec(1)[0] = R->mat(1,0)*retApp.vec(0)+R->mat(1,1)*retApp.vec(1)+PrevLoc->vec(1);
    }
    
    
    
    
    
    static void external_compute_RotationMatrix(double angle, Matrix<double> *ret)
    {
        ret->Pmat(0,0)[0] = cos(angle);
        ret->Pmat(0,1)[0] = -sin(angle);
        ret->Pmat(1,0)[0] = sin(angle);
        ret->Pmat(1,1)[0] = cos(angle);
    }
    static void external_compute_BivNormRotated(Vector<double> *ret, Matrix <double> * R, Vector<double> *retapp, Vector<double> *Loc,  Vector<double> *NextLoc)
    {
        retapp->Pvec(0)[0] = NextLoc->vec(0)-Loc->vec(0);
        retapp->Pvec(1)[0] = NextLoc->vec(1)-Loc->vec(1);
        
        ret->Pvec(0)[0] = R->mat(0,0)*retapp->vec(0)+R->mat(1,0)*retapp->vec(1);
        ret->Pvec(1)[0] = R->mat(0,1)*retapp->vec(0)+R->mat(1,1)*retapp->vec(1);
    }
    //    Class_NormalTrajectory::external_compute_BivNormRotated(&omega, &R, &omegaApp, &Loc,  &NextLoc);
    
    
    static void external_compute_Normal_from_Traj(int i,double *omega_P,double *RetAngStart, double * EndCoord,Matrix <double>* Y )
    {
        
        double RotAngle;
        double R_P[4];
        Matrix <double> R(2,2,R_P);
        
        int i2;
        int nvars   = Y->nCols;
        int nobs    = Y->nRows;
        
        
        Vector <double> omega(nvars,omega_P);
        
        double omegaApp_P[nvars];
        Vector <double> omegaApp(nvars,omegaApp_P);
        
        double Loc_P[2];
        Vector <double> Loc(2,Loc_P);
        
        double NextLoc_P[2];
        Vector <double> NextLoc(2,NextLoc_P);
        
        double PrevLoc_P[2];
        Vector <double> PrevLoc(2,PrevLoc_P);
        
        
        
        if(i==0)
        {
            Loc.P       = Y->Pmat(i,0);
            NextLoc.P   = Y->Pmat(i+1,0);
            
            RotAngle = RetAngStart[0];
            external_compute_RotationMatrix(RotAngle, &R);
            
            external_compute_BivNormRotated(&omega, &R, &omegaApp, &Loc,  &NextLoc);
            
        }else{
            if(i==(nobs-1))
            {
                PrevLoc.P   = Y->Pmat(i-1,0);
                Loc.P       = Y->Pmat(i,0);
                NextLoc.P   = EndCoord;
                
                RotAngle = atan2(Loc.vec(1)-PrevLoc.vec(1),Loc.vec(0)-PrevLoc.vec(0));
                Class_NormalTrajectory::external_compute_RotationMatrix(RotAngle, &R);
                
                Class_NormalTrajectory::external_compute_BivNormRotated(&omega, &R, &omegaApp, &Loc,  &NextLoc);
            }else{
                Loc.P       = Y->Pmat(i,0);
                NextLoc.P   = Y->Pmat(i+1,0);
                
                RotAngle = RetAngStart[0];
                external_compute_RotationMatrix(RotAngle, &R);
                
                external_compute_BivNormRotated(&omega, &R, &omegaApp, &Loc,  &NextLoc);
                
                for(i2=1;i2<nobs-1;i2++)
                {
                    
                    PrevLoc.P   = Y->Pmat(i2-1,0);
                    Loc.P       = Y->Pmat(i2,0);
                    NextLoc.P   = Y->Pmat(i2+1,0);
                    
                    RotAngle = atan2(Loc.vec(1)-PrevLoc.vec(1),Loc.vec(0)-PrevLoc.vec(0));
                    Class_NormalTrajectory::external_compute_RotationMatrix(RotAngle, &R);
                    
                    Class_NormalTrajectory::external_compute_BivNormRotated(&omega, &R, &omegaApp, &Loc,  &NextLoc);
                    
                    
                }
            }
        }
        
    }
	
	//	void compute_BivNormRotated_NormalTrajectory()
	//	{
	//		 // Ricordarsi che prima bisogna creare Ytrasformed
	//		 
	//		 // the locations
	//		 double Loc_P[nVars];
	//		 Vector <double> Loc(nVars,Loc_P);
	//		 
	//		 double PrevLoc_P[nVars];
	//		 Vector <double> PrevLoc(nVars,PrevLoc_P);
	//		 
	//		 double PrevPrevLoc_P[nVars];
	//		 Vector <double> PrevPrevLoc(nVars,PrevPrevLoc_P);
	//		 
	//		 double RotAngle;
	//		 double R_P[4];
	//		 Matrix <double> R(2,2,R_P);
	//		 
	//		 int t;
	//		 double ret_P[2];
	//		 Vector<double> ret(2,ret_P);
	//		 double retapp_P[2];
	//		 Vector<double> retapp(2,retapp_P);
	//		 
	//		 
	//		 
	//		 t = 0;
	//		 ret.P           = YTransformed.Pmat(t,0);
	//		 PrevLoc.P       = Y.Pmat(t,0);
	//		 Loc.P           = Y.Pmat(t+1,0);
	//		 RotAngle        = LatentVariables.Pvec(0)[0];
	//		 Class_NormalTrajectory::external_compute_RotationMatrix(RotAngle, &R);
	//		 Class_NormalTrajectory::external_compute_BivNormRotated(&ret, &R, &retapp, &PrevLoc,  &Loc);
	//		 
	//		 for(t=1;t<nObs-1;t++)
	//		 {
	//			  ret.P               = YTransformed.Pmat(t,0);
	//			  PrevPrevLoc.P       = Y.Pmat(t-1,0);
	//			  PrevLoc.P           = Y.Pmat(t,0);
	//			  Loc.P               = Y.Pmat(t+1,0);
	//			  
	//			  
	//			  RotAngle = atan2(PrevLoc.vec(1)-PrevPrevLoc.vec(1),PrevLoc.vec(0)-PrevPrevLoc.vec(0));
	//			  Class_NormalTrajectory::external_compute_RotationMatrix(RotAngle, &R);
	//			  Class_NormalTrajectory::external_compute_BivNormRotated(&ret, &R, &retapp, &PrevLoc,  &Loc);
	//		 }
	//		 t = nObs-1;
	//		 ret.P               = YTransformed.Pmat(t,0);
	//		 PrevPrevLoc.P       = Y.Pmat(t-1,0);
	//		 PrevLoc.P           = Y.Pmat(t,0);
	//		 Loc.P               = LatentVariables.Pvec(1);
	//		 
	//		 RotAngle = atan2(PrevLoc.vec(1)-PrevPrevLoc.vec(1),PrevLoc.vec(0)-PrevPrevLoc.vec(0));
	//		 Class_NormalTrajectory::external_compute_RotationMatrix(RotAngle, &R);
	//		 Class_NormalTrajectory::external_compute_BivNormRotated(&ret, &R, &retapp, &PrevLoc,  &Loc);
	//		 
	//		 
	//	}
    
};




class Class_MultiNormalTrajectoryReg: public Poly_Density
{
    // le traiettorie sono solo spaziali (cioè due coordinate)
private:
    
public:
    
    int nClasses;
    
    // CONSTRUCTORS
    Class_MultiNormalTrajectoryReg(){
        // nClasses = 0;
    }
    
    // DESTRUCTORS
    ~Class_MultiNormalTrajectoryReg(){};
    
    
    // ADDS
    void add_nClasses(int k)
    {
        nClasses = k;
    }
    
    
    
    
    // GET
    //double compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <Matrix<double>*>* hyper);
    //double compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <Matrix<double>*>* hyper);
    
    int  get_nHyperparams() override
    {
        return(4);
    }
    string get_NameDistr()  override
    {
        string name = "NormalTrajectory";
        return(name);
        
    }
    vector<string>      get_NameHyperparams(int k) override
    {
        string par1 = "Mu";
        string par2 = "Sigma";
		 string par3 = "phi";
		 string par4 = "eta0";
        //string par3 = "StartingAngle";
        //string par4 = "EndLocation";
        vector <string> ret;
        ret.push_back(par1);
        ret.push_back(par2);
        ret.push_back(par3);
        ret.push_back(par4);
        return(ret);
    }
    Matrix<int> get_DimPar(int n) override
    {
       
        Matrix<int> app = Matrix<int>(2,2,0);
        app.Pmat(0,0)[0]   = n;
        app.Pmat(0,1)[0]   = 1;
        
        app.Pmat(1,0)[0]   = n;
        app.Pmat(1,1)[0]   = n;
		 
		 
		 app.Pmat(2,0)[0]   = 1;
		 app.Pmat(2,1)[0]   = 1;
		 
		 app.Pmat(3,0)[0]   = 1;
		 app.Pmat(3,1)[0]   = 1;
        

        
        return(app);
    }
    
    static double external_compute_UnnormLogDensity(Vector <double>* Loc, Vector <double>* PrevLoc, Vector<double>  *mean , Matrix<double> *sigmaInv, double *logdet, Matrix<double> *R)
    {
		 error("CONTROLLARE");
        int     Itwo    = 2.0;
        double  Done    = 1.0;
        double  Dzero   = 0.0;
        int     Ione    = 1;
        
        
        
        double des;
        
        double ObsMinusMean[2];
        double InvCovMatrixApp[4];
        double InvCovMatrix[4];
        
        double ObsMinusMeanInvCov[2];
        
        ObsMinusMean[0] = Loc->vec(0) - ( PrevLoc->vec(0)+R->mat(0,0)*mean->vec(0)+R->mat(0,1)*mean->vec(1) );
        ObsMinusMean[1] = Loc->vec(1) - ( PrevLoc->vec(1)+R->mat(1,0)*mean->vec(0)+R->mat(1,1)*mean->vec(1) );
        
        
        sigmaInv->Pmat(1,0)[0] = sigmaInv->mat(0,1);
        
        // L'inversa di R è la sua trasposta
        // R^-1*SigmaInv
        InvCovMatrixApp[0] = R->mat(0,0)*sigmaInv->mat(0,0)+R->mat(1,0)*sigmaInv->mat(1,0);
        InvCovMatrixApp[1] = R->mat(0,0)*sigmaInv->mat(0,1)+R->mat(1,0)*sigmaInv->mat(1,1);
        InvCovMatrixApp[2] = R->mat(0,1)*sigmaInv->mat(0,0)+R->mat(1,1)*sigmaInv->mat(1,0);
        InvCovMatrixApp[3] = R->mat(0,1)*sigmaInv->mat(0,1)+R->mat(1,1)*sigmaInv->mat(1,1);
        
        // R*SigmaInv*R^-1T
        InvCovMatrix[0] = InvCovMatrixApp[0]*R->mat(0,0)+InvCovMatrixApp[1]*R->mat(1,0);
        InvCovMatrix[1] = InvCovMatrixApp[0]*R->mat(0,1)+InvCovMatrixApp[1]*R->mat(1,1);
        InvCovMatrix[2] = InvCovMatrixApp[2]*R->mat(0,0)+InvCovMatrixApp[3]*R->mat(1,0);
        InvCovMatrix[3] = InvCovMatrixApp[2]*R->mat(0,1)+InvCovMatrixApp[3]*R->mat(1,1);
        
        
        // P.S. The determinant of R is 1
        F77_NAME(dsymv)("L",&Itwo, &Done,&InvCovMatrix[0] ,&Itwo,&ObsMinusMean[0],&Ione, &Dzero, &ObsMinusMeanInvCov[0]  ,&Ione );
        des = -0.5*logdet[0]-0.5*F77_NAME(ddot)(&Itwo,&ObsMinusMeanInvCov[0], &Ione, &ObsMinusMean[0], &Ione);
        
        return( des );
    }
    
    
    static void external_Sample(Vector <double>* PrevLoc, Vector<double>  *mean , Matrix<double> *Chol, Matrix<double> *R, Vector<double> * ret)
    {
        error("CONTROLLARE");
        double retApp_P[2];
        Vector<double>retApp(2,retApp_P);
        
        Class_MultivariateNormal::external_SampleMultivariate(&retApp,mean, Chol);
        
        ret->Pvec(0)[0] = R->mat(0,0)*retApp.vec(0)+R->mat(0,1)*retApp.vec(1)+PrevLoc->vec(0);
        ret->Pvec(1)[0] = R->mat(1,0)*retApp.vec(0)+R->mat(1,1)*retApp.vec(1)+PrevLoc->vec(1);
    }
    
    
    
    
    
    static void external_compute_RotationMatrix(double angle, Matrix<double> *ret)
    {
		 error("CONTROLLARE");
        ret->Pmat(0,0)[0] = cos(angle);
        ret->Pmat(0,1)[0] = -sin(angle);
        ret->Pmat(1,0)[0] = sin(angle);
        ret->Pmat(1,1)[0] = cos(angle);
    }
    static void external_compute_BivNormRotated(Vector<double> *ret, Matrix <double> * R, Vector<double> *retapp, Vector<double> *Loc,  Vector<double> *NextLoc)
    {
		 error("CONTROLLARE");
        retapp->Pvec(0)[0] = NextLoc->vec(0)-Loc->vec(0);
        retapp->Pvec(1)[0] = NextLoc->vec(1)-Loc->vec(1);
        
        ret->Pvec(0)[0] = R->mat(0,0)*retapp->vec(0)+R->mat(1,0)*retapp->vec(1);
        ret->Pvec(1)[0] = R->mat(0,1)*retapp->vec(0)+R->mat(1,1)*retapp->vec(1);
    }
    //    Class_NormalTrajectory::external_compute_BivNormRotated(&omega, &R, &omegaApp, &Loc,  &NextLoc);
    
    
    static void external_compute_Normal_from_Traj(int i,double *omega_P,double *RetAngStart, double * EndCoord,Matrix <double>* Y )
    {
        error("CONTROLLARE");
        double RotAngle;
        double R_P[4];
        Matrix <double> R(2,2,R_P);
        
        int i2;
        int nvars   = Y->nCols;
        int nobs    = Y->nRows;
        
        
        Vector <double> omega(nvars,omega_P);
        
        double omegaApp_P[nvars];
        Vector <double> omegaApp(nvars,omegaApp_P);
        
        double Loc_P[2];
        Vector <double> Loc(2,Loc_P);
        
        double NextLoc_P[2];
        Vector <double> NextLoc(2,NextLoc_P);
        
        double PrevLoc_P[2];
        Vector <double> PrevLoc(2,PrevLoc_P);
        
        
        
        if(i==0)
        {
            Loc.P       = Y->Pmat(i,0);
            NextLoc.P   = Y->Pmat(i+1,0);
            
            RotAngle = RetAngStart[0];
            external_compute_RotationMatrix(RotAngle, &R);
            
            external_compute_BivNormRotated(&omega, &R, &omegaApp, &Loc,  &NextLoc);
            
        }else{
            if(i==(nobs-1))
            {
                PrevLoc.P   = Y->Pmat(i-1,0);
                Loc.P       = Y->Pmat(i,0);
                NextLoc.P   = EndCoord;
                
                RotAngle = atan2(Loc.vec(1)-PrevLoc.vec(1),Loc.vec(0)-PrevLoc.vec(0));
                Class_NormalTrajectory::external_compute_RotationMatrix(RotAngle, &R);
                
                Class_NormalTrajectory::external_compute_BivNormRotated(&omega, &R, &omegaApp, &Loc,  &NextLoc);
            }else{
                Loc.P       = Y->Pmat(i,0);
                NextLoc.P   = Y->Pmat(i+1,0);
                
                RotAngle = RetAngStart[0];
                external_compute_RotationMatrix(RotAngle, &R);
                
                external_compute_BivNormRotated(&omega, &R, &omegaApp, &Loc,  &NextLoc);
                
                for(i2=1;i2<nobs-1;i2++)
                {
                    
                    PrevLoc.P   = Y->Pmat(i2-1,0);
                    Loc.P       = Y->Pmat(i2,0);
                    NextLoc.P   = Y->Pmat(i2+1,0);
                    
                    RotAngle = atan2(Loc.vec(1)-PrevLoc.vec(1),Loc.vec(0)-PrevLoc.vec(0));
                    Class_NormalTrajectory::external_compute_RotationMatrix(RotAngle, &R);
                    
                    Class_NormalTrajectory::external_compute_BivNormRotated(&omega, &R, &omegaApp, &Loc,  &NextLoc);
                    
                    
                }
            }
        }
        
    }
	
	//	void compute_BivNormRotated_NormalTrajectory()
	//	{
	// error("CONTROLLARE");
	//		 // Ricordarsi che prima bisogna creare Ytrasformed
	//		 
	//		 // the locations
	//		 double Loc_P[nVars];
	//		 Vector <double> Loc(nVars,Loc_P);
	//		 
	//		 double PrevLoc_P[nVars];
	//		 Vector <double> PrevLoc(nVars,PrevLoc_P);
	//		 
	//		 double PrevPrevLoc_P[nVars];
	//		 Vector <double> PrevPrevLoc(nVars,PrevPrevLoc_P);
	//		 
	//		 double RotAngle;
	//		 double R_P[4];
	//		 Matrix <double> R(2,2,R_P);
	//		 
	//		 int t;
	//		 double ret_P[2];
	//		 Vector<double> ret(2,ret_P);
	//		 double retapp_P[2];
	//		 Vector<double> retapp(2,retapp_P);
	//		 
	//		 
	//		 
	//		 t = 0;
	//		 ret.P           = YTransformed.Pmat(t,0);
	//		 PrevLoc.P       = Y.Pmat(t,0);
	//		 Loc.P           = Y.Pmat(t+1,0);
	//		 RotAngle        = LatentVariables.Pvec(0)[0];
	//		 Class_NormalTrajectory::external_compute_RotationMatrix(RotAngle, &R);
	//		 Class_NormalTrajectory::external_compute_BivNormRotated(&ret, &R, &retapp, &PrevLoc,  &Loc);
	//		 
	//		 for(t=1;t<nObs-1;t++)
	//		 {
	//			  ret.P               = YTransformed.Pmat(t,0);
	//			  PrevPrevLoc.P       = Y.Pmat(t-1,0);
	//			  PrevLoc.P           = Y.Pmat(t,0);
	//			  Loc.P               = Y.Pmat(t+1,0);
	//			  
	//			  
	//			  RotAngle = atan2(PrevLoc.vec(1)-PrevPrevLoc.vec(1),PrevLoc.vec(0)-PrevPrevLoc.vec(0));
	//			  Class_NormalTrajectory::external_compute_RotationMatrix(RotAngle, &R);
	//			  Class_NormalTrajectory::external_compute_BivNormRotated(&ret, &R, &retapp, &PrevLoc,  &Loc);
	//		 }
	//		 t = nObs-1;
	//		 ret.P               = YTransformed.Pmat(t,0);
	//		 PrevPrevLoc.P       = Y.Pmat(t-1,0);
	//		 PrevLoc.P           = Y.Pmat(t,0);
	//		 Loc.P               = LatentVariables.Pvec(1);
	//		 
	//		 RotAngle = atan2(PrevLoc.vec(1)-PrevPrevLoc.vec(1),PrevLoc.vec(0)-PrevPrevLoc.vec(0));
	//		 Class_NormalTrajectory::external_compute_RotationMatrix(RotAngle, &R);
	//		 Class_NormalTrajectory::external_compute_BivNormRotated(&ret, &R, &retapp, &PrevLoc,  &Loc);
	//		 
	//		 
	//	}
    
};







class Mean_ToPass
{
private:
    
public:
    int UseControlledMemory;
    int nObs;
    
    Vector<double> *MeanAcc;
    Vector<double> *MeanProp;
    
    Matrix<double> XtInvX;
    Vector<double> XtInvOmega;
    Matrix<double> XtInv;
    Vector<double> Simapp;
    
    Mean_ToPass(){}
    
    ~Mean_ToPass(){}
    
    void Destroy()
    {
        MeanAcc->Destroy();
        MeanProp->Destroy();
    }
};





class Class_RegMean: public Mean_ToPass{
private:
    
public:
    
    int nCovariates;
    vector <Class_Parameter> *RegParameters;
    Matrix<double> *Covariates;
    
    
    int isGibbsPossible;
    
    //COSTRUCTORS
    Class_RegMean(){};
    //DESTRUCTORS
    ~Class_RegMean(){}
    void Destroy()
    {
        Covariates->Destroy();
        for(int i=0;i<RegParameters->size();i++)
        {
            //RegParameters[0][i].Destroy
        }
        XtInv.Destroy();
        XtInvX.Destroy();
        Simapp.Destroy();
    }
    
    void creat_FullObject(vector <Class_Parameter> *parameter, Matrix<double> *covariates, int usr )
    {
        UseControlledMemory     = usr;
        RegParameters   = parameter;
        Covariates      = covariates;
        
        nCovariates     = Covariates->nCols;
        nObs            = Covariates->nRows;
        
        MeanAcc             = new Vector<double>(nObs, UseControlledMemory );
        MeanProp            = new  Vector<double>(nObs, UseControlledMemory );
        
    }
    
    void creat_FullObjectNoMean(vector <Class_Parameter> *parameter, Matrix<double> *covariates, int usr )
    {
        UseControlledMemory     = usr;
        RegParameters   = parameter;
        Covariates      = covariates;
        
        nCovariates     = Covariates->nCols;
        nObs            = Covariates->nRows;
        
        //MeanAcc             = new Vector<double>(nObs, UseControlledMemory );
        //MeanProp            = new  Vector<double>(nObs, UseControlledMemory );
        
    }
    
    // UPDATE
    void update_MeanAcc()
    {
        MeanAcc->Init(0.0);
        for(int i=0;i<nObs;i++)
        {
            for(int j=0;j<nCovariates;j++)
            {
                MeanAcc[0].Pvec(i)[0] += RegParameters[0][j].ParameterAcc*Covariates[0].mat(i,j);
            }
        }
    }
    void update_MeanProp()
    {
        MeanProp->Init(0.0);
        for(int i=0;i<nObs;i++)
        {
            for(int j=0;j<nCovariates;j++)
            {
                MeanProp[0].Pvec(i)[0] += RegParameters[0][j].ParameterProp*Covariates[0].mat(i,j);
            }
        }
    }
    void UpdateIfAccepted()
    {
        double *app;
        app = MeanAcc->P;
        MeanAcc->P = MeanProp->P;
        MeanProp->P = app;
    }
    void DoGibbs()
    {
        XtInvX          = Matrix<double>(nCovariates,nCovariates,UseControlledMemory);
        XtInvOmega      = Vector<double>(nCovariates,UseControlledMemory);
        XtInv           = Matrix<double>(nObs,nCovariates,UseControlledMemory);
        Simapp           = Vector<double>(nCovariates,UseControlledMemory);
        
    }
    
    void sample_fullconditional(Matrix<double> *Inv, Vector<double> *omega)
    {
        //* ricordarsi di fare doGibbs (vedi sopra)
        double Done    = 1.0;
        double Dzero   = 0.0;
        int Ione        = 1;
        int info;
        
        
        
        
        F77_NAME(dsymm)("R", "L", &nCovariates, &nObs, &Done, Inv->P, &nObs, Covariates->P, &nCovariates, &Dzero, XtInv.P, &nCovariates);
        
        F77_NAME(dgemm)("N", "T", &nCovariates, &nCovariates, &nObs, &Done, XtInv.P, &nCovariates, Covariates->P, &nCovariates, &Dzero, XtInvX.P , &nCovariates);
        
        F77_NAME(dgemv)("N", &nCovariates, &nObs,  &Done, XtInv.P, &nCovariates, omega->P, &Ione, &Dzero, XtInvOmega.P, &Ione);
        
        // Add the priors
        for(int i=0;i<nCovariates;i++)
        {
            XtInvOmega.Pvec(i)[0]     += RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(0)[0]/RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
            
            XtInvX.Pmat(i,i)[0]     += 1.0/RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
        }
        
        F77_NAME(dpotrf)("L",&nCovariates, XtInvX.P, &nCovariates, &info);
        if(info != 0)
        {
            error("Cpp error Cholesky failed - function: sample_fullconditional\n");
        }
        
        F77_NAME(dpotri)("L",&nCovariates, XtInvX.P, &nCovariates, &info);
        if(info != 0)
        {
            error("Cpp error Cholesky inverse - function: sample_fullconditional\n");
        }
        
        
        F77_NAME(dsymv)("L", &nCovariates, &Done, XtInvX.P, &nCovariates, XtInvOmega.P, &Ione, &Dzero, XtInv.P, &Ione);
        
        
        
        
        
        
        
        F77_NAME(dpotrf)("L",&nCovariates, XtInvX.P, &nCovariates, &info);
        if(info != 0)
        {
            error("Cpp error Cholesky failed - function: sample_fullconditional\n");
        }
        
        for(int i=0;i<nCovariates;i++)
        {
            Simapp.Pvec(i)[0] = rnorm(0.0,1.0);
        }
        F77_NAME(dtrmv)("L", "N", "N", &nCovariates, XtInvX.P, &nCovariates, Simapp.P, &Ione);
        
        F77_NAME(daxpy)(&nCovariates, &Done, XtInv.P, &Ione, Simapp.P, &Ione);
        
        for(int i=0;i<nCovariates;i++)
        {
            RegParameters[0][i].ParameterAcc =   Simapp.Pvec(i)[0];
        }
        
        
        
        
    }
    
    
    
    
    
    static void external_ParametersForFullConditioanlBeta_WithoutMolt(Matrix <double> *Covariate, Matrix<double> *Inv, Vector<double> *omega, Matrix <double> *retMat, Vector<double> *retVec)
    {
        // FINIRE DI SISTEMARE -  USARE QUELLA SOTTO
        
        // t gives the values XS^-1X and XS^-1y
        
        int nCov    = Covariate->nCols;
        int nBeta   = Covariate->nRows;
        
        double              A_XtInv_P[nBeta*nCov];
        //Matrix<double>      A_XtInv(nBeta,nCov,A_XtInv_P);
        
        
        
        // XtInvX          = Matrix<double>(nCovariates,nCovariates,UseControlledMemory);
        // XtInvOmega      = Vector<double>(nCovariates,UseControlledMemory);
        
        //Simapp           = Vector<double>(nCovariates,UseControlledMemory);
        
        
        
        F77_NAME(dsymm)("R", "L", &nCov, &nBeta, &Class_ToLoad::Done, Inv->P, &nBeta, Covariate->P, &nCov, &Class_ToLoad::Dzero, &A_XtInv_P[0], &nCov);
        F77_NAME(dgemm)("N", "T", &nCov, &nCov, &nBeta, &Class_ToLoad::Done, &A_XtInv_P[0], &nCov, Covariate->P, &nCov, &Class_ToLoad::Dzero, retMat->P , &nCov);
        
        F77_NAME(dgemv)("N", &nCov, &nBeta,  &Class_ToLoad::Done, &A_XtInv_P[0], &nCov, omega->P, &Class_ToLoad::Ione, &Class_ToLoad::Dzero, retVec->P, &Class_ToLoad::Ione);
        
    }
    
    static void external_ParametersForFullConditioanlBeta_WithoutMolt(Matrix <double> *Covariate, Matrix<double> *Inv, Vector<double> *omega, Matrix <double> *retMat, Vector<double> *retVec, const double *AddOrNot)
    {
        //usare sotto, toltopointer AddOrNot
        // t gives the values XS^-1X and XS^-1y
        
        int nCov    = Covariate->nCols;
        int nBeta   = Covariate->nRows;
        
        double              A_XtInv_P[nBeta*nCov];
        //Matrix<double>      A_XtInv(nBeta,nCov,A_XtInv_P);
        
        
        F77_NAME(dsymm)("R", "L", &nCov, &nBeta, &Class_ToLoad::Done, Inv->P, &nBeta, Covariate->P, &nCov, &Class_ToLoad::Dzero, &A_XtInv_P[0], &nCov);
        F77_NAME(dgemm)("N", "T", &nCov, &nCov, &nBeta, &Class_ToLoad::Done, &A_XtInv_P[0], &nCov, Covariate->P, &nCov, AddOrNot, retMat->P , &nCov);
        
        F77_NAME(dgemv)("N", &nCov, &nBeta,  &Class_ToLoad::Done, &A_XtInv_P[0], &nCov, omega->P, &Class_ToLoad::Ione, AddOrNot, retVec->P, &Class_ToLoad::Ione);
        
    }
    static void external_ParametersForFullConditioanlBeta_WithoutMolt(Matrix <double> *Covariate, Matrix<double> *Inv, Vector<double> *omega, Matrix <double> *retMat, Vector<double> *retVec, const double AddOrNot)
    {
        //usare sotto, toltopointer AddOrNot
        // t gives the values XS^-1X and XS^-1y
        
        int nCov    = Covariate->nCols;
        int nBeta   = Covariate->nRows;
        
        double              A_XtInv_P[nBeta*nCov];
        //Matrix<double>      A_XtInv(nBeta,nCov,A_XtInv_P);
        
        
        F77_NAME(dsymm)("R", "L", &nCov, &nBeta, &Class_ToLoad::Done, Inv->P, &nBeta, Covariate->P, &nCov, &Class_ToLoad::Dzero, &A_XtInv_P[0], &nCov);
        F77_NAME(dgemm)("N", "T", &nCov, &nCov, &nBeta, &Class_ToLoad::Done, &A_XtInv_P[0], &nCov, Covariate->P, &nCov, &AddOrNot, retMat->P , &nCov);
        
        F77_NAME(dgemv)("N", &nCov, &nBeta,  &Class_ToLoad::Done, &A_XtInv_P[0], &nCov, omega->P, &Class_ToLoad::Ione, &AddOrNot, retVec->P, &Class_ToLoad::Ione);
        
    }
    
    static void external_SampleFromFullConditionl(Vector<double> *ret, Matrix <double> *XtSminus1S, Vector <double> * XtSminus1Y)
    {
        double appMeanPar_P[XtSminus1Y->nElem];
        Vector<double> appMeanPar(XtSminus1Y->nElem,appMeanPar_P);
        
        Class_Utils::external_computeCholesky(XtSminus1S);
        Class_Utils::external_computeInverseFromCholesky(XtSminus1S);
        Class_Utils::external_dsymv_MatMoltX(XtSminus1S, XtSminus1Y, &appMeanPar);
        Class_Utils::external_computeCholesky(XtSminus1S);
        Class_MultivariateNormal::external_SampleMultivariate(ret, &appMeanPar, XtSminus1S);
        
    }
    
    void priorParameters_forGibbs(Matrix<double> *PriorVarInv, Vector<double> *PriorMuPriorVarInv)
    {
        
        PriorVarInv->Init(0.0);
        for(int i=0;i<nCovariates;i++)
        {
            PriorMuPriorVarInv->Pvec(i)[0]     = RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(0)[0]/RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
            
            PriorVarInv->Pmat(i,i)[0]     = 1.0/RegParameters[0][i].PriorParameter[0].HyperparametersAcc.vec(1)[0];
        }
    }
    
};



/********************************************
 Coregionalization matrix
 ********************************************/

class CovMatrix_ToPass
{
private:
    
public:
    
    int DimCoreg; // attenzione, per la dimensione effettiva usare nTot/nObs
    int nObs;
    int nTot;
    int UserControlledMemory;
    
    double logdeterminantAcc;
    double logdeterminantProp;
    
    Matrix<double> SigmaCholAcc;
    Matrix<double> SigmaAcc;
    Matrix<double> SigmaInvAcc;
    
    
    Matrix<double> SigmaCholProp;
    Matrix<double> SigmaProp;
    Matrix<double> SigmaInvProp;
    
    
    CovMatrix_ToPass(){};
    
    ~CovMatrix_ToPass(){};
    
    void Destroy()
    {
        SigmaCholAcc.Destroy();
        SigmaAcc.Destroy();
        SigmaInvAcc.Destroy();
        
        SigmaCholProp.Destroy();
        SigmaProp.Destroy();
        SigmaInvProp.Destroy();
    }
    
    
    
    
    
};
//


#endif

