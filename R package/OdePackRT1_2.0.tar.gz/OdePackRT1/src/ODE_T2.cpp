#include <iostream>
#include <string>
#include <list>
#include <vector>
#ifdef _OPENMP
#include <omp.h>
#endif
#include <boost/numeric/odeint.hpp>

#include <R.h>//TTT
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>

#include "MatricesAndVectors.h"
#include "AdaptiveMH.h"
#include "ODE.h"//
//#include <Rcpp.h>

extern "C" {


SEXP ODE_T2(
SEXP nInits_r,
SEXP Inits_r,
SEXP NamePrior_r,
SEXP nParameters_r,
SEXP Prior_r,
SEXP nSd_r,
SEXP Sd_r,
SEXP MCMC_r,
SEXP Adaptpar_r,
SEXP Data_r,
SEXP indices_r,
SEXP indicesDouble_r,
SEXP IndexNotNA_r,
SEXP TEXT_r
           ){

  /*****************************************
          UTILS
   *****************************************/
  GetRNGstate();


  int i,j;
  double      *appPointDouble;
  int         *appPointInteger;

  int indexPriorParameters;
  int indexInit;
  string Name;
  string appName;

  int UserControlledMemory = 1;
  /*****************************************
           NAMES
   *****************************************/

  /********** Init Values ************/
  const int nInitsVector_R                    = 20;
  string  InitsVector_R[nInitsVector_R ]      = {
    "Beta0",
    "Beta1",
    "sigma2",
      "Y0",
      "MinK",
      "EtaK1",
      "EtaK2",
      "MeanK",
      "VarK",
    "EtaK1Mean",
    "EtaK2Mean",
    "MeanKMean",
    "VarKMean",
    "EtaK1Var",
    "EtaK2Var",
    "MeanKVar",
    "VarKVar",
      "Void"
  };

  vector <string> Names_ParametersInit;
  for(int i=0;i<nInitsVector_R;i++)
  {
      Names_ParametersInit.push_back(InitsVector_R[i]);
  }

  /********** Parameters ************/
  const int nParametersVector_R                           = 20;
  string ParametersVector_R[nParametersVector_R ]         = {
    "Beta0",
    "Beta1",
    "sigma2",
      "Y0",
      "MinK",
      "EtaK1",
      "EtaK2",
      "MeanK",
      "VarK",
    "EtaK1Mean",
    "EtaK2Mean",
    "MeanKMean",
    "VarKMean",
    "EtaK1Var",
    "EtaK2Var",
    "MeanKVar",
    "VarKVar",
      "Void"
  };
  vector <string> Names_ParametersPrior;
  for(int i=0;i<nParametersVector_R;i++)
  {
      Names_ParametersPrior.push_back(ParametersVector_R[i]);
  }


  /********** Priors ************/
  const int nPriorsVector_R                   = 11;
  string PriorsVector_R[nPriorsVector_R]      = {
      "NoPrior",
      "Normal",
      "Gamma",
      "InverseGamma",
      "Uniform",
      "InverseWishart",
      "HuangWand",
      "Dirichlet",
      "PositiveTruncatedNormal",
    "TruncatedNormal",
      "Void"};
  vector <string> Names_Priors;
  for(int i=0;i<nPriorsVector_R;i++)
  {
      Names_Priors.push_back(PriorsVector_R[i]);
  }

  /********** SD Adapt ************/
  const int nSdVector_R                           = 20;
  string SdVector_R[nSdVector_R ]         = {
    "Beta0",
    "Beta1",
      "General",
      "MinK",
      "EtaK1",
      "EtaK2",
      "MeanK",
      "VarK",
      "Y0",
    "EtaK1Mean",
    "EtaK2Mean",
    "MeanKMean",
    "VarKMean",
    "EtaK1Var",
    "EtaK2Var",
    "MeanKVar",
    "VarKVar",
      "Void"
  };
  vector <string> Names_Sd;
  for(int i=0;i<nSdVector_R;i++)
  {
      Names_Sd.push_back(SdVector_R[i]);
  }

  /*****************************************
   Indices
   *****************************************/

  int *indices                     = INTEGER(indices_r);

  i = 0;
  int nvar        = indices[i];i++;
  int nobsTOT     = indices[i];i++;
  int nG          = indices[i];i++;
  int nt          = indices[i];i++;
  int nrep        = indices[i];i++;
  int IterShow    = indices[i];i++;
  int DoParallel  = indices[i];i++;
  int Nthreads    = indices[i];i++;
  int Verbose     = indices[i];i++;
  int nlatentk    = indices[i];i++;
  int nstep       = indices[i];i++;
  int saveODE     = indices[i];i++;
  int nNotna      = indices[i];i++;
  int Rparam      = indices[i];i++;
  int sample_Var  = indices[i];i++;
  int sample_Ode  = indices[i];i++;
  int SampleOdeType= indices[i];i++;



  double *indicesD                     = REAL(indicesDouble_r);
  i = 0;
  double tmin        = indicesD[i];i++;
  double tmax        = indicesD[i];i++;
  double deltat      = indicesD[i];i++;
  double abs_err    = indicesD[i];i++;
  double rel_err    = indicesD[i];i++;

  /*****************************************
   ParallelComp
   *****************************************/


  #ifdef _OPENMP
  if(DoParallel==1)
  {
    omp_set_num_threads(min(Nthreads,omp_get_num_procs()));
  }else{
    omp_set_num_threads(1);
  }
  if(Verbose==1)
  {
    REprintf("ParmeterNthreads: %i\n",Nthreads);
    REprintf("NumberOfProcessors: %i\n ",omp_get_num_procs());
    REprintf("MaxNumberOfThreads: %i\n\n",omp_get_max_threads());
    # pragma omp parallel
    {
      REprintf("CheckThread: %i\n", omp_get_thread_num());
    }
    REprintf("\n");
  }
  #else
  if(DoParallel==1)
  {
    if(Verbose==1)
    {
      REprintf("OPENMP - not possible\n\n");
    }

  }
  #endif
  /*****************************************
   MCMC and ADAPT
   *****************************************/

  appPointInteger             = INTEGER(MCMC_r);
  int MCMCiter                = appPointInteger[0];
  int MCMCburnin              = appPointInteger[1];
  int MCMCthin                = appPointInteger[2];
  int MCMCiter_noTandB        = appPointInteger[3];
  int nSamples_save           = MCMCiter_noTandB+1;

  i=0;
  appPointDouble              = REAL(Adaptpar_r);
  int     AdaptStart          = (int)appPointDouble[i];i++;
  int     AdaptEnd            = (int)appPointDouble[i];i++;
  double  AdaptExp            = appPointDouble[i];i++;
  double  AdaptAcc            = appPointDouble[i];i++;
  int     AdaptBatch          = (int)appPointDouble[i];i++;
  double  AdaptEps            = appPointDouble[i];i++;
  double  AdaptLambda         = appPointDouble[i];i++;

  Class_AdaptPar      AdaptParameters(AdaptStart,AdaptEnd, AdaptExp, AdaptAcc, AdaptBatch);

  if(Verbose==1)
  {
    REprintf("MCMC parameters:\n");
    REprintf("Iterations=%i Burnin=%i Thin=%i SampleSave=%i\n\n", MCMCiter,MCMCburnin,MCMCthin , nSamples_save);

    REprintf("Adapt parameters:\n");
    REprintf("Start=%i End=%i AccRatio=%f \nBatch=%i Epsilon=%f Exponent=%f \n\n",AdaptStart,AdaptEnd ,AdaptAcc,AdaptBatch,AdaptEps,AdaptExp);
  }
  /*****************************************
  Parameters
  *****************************************/
  #pragma mark Par Beta

  Name                 = "Beta1";
   indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
   indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

   double *Beta1_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
   string Beta1_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
   double *Beta1_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


   vector<Poly_Prior* >            Beta1_Prior;
   vector<Class_Parameter>         Beta1_MCMC;

   if(Beta1_PriorName=="NoPrior")
   {
     for(i=0;i<nvar;i++)
     {
         Beta1_Prior.push_back(new Class_NoPrior);
         Beta1_Prior[i]->create_FullObject(UserControlledMemory);
     }
   }else{
     if(Beta1_PriorName=="Uniform")
     {
         for(i=0;i<nvar;i++)
         {
             Beta1_Prior.push_back(new Class_Uniform);
             Beta1_Prior[i]->create_FullObject(UserControlledMemory);
         }

     }else{
       if(Beta1_PriorName=="Normal")
       {
         for(i=0;i<nvar;i++)
         {
           Beta1_Prior.push_back(new Class_Normal);
           Beta1_Prior[i]->create_FullObject(UserControlledMemory);
         }
       }else{
         error("Prior on Beta1 not well specified");
       }
     }
   }


   for(i=0;i<nvar;i++)
   {
       for(int k=0;k<Beta1_Prior[i]->nHyperparams;k++)
       {
           Beta1_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = Beta1_PriorParameters[k*nvar+i];
           Beta1_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = Beta1_PriorParameters[k*nvar+i];
       }
   }
   for(i=0;i<nvar;i++)
   {
       Beta1_MCMC.push_back(Class_Parameter());
       appName = (("Beta1_")+to_string(i));
       Beta1_MCMC[i].create_FullObject(Beta1_InitParameters[i], appName,  Beta1_Prior[i]);
   }
   for(i=0;i<nvar;i++)
   {
       Beta1_MCMC[i].add_Pointerparameters_InVector();
   }


  Name                 = "Beta0";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

  double *Beta0_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string Beta0_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *Beta0_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  vector<Poly_Prior* >            Beta0_Prior;
  vector<Class_Parameter>         Beta0_MCMC;

  if(Beta0_PriorName=="NoPrior")
  {
    for(i=0;i<nvar;i++)
    {
        Beta0_Prior.push_back(new Class_NoPrior);
        Beta0_Prior[i]->create_FullObject(UserControlledMemory);
    }
  }else{
    if(Beta0_PriorName=="Uniform")
    {
        for(i=0;i<nvar;i++)
        {
            Beta0_Prior.push_back(new Class_Uniform);
            Beta0_Prior[i]->create_FullObject(UserControlledMemory);
        }

    }else{
      if(Beta0_PriorName=="Normal")
      {
        for(i=0;i<nvar;i++)
        {
          Beta0_Prior.push_back(new Class_Normal);
          Beta0_Prior[i]->create_FullObject(UserControlledMemory);
        }
      }else{
        error("Prior on Beta0 not well specified");
      }
    }
  }


  for(i=0;i<nvar;i++)
  {
      for(int k=0;k<Beta0_Prior[i]->nHyperparams;k++)
      {
          Beta0_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = Beta0_PriorParameters[k*nvar+i];
          Beta0_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = Beta0_PriorParameters[k*nvar+i];
      }
  }
  for(i=0;i<nvar;i++)
  {
      Beta0_MCMC.push_back(Class_Parameter());
      appName = (("Beta0_")+to_string(i));
      Beta0_MCMC[i].create_FullObject(Beta0_InitParameters[i], appName,  Beta0_Prior[i]);
  }
  for(i=0;i<nvar;i++)
  {
      Beta0_MCMC[i].add_Pointerparameters_InVector();
  }

  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/
  #pragma mark Par MinK

  Name                 = "MinK";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

  double *MinK_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string MinK_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *MinK_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  vector<vector<Poly_Prior* >   >            MinK_Prior; // uno per i k
  vector< vector <Class_Parameter > >        MinK_MCMC; // k/nvar/cluster
  if(MinK_PriorName=="Normal")
  {
    for(int g=0;g<nG;g++)
    {
      MinK_Prior.push_back(vector<Poly_Prior* >());
      for(i=0;i<nlatentk;i++)
      {
        MinK_Prior[g].push_back(new Class_Normal);
        MinK_Prior[g][i]->create_FullObject(UserControlledMemory);
      }
    }
  }else{
    if(MinK_PriorName=="NoPrior")
    {
      for(int g=0;g<nG;g++)
      {
        MinK_Prior.push_back(vector<Poly_Prior* >());
        for(i=0;i<nlatentk;i++)
        {
          MinK_Prior[g].push_back(new Class_NoPrior);
          MinK_Prior[g][i]->create_FullObject(UserControlledMemory);
        }
      }
    }else{
      if(MinK_PriorName=="Uniform")
      {
        for(int g=0;g<nG;g++)
        {
          MinK_Prior.push_back(vector<Poly_Prior* >());
          for(i=0;i<nlatentk;i++)
          {
            MinK_Prior[g].push_back(new Class_Uniform);
            MinK_Prior[g][i]->create_FullObject(UserControlledMemory);
          }
        }
      }else{
        if(MinK_PriorName=="InverseGamma")
        {
          for(int g=0;g<nG;g++)
          {
            MinK_Prior.push_back(vector<Poly_Prior* >());
            for(i=0;i<nlatentk;i++)
            {
              MinK_Prior[g].push_back(new Class_InverseGamma);
              MinK_Prior[g][i]->create_FullObject(UserControlledMemory);
            }
          }

        }else{
          if(MinK_PriorName=="TruncatedNormal")
          {
            for(int g=0;g<nG;g++)
            {
              MinK_Prior.push_back(vector<Poly_Prior* >());
              for(i=0;i<nlatentk;i++)
              {
                MinK_Prior[g].push_back(new Class_TruncatedNormal);
                MinK_Prior[g][i]->create_FullObject(UserControlledMemory);
              }
            }
          }else{
            error("Prior on MinK not well specified");
          }

        }
      }
    }

  }

  for(int g=0;g<nG;g++)
  {
    for(i=0;i<nlatentk;i++)
    {
      for(int k=0;k<MinK_Prior[g][i]->nHyperparams;k++)
      {
        MinK_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = MinK_PriorParameters[k*nlatentk+i];
        MinK_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = MinK_PriorParameters[k*nlatentk+i];
      }
    }
  }


  for(i=0;i<nG;i++)
  {
    MinK_MCMC.push_back(vector<Class_Parameter >());
    for(j=0;j<nlatentk;j++)
    {
      MinK_MCMC[i].push_back(Class_Parameter());
      appName = (("MinK_")+to_string(i)+to_string(j));
      MinK_MCMC[i][j].create_FullObject(MinK_InitParameters[i*nlatentk+j], appName,  MinK_Prior[i][j]);
    }
  }
  for(i=0;i<nG;i++)
  {
    for(j=0;j<nlatentk;j++)
    {
      MinK_MCMC[i][j].add_Pointerparameters_InVector();
    }
  }






  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/
  #pragma mark Par EtaK1

//  Name                 = "EtaK1Var";
//  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
//  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);
//
//  double *EtaK1Var_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
//  string EtaK1Var_PriorName         = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
//  double *EtaK1Var_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));
//
//
//  vector<Poly_Prior* >         EtaK1Var_Prior;
//  vector <Class_Parameter >    EtaK1Var_MCMC;
//  if(EtaK1Var_PriorName=="InverseGamma")
//  {
//    for(i=0;i<nlatentk;i++)
//    {
//      EtaK1Var_Prior.push_back(new Class_InverseGamma);
//      EtaK1Var_Prior[i]->create_FullObject(UserControlledMemory);
//    }
//  }else{
//      error("Prior on EtaK1Var not well specified");
//  }
//  for(i=0;i<nlatentk;i++)
//  {
//    for(int k=0;k<EtaK1Var_Prior[i]->nHyperparams;k++)
//    {
//      EtaK1Var_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = EtaK1Var_PriorParameters[k*nlatentk+i];
//      EtaK1Var_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = EtaK1Var_PriorParameters[k*nlatentk+i];
//    }
//  }
//  for(j=0;j<nlatentk;j++)
//  {
//    EtaK1Var_MCMC.push_back(Class_Parameter());
//    appName = (("EtaK1Var_")+to_string(j));
//    EtaK1Var_MCMC[j].create_FullObject(EtaK1Var_InitParameters[j], appName,  EtaK1Var_Prior[j]);
//  }
//  for(j=0;j<nlatentk;j++)
//  {
//    EtaK1Var_MCMC[j].add_Pointerparameters_InVector();
//  }
//
//
//  Name                 = "EtaK1Mean";
//  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
//  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);
//
//  double *EtaK1Mean_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
//  string EtaK1Mean_PriorName         = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
//  double *EtaK1Mean_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));
//
//
//  vector<Poly_Prior* >         EtaK1Mean_Prior;
//  vector <Class_Parameter >    EtaK1Mean_MCMC;
//  if(EtaK1Mean_PriorName=="Normal")
//  {
//    for(i=0;i<nlatentk;i++)
//    {
//      EtaK1Mean_Prior.push_back(new Class_Normal);
//      EtaK1Mean_Prior[i]->create_FullObject(UserControlledMemory);
//    }
//  }else{
//      error("Prior on EtaK1Mean not well specified");
//  }
//  for(i=0;i<nlatentk;i++)
//  {
//    for(int k=0;k<EtaK1Mean_Prior[i]->nHyperparams;k++)
//    {
//      EtaK1Mean_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = EtaK1Mean_PriorParameters[k*nlatentk+i];
//      EtaK1Mean_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = EtaK1Mean_PriorParameters[k*nlatentk+i];
//    }
//  }
//  for(j=0;j<nlatentk;j++)
//  {
//    EtaK1Mean_MCMC.push_back(Class_Parameter());
//    appName = (("EtaK1Mean_")+to_string(j));
//    EtaK1Mean_MCMC[j].create_FullObject(EtaK1Mean_InitParameters[j], appName,  EtaK1Mean_Prior[j]);
//  }
//  for(j=0;j<nlatentk;j++)
//  {
//    EtaK1Mean_MCMC[j].add_Pointerparameters_InVector();
//  }


  Name                 = "EtaK1";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

  double *EtaK1_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string EtaK1_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *EtaK1_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  vector<vector<Poly_Prior* >   >               EtaK1_Prior; // uno per i k
  vector< vector <Class_Parameter > >   EtaK1_MCMC; // k/nvar/cluster
  if(EtaK1_PriorName=="Normal")
  {
    for(int g=0;g<nG;g++)
    {
      EtaK1_Prior.push_back(vector<Poly_Prior* >());
      for(i=0;i<nlatentk;i++)
      {
        EtaK1_Prior[g].push_back(new Class_Normal);
        EtaK1_Prior[g][i]->create_FullObject(UserControlledMemory);
      }
    }
  }else{
//    if(RandomEffect==1)
//    {
//      error("If RandomEffect true, prior on EtaK1 must be normal");
//    }
    if(EtaK1_PriorName=="NoPrior")
    {
      for(int g=0;g<nG;g++)
      {
        EtaK1_Prior.push_back(vector<Poly_Prior* >());
        for(i=0;i<nlatentk;i++)
        {
          EtaK1_Prior[g].push_back(new Class_NoPrior);
          EtaK1_Prior[g][i]->create_FullObject(UserControlledMemory);
        }
      }
    }else{
      if(EtaK1_PriorName=="Uniform")
      {
        for(int g=0;g<nG;g++)
        {
          EtaK1_Prior.push_back(vector<Poly_Prior* >());
          for(i=0;i<nlatentk;i++)
          {
            EtaK1_Prior[g].push_back(new Class_Uniform);
            EtaK1_Prior[g][i]->create_FullObject(UserControlledMemory);
          }
        }
      }else{
        if(EtaK1_PriorName=="InverseGamma")
        {
          for(int g=0;g<nG;g++)
          {
            EtaK1_Prior.push_back(vector<Poly_Prior* >());
            for(i=0;i<nlatentk;i++)
            {
              EtaK1_Prior[g].push_back(new Class_InverseGamma);
              EtaK1_Prior[g][i]->create_FullObject(UserControlledMemory);
            }
          }

        }else{
          if(EtaK1_PriorName=="TruncatedNormal")
          {
            for(int g=0;g<nG;g++)
            {
              EtaK1_Prior.push_back(vector<Poly_Prior* >());
              for(i=0;i<nlatentk;i++)
              {
                EtaK1_Prior[g].push_back(new Class_TruncatedNormal);
                EtaK1_Prior[g][i]->create_FullObject(UserControlledMemory);
              }
            }
          }else{
            error("Prior on EtaK1 not well specified");
          }

        }
      }
    }

  }

  for(int g=0;g<nG;g++)
  {
    for(i=0;i<nlatentk;i++)
    {
      for(int k=0;k<EtaK1_Prior[g][i]->nHyperparams;k++)
      {
        EtaK1_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = EtaK1_PriorParameters[k*nlatentk+i];
        EtaK1_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = EtaK1_PriorParameters[k*nlatentk+i];
      }
    }
  }


  for(i=0;i<nG;i++)
  {
    EtaK1_MCMC.push_back(vector<Class_Parameter >());
    for(j=0;j<nlatentk;j++)
    {
      EtaK1_MCMC[i].push_back(Class_Parameter());
      appName = (("EtaK1_")+to_string(i)+to_string(j));
      EtaK1_MCMC[i][j].create_FullObject(EtaK1_InitParameters[i*nlatentk+j], appName,  EtaK1_Prior[i][j]);

//      if(RandomEffect==1)
//      {
//        EtaK1_MCMC[i][j].add_RandomHyper(&EtaK1Mean_MCMC[j], 0);
//        EtaK1_MCMC[i][j].add_RandomHyper(&EtaK1Var_MCMC[j], 0);
//      }
    }
  }
  for(i=0;i<nG;i++)
  {
    for(j=0;j<nlatentk;j++)
    {
      EtaK1_MCMC[i][j].add_Pointerparameters_InVector();
      //EtaK1_MCMC[i][j].PrintObject("Eta");
    }
  }

  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/
  #pragma mark Par EtaK2

//  Name                 = "EtaK2Var";
//  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
//  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);
//
//  double *EtaK2Var_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
//  string EtaK2Var_PriorName         = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
//  double *EtaK2Var_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));
//
//
//  vector<Poly_Prior* >         EtaK2Var_Prior;
//  vector <Class_Parameter >    EtaK2Var_MCMC;
//  if(EtaK2Var_PriorName=="InverseGamma")
//  {
//    for(i=0;i<nlatentk;i++)
//    {
//      EtaK2Var_Prior.push_back(new Class_InverseGamma);
//      EtaK2Var_Prior[i]->create_FullObject(UserControlledMemory);
//    }
//  }else{
//      error("Prior on EtaK2Var not well specified");
//  }
//  for(i=0;i<nlatentk;i++)
//  {
//    for(int k=0;k<EtaK2Var_Prior[i]->nHyperparams;k++)
//    {
//      EtaK2Var_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = EtaK2Var_PriorParameters[k*nlatentk+i];
//      EtaK2Var_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = EtaK2Var_PriorParameters[k*nlatentk+i];
//    }
//  }
//  for(j=0;j<nlatentk;j++)
//  {
//    EtaK2Var_MCMC.push_back(Class_Parameter());
//    appName = (("EtaK2Var_")+to_string(j));
//    EtaK2Var_MCMC[j].create_FullObject(EtaK2Var_InitParameters[j], appName,  EtaK2Var_Prior[j]);
//  }
//  for(j=0;j<nlatentk;j++)
//  {
//    EtaK2Var_MCMC[j].add_Pointerparameters_InVector();
//  }
//
//
//  Name                 = "EtaK2Mean";
//  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
//  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);
//
//  double *EtaK2Mean_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
//  string EtaK2Mean_PriorName         = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
//  double *EtaK2Mean_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));
//
//
//  vector<Poly_Prior* >         EtaK2Mean_Prior;
//  vector <Class_Parameter >    EtaK2Mean_MCMC;
//  if(EtaK2Mean_PriorName=="Normal")
//  {
//    for(i=0;i<nlatentk;i++)
//    {
//      EtaK2Mean_Prior.push_back(new Class_Normal);
//      EtaK2Mean_Prior[i]->create_FullObject(UserControlledMemory);
//    }
//  }else{
//      error("Prior on EtaK2Mean not well specified");
//  }
//  for(i=0;i<nlatentk;i++)
//  {
//    for(int k=0;k<EtaK2Mean_Prior[i]->nHyperparams;k++)
//    {
//      EtaK2Mean_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = EtaK2Mean_PriorParameters[k*nlatentk+i];
//      EtaK2Mean_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = EtaK2Mean_PriorParameters[k*nlatentk+i];
//    }
//  }
//  for(j=0;j<nlatentk;j++)
//  {
//    EtaK2Mean_MCMC.push_back(Class_Parameter());
//    appName = (("EtaK2Mean_")+to_string(j));
//    EtaK2Mean_MCMC[j].create_FullObject(EtaK2Mean_InitParameters[j], appName,  EtaK2Mean_Prior[j]);
//  }
//  for(j=0;j<nlatentk;j++)
//  {
//    EtaK2Mean_MCMC[j].add_Pointerparameters_InVector();
//  }


  Name                 = "EtaK2";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

  double *EtaK2_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string EtaK2_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *EtaK2_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  vector<vector<Poly_Prior* >   >               EtaK2_Prior; // uno per i k
  vector< vector <Class_Parameter > >   EtaK2_MCMC; // k/nvar/cluster
  if(EtaK2_PriorName=="Normal")
  {
    for(int g=0;g<nG;g++)
    {
      EtaK2_Prior.push_back(vector<Poly_Prior* >());
      for(i=0;i<nlatentk;i++)
      {
        EtaK2_Prior[g].push_back(new Class_Normal);
        EtaK2_Prior[g][i]->create_FullObject(UserControlledMemory);
      }
    }
  }else{
//    if(RandomEffect==1)
//    {
//      error("If RandomEffect true, prior on EtaK2 must be normal");
//    }
    if(EtaK2_PriorName=="NoPrior")
    {
      for(int g=0;g<nG;g++)
      {
        EtaK2_Prior.push_back(vector<Poly_Prior* >());
        for(i=0;i<nlatentk;i++)
        {
          EtaK2_Prior[g].push_back(new Class_NoPrior);
          EtaK2_Prior[g][i]->create_FullObject(UserControlledMemory);
        }
      }
    }else{
      if(EtaK2_PriorName=="Uniform")
      {
        for(int g=0;g<nG;g++)
        {
          EtaK2_Prior.push_back(vector<Poly_Prior* >());
          for(i=0;i<nlatentk;i++)
          {
            EtaK2_Prior[g].push_back(new Class_Uniform);
            EtaK2_Prior[g][i]->create_FullObject(UserControlledMemory);
          }
        }
      }else{
        if(EtaK2_PriorName=="InverseGamma")
        {
          for(int g=0;g<nG;g++)
          {
            EtaK2_Prior.push_back(vector<Poly_Prior* >());
            for(i=0;i<nlatentk;i++)
            {
              EtaK2_Prior[g].push_back(new Class_InverseGamma);
              EtaK2_Prior[g][i]->create_FullObject(UserControlledMemory);
            }
          }

        }else{
          if(EtaK2_PriorName=="TruncatedNormal")
          {
            for(int g=0;g<nG;g++)
            {
              EtaK2_Prior.push_back(vector<Poly_Prior* >());
              for(i=0;i<nlatentk;i++)
              {
                EtaK2_Prior[g].push_back(new Class_TruncatedNormal);
                EtaK2_Prior[g][i]->create_FullObject(UserControlledMemory);
              }
            }
          }else{
            error("Prior on EtaK2 not well specified");
          }

        }
      }
    }

  }

  for(int g=0;g<nG;g++)
  {
    for(i=0;i<nlatentk;i++)
    {
      for(int k=0;k<EtaK2_Prior[g][i]->nHyperparams;k++)
      {
        EtaK2_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = EtaK2_PriorParameters[k*nlatentk+i];
        EtaK2_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = EtaK2_PriorParameters[k*nlatentk+i];
      }
    }
  }


  for(i=0;i<nG;i++)
  {
    EtaK2_MCMC.push_back(vector<Class_Parameter >());
    for(j=0;j<nlatentk;j++)
    {
      EtaK2_MCMC[i].push_back(Class_Parameter());
      appName = (("EtaK2_")+to_string(i)+to_string(j));
      EtaK2_MCMC[i][j].create_FullObject(EtaK2_InitParameters[i*nlatentk+j], appName,  EtaK2_Prior[i][j]);

//      if(RandomEffect==1)
//      {
//        EtaK2_MCMC[i][j].add_RandomHyper(&EtaK2Mean_MCMC[j], 0);
//        EtaK2_MCMC[i][j].add_RandomHyper(&EtaK2Var_MCMC[j], 0);
//      }
    }
  }
  for(i=0;i<nG;i++)
  {
    for(j=0;j<nlatentk;j++)
    {
      EtaK2_MCMC[i][j].add_Pointerparameters_InVector();
    }
  }

  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/
  #pragma mark Par MeanK

//  Name                 = "MeanKVar";
//  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
//  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);
//
//  double *MeanKVar_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
//  string MeanKVar_PriorName         = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
//  double *MeanKVar_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));
//
//
//  vector<Poly_Prior* >         MeanKVar_Prior;
//  vector <Class_Parameter >    MeanKVar_MCMC;
//  if(MeanKVar_PriorName=="InverseGamma")
//  {
//    for(i=0;i<nlatentk;i++)
//    {
//      MeanKVar_Prior.push_back(new Class_InverseGamma);
//      MeanKVar_Prior[i]->create_FullObject(UserControlledMemory);
//    }
//  }else{
//      error("Prior on MeanKVar not well specified");
//  }
//  for(i=0;i<nlatentk;i++)
//  {
//    for(int k=0;k<MeanKVar_Prior[i]->nHyperparams;k++)
//    {
//      MeanKVar_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = MeanKVar_PriorParameters[k*nlatentk+i];
//      MeanKVar_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = MeanKVar_PriorParameters[k*nlatentk+i];
//    }
//  }
//  for(j=0;j<nlatentk;j++)
//  {
//    MeanKVar_MCMC.push_back(Class_Parameter());
//    appName = (("MeanKVar_")+to_string(j));
//    MeanKVar_MCMC[j].create_FullObject(MeanKVar_InitParameters[j], appName,  MeanKVar_Prior[j]);
//  }
//  for(j=0;j<nlatentk;j++)
//  {
//    MeanKVar_MCMC[j].add_Pointerparameters_InVector();
//  }
//
//
//  Name                 = "MeanKMean";
//  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
//  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);
//
//  double *MeanKMean_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
//  string MeanKMean_PriorName         = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
//  double *MeanKMean_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));
//
//
//  vector<Poly_Prior* >         MeanKMean_Prior;
//  vector <Class_Parameter >    MeanKMean_MCMC;
//  if(MeanKMean_PriorName=="Normal")
//  {
//    for(i=0;i<nlatentk;i++)
//    {
//      MeanKMean_Prior.push_back(new Class_Normal);
//      MeanKMean_Prior[i]->create_FullObject(UserControlledMemory);
//    }
//  }else{
//      error("Prior on MeanKMean not well specified");
//  }
//  for(i=0;i<nlatentk;i++)
//  {
//    for(int k=0;k<MeanKMean_Prior[i]->nHyperparams;k++)
//    {
//      MeanKMean_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = MeanKMean_PriorParameters[k*nlatentk+i];
//      MeanKMean_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = MeanKMean_PriorParameters[k*nlatentk+i];
//    }
//  }
//  for(j=0;j<nlatentk;j++)
//  {
//    MeanKMean_MCMC.push_back(Class_Parameter());
//    appName = (("MeanKMean_")+to_string(j));
//    MeanKMean_MCMC[j].create_FullObject(MeanKMean_InitParameters[j], appName,  MeanKMean_Prior[j]);
//  }
//  for(j=0;j<nlatentk;j++)
//  {
//    MeanKMean_MCMC[j].add_Pointerparameters_InVector();
//  }
//

  Name                 = "MeanK";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

  double *MeanK_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string MeanK_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *MeanK_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  vector<vector<Poly_Prior* >   >               MeanK_Prior; // uno per i k
  vector< vector <Class_Parameter > >   MeanK_MCMC; // k/nvar/cluster
  if(MeanK_PriorName=="Normal")
  {
    for(int g=0;g<nG;g++)
    {
      MeanK_Prior.push_back(vector<Poly_Prior* >());
      for(i=0;i<nlatentk;i++)
      {
        MeanK_Prior[g].push_back(new Class_Normal);
        MeanK_Prior[g][i]->create_FullObject(UserControlledMemory);
      }
    }
  }else{
//    if(RandomEffect==1)
//    {
//      error("If RandomEffect true, prior on MeanK must be normal");
//    }
    if(MeanK_PriorName=="NoPrior")
    {
      for(int g=0;g<nG;g++)
      {
        MeanK_Prior.push_back(vector<Poly_Prior* >());
        for(i=0;i<nlatentk;i++)
        {
          MeanK_Prior[g].push_back(new Class_NoPrior);
          MeanK_Prior[g][i]->create_FullObject(UserControlledMemory);
        }
      }
    }else{

      if(MeanK_PriorName=="Uniform")
      {
        for(int g=0;g<nG;g++)
        {
          MeanK_Prior.push_back(vector<Poly_Prior* >());
          for(i=0;i<nlatentk;i++)
          {
            MeanK_Prior[g].push_back(new Class_Uniform);
            MeanK_Prior[g][i]->create_FullObject(UserControlledMemory);
          }
        }
      }else{
        if(MeanK_PriorName=="InverseGamma")
        {
          for(int g=0;g<nG;g++)
          {
            MeanK_Prior.push_back(vector<Poly_Prior* >());
            for(i=0;i<nlatentk;i++)
            {
              MeanK_Prior[g].push_back(new Class_InverseGamma);
              MeanK_Prior[g][i]->create_FullObject(UserControlledMemory);
            }
          }

        }else{
          if(MeanK_PriorName=="TruncatedNormal")
          {
            for(int g=0;g<nG;g++)
            {
              MeanK_Prior.push_back(vector<Poly_Prior* >());
              for(i=0;i<nlatentk;i++)
              {
                MeanK_Prior[g].push_back(new Class_TruncatedNormal);
                MeanK_Prior[g][i]->create_FullObject(UserControlledMemory);
              }
            }
          }else{
            error("Prior on MeanK not well specified");
          }

        }
      }
    }

  }

  for(int g=0;g<nG;g++)
  {
    for(i=0;i<nlatentk;i++)
    {
      for(int k=0;k<MeanK_Prior[g][i]->nHyperparams;k++)
      {
        MeanK_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = MeanK_PriorParameters[k*nlatentk+i];
        MeanK_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = MeanK_PriorParameters[k*nlatentk+i];
      }
    }
  }


  for(i=0;i<nG;i++)
  {
    MeanK_MCMC.push_back(vector<Class_Parameter >());
    for(j=0;j<nlatentk;j++)
    {
      MeanK_MCMC[i].push_back(Class_Parameter());
      appName = (("MeanK_")+to_string(i)+to_string(j));
      MeanK_MCMC[i][j].create_FullObject(MeanK_InitParameters[i*nlatentk+j], appName,  MeanK_Prior[i][j]);

//      if(RandomEffect==1)
//      {
//        MeanK_MCMC[i][j].add_RandomHyper(&MeanKMean_MCMC[j], 0);
//        MeanK_MCMC[i][j].add_RandomHyper(&MeanKVar_MCMC[j], 0);
//      }
    }
  }
  for(i=0;i<nG;i++)
  {
    for(j=0;j<nlatentk;j++)
    {
      MeanK_MCMC[i][j].add_Pointerparameters_InVector();
    }
  }

 /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/
 #pragma mark Par VarK

//  Name                 = "VarKVar";
//  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
//  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);
//
//  double *VarKVar_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
//  string VarKVar_PriorName         = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
//  double *VarKVar_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));
//
//
//  vector<Poly_Prior* >         VarKVar_Prior;
//  vector <Class_Parameter >    VarKVar_MCMC;
//  if(VarKVar_PriorName=="InverseGamma")
//  {
//    for(i=0;i<nlatentk;i++)
//    {
//      VarKVar_Prior.push_back(new Class_InverseGamma);
//      VarKVar_Prior[i]->create_FullObject(UserControlledMemory);
//    }
//  }else{
//      error("Prior on VarKVar not well specified");
//  }
//  for(i=0;i<nlatentk;i++)
//  {
//    for(int k=0;k<VarKVar_Prior[i]->nHyperparams;k++)
//    {
//      VarKVar_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = VarKVar_PriorParameters[k*nlatentk+i];
//      VarKVar_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = VarKVar_PriorParameters[k*nlatentk+i];
//    }
//  }
//  for(j=0;j<nlatentk;j++)
//  {
//    VarKVar_MCMC.push_back(Class_Parameter());
//    appName = (("VarKVar_")+to_string(j));
//    VarKVar_MCMC[j].create_FullObject(VarKVar_InitParameters[j], appName,  VarKVar_Prior[j]);
//  }
//  for(j=0;j<nlatentk;j++)
//  {
//    VarKVar_MCMC[j].add_Pointerparameters_InVector();
//  }
//
//
//  Name                 = "VarKMean";
//  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
//  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);
//
//  double *VarKMean_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
//  string VarKMean_PriorName         = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
//  double *VarKMean_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));
//
//
//  vector<Poly_Prior* >         VarKMean_Prior;
//  vector <Class_Parameter >    VarKMean_MCMC;
//  if(VarKMean_PriorName=="Normal")
//  {
//    for(i=0;i<nlatentk;i++)
//    {
//      VarKMean_Prior.push_back(new Class_Normal);
//      VarKMean_Prior[i]->create_FullObject(UserControlledMemory);
//    }
//  }else{
//      error("Prior on VarKMean not well specified");
//  }
//  for(i=0;i<nlatentk;i++)
//  {
//    for(int k=0;k<VarKMean_Prior[i]->nHyperparams;k++)
//    {
//      VarKMean_Prior[i]->HyperparametersProp.Pvec(k)[0][0] = VarKMean_PriorParameters[k*nlatentk+i];
//      VarKMean_Prior[i]->HyperparametersAcc.Pvec(k)[0][0]  = VarKMean_PriorParameters[k*nlatentk+i];
//    }
//  }
//  for(j=0;j<nlatentk;j++)
//  {
//    VarKMean_MCMC.push_back(Class_Parameter());
//    appName = (("VarKMean_")+to_string(j));
//    VarKMean_MCMC[j].create_FullObject(VarKMean_InitParameters[j], appName,  VarKMean_Prior[j]);
//  }
//  for(j=0;j<nlatentk;j++)
//  {
//    VarKMean_MCMC[j].add_Pointerparameters_InVector();
//  }


 Name                 = "VarK";
 indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
 indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

 double *VarK_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
 string VarK_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
 double *VarK_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


 vector<vector<Poly_Prior* >   >               VarK_Prior; // uno per i k
 vector< vector <Class_Parameter > >   VarK_MCMC; // k/nvar/cluster
 if(VarK_PriorName=="Normal")
 {
   for(int g=0;g<nG;g++)
   {
     VarK_Prior.push_back(vector<Poly_Prior* >());
     for(i=0;i<nlatentk;i++)
     {
       VarK_Prior[g].push_back(new Class_Normal);
       VarK_Prior[g][i]->create_FullObject(UserControlledMemory);
     }
   }
 }else{
//   if(RandomEffect==1)
//   {
//     error("If RandomEffect true, prior on VarK must be normal");
//   }
   if(VarK_PriorName=="NoPrior")
   {
     for(int g=0;g<nG;g++)
     {
       VarK_Prior.push_back(vector<Poly_Prior* >());
       for(i=0;i<nlatentk;i++)
       {
         VarK_Prior[g].push_back(new Class_NoPrior);
         VarK_Prior[g][i]->create_FullObject(UserControlledMemory);
       }
     }
   }else{
     if(VarK_PriorName=="Uniform")
     {
       for(int g=0;g<nG;g++)
       {
         VarK_Prior.push_back(vector<Poly_Prior* >());
         for(i=0;i<nlatentk;i++)
         {
           VarK_Prior[g].push_back(new Class_Uniform);
           VarK_Prior[g][i]->create_FullObject(UserControlledMemory);
         }
       }
     }else{
       if(VarK_PriorName=="InverseGamma")
       {
         for(int g=0;g<nG;g++)
         {
           VarK_Prior.push_back(vector<Poly_Prior* >());
           for(i=0;i<nlatentk;i++)
           {
             VarK_Prior[g].push_back(new Class_InverseGamma);
             VarK_Prior[g][i]->create_FullObject(UserControlledMemory);
           }
         }

       }else{
         if(VarK_PriorName=="TruncatedNormal")
         {
           for(int g=0;g<nG;g++)
           {
             VarK_Prior.push_back(vector<Poly_Prior* >());
             for(i=0;i<nlatentk;i++)
             {
               VarK_Prior[g].push_back(new Class_TruncatedNormal);
               VarK_Prior[g][i]->create_FullObject(UserControlledMemory);
             }
           }
         }else{
           error("Prior on VarK not well specified");
         }

       }
     }
   }

 }

 for(int g=0;g<nG;g++)
 {
   for(i=0;i<nlatentk;i++)
   {
     for(int k=0;k<VarK_Prior[g][i]->nHyperparams;k++)
     {
       VarK_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = VarK_PriorParameters[k*nlatentk+i];
       VarK_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = VarK_PriorParameters[k*nlatentk+i];
     }
   }
 }


 for(i=0;i<nG;i++)
 {
   VarK_MCMC.push_back(vector<Class_Parameter >());
   for(j=0;j<nlatentk;j++)
   {
     VarK_MCMC[i].push_back(Class_Parameter());
     appName = (("VarK_")+to_string(i)+to_string(j));
     VarK_MCMC[i][j].create_FullObject(VarK_InitParameters[i*nlatentk+j], appName,  VarK_Prior[i][j]);

//     if(RandomEffect==1)
//     {
//       VarK_MCMC[i][j].add_RandomHyper(&VarKMean_MCMC[j], 0);
//       VarK_MCMC[i][j].add_RandomHyper(&VarKVar_MCMC[j], 0);
//     }
   }
 }
 for(i=0;i<nG;i++)
 {
   for(j=0;j<nlatentk;j++)
   {
     VarK_MCMC[i][j].add_Pointerparameters_InVector();
   }
 }


  REprintf("AA0\n");

  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **
   Random Effect
   * ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/
  vector <   vector< vector <Class_Parameter > > *  >  AllParamRandom;
  //vector <   vector <Class_Parameter >  *  >  AllParamRandomMean;
  //vector <   vector <Class_Parameter >  *  >  AllParamRandomVar;

  AllParamRandom.push_back(&MeanK_MCMC);
  AllParamRandom.push_back(&VarK_MCMC);
  AllParamRandom.push_back(&EtaK1_MCMC);
  AllParamRandom.push_back(&EtaK2_MCMC);


  vector <   vector< Class_Parameter > *>     AllBeta;

  AllBeta.push_back(&Beta0_MCMC);
  AllBeta.push_back(&Beta1_MCMC);

//  AllParamRandomMean.push_back(&MeanKMean_MCMC);
//  AllParamRandomMean.push_back(&VarKMean_MCMC);
//  AllParamRandomMean.push_back(&EtaK1Mean_MCMC);
//  AllParamRandomMean.push_back(&EtaK2Mean_MCMC);
//
//  AllParamRandomVar.push_back(&MeanKVar_MCMC);
//  AllParamRandomVar.push_back(&VarKVar_MCMC);
//  AllParamRandomVar.push_back(&EtaK1Var_MCMC);
//  AllParamRandomVar.push_back(&EtaK2Var_MCMC);

  /*****************************************
     Observations
     *****************************************/
  #pragma mark Observations
    REprintf("A1 \n");

    Matrix<double> ObsMatTot(nobsTOT,nvar,REAL(Data_r));
    vector <vector < Matrix <double> > > Obs;
    for(i=0;i<nG;i++)
    {
      Obs.push_back(vector < Matrix <double> >());
      for(j=0;j<nrep;j++)
      {
        int Ind = i*nrep*nt+j*nt;
        Obs[i].push_back(Matrix <double>(nt,nvar,ObsMatTot.Pmat(Ind,0)));
      }
    }

    Vector <int> IndexNotNA(nNotna,INTEGER(IndexNotNA_r));


  double SigmaMat_P[nG*nvar*nt];
  double SigmaMatProp_P[nG*nvar*nt];
  vector<Matrix <double> > SigmaMat;
  vector<Matrix <double> > SigmaMatProp;
  for(i=0;i<nG;i++)
  {
    SigmaMat.push_back(Matrix<double>(nt,nvar,&SigmaMat_P[i*nvar*nt]));
    SigmaMatProp.push_back(Matrix<double>(nt,nvar,&SigmaMatProp_P[i*nvar*nt]));
  }


  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/

  /** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **/

  REprintf("AA0B1\n");
  Name                 = "Y0";
  indexPriorParameters =  Class_Utils::FindIndexString(&Names_ParametersPrior, &Name);
  indexInit            =  Class_Utils::FindIndexString(&Names_ParametersInit, &Name);

  double *Y0_PriorParameters  = REAL(VECTOR_ELT(Prior_r, indexPriorParameters));
  string Y0_PriorName   = Names_Priors[INTEGER(NamePrior_r)[indexPriorParameters]];
  double *Y0_InitParameters   = REAL(VECTOR_ELT(Inits_r, indexInit));


  vector<vector<Poly_Prior* > >                  Y0_Prior; // uno per i k
  vector<  vector< Class_Parameter> >    Y0_MCMC; // k/nvar/cluster

  if(Y0_PriorName=="TruncatedNormal")
  {
    for(int g=0;g<nG;g++)
    {
      Y0_Prior.push_back(vector<Poly_Prior*>());
      for(i=0;i<nvar;i++)
      {
        Y0_Prior[g].push_back(new Class_TruncatedNormal);
        Y0_Prior[g][i]->create_FullObject(UserControlledMemory);
      }
    }
  }else{
    if(Y0_PriorName=="NoPrior")
    {
      for(int g=0;g<nG;g++)
      {
        Y0_Prior.push_back(vector<Poly_Prior*>());
        for(i=0;i<nvar;i++)
        {
          Y0_Prior[g].push_back(new Class_NoPrior);
          Y0_Prior[g][i]->create_FullObject(UserControlledMemory);
        }
      }
    }else{
      error("Prior on Y0 not well specified");
    }

  }


  for(int g=0;g<nG;g++)
  {
    for(i=0;i<nvar;i++)
    {

      int k = 0;
      Y0_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = 0.0;
      Y0_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = 0.0;
      for(int j=0;j<nrep;j++)
      {
        Y0_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] += Obs[g][j].mat(0,i)/nrep;
        Y0_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  += Obs[g][j].mat(0,i)/nrep;
      }

      if(Y0_PriorName!="NoPrior")
      {
        for(k=1;k<Y0_Prior[g][i]->nHyperparams;k++)
        {
          Y0_Prior[g][i]->HyperparametersProp.Pvec(k)[0][0] = Y0_PriorParameters[k*nvar+i];
          Y0_Prior[g][i]->HyperparametersAcc.Pvec(k)[0][0]  = Y0_PriorParameters[k*nvar+i];
        }
      }


      //Y0_Prior[g][i]->PrintObject("Yo");
    }
  }
  //error("");


  for(i=0;i<nG;i++)
  {
    Y0_MCMC.push_back(vector<Class_Parameter> ());
    for(j=0;j<nvar;j++)
    {
      Y0_MCMC[i].push_back(Class_Parameter());
      appName = (("Y0_")+to_string(i)+to_string(j));
      Y0_MCMC[i][j].create_FullObject(Y0_Prior[i][j]->HyperparametersAcc.vec(0)[0], appName,  Y0_Prior[i][j]);
    }
  }
   for(i=0;i<nG;i++)
   {
     for(j=0;j<nvar;j++)
     {
       Y0_MCMC[i][j].add_Pointerparameters_InVector();
       //Y0_MCMC[i][j].PrintObject("Y");
     }
   }
  //error("AA\n");

  /*****************************************
   Latent ODE
   *****************************************/
#pragma mark Latent ODE
  REprintf("A0 \n");



  // function k
  vector< vector < Function_K_T2 > > vecFK;
  for(int g=0;g<nG;g++)
  {
    vecFK.push_back(vector < Function_K_T2 >());
    for(i=0;i<nlatentk;i++)
    {
      vecFK[g].push_back(Function_K_T2(&VarK_MCMC[g][i], &MinK_MCMC[g][i], &MeanK_MCMC[g][i], &EtaK1_MCMC[g][i],&EtaK2_MCMC[g][i],Rparam));
    }
  }





  vector < vector<ODE_FURLAN_T2> > LatentODE;
  for(int g=0;g<nG;g++)
  {
    LatentODE.push_back(vector<ODE_FURLAN_T2>());
    int j = 0;
    LatentODE[g].push_back(ODE_FURLAN_T2(nt,nvar,&vecFK[g], tmin, tmax, deltat, nstep,&Y0_MCMC[g], abs_err, rel_err));
    for(j=1;j<nrep;j++)
    {
      LatentODE[g].push_back(ODE_FURLAN_T2(nt,nvar,&vecFK[g], tmin, tmax, deltat, nstep,&Y0_MCMC[g], &LatentODE[g][0], abs_err, rel_err));
    }
  }

  for(int g=0;g<nG;g++)
  {
    int j = 0;
    LatentODE[g][j].ODE_compute_V2();
    //REprintf("%i \n",g);
    //LatentODE[g][j].ODEMAT.Print("Ode");

  }
  //Class_Utils::WriteMatrix("TEST","DD.R", &LatentODE[0][0].ODEMAT );
  //error("StopGene");


  /*****************************************
   ADAPT par
   *****************************************/
 #pragma mark AdaptPar

  /*****************************************
   Adapt Param Like
   *****************************************/
  string NameAdapt;

  REprintf("A2 \n");
  int indexSd;

  Name                      = "Y0";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdY0           = REAL(VECTOR_ELT(Sd_r, indexSd));

  Name                      = "MinK";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdMinK           = REAL(VECTOR_ELT(Sd_r, indexSd));

  Name                      = "MeanK";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdMeanK          = REAL(VECTOR_ELT(Sd_r, indexSd));

  Name                      = "VarK";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdVarK           = REAL(VECTOR_ELT(Sd_r, indexSd));

  Name                      = "EtaK1";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdEtaK1          = REAL(VECTOR_ELT(Sd_r, indexSd));

  Name                      = "EtaK2";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdEtaK2           = REAL(VECTOR_ELT(Sd_r, indexSd));


  Name                      = "Beta1";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdBeta1           = REAL(VECTOR_ELT(Sd_r, indexSd));

  Name                      = "Beta0";
  indexSd                   = Class_Utils::FindIndexString(&Names_Sd, &Name);
  double *SdBeta0           = REAL(VECTOR_ELT(Sd_r, indexSd));


  int addsdBeta;
  int isdBeta;
  double SDvecBeta[50];
  vector<Poly_Adapt* >        AdaptBeta;

  for(i=0;i<nvar;i++)
  {
    isdBeta = 0;
    AdaptBeta.push_back(new Class_AdaptHaario());
    appName = ("beta")+to_string(i);
    AdaptBeta[i]->add_name(appName);
    addsdBeta = AdaptBeta[i]->add_parameters(&Beta0_MCMC[i]);
    if(addsdBeta==1)
    {
      SDvecBeta[isdBeta] = SdBeta0[0];
      isdBeta++;
    }
    addsdBeta = AdaptBeta[i]->add_parameters(&Beta1_MCMC[i]);
    if(addsdBeta==1)
    {
      SDvecBeta[isdBeta] = SdBeta1[0];
      isdBeta++;
    }
    AdaptBeta[i]->add_finalizedConstruct(AdaptEps, SDvecBeta, AdaptLambda , 1, &AdaptParameters);
    AdaptBeta[i]->CheckMultiUpdate();
  }



  int addsd;
  int isd;
  double SDvec[50];
  vector< Poly_Adapt* >        AdaptLikeAllParam;
  for(i=0;i<nG;i++)
  {
    isd = 0;
    AdaptLikeAllParam.push_back(new Class_AdaptHaario());
    appName = ("AllPAram")+to_string(i);
    AdaptLikeAllParam[i]->add_name(appName);


    for(j=0;j<nlatentk;j++)
    {
      addsd = AdaptLikeAllParam[i]->add_parameters(&MinK_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdMinK[0];
        isd++;
      }
      addsd = AdaptLikeAllParam[i]->add_parameters(&MeanK_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdMeanK[0];
        isd++;
      }
      addsd = AdaptLikeAllParam[i]->add_parameters(&VarK_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdVarK[0];
        isd++;
      }
      addsd = AdaptLikeAllParam[i]->add_parameters(&EtaK1_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdEtaK1[0];
        isd++;
      }
      addsd = AdaptLikeAllParam[i]->add_parameters(&EtaK2_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdEtaK2[0];
        isd++;
      }

    }
    for(int h=0;h<nvar;h++)
    {
      addsd = AdaptLikeAllParam[i]->add_parameters(&Y0_MCMC[i][h]);
      if(addsd==1)
      {
        SDvec[isd] = SdY0[0];
        isd++;
      }
    }
    AdaptLikeAllParam[i]->add_finalizedConstruct(AdaptEps, SDvec, AdaptLambda , 1, &AdaptParameters);
    AdaptLikeAllParam[i]->CheckMultiUpdate();
  }



  /*****************/




  vector<vector< Poly_Adapt* > >       AdaptkDivisi;
  for(i=0;i<nG;i++)
  {

    AdaptkDivisi.push_back(vector< Poly_Adapt* >());


    for(j=0;j<nlatentk;j++)
    {
      isd = 0;
      AdaptkDivisi[i].push_back(new Class_AdaptHaario());
      appName = ("AdaptkDivisi")+to_string(i)+to_string(j);
      AdaptkDivisi[i][j]->add_name(appName);

      addsd = AdaptkDivisi[i][j]->add_parameters(&MinK_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdMinK[0];
        isd++;
      }
      addsd = AdaptkDivisi[i][j]->add_parameters(&MeanK_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdMeanK[0];
        isd++;
      }
      addsd = AdaptkDivisi[i][j]->add_parameters(&VarK_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdVarK[0];
        isd++;
      }
      addsd = AdaptkDivisi[i][j]->add_parameters(&EtaK1_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdEtaK1[0];
        isd++;
      }
      addsd = AdaptkDivisi[i][j]->add_parameters(&EtaK2_MCMC[i][j]);
      if(addsd==1)
      {
        SDvec[isd] = SdEtaK2[0];
        isd++;
      }
      AdaptkDivisi[i][j]->add_finalizedConstruct(AdaptEps, SDvec, AdaptLambda , 1, &AdaptParameters);
      AdaptkDivisi[i][j]->CheckMultiUpdate();
    }



    isd = 0;
    AdaptkDivisi[i].push_back(new Class_AdaptHaario());
    appName = ("AdaptkDivisi")+to_string(i)+to_string(nlatentk);
    AdaptkDivisi[i][nlatentk]->add_name(appName);
    for(int h=0;h<nvar;h++)
    {
      addsd = AdaptkDivisi[i][nlatentk]->add_parameters(&Y0_MCMC[i][h]);
      if(addsd==1)
      {
        SDvec[isd] = SdY0[0];
        isd++;
      }
    }
    AdaptkDivisi[i][nlatentk]->add_finalizedConstruct(AdaptEps, SDvec, AdaptLambda , 1, &AdaptParameters);
    AdaptkDivisi[i][nlatentk]->CheckMultiUpdate();
  }



  /*****************************************
   FROM C++ to R
   *****************************************/
#pragma mark FROM C++ to R
  REprintf("A4 \n");

  int nProtect = 0;




  SEXP MinK_out_r;
  PROTECT(MinK_out_r    = allocMatrix(REALSXP, nG*nlatentk, nSamples_save)); nProtect++;
  double *MinK_out_P    = REAL(MinK_out_r);

  SEXP VarK_out_r;
  PROTECT(VarK_out_r    = allocMatrix(REALSXP, nG*nlatentk, nSamples_save)); nProtect++;
  double *VarK_out_P    = REAL(VarK_out_r);

  SEXP MeanK_out_r;
  PROTECT(MeanK_out_r    = allocMatrix(REALSXP, nG*nlatentk, nSamples_save)); nProtect++;
  double *MeanK_out_P    = REAL(MeanK_out_r);

  SEXP EtaK1_out_r;
  PROTECT(EtaK1_out_r    = allocMatrix(REALSXP, nG*nlatentk, nSamples_save)); nProtect++;
  double *EtaK1_out_P    = REAL(EtaK1_out_r);

  SEXP EtaK2_out_r;
  PROTECT(EtaK2_out_r    = allocMatrix(REALSXP, nG*nlatentk, nSamples_save)); nProtect++;
  double *EtaK2_out_P    = REAL(EtaK2_out_r);


  SEXP Beta1_out_r;
  PROTECT(Beta1_out_r    = allocMatrix(REALSXP, nvar, nSamples_save)); nProtect++;
  double *Beta1_out_P    = REAL(Beta1_out_r);

  SEXP Beta0_out_r;
  PROTECT(Beta0_out_r    = allocMatrix(REALSXP, nvar, nSamples_save)); nProtect++;
  double *Beta0_out_P    = REAL(Beta0_out_r);




//  SEXP VarKMean_out_r;
//  PROTECT(VarKMean_out_r    = allocMatrix(REALSXP, nlatentk, nSamples_save)); nProtect++;
//  double *VarKMean_out_P    = REAL(VarKMean_out_r);
//
//  SEXP MeanKMean_out_r;
//  PROTECT(MeanKMean_out_r    = allocMatrix(REALSXP, nlatentk, nSamples_save)); nProtect++;
//  double *MeanKMean_out_P    = REAL(MeanKMean_out_r);
//
//  SEXP EtaK1Mean_out_r;
//  PROTECT(EtaK1Mean_out_r    = allocMatrix(REALSXP, nlatentk, nSamples_save)); nProtect++;
//  double *EtaK1Mean_out_P    = REAL(EtaK1Mean_out_r);
//
//  SEXP EtaK2Mean_out_r;
//  PROTECT(EtaK2Mean_out_r    = allocMatrix(REALSXP, nlatentk, nSamples_save)); nProtect++;
//  double *EtaK2Mean_out_P    = REAL(EtaK2Mean_out_r);
//
//
//
//  SEXP VarKVar_out_r;
//  PROTECT(VarKVar_out_r    = allocMatrix(REALSXP, nlatentk, nSamples_save)); nProtect++;
//  double *VarKVar_out_P    = REAL(VarKVar_out_r);
//
//  SEXP MeanKVar_out_r;
//  PROTECT(MeanKVar_out_r    = allocMatrix(REALSXP, nlatentk, nSamples_save)); nProtect++;
//  double *MeanKVar_out_P    = REAL(MeanKVar_out_r);
//
//  SEXP EtaK1Var_out_r;
//  PROTECT(EtaK1Var_out_r    = allocMatrix(REALSXP, nlatentk, nSamples_save)); nProtect++;
//  double *EtaK1Var_out_P    = REAL(EtaK1Var_out_r);
//
//  SEXP EtaK2Var_out_r;
//  PROTECT(EtaK2Var_out_r    = allocMatrix(REALSXP, nlatentk, nSamples_save)); nProtect++;
//  double *EtaK2Var_out_P    = REAL(EtaK2Var_out_r);


  SEXP Y0_out_r;
  PROTECT(Y0_out_r    = allocMatrix(REALSXP, nG*nvar, nSamples_save)); nProtect++;
  double *Y0_out_P    = REAL(Y0_out_r);



  int nY = 0;
  if(saveODE==1)
  {
    nY  = nG*nNotna*nvar;
  }else{
    nY = 2;
  }
  SEXP Y_out_r;
  PROTECT(Y_out_r    = allocMatrix(REALSXP, nY, nSamples_save)); nProtect++;
  double *Y_out_P    = REAL(Y_out_r);



  /*****************************************
  MCMC UPDATES
  *****************************************/
#pragma mark MCMCupdates

  /****************** ComputeSigma ***********************/
  class MCMCupdates_ComputeSigmaMat
  {
  public:
      virtual void ComputeWitBetaAcc(Matrix<double> &ODE,vector <   vector< Class_Parameter > *>  &Betapar, Matrix<double> *SigmaAcc ,Vector <int> *NonNA, int ivar , int iter)
      {
          error("MCMCupdates_sigma2");
      }
    virtual void ComputeWitBetaProp(Matrix<double> &ODE,vector <   vector< Class_Parameter > *>  &Betapar, Matrix<double> *SigmaAcc,Vector <int> *NonNA, int ivar  , int iter)
    {
        error("MCMCupdates_sigma2");
    }

  };

  class MCMCupdates_ComputeSigmaMat_Type1: public MCMCupdates_ComputeSigmaMat
  {
  public:
      void ComputeWitBetaAcc(Matrix<double> &ODE,vector <   vector< Class_Parameter > *>  &Betapar, Matrix<double> *Sigma ,Vector <int> *NonNA, int ivar ,int iter) override
      {
        int nNotna = NonNA->nElem;

        for(int t1=0;t1<nNotna;t1++)
        {
          int i = NonNA[0].vec(t1);
          Sigma[0].Pmat(i,ivar)[0] = exp(Betapar[0][0][ivar].ParameterAcc+ Betapar[1][0][ivar].ParameterAcc*log(ODE.mat(i,ivar)));
        }
      }
    void ComputeWitBetaProp(Matrix<double> &ODE,vector <   vector< Class_Parameter > *>  &Betapar, Matrix<double> *Sigma,Vector <int> *NonNA , int ivar ,int iter) override
    {
      int nNotna = NonNA->nElem;

      for(int t1=0;t1<nNotna;t1++)
      {
        int i = NonNA[0].vec(t1);
        Sigma[0].Pmat(i,ivar)[0] = exp(Betapar[0][0][ivar].ParameterProp+ Betapar[1][0][ivar].ParameterProp*log(ODE.mat(i,ivar)));
      }
    }
  };


  /****************** SIGMA2 ***********************/
  class MCMCupdates_sigma2
  {
  public:
      virtual void sample(
       MCMCupdates_ComputeSigmaMat *SigmaCompute,
       vector<Poly_Adapt* > *Adapt,
       vector <   vector< Class_Parameter > *>  *Betapar,
      vector< Matrix<double> >*SigmaAcc,
       vector<Matrix<double> > *SigmaProp,
       vector<vector <Matrix <double> > > *Y ,
       vector < vector<ODE_FURLAN_T2> >  *LatODE ,
       Vector <int> *NonNA  ,
       int iter
       )
      {
          error("MCMCupdates_sigma2");
      }

  };
  class MCMCupdates_sigma2_NoUpdate: public MCMCupdates_sigma2
  {
  public:
      void sample(
       MCMCupdates_ComputeSigmaMat *SigmaCompute,
       vector<Poly_Adapt* > *Adapt,
       vector <   vector< Class_Parameter > *>  *Betapar,
      vector< Matrix<double> >*SigmaAcc,
       vector<Matrix<double> > *SigmaProp,
       vector<vector <Matrix <double> > > *Y ,
       vector < vector<ODE_FURLAN_T2> >  *LatODE ,
       Vector <int> *NonNA  ,
       int iter
       )override
      {

      }
  };
  class MCMCupdates_sigma2_Type1: public MCMCupdates_sigma2
  {
  public:
      void sample(
                  MCMCupdates_ComputeSigmaMat *SigmaCompute,
                  vector<Poly_Adapt* > *Adapt,
                  vector <   vector< Class_Parameter > *>  *Betapar,
                 vector< Matrix<double> >*SigmaAcc,
                  vector<Matrix<double> > *SigmaProp,
                  vector<vector <Matrix <double> > > *Y ,
                  vector < vector<ODE_FURLAN_T2> >  *LatODE ,
                  Vector <int> *NonNA  ,
                  int iter
                  ) override
      {
        int nvar   = (int)Y[0][0][0].nCols;
        int nG     = (int)Y[0].size();
        int nrep   = (int)Y[0][0].size();
        int nNotna = NonNA->nElem;

        #pragma omp parallel for default(none) schedule(dynamic) shared(nvar,nG,nrep,nNotna,SigmaCompute,Betapar,SigmaAcc,SigmaProp,Y, LatODE, NonNA,Adapt,iter)
        for(int i=0;i<nvar;i++)
        {

          Adapt[0][i]->Samp();

          double MH = Adapt[0][i]->get_logDensityParameterWithLogJacobian_DiffPropAcc();
          //REprintf("%f ",MH);
          for(int g=0;g<nG;g++)
          {
            SigmaCompute->ComputeWitBetaProp(LatODE[0][g][0].ODEMAT, Betapar[0], &SigmaProp[0][g], NonNA,i,iter);

            for(int j=0;j<nrep;j++)
            {
              //Y[0][g][j].Print("Y");
              //LatODE[0][g][j].ODEMAT.Print("ODE");
              for(int t1=0;t1<nNotna;t1++)
              {
                int t = NonNA[0].vec(t1);
                //REprintf("%i %i %f %f %f %f %f %f\n",t,t1,Y[0][g][j].mat(t,i),LatODE[0][g][j].ODEMAT.mat(t,i), sqrt(SigmaProp[0][g].mat(t,i)),sqrt(SigmaAcc[0][g].mat(t,i)),Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), LatODE[0][g][j].ODEMAT.mat(t,i), sqrt(SigmaProp[0][g].mat(t,i)), 0.0),Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), LatODE[0][g][j].ODEMAT.mat(t,i), sqrt(SigmaAcc[0][g].mat(t,i)), 0.0));
                MH +=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), LatODE[0][g][j].ODEMAT.mat(t,i), sqrt(SigmaProp[0][g].mat(t,i)), 0.0);
                MH -=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), LatODE[0][g][j].ODEMAT.mat(t,i), sqrt(SigmaAcc[0][g].mat(t,i)), 0.0);
              }
            }
//REprintf("%f %i \n",MH,i);
          }

          //error("");

          double alphaRatio = min(1.0,exp(MH));
          if(runif(0.0,1.0)<alphaRatio)
          {
            Adapt[0][i]->UpdateIfAccepted();
            for(int g=0;g<nG;g++)
            {
              for(int t1=0;t1<nNotna;t1++)
              {
                int t = NonNA[0].vec(t1);
                SigmaAcc[0][g].Pmat(t,i)[0] = SigmaProp[0][g].Pmat(t,i)[0];
              }
            }
          }else{
            //Adapt[0][i]->UpdateIfNotAccepted();
          }
          Adapt[0][i]->PostSamp(alphaRatio);
        }
      }
  };


  /****************** ODEPAR ***********************/
  class MCMCupdates_OdeParameters
  {
  public:
      virtual void sample( vector< vector< Poly_Adapt*  > > *AdaptDivisi,
                          MCMCupdates_ComputeSigmaMat *SigmaCompute,
                           vector <   vector< Class_Parameter > *>  *Betapar,
                          vector< Matrix<double> >*SigmaAcc,
                           vector<Matrix<double> > *SigmaProp,
                          vector<vector <Matrix <double> > > *Y ,vector < vector<ODE_FURLAN_T2> >  *LatODE ,Vector <int> *NonNA , vector< Poly_Adapt* > *Adapt , int iter)
      {
          error("MCMCupdates_Ode");
      }

  };
  class MCMCupdates_OdeParameters_NoUpdate: public MCMCupdates_OdeParameters
  {
  public:
      void sample( vector< vector< Poly_Adapt*  > > *AdaptDivisi,
                  MCMCupdates_ComputeSigmaMat *SigmaCompute,
                   vector <   vector< Class_Parameter > *>  *Betapar,
                  vector< Matrix<double> >*SigmaAcc,
                   vector<Matrix<double> > *SigmaProp,
                  vector<vector <Matrix <double> > > *Y ,vector < vector<ODE_FURLAN_T2> >  *LatODE ,Vector <int> *NonNA , vector< Poly_Adapt* > *Adapt  ,int iter) override
      {

      }
  };
  class MCMCupdates_OdeParameters_Adapt: public MCMCupdates_OdeParameters
  {
  public:
      void sample( vector< vector< Poly_Adapt*  > > *AdaptDivisi,
                  MCMCupdates_ComputeSigmaMat *SigmaCompute,
                   vector <   vector< Class_Parameter > *>  *Betapar,
                  vector< Matrix<double> >*SigmaAcc,
                   vector<Matrix<double> > *SigmaProp,
                  vector <vector < Matrix <double> > > *Y ,vector < vector<ODE_FURLAN_T2> >  *LatODE ,Vector <int> *NonNA , vector< Poly_Adapt* > *Adapt  ,int iter) override
      {
        int nvar   = (int)Y[0][0][0].nCols;
        int nt     = (int)Y[0][0][0].nRows;
        int nG     = (int)Y[0].size();
        int nrep   = (int)Y[0][0].size();
        int nNotna = NonNA->nElem;

        #pragma omp parallel for default(none) schedule(dynamic) shared(nvar,nt,nG,nrep,nNotna,SigmaCompute,Betapar,SigmaAcc,SigmaProp,Y, LatODE, NonNA,Adapt,iter,AdaptDivisi)
        for(int g=0;g<nG;g++)
        {
          Adapt[0][g]->Samp();
           //Adapt[0][g]->PrintObject("a");
          double MH = Adapt[0][g]->get_logDensityParameterWithLogJacobian_DiffPropAcc();




          int j = 0;
          int OUT = LatODE[0][g][j].ODE_compute_V2_Prop();

          for(int i=0;i<nvar;i++)
          {
            SigmaCompute->ComputeWitBetaAcc(LatODE[0][g][0].ODEMATProp, Betapar[0], &SigmaProp[0][g], NonNA,i,iter);
          }

          for(j=0;j<nrep;j++)
          {
            for(int t1=0;t1<nNotna;t1++)
            {
              int t = NonNA[0].vec(t1);

              for(int i=0;i<nvar;i++)
              {

                MH +=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), LatODE[0][g][j].ODEMATProp.mat(t,i), sqrt(SigmaProp[0][g].mat(t,i)), 0.0);
                MH -=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), LatODE[0][g][j].ODEMAT.mat(t,i), sqrt(SigmaAcc[0][g].mat(t,i)), 0.0);


              }
            }
          }

          double alphaRatio = min(1.0,exp(MH));

//          for(int hh =0;hh<3;hh++)
//          {
//            if(!isfinite(LatODE[0][g][0].ODEMAT.mat(nt-1,hh)))
//            {
//              alphaRatio = 0.0;
//            }
//          }
          if(OUT!=0)
          {
            alphaRatio = 0.0;
          }
          if(runif(0.0,1.0)<alphaRatio)
          {
            //REprintf("ACC \n");
            Adapt[0][g]->UpdateIfAccepted();
            j = 0;
            LatODE[0][g][j].copyFromODEMATPropToAcc();
            for(int i=0;i<nvar;i++)
            {
              for(int t1=0;t1<nNotna;t1++)
              {
                int t = NonNA[0].vec(t1);
                SigmaAcc[0][g].Pmat(t,i)[0] = SigmaProp[0][g].Pmat(t,i)[0];
              }
            }
          }else{
            //REprintf("RIF\n");
            //Adapt[0][g]->UpdateIfNotAccepted();
          }
          Adapt[0][g]->PostSamp(alphaRatio);

          //LatODE[0][g][0].ODEMAT.Print("ODEPost");
        }
      }
  };


  class MCMCupdates_OdeParameters_Adapt_SingleK: public MCMCupdates_OdeParameters
    {
    public:
        void sample( vector< vector< Poly_Adapt*  > > *AdaptDivisi,
                    MCMCupdates_ComputeSigmaMat *SigmaCompute,
                     vector <   vector< Class_Parameter > *>  *Betapar,
                    vector< Matrix<double> >*SigmaAcc,
                     vector<Matrix<double> > *SigmaProp,
                    vector <vector < Matrix <double> > > *Y ,vector < vector<ODE_FURLAN_T2> >  *LatODE ,Vector <int> *NonNA , vector< Poly_Adapt* > *Adapt  ,int iter) override
        {
          int nvar   = (int)Y[0][0][0].nCols;
          int nt     = (int)Y[0][0][0].nRows;
          int nG     = (int)Y[0].size();
          int nrep   = (int)Y[0][0].size();
          int nNotna = NonNA->nElem;

          #pragma omp parallel for default(none) schedule(dynamic) shared(nvar,nt,nG,nrep,nNotna,SigmaCompute,Betapar,SigmaAcc,SigmaProp,Y, LatODE, NonNA,Adapt,iter,AdaptDivisi)
          for(int g=0;g<nG;g++)
          {
            double MH = 0.0;
            int nPar = (int)AdaptDivisi[0][g].size();
            for(int NP=0;NP<nPar;NP++)
            {
              //REprintf("%i %i \n",g,NP);
              AdaptDivisi[0][g][NP]->Samp();

              MH =  AdaptDivisi[0][g][NP]->get_logDensityParameterWithLogJacobian_DiffPropAcc();


              int j = 0;
              LatODE[0][g][j].ODE_compute_V2_Prop();

              for(int i=0;i<nvar;i++)
              {
                SigmaCompute->ComputeWitBetaAcc(LatODE[0][g][0].ODEMATProp, Betapar[0], &SigmaProp[0][g], NonNA,i,iter);
              }

              for(j=0;j<nrep;j++)
              {
                for(int t1=0;t1<nNotna;t1++)
                {
                  int t = NonNA[0].vec(t1);

                  for(int i=0;i<nvar;i++)
                  {

                    MH +=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), LatODE[0][g][j].ODEMATProp.mat(t,i), sqrt(SigmaProp[0][g].mat(t,i)), 0.0);
                    MH -=  Class_TruncatedNormal::compute_LogDensity_a(Y[0][g][j].mat(t,i), LatODE[0][g][j].ODEMAT.mat(t,i), sqrt(SigmaAcc[0][g].mat(t,i)), 0.0);


                  }
                }
              }

              double alphaRatio = min(1.0,exp(MH));

//              if(OUT!=0)
//              {
//                alphaRatio = 0.0;
//              }
              if(runif(0.0,1.0)<alphaRatio)
              {
                //REprintf("ACC \n");
                AdaptDivisi[0][g][NP]->UpdateIfAccepted();
                j = 0;
                LatODE[0][g][j].copyFromODEMATPropToAcc();
                for(int i=0;i<nvar;i++)
                {
                  for(int t1=0;t1<nNotna;t1++)
                  {
                    int t = NonNA[0].vec(t1);
                    SigmaAcc[0][g].Pmat(t,i)[0] = SigmaProp[0][g].Pmat(t,i)[0];
                  }
                }
              }
              AdaptDivisi[0][g][NP]->PostSamp(alphaRatio);
              //REprintf("s");
              AdaptDivisi[0][g][NP]->SetAccPropEqual();
              //REprintf("s2");
            }
          }
        }
    };


  /****************** Random Effect ***********************/
//  class MCMCupdates_RandomEffects
//  {
//  public:
//      virtual void sample(vector <   vector< vector <Class_Parameter > > *  >  * par,
//      vector <   vector <Class_Parameter >  *  >  * MeanPar,
//      vector <   vector <Class_Parameter >  *  >  *VarPar, int iter)
//      {
//          error("MCMCupdates_Ode");
//      }
//
//  };
//  class MCMCupdates_RandomEffects_NoUpdate: public MCMCupdates_RandomEffects
//  {
//  public:
//      void sample(vector <   vector< vector <Class_Parameter > > *  >  * par,
//      vector <   vector <Class_Parameter >  *  >  * MeanPar,
//      vector <   vector <Class_Parameter >  *  >  *VarPar, int iter) override
//      {
//
//      }
//  };
//
//
////  AllParamRandom.push_back(&MeanK_MCMC);
////  AllParamRandom.push_back(&VarK_MCMC);
////  AllParamRandom.push_back(&EtaK1_MCMC);
////  AllParamRandom.push_back(&EtaK2_MCMC);
//  class MCMCupdates_RandomEffects_NormalInverseGammaPrior: public MCMCupdates_RandomEffects
//  {
//  public:
//      void sample(vector <   vector< vector <Class_Parameter > > *  >  * par,
//      vector <   vector <Class_Parameter >  *  >  * MeanPar,
//      vector <   vector <Class_Parameter >  *  > *VarPar, int iter) override
//      {
//       // REprintf("RANDOM\n");
//        int nparam    = (int)par[0].size();
//        int nG        = (int)par[0][0][0].size();
//        int nlatentk  = (int)par[0][0][0][0].size();
//
//        double MeanPost_P[nlatentk];
//        Vector<double> MeanPost(nlatentk,MeanPost_P);
//        MeanPost.Init(0.0);
//
//        double VarPost_P[nlatentk];
//        Vector<double> VarPost(nlatentk,VarPost_P);
//        VarPost.Init(0.0);
//
//        double aPost_P[nlatentk];
//        Vector<double> aPost(nlatentk,aPost_P);
//        aPost.Init(0.0);
//
//        double bPost_P[nlatentk];
//        Vector<double> bPost(nlatentk,bPost_P);
//        bPost.Init(0.0);
//
//        int iP2 = 0;
//        int i0  = 0;
//
//        for(int iparam=0;iparam<nparam;iparam++)
//        {
//          // mean
//
//ComputeSigma, &AdaptBeta,  &AllBeta, &SigmaMat,&SigmaMatProp,>>
//          for(int k=0;k<nlatentk;k++)
//          {
//            MeanPost.Pvec(k)[0] = MeanPar[iP2][iparam][iP2][k].PriorParameter->HyperparametersAcc.vec(0)[iP2]/MeanPar[iP2][iparam][iP2][k].PriorParameter->HyperparametersAcc.vec(1)[iP2];
//            VarPost.Pvec(k)[0] = 1.0/MeanPar[iP2][iparam][iP2][k].PriorParameter->HyperparametersAcc.vec(1)[iP2];
//
//
//            VarPost.Pvec(k)[0] += nG/par[iP2][iparam][iP2][i0][k].PriorParameter->HyperparametersAcc.vec(1)[iP2];
//
//          }
//          for(int g=0;g<nG;g++)
//          {
//            for(int k=0;k<nlatentk;k++)
//            {
//              MeanPost.Pvec(k)[0] +=     par[iP2][iparam][iP2][g][k].ParameterAcc/par[iP2][iparam][iP2][i0][k].PriorParameter->HyperparametersAcc.vec(1)[iP2];
//            }
//          }
//          for(int k=0;k<nlatentk;k++)
//          {
//            VarPost.Pvec(k)[0]  = 1.0/VarPost.Pvec(k)[0];
//            MeanPost.Pvec(k)[0] = VarPost.Pvec(k)[0]*MeanPost.Pvec(k)[0];
//
//            MeanPar[iP2][iparam][iP2][k].ParameterAcc = rnorm(MeanPost.Pvec(k)[0],pow(VarPost.Pvec(k)[0],0.5));
//            REprintf("%f \n",MeanPar[iP2][iparam][iP2][k].ParameterAcc);
//            REprintf("%f %f \n",MeanPost.Pvec(k)[0],VarPost.Pvec(k)[0]);
//          }
//
//          //sigma2
//          for(int k=0;k<nlatentk;k++)
//          {
//            //vector <   vector <Class_Parameter >  *  > *VarPar
//
//            aPost.Pvec(k)[0] = VarPar[iP2][iparam][iP2][k].PriorParameter->HyperparametersAcc.vec(0)[iP2];
//            bPost.Pvec(k)[0] = VarPar[iP2][iparam][iP2][k].PriorParameter->HyperparametersAcc.vec(1)[iP2];
//
//            aPost.Pvec(k)[0] += 0.5*nG;
//          }
//          for(int g=0;g<nG;g++)
//          {
//            for(int k=0;k<nlatentk;k++)
//            {
//              bPost.Pvec(k)[0] +=   0.5*pow(par[iP2][iparam][iP2][g][k].ParameterAcc-MeanPar[iP2][iparam][iP2][k].ParameterAcc,2);
//            }
//          }
//          for(int k=0;k<nlatentk;k++)
//          {
//
//            VarPar[iP2][iparam][iP2][k].ParameterAcc = 1.0/rgamma( aPost.Pvec(k)[0],1.0/ bPost.Pvec(k)[0]);
//            REprintf("%f \n",VarPar[iP2][iparam][iP2][k].ParameterAcc);
//            REprintf("%f %f \n",aPost.Pvec(k)[0],bPost.Pvec(k)[0]);
//          }
//
//        }
//
//
//      }
//  };
  /*****************************************
   MCMC UPDATES - SET
   *****************************************/

  MCMCupdates_ComputeSigmaMat *ComputeSigma = 0;
  ComputeSigma = new MCMCupdates_ComputeSigmaMat_Type1;

  MCMCupdates_sigma2 *sigma2_UPDATE = 0;
  if(sample_Var==1)
  {
    sigma2_UPDATE = new MCMCupdates_sigma2_Type1;
  }else{
    sigma2_UPDATE = new MCMCupdates_sigma2_NoUpdate;
  }



  MCMCupdates_OdeParameters *OdeParameters_UPDATE = 0;
  if(sample_Ode==1)
  {
    if(SampleOdeType==1)
    {
      OdeParameters_UPDATE = new MCMCupdates_OdeParameters_Adapt;
    }else{
      OdeParameters_UPDATE = new MCMCupdates_OdeParameters_Adapt_SingleK;
    }
  }else{
    OdeParameters_UPDATE = new MCMCupdates_OdeParameters_NoUpdate;
  }


//  MCMCupdates_RandomEffects *RandomEffects_UPDATE = nullptr;
//  if(RandomEffect==1)
//  {
//    RandomEffects_UPDATE = new MCMCupdates_RandomEffects_NormalInverseGammaPrior;
//  }else{
//    RandomEffects_UPDATE = new MCMCupdates_RandomEffects_NoUpdate;
//  }
  /*****************************************
   PreMCMC
   *****************************************/

  for(int g=0;g<nG;g++)
  {
    for(int ivar=0;ivar<nvar;ivar++)
    {
      ComputeSigma->ComputeWitBetaAcc(LatentODE[g][0].ODEMAT, AllBeta, &SigmaMat[g],&IndexNotNA,ivar, 0);
      ComputeSigma->ComputeWitBetaProp(LatentODE[g][0].ODEMATProp, AllBeta, &SigmaMatProp[g], &IndexNotNA,ivar,0);
    }

  }

  const char *TEXT = CHAR(STRING_ELT(TEXT_r,0));

  /*****************************************
   MCMC
   *****************************************/
  REprintf("R4wwA");
  int iterations = 0;
  int iMCMC_app = MCMCburnin;
  for(int iMCMC1=0;iMCMC1<nSamples_save;iMCMC1++)
  {

    for(int iMCMC2=0;iMCMC2<iMCMC_app;iMCMC2++)
    {
      R_CheckUserInterrupt();

      /************* Print *********************/
      if((iterations%IterShow)==0)
      {
        REprintf("Iterations %i \n", iterations);
        if(Verbose==1)
        {
//          for(i=0;i<nvar;i++)
//          {
//            AdaptBeta[i]->PrintObjectEnd("Adapt - ");
//            AdaptBeta[i]->reset_AccRatio();
//          }
//
//          for(i=0;i<nG;i++)
//          {
//            AdaptLikeAllParam[i]->PrintObjectEnd("Adapt - ");
//            AdaptLikeAllParam[i]->reset_AccRatio();
//          }
//          for(i=0;i<nG;i++)
//          {
//            for(j=0;j<AdaptkDivisi[i].size();j++)
//            {
//              AdaptkDivisi[i][j]->PrintObjectEnd("Adapt - ");
//              AdaptkDivisi[i][j]->reset_AccRatio();
//            }
//          }
         FILE * (file);
         file = fopen(TEXT,"wt");
         fprintf(file, "Iterations %i \n", iterations);
         fclose (file);


        }
      }
      /**********************************/
      iterations ++;
      AdaptParameters.Update(iterations);
      /************* Random *********************/

     // RandomEffects_UPDATE->sample(&AllParamRandom,&AllParamRandomMean,&AllParamRandomVar, iterations);

      /************* OdeParam *********************/
      //REprintf("ODE\n");
      OdeParameters_UPDATE->sample(&AdaptkDivisi,  ComputeSigma,   &AllBeta, &SigmaMat,&SigmaMatProp,&Obs ,&LatentODE , &IndexNotNA , &AdaptLikeAllParam, iterations);

      /************* sigma2 *********************/
      //REprintf("SIgma2\n");
      sigma2_UPDATE->sample(ComputeSigma, &AdaptBeta,  &AllBeta, &SigmaMat,&SigmaMatProp, &Obs ,&LatentODE , &IndexNotNA ,iterations);



      /************* *********************/
    }

    iMCMC_app = MCMCthin;

    /*****************************************
     From C++ To R (2)
     *****************************************/

//    for(int jj=0;jj<nvar;jj++)
//    {
//      sigma2_out_P[iMCMC1*nvar+jj] = sigma2_MCMC[jj].ParameterAcc;
//    }

    for(int ii=0;ii<nG;ii++)
    {
      for(int jj=0;jj<nlatentk;jj++)
      {

        MinK_out_P[iMCMC1*nG*nlatentk+nlatentk*ii+jj]    = abs(MinK_MCMC[ii][jj].ParameterAcc);
        VarK_out_P[iMCMC1*nG*nlatentk+nlatentk*ii+jj]    = VarK_MCMC[ii][jj].ParameterAcc;
        EtaK1_out_P[iMCMC1*nG*nlatentk+nlatentk*ii+jj]   = EtaK1_MCMC[ii][jj].ParameterAcc;
        EtaK2_out_P[iMCMC1*nG*nlatentk+nlatentk*ii+jj]   = EtaK2_MCMC[ii][jj].ParameterAcc;
        MeanK_out_P[iMCMC1*nG*nlatentk+nlatentk*ii+jj]   = MeanK_MCMC[ii][jj].ParameterAcc;;

      }
      for(int jj=0;jj<nvar;jj++)
      {
         Y0_out_P[iMCMC1*nG*nvar+nvar*ii+jj]   = Y0_MCMC[ii][jj].ParameterAcc;;
      }
    }
    for(int jj=0;jj<nvar;jj++)
    {
      Beta0_out_P[iMCMC1*nvar+jj]   = Beta0_MCMC[jj].ParameterAcc;;
      Beta1_out_P[iMCMC1*nvar+jj]   = Beta1_MCMC[jj].ParameterAcc;;
    }

//    for(int jj=0;jj<nlatentk;jj++)
//    {
//      MeanKMean_out_P[iMCMC1*nlatentk+jj]    = MeanKMean_MCMC[jj].ParameterAcc;
//      VarKMean_out_P[iMCMC1*nlatentk+jj]    = VarKMean_MCMC[jj].ParameterAcc;
//      EtaK1Mean_out_P[iMCMC1*nlatentk+jj]    = EtaK1Mean_MCMC[jj].ParameterAcc;
//      EtaK2Mean_out_P[iMCMC1*nlatentk+jj]    = EtaK2Mean_MCMC[jj].ParameterAcc;
//
//      MeanKVar_out_P[iMCMC1*nlatentk+jj]    = MeanKVar_MCMC[jj].ParameterAcc;
//      VarKVar_out_P[iMCMC1*nlatentk+jj]    = VarKVar_MCMC[jj].ParameterAcc;
//      EtaK1Var_out_P[iMCMC1*nlatentk+jj]    = EtaK1Var_MCMC[jj].ParameterAcc;
//      EtaK2Var_out_P[iMCMC1*nlatentk+jj]    = EtaK2Var_MCMC[jj].ParameterAcc;
//
//    }
    //int nrepApp = 1;
    if(saveODE==1)
    {
      for(int ii=0;ii<nG;ii++)
      {
        for(int t1=0;t1<nNotna;t1++)
        {
          int ir = IndexNotNA.vec(t1);
          for(int ic=0;ic<nvar;ic++)
          {
            Y_out_P[iMCMC1*nG*nNotna*nvar+ii*nNotna*nvar+t1*nvar+ic] =  LatentODE[ii][0].ODEMAT.mat(ir,ic);
          }
        }
      }
//      if(iMCMC1==199)
//      {
//        LatentODE[0][0].ODEMAT.Print("s");
//        LatentODE[0][0].ODE_compute_TEST_TODELETE();
//
//        MinK_MCMC[0][0].PrintObject("a");
//        VarK_MCMC[0][0].PrintObject("a");
//        EtaK1_MCMC[0][0].PrintObject("a");
//        EtaK2_MCMC[0][0].PrintObject("a");
//        MeanK_MCMC[0][0].PrintObject("a");
//
//      }
//      LatentODE[0][0].ODEMAT.Print("TEST");
    }else{
//      for(int ii=0;ii<nG;ii++)
//      {
//        for(int ir=0;ir<1;ir++)
//        {
//          for(int ic=0;ic<nvar;ic++)
//          {
//            Y_out_P[iMCMC1*nG*nvar+ii*nvar+ic] = LatentODE[ii][0].ODEMAT.mat(ir,ic);
//          }
//        }
//      }
    }


    /*****************************************
     Here, the second MCMC parentheses end
     *****************************************/
  }
  /*****************************************
  Final print
  *****************************************/




  /*****************************************
   From C++ to R
   *****************************************/

  SEXP result,resultNames;
  int nResultListObjs = nProtect;

  PROTECT(result = allocVector(VECSXP, nResultListObjs)); nProtect++;
  PROTECT(resultNames = allocVector(VECSXP, nResultListObjs)); nProtect++;

  i=0;

  SET_VECTOR_ELT(result, i, MinK_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("MinK"));i++;
  SET_VECTOR_ELT(result, i, VarK_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("VarK"));i++;
  SET_VECTOR_ELT(result, i, MeanK_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("MeanK"));i++;
  SET_VECTOR_ELT(result, i, EtaK1_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("EtaK1"));i++;
  SET_VECTOR_ELT(result, i, EtaK2_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("EtaK2"));i++;

  SET_VECTOR_ELT(result, i, Y0_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("Y0"));i++;

  SET_VECTOR_ELT(result, i, Y_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("Y"));i++;

  SET_VECTOR_ELT(result, i, Beta0_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("Beta0"));i++;
  SET_VECTOR_ELT(result, i, Beta1_out_r);
  SET_VECTOR_ELT(resultNames, i, mkChar("Beta1"));i++;

//  SET_VECTOR_ELT(result, i, VarKMean_out_r);
//  SET_VECTOR_ELT(resultNames, i, mkChar("VarKMean"));i++;
//  SET_VECTOR_ELT(result, i, MeanKMean_out_r);
//  SET_VECTOR_ELT(resultNames, i, mkChar("MeanKMean"));i++;
//  SET_VECTOR_ELT(result, i, EtaK1Mean_out_r);
//  SET_VECTOR_ELT(resultNames, i, mkChar("EtaK1Mean"));i++;
//  SET_VECTOR_ELT(result, i, EtaK2Mean_out_r);
//  SET_VECTOR_ELT(resultNames, i, mkChar("EtaK2Mean"));i++;
//
//
//  SET_VECTOR_ELT(result, i, VarKVar_out_r);
//  SET_VECTOR_ELT(resultNames, i, mkChar("VarKVar"));i++;
//  SET_VECTOR_ELT(result, i, MeanKVar_out_r);
//  SET_VECTOR_ELT(resultNames, i, mkChar("MeanKVar"));i++;
//  SET_VECTOR_ELT(result, i, EtaK1Var_out_r);
//  SET_VECTOR_ELT(resultNames, i, mkChar("EtaK1Var"));i++;
//  SET_VECTOR_ELT(result, i, EtaK2Var_out_r);
//  SET_VECTOR_ELT(resultNames, i, mkChar("EtaK2Var"));i++;

  namesgets(result, resultNames);

  UNPROTECT(nProtect);
  PutRNGstate();


  return(result);

  //PutRNGstate();
  //return(R_NilValue);


}
}
