#ifndef RandomEffect_H
#define RandomEffect_H

#include <iostream>


class RandomEffect_NormalUni
{
  
}

#endif

