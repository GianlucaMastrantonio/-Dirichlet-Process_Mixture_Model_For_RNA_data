#ifndef MatricesAndVectors_H
#define MatricesAndVectors_H
#include <iostream>
using std::cout; using std::endl; using std::string;
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>
#include <string>
#include <time.h>
#include <list>
#include <vector>  
#include <sys/time.h>
#include "Functions.h"
//#include <fstream>


template <typename T>
static string to_string(T data){
    stringstream s;
    s<<data;
    return s.str();
}


//void PrintTemplate(double val)
//{
//    REprintf("%f ", val);
//};
//void PrintTemplate(int val)
//{
//    REprintf("%i ", val);
//};



/*****************************************
 Class COnstant and parameters
 ****************************************/
class Class_ToLoad
{
private:
    
public:
    
    static const double Dzero;
    static const double Done;
    static const double Dtwo;
    static const double DMinusOne;
    
    static const int Izero;
    static const int Ione;
    
    static int info;
    
    //static int iterations;
    
    static void PrintTemplate(double val)
    {
        REprintf("%f ", val);
    };
    static void PrintTemplate(int val)
    {
        REprintf("%i ", val);
        
    };
    
};



class VectorDouble{
private:
    // int nPositionVector;
public:
    int UsCont;
    int nElem;
    double *P;
    VectorDouble()
    {
        UsCont = 0;
        nElem = 0;
        P   = 0;
        
    };

    ~VectorDouble()
    {
        
    }
    
    void Vector(int nelem,  double* VectorAsVec)
    {
        UsCont = 0;
        nElem = nelem;
        if(nElem==0)
        {
            P=0;
        }else{
            P   = VectorAsVec;
        }
    }
};
/*****************************************/
/*********** Vector
 *****************************/

template <typename Tvec> class Vector{
    
private:
    // int nPositionVector;
public:
    
    
    int UsCont;
    int nElem;
    Tvec *P;
    Vector()
    {
        UsCont = 0;
        nElem = 0;
        P   = 0;
        
    };
    ~Vector()
    {
        
    }
//    Vector<Tvec>(const Vector<Tvec>& p) {
//        //printf("COPY Op \n");
//        UsCont = 0;
//        nElem = p.nElem;
//        P = (Tvec*)R_alloc(nElem,sizeof(Tvec));;
//        for(int i=0;i<nElem;i++)
//        {
//            P[i] = p.P[i];
//        }
//    }
    
    void Destroy()
    {
        nElem=0;
        if(P!=0)
        {
            if(UsCont==1)
            {
                //Class_ToLoad::zeropointer(P, nPositionVector);
                Free(P);
                P = 0;
            }
        }
        
    };

    
    Vector(int nelem,  Tvec  *VectorAsVec);
    // R crea gli oggetti
    Vector(int nelem, int UserControledMemory);
    
    void Init(Tvec a);
    
    Tvec *Pvec(int i );
    Tvec vec(int i ) const;
    
    Tvec *Pvec_mat(int i , int j, int rescale);
    Tvec vec_mat(int i , int j, int rescale);
    
    void SubstitutePointer(Tvec* VectorAsVec);
    
    void Print(string ToPrint) ;
    void Print() ;
    void Print(string ToPrint,int i_min, int i_max);
    
    
};




template <typename Tvec>  Vector<Tvec>::Vector(int nelem, Tvec* VectorAsVec)
{
    UsCont = 0;
    nElem = nelem;
    if(nElem==0)
    {
        P=0;
    }else{
        P   = VectorAsVec;
    }
    
};

//template <typename Tvec>  void Vector<Tvec>::SubstitutePointer(Tvec* VectorAsVec)
//{
//
//    // ANDREBBE RICONTROLLATO COME GESTIRE UsCont
//    UsCont = 0;
//
//    if(nElem==0)
//    {
//        P=0;
//    }else{
//        P   = VectorAsVec;
//    }
//
//
//};



template <typename Tvec>  Vector<Tvec>::Vector(int nelem,  int UserControledMemory)
{
    UsCont = 0;
    nElem = nelem;
    
    
    if(nElem==0)
    {
        P=0;
    }else{
        if(UserControledMemory==1)
        {
            P = Calloc(nElem, Tvec);
            UsCont = 1;
            //nPositionVector = Class_ToLoad::addpointer(P);
            ;
            if(P==0)
            {
                error("Pointer not allocated");
            }
            
            
        }else{
            P = (Tvec*)R_alloc(nElem,sizeof(Tvec));
            if(P==0)
            {
                error("Pointer not allocated");
            }
        }
    }
    
};



template <typename Tvec>  Tvec* Vector<Tvec>::Pvec(int i )
{
    return &P[i];
};


template <typename Tvec>  Tvec Vector<Tvec>::vec(int i ) const
{
    return P[i];
};

template <typename Tvec>  Tvec* Vector<Tvec>::Pvec_mat(int i , int j, int rescale)
{
    return &P[i*rescale+j];
}
template <typename Tvec>  Tvec Vector<Tvec>::vec_mat(int i , int j, int rescale)
{
    return P[i*rescale+j];
}


template <typename Tvec>  void Vector<Tvec>::Print(string ToPrint)
{
    REprintf(" %s \n Vector nelem=%i address=%p \n", ToPrint.c_str(),nElem,P);
    for(int i=0;i<nElem;i++)
    {
        
        Class_ToLoad::PrintTemplate(P[i]);
        
        
        REprintf("\n");
    }
};


template <typename Tvec>  void Vector<Tvec>::Print(string ToPrint,int i_min, int i_max)
{
    REprintf(" %s \n Vector nelem=%i address=%p \n", ToPrint.c_str(),nElem,P);
    for(int i=i_min;i<i_max;i++)
    {
        
        PrintTemplate(P[i]);
        
        REprintf("\n");
    }
};
template <typename Tvec>  void Vector<Tvec>::Print()
{
    REprintf(" Vector nelem=%i address=%p \n", nElem,P);
    for(int i=0;i<nElem;i++)
    {
        
        PrintTemplate(P[i]);
        
        REprintf("\n");
    }
};




template <typename Tvec>  void Vector<Tvec>::Init(Tvec a)
{
    for(int i=0;i<nElem;i++)
    {
        P[i] = a;
    }
    
};



/*****************************************/
/*********** MATRIX *************/
/*****************************************/

template <typename Tmat> class Matrix
{
    
private:
    
    int UsCont;
    //int nPositionVector;
public:
    
    int nRows;
    int nCols;
    int DimTot;
    Tmat *P;
    // Vector<Tmat> VecInMat;
    
    
    ~Matrix()
    {
        
    }
    // default constructor
    Matrix()
    {
        UsCont = 0;
        nRows = 0;
        nCols = 0;
        DimTot=0;
        P   = 0;
        
    };
    void Destroy()
    {
        
        nRows=0;
        nCols=0;
        DimTot = 0;
        if(P!=0)
        {
            if(UsCont==1)
            {
                //Class_ToLoad::zeropointer(P, nPositionVector);
                Free(P);
                P = 0;
            }
        }
    };

//    Matrix<Tmat>(const Matrix<Tmat>& p) {
//        //printf("COPY Op mat\n");
//        UsCont = 0;
//        nRows = p.nRows;
//        nCols = p.nCols;
//        DimTot= nRows*nCols;
//        P = (Tmat*)R_alloc(DimTot,sizeof(Tmat));;
//        for(int i=0;i<DimTot;i++)
//        {
//            P[i] = p.P[i];
//        }
//    }
    
    
    Matrix(int nrow, int ncol, Tmat* MatrixAsVec);
    Matrix(int nrow, int ncol, int UserControledMemory);
    
    
    Tmat *Pmat(int i, int j ) ;
    Tmat *Pvec(int i );
    
    
    Tmat mat(int i, int j ) const;
    Tmat vec(int i );
    void Init(Tmat a);
    Tmat mat(int i, int j, int rescale);
    
    Tmat *Pmat(int i, int j, int rescale );
    
    
    void Print(string ToPrint) ;
    void Print(string ToPrint, int i_min, int i_max, int j_min, int j_max);
    void Print() ;
    
    void PrintTriUpper(string ToPrint) ;
    void PrintTriUpper() ;
    
    
    
    // static function
    static void compute_SpectralDecompositionSymmetricMatrix(int *info, Matrix<double> * EigenVec, Vector <double> *EigVal)
    {
        // not efficient version, to be used only with small matrix
        
        int dimW = 3*EigenVec->nRows;
        double W[dimW];
        F77_NAME(dsyev)("V", "L", &EigenVec->nRows, EigenVec->P, &EigenVec->nRows, EigVal->P, &W[0], &dimW, info);
        if(info[0]!=0)
        {
            error("Error1 in dsyev %i", info[0]);
        }
        
    }

    static void compute_SpectralDecompositionQLambdaSquaredQt_PositiveDefiniteMatrix(int *info, Matrix<double> *dest, int usr)
    {
        

        
        
        double EigenVecApp_P[dest->nRows*dest->nRows];
        Matrix <double> EigenVecApp(dest->nRows,dest->nRows,EigenVecApp_P);
        double EigenVec_P[dest->nRows*dest->nRows];
        Matrix <double> EigenVec(dest->nRows,dest->nRows,EigenVec_P);
        double EigVal_P[dest->nRows];
        Vector <double> EigVal(dest->nRows,EigVal_P);
        
        
        for(int i=0;i<dest->nRows;i++)
        {
            for(int j=i;j<dest->nRows;j++)
            {
                EigenVec.Pmat(i,j)[0] = dest->mat(i,j);
            }
        }
        compute_SpectralDecompositionSymmetricMatrix(info, &EigenVec, &EigVal);
        if(info[0]!=0)
        {
            REprintf("Error in SpectralDecompositionSymmetricMatrix\n");
            return;
        }
        
        
        for(int i=0;i<dest->nRows;i++)
        {
            double squareL     = pow(EigVal.vec(i),0.5);
            for(int j=0;j<dest->nRows;j++)
            {
                 EigenVecApp.Pmat(j,i)[0] = EigenVec.mat(i,j)*squareL;
               // dest->Pmat(j,i)[0] = EigenVec.mat(i,j)*squareL;
            }
        }
        for(int i=0;i<dest->nRows;i++)
        {
            for(int j=0;j<dest->nRows;j++)
            {
                dest->Pmat(i,j)[0] = 0.0;
                for(int k=0;k<dest->nRows;k++)
                {
                    dest->Pmat(i,j)[0] +=  EigenVecApp.mat(i,k)*EigenVec.mat(k,j);
                }
            }
        }

    }
    
    
    
    
    
    
};



template <typename Tmat>  Matrix<Tmat>::Matrix(int nrow, int ncol, Tmat* MatrixAsVec)
{
    UsCont = 0;
    nRows = nrow;
    nCols = ncol;
    DimTot = nRows*nCols;
    if(DimTot==0)
    {
        P=0;
    }else{
        P   = MatrixAsVec;
        
    }
    // VecInMat = Vector<Tmat>(DimTot,MatrixAsVec);
    
    
};

template <typename Tmat>  Matrix<Tmat>::Matrix(int nrow, int ncol, int UserControledMemory)
{
    UsCont = 0;
    nRows = nrow;
    nCols = ncol;
    DimTot = nRows*nCols;
    if(DimTot==0)
    {
        P=0;
    }else{
        if(UserControledMemory==1)
        {
            P = Calloc(nRows*nCols, Tmat);
            UsCont = 1;
            if(P==0)
            {
                error("Pointer not allocated");
            }
        }else{
            P = (Tmat*)R_alloc(nRows*nCols,sizeof(Tmat));
            if(P==0)
            {
                error("Pointer not allocated");
            }
        }
    }
    // VecInMat = Vector<Tmat>(DimTot,UserControledMemory);
    
};


template <typename Tmat>  Tmat* Matrix<Tmat>::Pmat(int i, int j )
{
    return &P[i*nCols+j];
};

template <typename Tmat>  Tmat* Matrix<Tmat>::Pvec(int i )
{
    return &P[i];
};

template <typename Tmat>  Tmat Matrix<Tmat>::mat(int i, int j ) const
{
    return P[i*nCols+j];
};

template <typename Tmat>  Tmat Matrix<Tmat>::vec(int i )
{
    return P[i];
};

template <typename Tmat>  void Matrix<Tmat>::Init(Tmat a )
{
    for(int i=0;i<nRows*nCols;i++)
    {
        P[i] = a;
    }
};

template <typename Tmat>  void Matrix<Tmat>::Print(string ToPrint)
{
    REprintf("%s \n Matrix nrows=%i ncols=%i address=%p \n", ToPrint.c_str(),nRows, nCols,P);
    for(int i=0;i<nRows;i++)
    {
        for(int j=0;j<nCols;j++)
        {
            Class_ToLoad::PrintTemplate(P[i*nCols+j]);
        }
        REprintf("\n");
    }
}

template <typename Tmat>  void Matrix<Tmat>::Print(string ToPrint, int i_min, int i_max, int j_min, int j_max)
{
    REprintf("%s \n Matrix nrows=%i ncols=%i address=%p \n", ToPrint.c_str(),nRows, nCols,P);
    for(int i=i_min;i<i_max;i++)
    {
        for(int j=j_min;j<j_max;j++)
        {
            PrintTemplate(P[i*nCols+j]);
        }
        REprintf("\n");
    }
}

template <typename Tmat>  void Matrix<Tmat>::Print()
{
    REprintf("Matrix nrows=%i ncols=%i address=%p  \n", nRows, nCols,P);
    for(int i=0;i<nRows;i++)
    {
        for(int j=0;j<nCols;j++)
        {
            PrintTemplate(P[i*nCols+j]);
        }
        REprintf("\n");
    }
}


template <typename Tmat>  void Matrix<Tmat>::PrintTriUpper(string ToPrint)
{
    REprintf("%s \n (Upper) Matrix nrows=%i ncols=%i address=%p  \n", ToPrint.c_str(),nRows, nCols,P);
    for(int i=0;i<nRows;i++)
    {
        for(int j=i;j<nCols;j++)
        {
            Class_ToLoad::PrintTemplate(P[i*nCols+j]);
        }
        REprintf("\n");
    }
}

template <typename Tmat>  void Matrix<Tmat>::PrintTriUpper()
{
    REprintf("(Upper) Matrix nrows=%i ncols=%i address=&p  \n", nRows, nCols,P);
    for(int i=0;i<nRows;i++)
    {
        for(int j=i;j<nCols;j++)
        {
            PrintTemplate(P[i*nCols+j]);
        }
        REprintf("\n");
    }
}




template <typename Tmat> Tmat Matrix<Tmat>::mat(int i, int j, int rescale)
{
    return P[i*rescale+j];
}

template <typename Tmat>  Tmat *Matrix<Tmat>::Pmat(int i, int j, int rescale )
{
    return &P[i*rescale+j];
}







//
///*****************************************/
///*********** MATRIX3 *************/
///*****************************************/
//
//template <typename Tmat> class Matrix3{
//
//private:
//    // int nPositionVector;
//    int UsCont;
//public:
//
//    int nFirst;
//    int nRows;
//    int nCols;
//    int DimTot3;
//    Tmat *P3;
//
//
//
//
//    // default constructor
//    Matrix3()
//    {
//        nFirst = 0;
//        UsCont = 0;
//        nRows = 0;
//        nCols = 0;
//
//
//        DimTot3 = 0;
//        P3   = 0;
//
//    };
//    void Destroy()
//    {
//        DimTot3 =0;
//
//
//        nFirst = 0;
//        nRows=0;
//        nCols=0;
//
//        if(P3!=0)
//        {
//            if(UsCont==1)
//            {
//                // Class_ToLoad::zeropointer(P3, nPositionVector);
//                Free(P3);
//                P3 = 0;
//            }
//        }
//    };
//    //    ~Matrix3(){
//    //
//    //
//    //
//    //    };
//
//
//    Matrix3(int nfirst,int nrow, int ncol, Tmat* MatrixAsVec);
//    Matrix3(int nfirst,int nrow, int ncol, int UserControledMemory);
//
//
//    Tmat *Pmat3(int h, int i, int j );
//    Tmat *Pvec(int i );
//    Tmat mat3(int h, int i, int j );
//    Tmat vec(int i );
//    void Init(Tmat a);
//
//    Tmat mat3(int h,int i, int j, int rescale);
//
//    Tmat *Pmat3(int h,int i, int j, int rescale );
//    //
//    //
//    //    void Print(string ToPrint) ;
//    //    void Print() ;
//    //
//    //    void PrintTriUpper(string ToPrint) ;
//    //    void PrintTriUpper() ;
//
//
//};
//
//
//
//template <typename Tmat>  Matrix3<Tmat>::Matrix3(int nfirst , int nrow, int ncol, Tmat* MatrixAsVec)
//{
//    nFirst = nfirst;
//    UsCont = 0;
//    nRows = nrow;
//    nCols = ncol;
//
//    DimTot3 = nRows*nCols*nFirst;
//    P3   = MatrixAsVec;
//
//
//
//};
//template <typename Tmat>  Matrix3<Tmat>::Matrix3(int nfirst, int nrow, int ncol, int UserControledMemory)
//{
//    nFirst = nfirst;
//    UsCont = 0;
//    nRows = nrow;
//    nCols = ncol;
//
//
//    DimTot3 = nRows*nCols*nFirst;
//
//    if(UserControledMemory==1)
//    {
//        P3 = Calloc(nFirst*nRows*nCols, Tmat);
//        UsCont = 1;
//        //nPositionVector = Class_ToLoad::addpointer(P3);
//    }else{
//        P3 = (Tmat*)R_alloc(nFirst*nRows*nCols,sizeof(Tmat));
//    }
//};
//
//
//
//
//template <typename Tmat>  Tmat* Matrix3<Tmat>::Pmat3(int h, int i, int j )
//{
//    return &P3[h*(nCols*nRows)+i*nCols+j];
//};
//
//template <typename Tmat>  Tmat* Matrix3<Tmat>::Pvec(int i )
//{
//    return &P3[i];
//};
//
//template <typename Tmat>  Tmat Matrix3<Tmat>::mat3(int h, int i, int j )
//{
//    return P3[h*(nCols*nRows)+i*nCols+j];
//};
//
//template <typename Tmat>  Tmat Matrix3<Tmat>::vec(int i )
//{
//    return P3[i];
//};
//
//template <typename Tmat>  void Matrix3<Tmat>::Init(Tmat a )
//{
//    for(int i=0;i<nFirst*nRows*nCols;i++)
//    {
//        P3[i] = a;
//    }
//};
//
//
//
//
//
//template <typename Tmat> Tmat Matrix3<Tmat>::mat3(int h, int i, int j, int rescale)
//{
//    return P3[h*(nCols*nRows)+i*rescale+j];
//}
//
//template <typename Tmat>  Tmat *Matrix3<Tmat>::Pmat3(int h, int i, int j, int rescale )
//{
//    return &P3[h*(nCols*nRows)+i*rescale+j];
//}
//
//
//
//








/*****************************************
 Utils
 ****************************************/

class Class_Utils{
private:
    
public:
    // distances
    static void compute_dist(int nelem, int dimcoords, double *coords, double *ret);
    static void compute_dist(Matrix<double> *coords, Matrix<double> *dist);
    static void compute_dist(int nelem,Matrix<double> *coords, Matrix<double> *dist);
    
    static void compute_dist(int nelem, int dimcoords, double *coords, double *ret, double *ret2);
    static void compute_dist(int nelem,Matrix<double> *coords, Matrix<double> *dist, Matrix<double> *dist2);
    static void compute_dist(Matrix<double> *coords, Matrix<double> *dist, Matrix<double> *dist2);
    
    
    
    static int sample_Integers(int min, int max)
    {
        double u = runif(min-1,max);
        int k = min-1;
        do{
            k++;
        }while(k<u);
        return(k);
    }
    
    
    // matrix vector multiplication
    static void external_dsymv_MatMoltX(Matrix<double> *Inv, Vector<double> *mu, Vector<double> *ret);
    static void external_dgemv(Matrix<double> *Mat, Vector<double> *Vec, Vector<double> *ret, const  double Add);
    static void external_dgemm(Matrix<double> *Mat1, Matrix<double> *Mat2, Matrix<double> *ret, const  double Add);
    
    static void external_ytSigmaInvy(Vector <double> *y, Matrix <double> * SigmaInv,double *ret);
    static void external_vec1vec2(Vector <double> *y1, Vector <double> *y2,double *ret);
    
    static void external_computeCholesky(Matrix<double> *Sigma);
	
  static void external_computeCholesky_Lower(Matrix<double> *Sigma);
    static double external_computeLogDetCholesky(Matrix<double> *Chol);
    static void external_computeInverseFromCholesky(Matrix<double> *Chol);
  static void external_computeInverseFromCholesky_Lower(Matrix<double> *Chol);
  static void external_computeInverseTriMatrix_Lower(Matrix<double> *Tri);
  static void external_computeInverseTriMatrix(Matrix<double> *Tri);
  static void compute_Sigma_Chol_LogDet_FromInverse(Matrix<double> *Inv, Matrix <double> *Retmat,Matrix <double> *RetChol, double *logDet);
    static double ModOp(double x, double y);
    static void log_sum_exp(double *ret, int k, double *x);
    static void log_sum_exp_Type2(double *ret, int k, double *x, double *a_i);
    static void log_sum_exp(double *ret, int k, double *x, int* nonzero);
//    static void PrintTemplate(double val);
//    static void PrintTemplate(int val);
    static double log1mexp(double x); // calcpla log(1-exp(x)) senza cancellazione numerica, con x<0
    static double CircDist(double dist, double Cicle);
    static SEXP getListElement(SEXP list, const char *str);
    static int FindIndexString(vector <string> *Names, string *name);
    
    static int sample_DiscreteVarTEST(double *logprob_NonNormalized, int K);
   static int sample_DiscreteVarEqualProb(int K); 
	static int sample_DiscreteVar(double *logprob_NonNormalized, int K);
    static int sample_DiscreteVar(double *logprob_NonNormalized, int K, int *nonzero);
    static int sample_DiscreteVarFixed(double *logprob_NonNormalized, int K, int *nonzero);
    
    static double RoundComma(double x, int n)
    {
        double molt = pow(10,n);
        double ret = round(x*molt)/molt;
        return(ret);
    }
    
    static int ifelse(int n1, int n2, int t, int f)
    {
        if(n1==n2)
        {
            return(t);
        }else{
            return(f);
        }
    };
    static double ifelse(double n1, double n2, double t, double f)
    {
        if(n1==n2)
        {
            return(t);
        }else{
            return(f);
        }
    };
  static void WriteMatrix(string nameobj,string FileOUT, Matrix<double> *Mat )
  {
    FILE * (file);
    file = fopen(FileOUT.c_str(),"wt");
    
    fprintf(file, "nan= NaN \ninf=Inf \n  %s = matrix(c(  \n", nameobj.c_str());
    for (int i=0;i<Mat->nRows-1;i++)
    {
      for (int j=0;j<Mat->nCols;j++)
      {
        fprintf(file, "%e, ",Mat->mat(i,j));
      }
      fprintf (file,"\n");
    } 
    int i=Mat->nRows-1;
    for (int j=0;j<Mat->nCols-1;j++)
    {
      fprintf(file, "%e, ",Mat->mat(i,j));
    }
    int j = Mat->nCols-1;
    fprintf(file, "%e ",Mat->mat(i,j));
    fprintf (file,"\n");
    fprintf(file, "),ncol=%i,nrow=%i, byrow=T) \n", Mat->nCols,Mat->nRows);
    fclose (file);

  }
	
//	static void WriteMatrix_no_e(Matrix<double> *Mat )
//	{
//	  
//	  for (int i=0;i<Mat->nRows;i++)
//	  {
//		 for (int j=0;j<Mat->nCols;j++)
//		 {
//			fprintf(file, "%f, ",Mat->mat(i,j));
//		 }
//		 fprintf (file,"\n");
//	  } 
//	}
//  
   

};


class TimingOLD
{
public:
    clock_t start;
    double sum;
    double Elapsed;
    int iter;
    
    TimingOLD(): start(0.0), sum(0.0),  Elapsed(0.0), iter(0)
    {

    }
    
    void compute_start()
    {
        
        
        start = clock();
        
    }
    
    void compute_end()
    {
        
        Elapsed = double( clock() - start ) / (double)CLOCKS_PER_SEC;
        
        
        sum += Elapsed;
        iter ++;
    }
    
    double compute_mean()
    {
        return(sum/iter);
    }
    double return_elapsed()
    {
        return(Elapsed);
    }

    
    
    
};


class Timing
{
public:
    //time_t start, end;
    double sum;
    double Elapsed;
    int iter;
    struct timeval start, end;
    
    Timing(): sum(0.0),  Elapsed(0.0), iter(0)
    {

    }
    
    void compute_start()
    {
        gettimeofday(&start, NULL);
        ios_base::sync_with_stdio(false);
        //time(&start);
        
    }
    
    void compute_end()
    {
        gettimeofday(&end, NULL);
        Elapsed = ((end.tv_sec  - start.tv_sec) * 1000000u +end.tv_usec - start.tv_usec) / 1.e6;
        sum += Elapsed;
        iter ++;
    }
    
    double compute_mean()
    {
        return(sum/iter);
    }
    double return_elapsed()
    {
        return(Elapsed);
    }
    
    
    
    
};


#endif








