#ifndef CovFunctionsV3_H
#define CovFunctionsV3_H


#include <iostream>
#include <list>
#include <vector>
#include "DensityPriorParam.h"
#include "MatricesAndVectors.h"
using namespace std;
#include <vector>
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>




/*******************
Poly Cor Funtions
 *******************/


class Poly_CovCorFunction
{
private:
    
public:
    int TwoParts;
    
    
    int nParameters;
    vector<string> NameParameters;
    string NameCor;

    vector<Class_Parameter*> Parameters;
    
    //COSTRUCTORS
    Poly_CovCorFunction(): TwoParts(1), nParameters(0)
    {

    };
    Poly_CovCorFunction(int twopart, int nparam): TwoParts(twopart), nParameters(nparam)
    {
        
    };
    
    
    //DESTRUCTORS
    ~Poly_CovCorFunction(){}
    void Destroy()
    {
        
    }
    
    
    
    // CREATES
    void create_FullObject()
    {
        nParameters             = get_nParameters();
        NameParameters          = get_NameParameters();
        NameCor                 = get_NameCor();
        
        for(int i=0;i<nParameters;i++)
        {
            Parameters.push_back(new Class_Parameter);
        }
        
    }
    
    /****** ADD********/
    void add_Parameters(int k, Class_Parameter* par)
    {
        if(k>=nParameters)
        {
            error("Too many parameters in Poly_CovCorFunction");
        }
        Parameters[k] = par;
    }
    
    
    /***** GET *****/
    virtual void get_valueAcc(int n,  double* dist, double *ret)
    {
        error("Non overrided function get_valueAcc(int n,  double* dist, double *ret)");
    };
    virtual void get_valueProp(int n,  double* dist, double *ret)
    {
        error("Non overrided function get_valueProp(int n,  double* dist, double *ret)");
    };
    virtual void get_valueAcc_Part1(int n,  double* dist, double *ret)
    {
         error("Non overrided function get_valueAcc_Part1");
        get_valueAcc(n, dist, ret);
    };
    virtual void get_valueProp_Part1(int n,  double* dist, double *ret)
    {
         error("Non overrided function get_valueProp_Part1");
        //ret[0] = 0.0;
        get_valueProp(n, dist, ret);
    };
    virtual void get_valueAcc_Part2(int n,  double* dist, double *ret)
    {
         error("Non overrided functionget_valueAcc_Part2");
        //get_valueProp(n, dist, ret);
        ret[0] = 0.0;
    };
    virtual void get_valueProp_Part2(int n,  double* dist, double *ret)
    {
         error("Non overrided function get_valueProp_Part2");
        ret[0] = 0.0;
    };
    
    
    
    virtual void get_valueAcc(int n,  double* dist1,double* dist2, double *ret)
    {
        error("Non overrided function get_valueAcc(int n,  double* dist1,double* dist2, double *ret)");
    };
    virtual void get_valueProp(int n,  double* dist1, double* dist2, double *ret)
    {
        error("Non overrided function get_valueProp(int n,  double* dist1, double* dist2, double *ret)");
    };
    virtual void get_valueAcc_Part1(int n,  double* dist1, double* dist2, double *ret)
    {
         error("Non overrided function get_valueAcc_Part1(int n,  double* dist1, double* dist2, double *ret)");
    };
    virtual void get_valueProp_Part1(int n,  double* dist1, double* dist2, double *ret)
    {
         error("Non overrided function get_valueProp_Part1(int n,  double* dist1, double* dist2, double *ret)");
    };
    virtual void get_valueAcc_Part2(int n,  double* dist1, double* dist2, double *ret)
    {
         error("Non overrided function get_valueAcc_Part2(int n,  double* dist1, double* dist2, double *ret)");
    };
    virtual void get_valueProp_Part2(int n,  double* dist1, double* dist2, double *ret)
    {
         error("Non overrided function get_valueProp_Part2(int n,  double* dist1, double* dist2, double *ret)");
    };
    virtual int  get_nParameters()=0;
    virtual string get_NameCor()=0;
    virtual vector<string>      get_NameParameters()=0;

};



/*******************
Cor Funtions
*******************/

class Class_Exponential: public Poly_CovCorFunction
{
private:
    
public:
    
    //COSTRUCTORS
    Class_Exponential(){};
    
    //DESTRUCTORS
    ~Class_Exponential(){};
    void Destroy()
    {
        
    }
    
    
    
    
    void get_valueAcc(int n,  double* dist, double *ret) override;
    void get_valueProp(int n,  double* dist, double *ret) override;
    void get_valueAcc_Part1(int n,  double* dist, double *ret) override;
    void get_valueAcc_Part2(int n,  double* dist, double *ret) override;
    void get_valueProp_Part1(int n,  double* dist, double *ret) override;
    void get_valueProp_Part2(int n,  double* dist, double *ret) override;
    
    
    int  get_nParameters() override
    {
        return(1);
    }
    string get_NameCor() override
    {
        string name = "Exponential";
        return(name);
        
    }
    vector<string>      get_NameParameters() override
    {
        string par1 = "decay";
        vector <string> ret;
        ret.push_back(par1);
        return(ret);
    }
};




class Class_ExponentialCirc: public Poly_CovCorFunction
{
private:
    
public:
    
    //COSTRUCTORS
    Class_ExponentialCirc(){};
    
    //DESTRUCTORS
    ~Class_ExponentialCirc(){};
    void Destroy()
    {
        
    }
    
    
    
    
    void get_valueAcc(int n,  double* dist, double *ret) override;
    void get_valueProp(int n,  double* dist, double *ret) override;
    void get_valueAcc_Part1(int n,  double* dist, double *ret) override;
    void get_valueAcc_Part2(int n,  double* dist, double *ret) override;
    void get_valueProp_Part1(int n,  double* dist, double *ret) override;
    void get_valueProp_Part2(int n,  double* dist, double *ret) override;
    
    
    int  get_nParameters() override
    {
        return(2);
    }
    string get_NameCor() override
    {
        string name = "ExponentialCirc";
        return(name);
        
    }
    vector<string>      get_NameParameters() override
    {
        vector <string> ret;
        
        string par1 = "decay";
        ret.push_back(par1);
        string par2 = "SeasonPar";
        ret.push_back(par2);
        return(ret);
    }
};





class Class_Exponential_LinearCovSeason: public Poly_CovCorFunction
{
private:
    
public:
    
    //COSTRUCTORS
    Class_Exponential_LinearCovSeason(){};
    
    //DESTRUCTORS
    ~Class_Exponential_LinearCovSeason(){};
    void Destroy()
    {
        
    }
    
    
    
    
    void get_valueAcc(int n,  double* dist, double *ret) override;
    void get_valueProp(int n,  double* dist, double *ret) override;
    void get_valueAcc_Part1(int n,  double* dist, double *ret) override;
    void get_valueAcc_Part2(int n,  double* dist, double *ret) override;
    void get_valueProp_Part1(int n,  double* dist, double *ret) override;
    void get_valueProp_Part2(int n,  double* dist, double *ret) override;
    
    int  get_nParameters() override
    {
        return(4);
    }
    string get_NameCor() override
    {
        string name = "Exponential_LinearCovSeason";
        return(name);
        
    }
    vector<string>      get_NameParameters() override
    {
        vector <string> ret;
        string par1 = "decay";
        ret.push_back(par1);
        string par2 = "Seasonaldecay";
        ret.push_back(par2);
        string par3 = "SeasonalPar";
        ret.push_back(par3);
        string par4 = "VarPart2";
        ret.push_back(par4);
        return(ret);
    }
};


class Class_ExponentialExponential: public Poly_CovCorFunction
{
private:
    
public:
    
    //COSTRUCTORS
    Class_ExponentialExponential(){};
    
    //DESTRUCTORS
    ~Class_ExponentialExponential(){};
    void Destroy()
    {
        
    }
    
    
    
    
    void get_valueAcc(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueProp(int n,           double* dist1, double* dist2, double *ret) override;
    void get_valueAcc_Part1(int n,      double* dist1, double* dist2, double *ret) override;
    void get_valueAcc_Part2(int n,      double* dist1, double* dist2, double *ret) override;
    void get_valueProp_Part1(int n,     double* dist1, double* dist2, double *ret) override;
    void get_valueProp_Part2(int n,     double* dist1, double* dist2, double *ret) override;
    
    int  get_nParameters() override
    {
        return(2);
    }
    string get_NameCor() override
    {
        string name = "Class_ExponentialExponential";
        return(name);
        
    }
    vector<string>      get_NameParameters() override
    {
        vector <string> ret;
        string par1 = "Spatial_decay";
        ret.push_back(par1);
        string par2 = "Temporal_decay";
        ret.push_back(par2);
        return(ret);
    }
};



class Class_GneitingPlusCirc: public Poly_CovCorFunction
{
private:
    
public:
    
    //COSTRUCTORS
    Class_GneitingPlusCirc(){};
    
    //DESTRUCTORS
    ~Class_GneitingPlusCirc(){};
    void Destroy()
    {
        
    }
    
    
    
    
    void get_valueAcc(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueProp(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueAcc_Part1(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueAcc_Part2(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueProp_Part1(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueProp_Part2(int n,            double* dist1, double* dist2, double *ret) override;
    
    int  get_nParameters() override
    {
        return(6);
    }
    string get_NameCor() override
    {
        string name = "Exponential_LinearCovSeason";
        return(name);
        
    }
    vector<string>      get_NameParameters() override
    {
        vector <string> ret;
        string par1 = "decaySp";
        ret.push_back(par1);
        
        string par2 = "decayT";
        ret.push_back(par2);
        
        string par3 = "decayC";
        ret.push_back(par3);
        
        string par4 = "SepPar";
        ret.push_back(par4);
        
        string par5 = "VarCirc";
        ret.push_back(par5);
        
        string par6 = "SeasonPar";
        ret.push_back(par6);
        return(ret);
    }
};



class Class_GneitingCov: public Poly_CovCorFunction
{
private:
    
public:
    
    //COSTRUCTORS
    Class_GneitingCov(){};
    
    //DESTRUCTORS
    ~Class_GneitingCov(){};
    void Destroy()
    {
        
    }
    
    
    
    
    void get_valueAcc(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueProp(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueAcc_Part1(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueAcc_Part2(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueProp_Part1(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueProp_Part2(int n,            double* dist1, double* dist2, double *ret) override;
    
    int  get_nParameters() override
    {
        return(4);
    }
    string get_NameCor() override
    {
        string name = "Class_GneitingCov";
        return(name);
        
    }
    vector<string>      get_NameParameters() override
    {
        vector <string> ret;
        string par1 = "decaySp";
        ret.push_back(par1);
        
        string par2 = "decayT";
        ret.push_back(par2);
        
        //string par3 = "decayC";
        //ret.push_back(par3);
        
        string par4 = "SepPar";
        ret.push_back(par4);
        
        string par5 = "Var";
        ret.push_back(par5);
        
        //string par6 = "SeasonPar";
        //ret.push_back(par6);
        return(ret);
    }
};


class Class_ExponentialPlusNugget: public Poly_CovCorFunction
{
private:
    
public:
    
    //COSTRUCTORS
    Class_ExponentialPlusNugget(): Poly_CovCorFunction(1,3)
    {
        
    };
    
    //DESTRUCTORS
    ~Class_ExponentialPlusNugget()
    {
        
    };
    void Destroy()
    {
        
    }
    
    
    
    
    void get_valueAcc(int n,  double* dist, double *ret) override;
    void get_valueProp(int n,  double* dist, double *ret) override;
    void get_valueAcc_Part1(int n,  double* dist, double *ret) override;
    void get_valueAcc_Part2(int n,  double* dist, double *ret) override;
    void get_valueProp_Part1(int n,  double* dist, double *ret) override;
    void get_valueProp_Part2(int n,  double* dist, double *ret) override;
    
    
    int  get_nParameters() override
    {
        return(nParameters);
    }
    string get_NameCor() override
    {
        string name = "ExponentialCirc";
        return(name);
        
    }
    vector<string>      get_NameParameters() override
    {
        vector <string> ret;
        
        string par1 = "varTot";
        ret.push_back(par1);
        string par2 = "decayTot";
        ret.push_back(par2);
        
        string par3 = "varYear";
        ret.push_back(par3);
        string par4 = "decayYear";
        ret.push_back(par4);
        
        //        string par5 = "varWeek";
        //        ret.push_back(par5);
        //        string par6 = "decayWeek";
        //        ret.push_back(par6);
        
        string par5 = "nugget";
        ret.push_back(par5);
        
        
        return(ret);
    }
};


class Class_ExponentialPlusNugget_Tstudent: public Poly_CovCorFunction
{
private:
    
public:
    
    //COSTRUCTORS
    Class_ExponentialPlusNugget_Tstudent(): Poly_CovCorFunction(1,4)
    {
        
    };
    
    //DESTRUCTORS
    ~Class_ExponentialPlusNugget_Tstudent()
    {
        
    };
    void Destroy()
    {
        
    }
    
    
    
    
    void get_valueAcc(int n,  double* dist, double *ret) override;
    void get_valueProp(int n,  double* dist, double *ret) override;
    void get_valueAcc_Part1(int n,  double* dist, double *ret) override;
    void get_valueAcc_Part2(int n,  double* dist, double *ret) override;
    void get_valueProp_Part1(int n,  double* dist, double *ret) override;
    void get_valueProp_Part2(int n,  double* dist, double *ret) override;
    
    
    int  get_nParameters() override
    {
        return(nParameters);
    }
    string get_NameCor() override
    {
        string name = "ExponentialCirc";
        return(name);
        
    }
    vector<string>      get_NameParameters() override
    {
        vector <string> ret;
        
        string par1 = "varTot";
        ret.push_back(par1);
        string par2 = "decayTot";
        ret.push_back(par2);
        
        string par3 = "varYear";
        ret.push_back(par3);
        string par4 = "decayYear";
        ret.push_back(par4);
        
        //        string par5 = "varWeek";
        //        ret.push_back(par5);
        //        string par6 = "decayWeek";
        //        ret.push_back(par6);
        
        string par5 = "nugget";
        ret.push_back(par5);
        
        string par6 = "nuT";
        ret.push_back(par6);
        
        
        return(ret);
    }
};


class Class_GneitingCovPlusCirc: public Poly_CovCorFunction
{
private:
    
public:
    
    //COSTRUCTORS
    Class_GneitingCovPlusCirc(){};
    
    //DESTRUCTORS
    ~Class_GneitingCovPlusCirc(){};
    void Destroy()
    {
        
    }
    
    
    
    
    void get_valueAcc(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueProp(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueAcc_Part1(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueAcc_Part2(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueProp_Part1(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueProp_Part2(int n,            double* dist1, double* dist2, double *ret) override;
    
    int  get_nParameters() override
    {
        return(7);
    }
    string get_NameCor() override
    {
        string name = "Exponential_LinearCovSeason";
        return(name);
        
    }
    vector<string>      get_NameParameters() override
    {
        vector <string> ret;
        string par1 = "decaySp";
        ret.push_back(par1);
        
        string par2 = "decayT";
        ret.push_back(par2);
        
        string par3 = "decayC";
        ret.push_back(par3);
        
        string par4 = "SepPar";
        ret.push_back(par4);
        
        string par5 = "VarCirc";
        ret.push_back(par5);
        
        string par6 = "SeasonPar";
        ret.push_back(par6);
        
        string par7 = "VarPart1";
        ret.push_back(par7);
        return(ret);
    }
};



class Class_ExponentialExponentialCov: public Poly_CovCorFunction
{
private:
    
public:
    
    //COSTRUCTORS
    Class_ExponentialExponentialCov(){};
    
    //DESTRUCTORS
    ~Class_ExponentialExponentialCov(){};
    void Destroy()
    {
        
    }
    
    
    
    
    void get_valueAcc(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueProp(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueAcc_Part1(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueAcc_Part2(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueProp_Part1(int n,            double* dist1, double* dist2, double *ret) override;
    void get_valueProp_Part2(int n,            double* dist1, double* dist2, double *ret) override;
    
    int  get_nParameters() override
    {
        return(3);
    }
    string get_NameCor() override
    {
        string name = "Class_ExponentialExponentialCov";
        return(name);
        
    }
    vector<string>      get_NameParameters() override
    {
        vector <string> ret;
        string par1 = "decaySp";
        ret.push_back(par1);
        
        string par2 = "decayT";
        ret.push_back(par2);
        
        //string par3 = "decayC";
        //ret.push_back(par3);
        

        
        string par5 = "Var";
        ret.push_back(par5);
        
        //string par6 = "SeasonPar";
        //ret.push_back(par6);
        return(ret);
    }
};










class Class_CovPM10Mod1: public Poly_CovCorFunction
{
private:
    
public:
    
    double SeasWeek;
    double SeasYear;
    //COSTRUCTORS
    Class_CovPM10Mod1(double week, double year): Poly_CovCorFunction(1, 7), SeasWeek(week), SeasYear(year)
    {
        
    };
    
    //DESTRUCTORS
    ~Class_CovPM10Mod1()
    {
        
    };
    void Destroy()
    {
        
    }
    
    
    
    
    void get_valueAcc(int n,  double* dist, double *ret) override;
    void get_valueProp(int n,  double* dist, double *ret) override;
    void get_valueAcc_Part1(int n,  double* dist, double *ret) override;
    void get_valueAcc_Part2(int n,  double* dist, double *ret) override;
    void get_valueProp_Part1(int n,  double* dist, double *ret) override;
    void get_valueProp_Part2(int n,  double* dist, double *ret) override;
    
    
    int  get_nParameters() override
    {
        return(nParameters);
    }
    string get_NameCor() override
    {
        string name = "ExponentialCirc";
        return(name);
        
    }
    vector<string>      get_NameParameters() override
    {
        vector <string> ret;
        
        string par1 = "varTot";
        ret.push_back(par1);
        string par2 = "decayTot";
        ret.push_back(par2);
        
        string par3 = "varYear";
        ret.push_back(par3);
        string par4 = "decayYear";
        ret.push_back(par4);
        
        string par5 = "varWeek";
        ret.push_back(par5);
        string par6 = "decayWeek";
        ret.push_back(par6);
        
        string par7 = "nugget";
        ret.push_back(par7);
        

        return(ret);
    }
};




class Class_CovPM10Mod1_2: public Poly_CovCorFunction
{
private:
    
public:
    
    double SeasYear;
    //COSTRUCTORS
    Class_CovPM10Mod1_2(double year): Poly_CovCorFunction(1,5),  SeasYear(year)
    {

    };
    
    //DESTRUCTORS
    ~Class_CovPM10Mod1_2()
    {
        
    };
    void Destroy()
    {
        
    }
    
    
    
    
    void get_valueAcc(int n,  double* dist, double *ret) override;
    void get_valueProp(int n,  double* dist, double *ret) override;
    void get_valueAcc_Part1(int n,  double* dist, double *ret) override;
    void get_valueAcc_Part2(int n,  double* dist, double *ret) override;
    void get_valueProp_Part1(int n,  double* dist, double *ret) override;
    void get_valueProp_Part2(int n,  double* dist, double *ret) override;
    
    
    int  get_nParameters() override
    {
        return(nParameters);
    }
    string get_NameCor() override
    {
        string name = "ExponentialCirc";
        return(name);
        
    }
    vector<string>      get_NameParameters() override
    {
        vector <string> ret;
        
        string par1 = "varTot";
        ret.push_back(par1);
        string par2 = "decayTot";
        ret.push_back(par2);
        
        string par3 = "varYear";
        ret.push_back(par3);
        string par4 = "decayYear";
        ret.push_back(par4);
        
//        string par5 = "varWeek";
//        ret.push_back(par5);
//        string par6 = "decayWeek";
//        ret.push_back(par6);
        
        string par5 = "nugget";
        ret.push_back(par5);
        
        
        return(ret);
    }
};

#endif

