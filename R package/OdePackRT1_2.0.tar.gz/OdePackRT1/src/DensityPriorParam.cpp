
#include <iostream>

#include "MatricesAndVectors.h"
#include <string>
#include <vector>
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>
#include "DensityPriorParam.h"
#include "Functions.h"

//using namespace std;
using std::cout; using std::endl; using std::string;



double compute_LogJacobian_BASE_R_To_R(double *variable,Vector <double*> hyper)
{
    return(0.0);
}

double compute_LogJacobian_BASE_Rplus_To_R(double *variable,Vector <double*> hyper)
{
    return(log(variable[0]));
}



double compute_LogJacobian_BASE_Segment_To_R(double *variable,Vector <double*> hyper)
{
    double ex = (variable[0]-hyper.vec(0)[0])/(hyper.vec(1)[0]-variable[0]);
    return( log(hyper.vec(1)[0]-hyper.vec(0)[0])+log(ex)-2.0*log(1.0+ex)  );
}


double fromParameterToTransParameter_BASE_R_To_R(double *variable,Vector <double*> hyper)
{
    return(variable[0]);
}

double fromParameterToTransParameter_BASE_Rplus_To_R(double *variable,Vector <double*> hyper)
{
    return(log(variable[0]));
}

double fromParameterToTransParameter_BASE_Segment_To_R(double *variable,Vector <double*> hyper)
{
    double ex = (variable[0]-hyper.vec(0)[0])/(hyper.vec(1)[0]-variable[0]);
    return( log(ex)  );
}

double fromTransParameterToParameter_BASE_R_To_R(double *transvariable,Vector <double*> hyper)
{
    return(transvariable[0]);
}

double fromTransParameterToParameter_BASE_R_To_Rplus(double *transvariable,Vector <double*> hyper)
{
    return(exp(transvariable[0]));
}


double fromTransParameterToParameter_BASE_R_To_Segment(double *transvariable,Vector <double*> hyper)
{

    return(   (hyper.vec(0)[0]+hyper.vec(1)[0]*exp(transvariable[0]))/(1+exp(transvariable[0]))    );
}




int  get_nHyperparams_R()
{
    return(1);
}
int  get_nHyperparams_Rplus()
{
    return(1);
}
int  get_nHyperparams_Segment()
{
    return(2);
}


vector<string>      get_NameHyperparams_R()
{
    string par1 = "Hyper_VOID";
    vector <string> ret;
    ret.push_back(par1);
    return(ret);
}
vector<string>      get_NameHyperparams_Rplus()
{
    string par1 = "Hyper_VOID";
    vector <string> ret;
    ret.push_back(par1);
    return(ret);
}
vector<string>      get_NameHyperparams_Segment()
{
    string par1 = "Hyper_min";
    string par2 = "Hyper_max";
    vector <string> ret;
    ret.push_back(par1);
    ret.push_back(par2);
    return(ret);
}


int get_Discrete_Discrete()
{
    return(1);
}
int get_Discrete_NoDiscrete()
{
    return(0);
}
int get_Circular_Circular()
{
    return(1);
}
int get_Circular_NoCircular()
{
    return(0);
}

/*************
 double get_NoNormlogDensity_forParameter_BASE(int n,double *variable,Vector <double*> hyper)
 **********/

// NOPRRIORD
double Class_NoPrior::compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper)
{
    return(0);
}

double Class_NoPrior::compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper)
{
    return(0);
}


double Class_NoPrior::compute_LogJacobian_BASE(double *variable,Vector <double*> hyper)
{
    return(0.0);
}
double Class_NoPrior::compute_LogDensity(double *x, double * hyper)
{
    Rprintf("Valutare se serve ancora");
    return(0.0 );
}

double Class_NoPrior::fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper)
{
    return(transvariable[0]);
}
double Class_NoPrior::fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper)
{
    return(variable[0]);
}
// CIRCULA UNIFORM

double Class_CircularUniform::compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper)
{
    
    return(1.0/(2*M_PI));
}

double Class_CircularUniform::compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper)
{
    return(1.0);
}

double Class_CircularUniform::compute_LogJacobian_BASE(double *variable,Vector <double*> hyper)
{
    return(0.0);
}
double Class_CircularUniform::compute_LogDensity(double *x, double * hyper)
{
    return(dbeta(x[0], hyper[0], hyper[1],1));
}
double Class_CircularUniform::fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper)
{
    return(transvariable[0]);
}
double Class_CircularUniform::fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper)
{
    return(variable[0]);
}

// Binomial
double Class_Binomial::compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    for(int i=0;i<n;i++)
    {
        ret += dbinom(variable[i], (int)hyper.vec(0)[0], hyper.vec(1)[0],1);
    }
    return(ret);
}



double Class_Binomial::compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper)
{
    return(dbinom(variable[0], (int)hyper.vec(0)[0], hyper.vec(1)[0],1));
}


//double Class_Binomial::compute_LogJacobian_BASE(double *variable,Vector <double*> hyper)
//{
//    return(0.0);
//}

double Class_Binomial::compute_LogDensity(double *x, double * hyper)
{
    return(dbinom(x[0], (int)hyper[0], hyper[1],1));
}

//double Class_Binomial::fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper)
//{
//    return(transvariable[0]);
//}
//
//
//double Class_Binomial::fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper)
//{
//    return(variable[0]);
//}


//// PositiveTruncatedNormal
//double Class_PositiveTruncatedNormal::compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper)
//{
//    double ret = 0.0;
//    for(int i=0;i<n;i++)
//    {
//        ret += -0.5*pow(variable[i]-hyper.vec(0)[0],2.0)/hyper.vec(1)[0];
//    }
//    return(ret);
//}
//
//
//
//double Class_PositiveTruncatedNormal::compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper)
//{
//    return(-0.5*pow(variable[0]-hyper.vec(0)[0],2.0)/hyper.vec(1)[0]);
//}
//
//
//double Class_PositiveTruncatedNormal::compute_LogJacobian_BASE(double *variable,Vector <double*> hyper)
//{
//    return(log(variable[0]));
//}
//
//double Class_PositiveTruncatedNormal::compute_LogDensity(double *x, double * hyper)
//{
//    return(dnorm(x[0], hyper[0], pow(hyper[1],0.5),1)-pnorm(0.0, hyper[0], pow(hyper[1],0.5),0,1));
//}
//
//double Class_PositiveTruncatedNormal::fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper)
//{
//    return(exp(transvariable[0]));
//}
//
//
//double Class_PositiveTruncatedNormal::fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper)
//{
//    return(log(variable[0]));
//}

// NORMAL
double Class_Normal::compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    for(int i=0;i<n;i++)
    {
        ret += -0.5*pow(variable[i]-hyper.vec(0)[0],2.0)/hyper.vec(1)[0];
    }
    return(ret);
}



double Class_Normal::compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper)
{
    return(-0.5*pow(variable[0]-hyper.vec(0)[0],2.0)/hyper.vec(1)[0]);
}


double Class_Normal::compute_LogJacobian_BASE(double *variable,Vector <double*> hyper)
{
    return(0.0);
}

double Class_Normal::compute_LogDensity(double *x, double * hyper)
{
    return(dnorm(x[0], hyper[0], pow(hyper[1],0.5),1));
}

double Class_Normal::fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper)
{
    return(transvariable[0]);
}


double Class_Normal::fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper)
{
    return(variable[0]);
}


//BETA
double Class_Beta::compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    for(int i=0;i<n;i++)
    {
        ret += (hyper.vec(0)[0]-1.0)*log(variable[i])+(hyper.vec(1)[0]-1.0)*log(1.0-variable[i]);
    }
    return(ret);
}

double Class_Beta::compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper)
{
    return((hyper.vec(0)[0]-1.0)*log(variable[0])+(hyper.vec(1)[0]-1.0)*log(1.0-variable[0]  ));
}

double Class_Beta::compute_LogJacobian_BASE(double *variable,Vector <double*> hyper)
{
    double ex = (variable[0])/(1.0-variable[0]);
    return( log(ex)-2.0*log(1.0+ex)  );
}

double Class_Beta::compute_LogDensity(double *x, double * hyper)
{
    return(dbeta(x[0], hyper[0], hyper[1],1));
}
double Class_Beta::fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper)
{
    
    return(   (0.0+1.0*exp(transvariable[0]))/(1.0+exp(transvariable[0]))    );
}
double Class_Beta::fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper)
{
    double ex = (variable[0]-0.0)/(1.0-variable[0]);
    return( log(ex)  );
}

// GAMMA
double Class_Gamma::compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    for(int i=0;i<n;i++)
    {
        ret += (hyper.vec(0)[0]-1.0)*log(variable[i])-1.0*hyper.vec(1)[0]*variable[i];
    }
    return(ret);
}

double Class_Gamma::compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper)
{
    return((hyper.vec(0)[0]-1.0)*log(variable[0])-1.0*hyper.vec(1)[0]*variable[0]);
}


double Class_Gamma::compute_LogJacobian_BASE(double *variable,Vector <double*> hyper)
{
    return(log(variable[0]));
}

double Class_Gamma::compute_LogDensity(double *x, double * hyper)
{
    return( hyper[0]*log(hyper[1])+(hyper[0]-1)*log(x[0])-hyper[1]*x[0]-lgamma(hyper[0]) );
}

double Class_Gamma::fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper)
{
    return(exp(transvariable[0]));
}
double Class_Gamma::fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper)
{
    return(log(variable[0]));
}
// INVERSE GAMMA
double Class_InverseGamma::compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    for(int i=0;i<n;i++)
    {
        ret += -1.0*(hyper.vec(0)[0]+1.0)*log(variable[i])-1.0*hyper.vec(1)[0]/variable[i];
    }
    return(ret);
}

double Class_InverseGamma::compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper)
{
    return(-1.0*(hyper.vec(0)[0]+1.0)*log(variable[0])-1.0*hyper.vec(1)[0]/variable[0]);
}

double Class_InverseGamma::compute_LogJacobian_BASE(double *variable,Vector <double*> hyper)
{
    return(log(variable[0]));
}
double Class_InverseGamma::compute_LogDensity(double *x, double * hyper)
{
    return(  hyper[0]*log(hyper[1])-1.0*(hyper[0]+1)*log(x[0])-hyper[1]/x[0]-lgamma(hyper[0])  );
}
double Class_InverseGamma::fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper)
{
    return(exp(transvariable[0]));
}
double Class_InverseGamma::fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper)
{
    return(log(variable[0]));
}
// UNIFORM
double Class_Uniform::compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    for(int i=0;i<n;i++)
    {
        ret += -log(hyper.vec(1)[0]-hyper.vec(0)[0]);
    }
    return(ret);
}


double Class_Uniform::compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper)
{
    return( -log(hyper.vec(1)[0]-hyper.vec(0)[0]));
}



double Class_Uniform::compute_LogJacobian_BASE(double *variable,Vector <double*> hyper)
{
    double ex = (variable[0]-hyper.vec(0)[0])/(hyper.vec(1)[0]-variable[0]);
    return( log(hyper.vec(1)[0]-hyper.vec(0)[0])+log(ex)-2.0*log(1.0+ex)  );
}
double Class_Uniform::compute_LogDensity(double *x, double * hyper)
{
    
    return(   -log(hyper[1]-hyper[0])  );
}
double Class_Uniform::fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper)
{
    
    return(   (hyper.vec(0)[0]+hyper.vec(1)[0]*exp(transvariable[0]))/(1.0+exp(transvariable[0]))    );
}


double Class_Uniform::fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper)
{
    double ex = (variable[0]-hyper.vec(0)[0])/(hyper.vec(1)[0]-variable[0]);
    return( log(ex)  );
}
// CATEGORIAL
double Class_Categorial::compute_NoNormlogDensity_forVariable_BASE(int n,int *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    for(int i=0;i<n;i++)
    {
        ret += log(hyper.vec(variable[i])[0]);
    }
    return(ret);
}

double Class_Categorial::compute_NoNormlogDensity_forVariable_BASE(int *variable,Vector <double*> hyper)
{
    return( log(hyper.vec(variable[0])[0]));
}
double Class_Categorial::compute_LogDensity(int *x, double * hyper)
{
    
    return(  log(hyper[x[0]]) );
}
// CHI SQUARED
double Class_ChiSquared::compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    for(int i=0;i<n;i++)
    {
        ret +=  dchisq(variable[i],hyper.vec(0)[0],1);
    }
    return(ret);
}


double Class_ChiSquared::compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper)
{
    return( dchisq(variable[0],hyper.vec(0)[0],1));
}


double Class_ChiSquared::compute_LogJacobian_BASE(double *variable,Vector <double*> hyper)
{
    return(log(variable[0]));
}

double Class_ChiSquared::compute_LogDensity(double *x, double * hyper)
{
    
    return(   dchisq(x[0], hyper[0],1)  );
}
double Class_ChiSquared::fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper)
{
    return(exp(transvariable[0]));
}
double Class_ChiSquared::fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper)
{
    return(log(variable[0]));
}
// DISXRETE UNIFORM INTEGER
double Class_DiscreteUniformInteger::compute_NoNormlogDensity_forVariable_BASE(int n,int *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    for(int i=0;i<n;i++)
    {
        if(((1.0*variable[i])>=hyper.vec(0)[0])&((1.0*variable[i])<=hyper.vec(1)[0]))
        {
            ret += -log(hyper.vec(2)[0]);
        }else{
            error("Class_DiscreteUniformInteger outside interval");
        }
        
    }
    return(ret);
}

double Class_DiscreteUniformInteger::compute_NoNormlogDensity_forVariable_BASE(int *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    //for(int i=0;i<n;i++)
    //{
    if(((1.0*variable[0])>=hyper.vec(0)[0])&((1.0*variable[0])<=hyper.vec(1)[0]))
    {
        ret += -log(hyper.vec(2)[0]);
    }else{
        error("Class_DiscreteUniformInteger outside interval");
    }
    
    //}
    return(ret);
}

double Class_DiscreteUniformInteger::compute_LogCumulative(int *x, double * hyper)
{
    double ret = 0.0;
    for(int i=0;i<x[0]+1;i++)
    {
        ret += exp(Class_DiscreteUniformInteger::compute_LogDensity(&i, hyper));
    }
    return(log(ret));
}

double Class_DiscreteUniformInteger::compute_LogDensity(int *x, double * hyper)
{
    double ret = 0.0;
    //for(int i=0;i<n;i++)
    //{
    if(((1.0*x[0])>=hyper[0])&((1.0*x[0])<=hyper[1]))
    {
        ret += -log(hyper[2]);
    }else{
        error("Class_DiscreteUniformInteger outside interval");
    }
    
    //}
    return(ret);
}

double Class_DiscreteUniformInteger::compute_logCumulative_BASE(double *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    //if(variable[0]>=0)
    //{
    for(int i=0;i<=variable[0];i++)
    {
        if(((1.0*variable[0])<=hyper.vec(1)[0]))
        {
            ret += 1/(hyper.vec(2)[0]);
        }
    }
    //}
    return(log(ret));
}


double Class_DiscreteUniformInteger::compute_logDensity_BASE(double *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    //for(int i=0;i<n;i++)
    //{
    if(((1.0*variable[0])>=hyper.vec(0)[0])&((1.0*variable[0])<=hyper.vec(1)[0]))
    {
        ret += -log(hyper.vec(2)[0]);
    }else{
        error("Class_DiscreteUniformInteger outside interval");
    }
    
    //}
    return(ret);
}


// POISSON
double Class_Poisson::compute_NoNormlogDensity_forVariable_BASE(int n,int *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    double logfact;
    
    for(int i=0;i<n;i++)
    {
        logfact = 0.0;
        for(int i2=2;i2<=variable[0]+0.1;i2++)
        {
            logfact += log(1.0*i2);
        }
        ret += (1.0*variable[i])*log(hyper.vec(0)[0])-hyper.vec(0)[0]-logfact;
    
    }
    
    return(ret);
}

double Class_Poisson::compute_NoNormlogDensity_forVariable_BASE(int *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    double logfact;
    logfact = 0.0;
    
    for(int i=2;i<=variable[0]+0.1;i++)
    {
        logfact += log(1.0*i);
    }
    //for(int i=0;i<n;i++)
    //{
    ret += (1.0*variable[0])*log(hyper.vec(0)[0])-hyper.vec(0)[0]-logfact;
    //}
    return(ret);
}
double Class_Poisson::compute_LogCumulative(int *x, double * hyper)
{
    double ret = 0.0;
    for(int i=0;i<x[0]+1;i++)
    {
        ret += exp(Class_Poisson::compute_LogDensity(&i, hyper));
    }
    return(log(ret));
}


double Class_Poisson::compute_LogDensity(int *x, double * hyper)
{
    double ret = 0.0;
    double logfact;
    logfact = 0.0;
    
    for(int i=2;i<=x[0];i++)
    {
        logfact += log(1.0*i);
    }
    //for(int i=0;i<n;i++)
    //{
    ret += (1.0*x[0])*log(hyper[0])-hyper[0]-logfact;
    //}
    return(ret);
}
double Class_Poisson::compute_logCumulative_BASE(double *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    double logfact;
    
    //if(variable[0]>=0)
    //{
    logfact = 0.0;
    for(int i=0;i<=variable[0];i++)
    {
        
        ret += exp((1.0*i)*log(hyper.vec(0)[0])-hyper.vec(0)[0]-logfact);
        logfact += log(1.0*i+1.0);
    }
    //}
    return(log(ret));
}
double Class_Poisson::compute_logDensity_BASE(double *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    double logfact;
    logfact = 0.0;
    
    for(int i=2;i<=variable[0]+0.1;i++)
    {
        logfact += log(1.0*i);
    }
    //for(int i=0;i<n;i++)
    //{
    ret += (1.0*variable[0])*log(hyper.vec(0)[0])-hyper.vec(0)[0]-logfact;
    //}
    return(ret);
}


// GEOMETRIC
double Class_Geometric::compute_NoNormlogDensity_forVariable_BASE(int n,int *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    for(int i=0;i<n;i++)
    {
        ret += (1.0*variable[i])*log(1.0-hyper.vec(0)[0])+log(hyper.vec(0)[0]);
    }
    return(ret);
}

double Class_Geometric::compute_NoNormlogDensity_forVariable_BASE(int *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    //for(int i=0;i<n;i++)
    //{
    ret += (1.0*variable[0])*log(1.0-hyper.vec(0)[0])+log(hyper.vec(0)[0]);
    //}
    return(ret);
}

double Class_Geometric::compute_LogCumulative(int *x, double * hyper)
{
    double ret = 0.0;
    for(int i=0;i<x[0]+1;i++)
    {
        ret += exp(Class_Geometric::compute_LogDensity(&i, hyper));
    }
    return(log(ret));
}


double Class_Geometric::compute_LogDensity(int *x, double * hyper)
{
    double ret = 0.0;
    //for(int i=0;i<n;i++)
    //{
    ret += (1.0*x[0])*log(1.0-hyper[0])+log(hyper[0]);
    //}
    return(ret);
}
double Class_Geometric::compute_logCumulative_BASE(double *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    //if(variable[0]>=0)
    //{
    for(int i=0;i<=variable[0];i++)
    {
        ret +=   exp((1.0*i)*log(1.0-hyper.vec(0)[0])+log(hyper.vec(0)[0]));
    }
    //}
    return(log(ret));
}
double Class_Geometric::compute_logDensity_BASE(double *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    //for(int i=0;i<n;i++)
    //{
    ret += (1.0*variable[0])*log(1.0-hyper.vec(0)[0])+log(hyper.vec(0)[0]);
    //}
    return(ret);
}

// ABE LEY

double Class_AbeLey::compute_LogDensity(double *x, double * hyper)
{
    double ret;
    double appret;
    ret = log(hyper[0])+hyper[0]*log(hyper[1])-log(2*M_PI*cosh(hyper[3]));
    ret += log(1.0+hyper[4]*sin(x[0]-hyper[2]))+(hyper[0]-1.0)*log(x[1]);
    
    appret = hyper[0]*log(hyper[1]*x[1])+log(1-tanh(hyper[3])*cos(x[0]-hyper[2]));
    
    ret += -1.0*exp(appret);
    
    return(ret);
}





// TruncatedNormal
double Class_TruncatedNormal::compute_NoNormlogDensity_forVariable_BASE(int n,double *variable,Vector <double*> hyper)
{
    double ret = 0.0;
    for(int i=0;i<n;i++)
    {
        ret += -0.5*pow(variable[i]-hyper.vec(0)[0],2.0)/hyper.vec(1)[0];
    }
    return(ret);
}



double Class_TruncatedNormal::compute_NoNormlogDensity_forVariable_BASE(double *variable,Vector <double*> hyper)
{
    return(-0.5*pow(variable[0]-hyper.vec(0)[0],2.0)/hyper.vec(1)[0]);
}


double Class_TruncatedNormal::compute_LogJacobian_BASE(double *variable,Vector <double*> hyper)
{
  
    double ret = 0.0;
    if(hyper.vec(4)[0]==0)
    {
      ret = log(variable[0]-hyper.vec(2)[0]);
    }else{
      if(hyper.vec(4)[0]==1)
      {
        ret = log(hyper.vec(3)[0]-variable[0]);
      }else{
        double ex = (variable[0]-hyper.vec(2)[0])/(hyper.vec(3)[0]-variable[0]);
        ret =  log(hyper.vec(3)[0]-hyper.vec(2)[0])+log(ex)-2.0*log(1.0+ex);
      }
    }
    return(ret);
}

double Class_TruncatedNormal::compute_LogDensity(double *x, double * hyper)
{
  double ret;
  if(hyper[4]==0)
  {
    ret = dnorm(x[0], hyper[0], pow(hyper[1],0.5),1)-pnorm(hyper[2], hyper[0], pow(hyper[1],0.5),0,1);
  }else{
    if(hyper[4]==1)
    {
      ret = dnorm(x[0], hyper[0], pow(hyper[1],0.5),1)-pnorm(hyper[3], hyper[0], pow(hyper[1],0.5),1,1);
    }else{
      ret = dnorm(x[0], hyper[0], pow(hyper[1],0.5),1)-
      log(pnorm(hyper[3], hyper[0], pow(hyper[1],0.5),1,0)-pnorm(hyper[2], hyper[0], pow(hyper[1],0.5),1,0));
    }
  }
  return(ret);

}

double Class_TruncatedNormal::fromTransParameterToParameter_BASE(double *transvariable,Vector <double*> hyper)
{
    double ret;
    if(hyper.vec(4)[0]==0)
    {
      ret = hyper.vec(2)[0]+exp(transvariable[0]);
    }else{
      if(hyper.vec(4)[0]==1)
      {
        ret = hyper.vec(3)[0]-exp(transvariable[0]);
      }else{
        ret = (hyper.vec(2)[0]+hyper.vec(3)[0]*exp(transvariable[0]) )/(1.0+exp(transvariable[0]));    
      }
    }
    return(ret);
}


double Class_TruncatedNormal::fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper)
{
  double ret;
  if(hyper.vec(4)[0]==0)
  {
    ret = log(variable[0]-hyper.vec(2)[0]);
  }else{
    if(hyper.vec(4)[0]==1)
    {
      ret = log(hyper.vec(3)[0]-variable[0]);
    }else{
      ret = log((variable[0]-hyper.vec(2)[0])/(hyper.vec(3)[0]-variable[0]));
   }
  }
  return(ret);
}


 

/*************
 double get_NoNormlogDensity_forParameter_BASE(int n,double *variable,Vector <double*> hyper)
 **********/
















/*************
double get_LogJacobian_BASE(double *variable,Vector <double*> hyper);
 **********/



















/*************
double fromParameterToTransParameter_BASE(double *variable,Vector <double*> hyper);
  **********/


















/*************
 double fromTransParameterToParameter_BASE(double *variable,Vector <double*> hyper);
 **********/










/*****
 void double compute_LogDensity(double *variable,Vector <double*> hyper;
 ******/









/*****
 void compute_LogDensity(double x, double * hyper);
 ******/



//double Class_WrappedNormal::compute_LogDensity(double *x, double * hyper)
//{
//    double ret = 0.0;
//
//    return(dnorm(x[0]-2*2.0*M_PI, hyper[0], pow(hyper[1],0.5),1)+dnorm(x[0]-2.0*M_PI, hyper[0], pow(hyper[1],0.5),1)+dnorm(x[0], hyper[0], pow(hyper[1],0.5),1)+dnorm(x[0]+2*2.0*M_PI, hyper[0], pow(hyper[1],0.5),1)+dnorm(x[0]+2.0*M_PI, hyper[0], pow(hyper[1],0.5),1));
//}
























/*****
 void compute_LogCumulative(int *x, double * hyper);
 ******/





/********************
 PRIOR
 *******************/




/********************
 PARAMETER
 *******************/
double Class_Parameter::compute_NoNormlogDensity_forVariable_DiffPropLessAcc()
{
    double ret = 0.0;
//    Rprintf("%f \n",ParameterAcc);
//    Rprintf("%f \n",ParameterProp);
//    Rprintf("%p \n",&ParameterAcc);
//    Rprintf("%p \n",&ParameterProp);
//    ret += PriorParameter->compute_NoNormlogDensity_forVariable_BASE(&ParameterProp,PriorParameter->HyperparametersProp);
//    ret -= PriorParameter->compute_NoNormlogDensity_forVariable_BASE(&ParameterAcc,PriorParameter->HyperparametersAcc);
//    return(ret);
  
  ret += PriorParameter->compute_NoNormlogDensity_forVariable_BASE(&ParameterProp,PriorParameter->HyperparametersAcc);
  ret -= PriorParameter->compute_NoNormlogDensity_forVariable_BASE(&ParameterAcc,PriorParameter->HyperparametersAcc);
  return(ret);
}
double Class_Parameter::compute_LogJacobian_DiffPropLessAcc()
{
    double ret = 0.0;
//    ret += PriorParameter->compute_LogJacobian_BASE(&ParameterProp,PriorParameter->HyperparametersProp);
//    ret -= PriorParameter->compute_LogJacobian_BASE(&ParameterAcc,PriorParameter->HyperparametersAcc);
//    return(ret);
  
  ret += PriorParameter->compute_LogJacobian_BASE(&ParameterProp,PriorParameter->HyperparametersAcc);
  ret -= PriorParameter->compute_LogJacobian_BASE( &ParameterAcc,PriorParameter->HyperparametersAcc);
  return(ret);
}

/****
 oiv update_ParameterAcc_FromTransParameterAcc(double *variable,Vector <double*> hyper);
 double update_TransParameterAcc_FromParameterAcc(double *variable,Vector <double*> hyper);
*****/
void Class_Parameter::update_ParameterAcc_FromTransParameterAcc(double *transvariable)
{
    ParameterAcc =  PriorParameter->fromTransParameterToParameter_BASE(transvariable, PriorParameter->HyperparametersAcc);
}
void Class_Parameter::update_ParameterProp_FromTransParameterProp(double *transvariable)
{
    ParameterProp =  PriorParameter->fromTransParameterToParameter_BASE(transvariable, PriorParameter->HyperparametersProp);
}


void Class_Parameter::update_TransParameterAcc_FromParameterAcc(double *transvariable)
{
    transvariable[0]    = PriorParameter->fromParameterToTransParameter_BASE(&ParameterAcc, PriorParameter->HyperparametersAcc);
}

void Class_Parameter::update_TransParameterProp_FromParameterProp(double *transvariable)
{
    transvariable[0]    = PriorParameter->fromParameterToTransParameter_BASE(&ParameterProp, PriorParameter->HyperparametersProp);
}



double Class_Parameter::compute_logDensityAccHyperProp()
{
    return(PriorParameter->compute_logDensity_BASE(&ParameterAcc, PriorParameter->HyperparametersProp));
    
}
double Class_Parameter::compute_logCumulativeAccHyperProp()
{
    return(PriorParameter->compute_logCumulative_BASE(&ParameterAcc, PriorParameter->HyperparametersProp));
}


double Class_Parameter::compute_logDensityAcc()
{
    return(PriorParameter->compute_logDensity_BASE(&ParameterAcc, PriorParameter->HyperparametersAcc));
    
}
double Class_Parameter::compute_logCumulativeAcc()
{
    return(PriorParameter->compute_logCumulative_BASE(&ParameterAcc, PriorParameter->HyperparametersAcc));
}

double Class_Parameter::compute_logDensityProp()
{
    return(PriorParameter->compute_logDensity_BASE(&ParameterProp, PriorParameter->HyperparametersAcc));
    
}
double Class_Parameter::compute_logCumulativeProp()
{
    return(PriorParameter->compute_logCumulative_BASE(&ParameterProp, PriorParameter->HyperparametersAcc));
}

/************
 void get_CompanionParameters();
 ***********/



//1
void Class_Parameter_PDMatrixUnivSamp::get_CompanionParameters(double *hyperalpha)
{

    //Rprintf("C1\n");
    DimGamma = 0;
    string appName;
    for(int k=0;k<Dim;k++)
    {

        if(PriorParameter->NamePrior=="NoPrior")
        {

            parSigma2_Prior.push_back(new Poly_Prior);
            parSigma2_Prior[k]      = new Class_NoPrior;
            parSigma2_Prior[k]->create_FullObject(UserControlledMemory);
            parSigma2_Prior[k]->HyperparametersProp.Pvec(0)[0][0]     = NAN;
            parSigma2_Prior[k]->HyperparametersAcc.Pvec(0)[0][0]      = NAN;

            appName = "parSigma_"+to_string(k);
            parSigma2.push_back(new Class_Parameter);
            parSigma2[k]->create_FullObject(NAN, appName, parSigma2_Prior[k]);


            parAlpha_Prior.push_back(new Poly_Prior);
            parAlpha_Prior[k]      = new Class_NoPrior;
            parAlpha_Prior[k]->create_FullObject(UserControlledMemory);
            parAlpha_Prior[k]->HyperparametersProp.Pvec(0)[0][0]     = NAN;
            parAlpha_Prior[k]->HyperparametersAcc.Pvec(0)[0][0]      = NAN;

            appName = "parAlpha_"+to_string(k);
            parAlpha.push_back(new Class_Parameter);
            parAlpha[k]->create_FullObject(NAN, appName, parAlpha_Prior[k]);




            for(int j=0;j<k;j++)
            {

                parGamma_Prior.push_back(new Poly_Prior);
                parGamma_Prior[DimGamma] = new Class_NoPrior;
                parGamma_Prior[DimGamma]->create_FullObject(UserControlledMemory);
                parGamma_Prior[DimGamma]->HyperparametersProp.Pvec(0)[0][0]     = NAN;
                parGamma_Prior[DimGamma]->HyperparametersAcc.Pvec(0)[0][0]      = NAN;

                appName = "parGamma_"+to_string(k);
                parGamma.push_back(new Class_Parameter);
                parGamma[DimGamma]->create_FullObject(NAN, appName, parGamma_Prior[DimGamma]);

                DimGamma++;
            }
        }else{

            parSigma2_Prior.push_back(new Poly_Prior);
            parSigma2_Prior[k]      = new Class_ChiSquared;
            parSigma2_Prior[k]->create_FullObject(UserControlledMemory);
            parSigma2_Prior[k]->HyperparametersProp.Pvec(0)[0][0]     = (PriorParameter->nuProp[0]+Dim-1) -(k+1)+1;
            parSigma2_Prior[k]->HyperparametersAcc.Pvec(0)[0][0]      = (PriorParameter->nuProp[0]+Dim-1) -(k+1)+1;

            appName = "parSigma_"+to_string(k);
            parSigma2.push_back(new Class_Parameter);
            parSigma2[k]->create_FullObject(1.0, appName, parSigma2_Prior[k]);


            if(PriorParameter->NamePrior=="InverseWishart")
            {
                parAlpha_Prior.push_back(new Poly_Prior);
                parAlpha_Prior[k]      = new Class_NoPrior;
                parAlpha_Prior[k]->create_FullObject(UserControlledMemory);
                parAlpha_Prior[k]->HyperparametersProp.Pvec(0)[0][0]     = NAN;
                parAlpha_Prior[k]->HyperparametersAcc.Pvec(0)[0][0]      = NAN;

                appName = "parAlpha_"+to_string(k);
                parAlpha.push_back(new Class_Parameter);
                parAlpha[k]->create_FullObject(NAN, appName, parAlpha_Prior[k]);

            }else{
                if(PriorParameter->NamePrior=="HuangWand")
                {
                    //error("Controllare bene HuangWand prior - ");
                    parAlpha_Prior.push_back(new Poly_Prior);
                    parAlpha_Prior[k]      = new Class_InverseGamma;
                    parAlpha_Prior[k]->create_FullObject(UserControlledMemory);
                    parAlpha_Prior[k]->HyperparametersProp.Pvec(0)[0][0]      = 0.5;
                    parAlpha_Prior[k]->HyperparametersProp.Pvec(1)[0][0]      = 1.0/pow(hyperalpha[k],2.0);
                    parAlpha_Prior[k]->HyperparametersAcc.Pvec(0)[0][0]       = 0.5;
                    parAlpha_Prior[k]->HyperparametersAcc.Pvec(1)[0][0]       = 1.0/pow(hyperalpha[k],2.0);

                    appName = "parAlpha_"+to_string(k);
                    parAlpha.push_back(new Class_Parameter);
                    parAlpha[k]->create_FullObject(1.0, appName, parAlpha_Prior[k]);


                }else{
                    error("prior on Sigma non well specified (%s)\n", PriorParameter->NamePrior.c_str());
                }
            }


            for(int j=0;j<k;j++)
            {
                Rprintf("C10\n");
                parGamma_Prior.push_back(new Poly_Prior);
                parGamma_Prior[DimGamma] = new Class_Normal;
                parGamma_Prior[DimGamma]->create_FullObject(UserControlledMemory);
                parGamma_Prior[DimGamma]->HyperparametersProp.Pvec(0)[0][0]      = 0.0;
                parGamma_Prior[DimGamma]->HyperparametersProp.Pvec(1)[0][0]      = 1.0;
                parGamma_Prior[DimGamma]->HyperparametersAcc.Pvec(0)[0][0]       = 0.0;
                parGamma_Prior[DimGamma]->HyperparametersAcc.Pvec(1)[0][0]       = 1.0;

                appName = "parGamma_"+to_string(k);
                parGamma.push_back(new Class_Parameter);
                parGamma[DimGamma]->create_FullObject(1.0, appName, parGamma_Prior[DimGamma]);

                DimGamma++;

            }
        }


    }







    //ACC
    //Rprintf("C11\n");
    double SigmaCopy[Dim*Dim];
    int info;


    for(int i=0;i<Dim;i++)
    {
        for(int j=i;j<Dim;j++)
        {
            SigmaCopy[i*Dim+j] = SigmaAcc.mat(i,j);
        }
    }
    //Rprintf("TEST02 %i\n",Dim);
    
    
    //if(Dim>1)
    //{
        F77_NAME(dpotrf)("L",&Dim, &SigmaCopy[0], &Dim, &info);
        if(info != 0)
        {
            error("Cpp error Cholesky failed - function: get_CompanionParameters\n");
        }
        F77_NAME(dpotri)("L",&Dim, &SigmaCopy[0], &Dim, &info);
        if(info != 0)
        {
            error("Cpp error Cholesky inverse - function: get_CompanionParameters\n");
        }
    //}else{
    //    SigmaCopy[0] = 1.0/SigmaCopy[0];
    //}
    
    //Rprintf("Test1\n");

    MatrixLAcc      = new Matrix<double>(Dim,Dim,UserControlledMemory);
    MatrixLAcc->Init(0.0);
    MatrixAAcc      = new Matrix<double>(Dim,Dim,UserControlledMemory);
    MatrixAAcc->Init(0.0);

    if(PriorParameter->NamePrior=="NoPrior")
    {

    }else{
        if(PriorParameter->NamePrior=="InverseWishart")
        {
            for(int i=0;i<Dim;i++)
            {
                MatrixLAcc->Pmat(i,i)[0] =  pow(1.0/PriorParameter->PsiAcc->mat(i,i),0.5  );
            }
        }else{
            if(PriorParameter->NamePrior=="HuangWand")
            {

                for(int k=0;k<Dim;k++)
                {
                    parAlpha[k]->ParameterAcc =  (2.0*PriorParameter->nuAcc[0])/PriorParameter->PsiAcc->mat(k,k);
                }

                for(int i=0;i<Dim;i++)
                {
                    MatrixLAcc->Pmat(i,i)[0] =  pow(parAlpha[i]->ParameterAcc/(2*PriorParameter->nuAcc[0]),0.5  );
                }
            }else{
                error("prior on Sigma non well specified (%s)\n", PriorParameter->NamePrior.c_str());
            }
        }
        for(int i=0;i<Dim;i++)
        {
            for(int j=i;j<Dim;j++)
            {
                MatrixAAcc->Pmat(i,j)[0] = SigmaCopy[i*Dim+j]/(MatrixLAcc->mat(i,i)*MatrixLAcc->mat(j,j));

            }
        }

        F77_NAME(dpotrf)("L",&Dim, MatrixAAcc->P, &Dim, &info);
        if(info != 0)
        {
            error("Cpp error Cholesky failed2 - function: get_CompanionParameters\n");
        }

        int h=0;
        for(int i=0;i<Dim;i++)
        {
            for(int j=i+1;j<Dim;j++)
            {
                parGamma[h]->ParameterAcc = MatrixAAcc->mat(i,j);
                h++;
            }
            parSigma2[i]->ParameterAcc = pow(MatrixAAcc->mat(i,i),2.0);
        }

    }







    //PROP
    for(int i=0;i<Dim;i++)
    {
        for(int j=i;j<Dim;j++)
        {
            SigmaCopy[i*Dim+j] = SigmaProp.mat(i,j);
        }
    }

    //if(Dim>1)
    //{
        F77_NAME(dpotrf)("L",&Dim, &SigmaCopy[0], &Dim, &info);
        if(info != 0)
        {
            error("Cpp error Cholesky failed - function: get_CompanionParameters\n");
        }
        F77_NAME(dpotri)("L",&Dim, &SigmaCopy[0], &Dim, &info);
        if(info != 0)
        {
            error("Cpp error Cholesky inverse - function: get_CompanionParameters\n");
        }
    //}else{
    //    SigmaCopy[0] = 1.0/SigmaCopy[0];
    //}
    


    MatrixLProp      = new Matrix<double>(Dim,Dim,UserControlledMemory);
    MatrixLProp->Init(0.0);
    MatrixAProp      = new Matrix<double>(Dim,Dim,UserControlledMemory);
    MatrixAProp->Init(0.0);


    if(PriorParameter->NamePrior=="NoPrior")
    {

    }else{
        if(PriorParameter->NamePrior=="InverseWishart")
        {
            for(int i=0;i<Dim;i++)
            {
                MatrixLProp->Pmat(i,i)[0] =  pow(1.0/PriorParameter->PsiProp->mat(i,i),0.5  );
            }
        }else{
            if(PriorParameter->NamePrior=="HuangWand")
            {

                for(int k=0;k<Dim;k++)
                {
                    parAlpha[k]->ParameterProp =  (2.0*PriorParameter->nuProp[0])/PriorParameter->PsiProp->mat(k,k);
                }

                for(int i=0;i<Dim;i++)
                {
                    MatrixLProp->Pmat(i,i)[0] =  pow(parAlpha[i]->ParameterProp/(2*PriorParameter->nuProp[0]),0.5  );
                }
            }else{
                error("prior on Sigma non well specified (%s)\n", PriorParameter->NamePrior.c_str());
            }
        }
        for(int i=0;i<Dim;i++)
        {
            for(int j=i;j<Dim;j++)
            {
                MatrixAProp->Pmat(i,j)[0] = SigmaCopy[i*Dim+j]/(MatrixLProp->mat(i,i)*MatrixLProp->mat(j,j));
            }
        }

        F77_NAME(dpotrf)("L",&Dim, MatrixAProp->P, &Dim, &info);
        if(info != 0)
        {
            error("Cpp error Cholesky failed2 - function: get_CompanionParameters\n");
        }

        int h=0;
        for(int i=0;i<Dim;i++)
        {
            for(int j=i+1;j<Dim;j++)
            {
                parGamma[h]->ParameterProp = MatrixAProp->mat(i,j);
                h++;
            }
            parSigma2[i]->ParameterProp = pow(MatrixAProp->mat(i,i),2.0);
        }
    }







}


void Class_Parameter_PDMatrixUnivSamp::update_allMatricesAcc()
{
    MatrixAAcc->Init(0.0);
    MatrixLAcc->Init(0.0);
    int h=0;
    for(int i=0;i<Dim;i++)
    {
        MatrixAAcc->Pmat(i,i)[0] = pow(parSigma2[i]->ParameterAcc,0.5);
        for(int j=i+1;j<Dim;j++)
        {
            MatrixAAcc->Pmat(i,j)[0] = parGamma[h]->ParameterAcc;
            h++;
        }
    }

    if(PriorParameter->NamePrior=="NoPrior")
    {

    }else{
        if(PriorParameter->NamePrior=="InverseWishart")
        {

            for(int i=0;i<Dim;i++)
            {
                MatrixLAcc->Pmat(i,i)[0] =  pow(1.0/PriorParameter->PsiAcc->mat(i,i),0.5  );
            }
        }else{
            if(PriorParameter->NamePrior=="HuangWand")
            {
                for(int i=0;i<Dim;i++)
                {
                    MatrixLAcc->Pmat(i,i)[0] =  pow(parAlpha[i]->ParameterAcc/(2*PriorParameter->nuAcc[0]),0.5  );
                    PriorParameter->PsiAcc->Pmat(i,i)[0] = 2*PriorParameter->nuAcc[0]/parAlpha[i]->ParameterAcc;
                }
            }else{
               error("prior on Sigma non well specified (%s)\n", PriorParameter->NamePrior.c_str());
            }
        }
        //double Chol[Dim*Dim];
        for(int i=0;i<Dim;i++)
        {
            for(int j=i;j<Dim;j++)
            {
                SigmaAcc.Pmat(i,j)[0] = MatrixAAcc->Pmat(i,j)[0]*MatrixLAcc->Pmat(j,j)[0];

            }
        }
        int info;
        F77_NAME(dpotri)("L",&Dim, SigmaAcc.P, &Dim, &info);
        if(info != 0)
        {
            error("Cpp error Cholesky inverse - function: update_allMatrices\n");
        }
        for(int i=0;i<Dim;i++)
        {
            for(int j=0;j<i;j++)
            {
                SigmaAcc.Pmat(i,j)[0] = SigmaAcc.mat(j,i);
            }
        }
    }



}

void Class_Parameter_PDMatrixUnivSamp::update_allMatricesProp()
{
    //Rprintf("FACCIO UI\n\n\n\n\\n\n\n\n\n\\n\n");
    MatrixAProp->Init(0.0);
    MatrixLProp->Init(0.0);
    int h=0;
    for(int i=0;i<Dim;i++)
    {
        MatrixAProp->Pmat(i,i)[0] = pow(parSigma2[i]->ParameterProp,0.5);
        for(int j=i+1;j<Dim;j++)
        {
            MatrixAProp->Pmat(i,j)[0] = parGamma[h]->ParameterProp;
            h++;
        }

    }
    //MatrixAProp->Print("A2");
    if(PriorParameter->NamePrior=="NoPrior")
    {

    }else{
        if(PriorParameter->NamePrior=="InverseWishart")
        {

            for(int i=0;i<Dim;i++)
            {
                MatrixLProp->Pmat(i,i)[0] =  pow(1.0/PriorParameter->PsiProp->mat(i,i),0.5  );
            }
        }else{
            if(PriorParameter->NamePrior=="HuangWand")
            {
                for(int i=0;i<Dim;i++)
                {
                    MatrixLProp->Pmat(i,i)[0] =  pow(parAlpha[i]->ParameterProp/(2*PriorParameter->nuProp[0]),0.5  );
                    PriorParameter->PsiProp->Pmat(i,i)[0] = 2*PriorParameter->nuProp[0]/parAlpha[i]->ParameterProp;
                }
            }else{
                error("prior on Sigma non well specified (%s)\n", PriorParameter->NamePrior.c_str());
            }
        }
        //double Chol[Dim*Dim];
        for(int i=0;i<Dim;i++)
        {
            for(int j=i;j<Dim;j++)
            {
                SigmaProp.Pmat(i,j)[0] = MatrixAProp->Pmat(i,j)[0]*MatrixLProp->Pmat(j,j)[0];

            }
        }
//MatrixAProp->Print("A3");
//        MatrixLProp->Print("A4");
//        SigmaProp.Print("SS");
        int info;
        F77_NAME(dpotri)("L",&Dim, SigmaProp.P, &Dim, &info);
        if(info != 0)
        {
            error("Cpp error Cholesky inverse - function: update_allMatrices\n");
        }
        for(int i=0;i<Dim;i++)
        {
            for(int j=0;j<i;j++)
            {
                SigmaProp.Pmat(i,j)[0] = SigmaProp.mat(j,i);
            }
        }
    }







}







/*************
MULTIVAROATE NORMAL
 *********/


void Class_MultivariateNormal::external_computeConditioanlMeanAndVariance_uni_ZeroMean(int index,  double *muA,  double *varA, Matrix<double> *SigmaInv,  Vector <double> * omega)
{
    // valori sulla diagonale superiore
    varA[0]         = SigmaInv->mat(index,index);
    muA[0]          = 0.0;
    for(int i=0; i<index;i++)
    {
        muA[0] += SigmaInv->mat(i,index)*(omega->vec(i));
    }
    for(int i=index+1;i< SigmaInv->nCols;i++)
    {
        muA[0] += SigmaInv->mat(index,i)*(omega->vec(i));
    }
    varA[0]         = 1.0/varA[0];
    muA[0]          = -1.0*varA[0]*muA[0];
}

void Class_MultivariateNormal::external_computeConditioanlMeanAndVariance_uni(int index,  double *muA,  double *varA, Matrix<double> *SigmaInv, Vector <double> * mu, Vector <double> * omega)
{
    // valori sulla diagonale superiore
    varA[0]         = SigmaInv->mat(index,index);
    muA[0]          = 0.0;
    for(int i=0; i<index;i++)
    {
        muA[0] += SigmaInv->mat(i,index)*(omega->vec(i)-mu->vec(i));
    }
    for(int i=index+1;i< SigmaInv->nCols;i++)
    {
        muA[0] += SigmaInv->mat(index,i)*(omega->vec(i)-mu->vec(i));
    }
    varA[0]         = 1.0/varA[0];
    muA[0]          = mu->vec(index)-1.0*varA[0]*muA[0];
}



void Class_MultivariateNormal::external_computeConditioanlMeanAndVariance(Vector<int> *IndexA,  Vector<double>* muA,  Matrix<double> *SigmaA, Matrix<double> *Sigma, Vector <double> * mu, Vector <double> * omega)
{

    int nA      = IndexA->nElem;
    int nB      = Sigma->nCols-nA;


    if(nB>0)
    {
        double SigmaAB_P[nA*nB];
        Matrix<double> SigmaAB(nA,nB,SigmaAB_P);
        double SigmaApp_P[nA*nB];
        Matrix<double> SigmaApp(nA,nB,SigmaApp_P);
        double SigmaB_P[nB*nB];
        Matrix<double> SigmaB(nB,nB,SigmaB_P);
        


        double omegaBLmuB_P[nB];
        Vector <double> omegaBLmuB(nB,omegaBLmuB_P);
        
        int IndexB_P[nB];
        Vector <int> IndexB(nB,&IndexB_P[0]);



        int iRowA =0;
        int iRowB =0;


        for(int i=0;i<nB+nA;i++)
        {

            if(iRowA<IndexA[0].nElem)
            {
                if(IndexA[0].vec(iRowA)!=i)
                {
                    //Rprintf("is B %i %i %i",IndexA[0].vec(iRowA),iRowA,iRowB );
                    IndexB.Pvec(iRowB)[0] = i;
                    iRowB++;
                }else{
                    //Rprintf("is A %i %i",IndexA[0].vec(iRowA),iRowA );
                    iRowA++;
                }
                
            }else{
                //Rprintf("is B %i %i %i",IndexA[0].vec(iRowA),iRowA,iRowB );
                IndexB.Pvec(iRowB)[0] = i;
                iRowB++;
            }
            
        }

        iRowA = 0;
        iRowB = 0;
//        for(int i=0;i<nA+nB;i++)
//        {
//            if(IndexA[0].vec(iRowA)==i)
//            {
//                muA->Pvec(iRowA)[0]       = mu->vec(i);
//                // allora metto dentro A
//                iColA = iRowA;
//                for(int j=i;j<nA+nB;j++)
//                {
//                    if(IndexA[0].vec(iColA)==j)
//                    {
//                        SigmaA[0].Pmat(iRowA, iColA)[0] =  Sigma[0].mat(i,j);
//                        iColA++;
//                    }
//                }
//                iRowA++;
//            }else{
//                omegaBLmuB.Pvec(iRowB)[0]    = omega->vec(i)-mu->vec(i);
//                iColB = iRowB;
//                for(int j=i;j<nA+nB;j++)
//                {
//                    if(IndexB.vec(iColB)==j)
//                    {
//                        SigmaB.Pmat(iRowB, iColB)[0] =  Sigma[0].mat(i,j);
//                        iColB++;
//                    }
//                }
//                iRowB++;
//            }
//        }
        for(int i =0;i<nA;i++)
        {
            for(int j=0;j<nA;j++)
            {
                SigmaA[0].Pmat(i,j)[0] = Sigma[0].mat(IndexA->vec(i),IndexA->vec(j));
            }
            muA->Pvec(i)[0]       = mu->vec(IndexA->vec(i));
        }
        for(int i =0;i<nB;i++)
        {
            for(int j=0;j<nB;j++)
            {
                SigmaB.Pmat(i,j)[0] = Sigma[0].mat(IndexB.vec(i),IndexB.vec(j));
            }
            omegaBLmuB.Pvec(i)[0]    = omega->vec(IndexB.vec(i))-mu->vec(IndexB.vec(i));
        }
        for(int i =0;i<nA;i++)
        {
            for(int j=0;j<nB;j++)
            {
                SigmaAB.Pmat(i,j)[0] = Sigma[0].mat(IndexA->vec(i),IndexB.vec(j));
            }
        }

//        int iRowAB = 0;
//        int iColAB = 0;
//        for(int i=0;i<nA+nB;i++)
//        {
//            if(IndexA[0].vec(iRowAB)==i)
//            {
//                iColAB = 0;
//                for(int j=0;j<nA+nB;j++)
//                {
//                    if(IndexB.vec(iColAB)==j)
//                    {
//                        if(i<j)
//                        {
//                            SigmaAB.Pmat(iRowAB, iColAB)[0] =  Sigma[0].mat(i,j);
//                        }else{
//                            SigmaAB.Pmat(iRowAB, iColAB)[0] = Sigma[0].mat(j,i);
//                        }
//                        iColAB++;
//
//                    }
//                }
//                iRowAB++;
//            }
//        }
//        Rprintf("\n\nPRE\n");
//        SigmaAB.Print("Sab");
//        SigmaB.Print("Sb");
//        SigmaA->Print("Sa");
//        Rprintf("MATRICI");
//
//
//        IndexA->Print("IndA");
//        IndexB.Print("IndB");
//        omega->Print("OMEGA");
//        mu->Print("MU");
//        Sigma->Print("SIGMA");
//
        
//        SigmaB->Print("SIGMB");
//        SigmaAB->Print("SIGMAAB");
//        omegaBLmuB.Print("omegaBLmuB");

        /**** INVERT MATRICES ******/
        int info;
        double Done = 1.0;
        double DLone = -1.0;
        double Dzero = 0.0;
        int Ione     = 1;

        F77_NAME(dpotrf)("L",&nB, SigmaB.P, &nB, &info);
        if(info != 0)
        {
            
            error("Cpp error ... Cholesky failed - function: external_computeConditioanlMeanAndVariance1\n");
        }
        F77_NAME(dpotri)("L",&nB, SigmaB.P, &nB, &info);
        if(info != 0)
        {
            error("Cpp error Cholesky inverse - function: external_computeConditioanlMeanAndVariance1\n");
        }

        //
        F77_NAME(dsymm)("L", "L", &nB, &nA, &Done, SigmaB.P, &nB, SigmaAB.P, &nB, &Dzero, SigmaApp.P, &nB);
        F77_NAME(dgemm)("T", "N", &nA, &nA, &nB, &DLone, SigmaApp.P,  &nB, SigmaAB.P, &nB, &Done, SigmaA->P, &nA);
        F77_NAME(dgemv)("T",  &nB, &nA, &Done, SigmaApp.P,  &nB, omegaBLmuB.P, &Ione, &Done, muA->P, &Ione);

        
//
//        Rprintf("Cond na %i nb %i\n", nA,nB);
//        IndexA->Print("IndA");
//        IndexB.Print("IndB");
//
//
//        Sigma->Print("SIGMA");
//        SigmaAB.Print("Sab");
//        SigmaB.Print("Sb");
//        SigmaA->Print("Sa");
//
//        mu->Print("Mu");
//        muA->Print("Mua");
//
//        omega->Print("Omega");
//
//        omegaBLmuB.Print("omegaBLmuB");
        
        
        
     
    }else{
        for(int i=0;i<nA;i++)
        {
            for(int j=i;j<nA;j++)
            {
                SigmaA->Pmat(i,j)[0] = Sigma->mat(i,j);
            }
            muA->Pvec(i)[0] = mu->vec(i);
        }
    }


//    muA->Print("muA");
//    SigmaA->Print("SIGMAA");

}
//
//void Class_MultivariateNormal::external_computeCholesky(Matrix<double> *Sigma)
//{
//
//        int info;
//        F77_NAME(dpotrf)("L",&Sigma->nCols, Sigma->P, &Sigma->nCols, &info);
//        if(info != 0)
//        {
//            if(Sigma->nRows==1)
//            {
//                Sigma->Pmat(0,0)[0] = pow(Sigma->Pmat(0,0)[0],0.5);
//            }else{
//                error("Cpp error Cholesky failed - function: external_computeCholesk\n");
//            }
//
//        }
//
//
//}
//
//void Class_MultivariateNormal::external_computeInverseFromCholesky(Matrix<double> *Chol)
//{
//
//        int info;
//        F77_NAME(dpotri)("L",&Chol->nCols, Chol->P, &Chol->nCols, &info);
//        if(info != 0)
//        {
//            if(Chol->nRows==1)
//            {
//                Chol->Pmat(0,0)[0] = pow(1.0/Chol->Pmat(0,0)[0],2);
//            }else{
//              error("CCpp error Cholesky inverse  - function: external_computeCholesk\n");
//            }
//
//        }
//
//
//}
//
//
//
//void Class_MultivariateNormal::external_dsymv_MatMoltX(Matrix<double> *Inv, Vector<double> *mu, Vector<double> *ret)
//{
//    double Done = 1.0;
//    double Dzero = 0.0;
//    int    Ione = 1;
//
//        F77_NAME(dsymv)("L", &mu->nElem, &Done, Inv->P, &mu->nElem, mu->P, & Ione, &Dzero, ret->P, &Ione);
//
//
//
//}



void Class_MultivariateNormal::external_SampleMultivariate(Vector<double>* ret, const Vector<double> * mu, const Matrix<double> *Chol)
{

    double Done = 1.0;
    int Ione = 1;
    for(int i=0;i<ret->nElem;i++)
    {
        ret[0].Pvec(i)[0] = rnorm(0.0,1.0);
    }
        F77_NAME(dtrmv)("L", "N", "N", &ret->nElem, Chol->P, &ret->nElem, ret[0].P, &Ione);
        F77_NAME(daxpy)(&ret->nElem, &Done, mu[0].P, &Ione, ret[0].P, &Ione);
}
void Class_MultivariateNormal::external_SampleMultivariate_ZeroMean(Vector<double>* ret,  const Matrix<double> *Chol)
{
    
    //double Done = 1.0;
    int Ione = 1;
    for(int i=0;i<ret->nElem;i++)
    {
        ret[0].Pvec(i)[0] = rnorm(0.0,1.0);
    }
    F77_NAME(dtrmv)("L", "N", "N", &ret->nElem, Chol->P, &ret->nElem, ret[0].P, &Ione);
}




double Class_MultivariateNormal::external_compute_LogDensity_forCovMat(int n, double *x,double  *mean , double *sigmaInv, double *logdet)
{

    //    double Done = 1.0;
    //    double Dzero = 0.0;
    //    int Ione = 1;

    const double    Dzero          = 0.0;
    const double    Done          = 1.0;
    //const double    Dtwo          = 2.0;
    //const double    DMinusOne     = -1.0;

    //const int       Izero         = 0;
    const int       Ione          = 1;

    //int             Class_ToLoad::iterations    = 0;
    //int            info          = 0;


    double des;

    double ObsMinusMean[n];
    double ObsMinusMeanInvCov[n];
    for(int i=0;i<n;i++)
    {
        ObsMinusMean[i] = x[i]-mean[i];
    }


    F77_NAME(dsymv)("L",&n, &Done,sigmaInv ,&n,&ObsMinusMean[0],&Ione, &Dzero, &ObsMinusMeanInvCov[0]  ,&Ione );
    des = -0.5*logdet[0]-0.5*F77_NAME(ddot)(&n,&ObsMinusMeanInvCov[0], &Ione, &ObsMinusMean[0], &Ione);

    return( des );
}


 double Class_MultivariateNormal::external_compute_LogDensity_forCovMat(int n, Vector<double> *x,Vector<double>  *mean , Matrix<double> *sigmaInv, double *logdet)
{


	
	
//    double Done = 1.0;
//    double Dzero = 0.0;
//    int Ione = 1;
    const double    Dzero          = 0.0;
    const double    Done          = 1.0;
    //const double    Dtwo          = 2.0;
    //const double    DMinusOne     = -1.0;

   // const int       Izero         = 0;
    const int       Ione          = 1;

    //int             Class_ToLoad::iterations    = 0;
    //int            info          = 0;

    double des;

    double ObsMinusMean[n];
    double ObsMinusMeanInvCov[n];
    for(int i=0;i<n;i++)
    {
        ObsMinusMean[i] = x->vec(i)-mean->vec(i);
    }


    F77_NAME(dsymv)("L",&n, &Done,sigmaInv->P ,&n,&ObsMinusMean[0],&Ione, &Dzero, &ObsMinusMeanInvCov[0]  ,&Ione );
    des = -0.5*logdet[0]-0.5*F77_NAME(ddot)(&n,&ObsMinusMeanInvCov[0], &Ione, &ObsMinusMean[0], &Ione);

    return( des );
}

double Class_MultivariateNormal::external_compute_LogDensity_forCovMatZeroMean(int n, Vector<double> *x, Matrix<double> *sigmaInv, double *logdet)
{
    
    //    double Done = 1.0;
    //    double Dzero = 0.0;
    //    int Ione = 1;
    const double    Dzero          = 0.0;
    const double    Done          = 1.0;
    //const double    Dtwo          = 2.0;
    //const double    DMinusOne     = -1.0;
    
    //const int       Izero         = 0;
    const int       Ione          = 1;
    
    //int             Class_ToLoad::iterations    = 0;
    //int            info          = 0;
    
    double des;
    
    double ObsMinusMean[n];
    double ObsMinusMeanInvCov[n];
    for(int i=0;i<n;i++)
    {
        ObsMinusMean[i] = x->vec(i);
    }
    
    
    F77_NAME(dsymv)("L",&n, &Done,sigmaInv->P ,&n,&ObsMinusMean[0],&Ione, &Dzero, &ObsMinusMeanInvCov[0]  ,&Ione );
    des = -0.5*logdet[0]-0.5*F77_NAME(ddot)(&n,&ObsMinusMeanInvCov[0], &Ione, &ObsMinusMean[0], &Ione);
    
    return( des );
}





void Class_MultivariateNormal::external_computeBandF_NNGP(Vector<int> *IndexA,  Matrix<double> *B,  Matrix<double> *F, Matrix<double> *Sigma)
{
    /*IndexA deve essere in ordine crescente*/

    // Sigmaapp = B
    // SigmaA = F
    int nA      = IndexA->nElem;
    int nB      = Sigma->nCols-nA;


    if(nB>0)
    {

        double app1[nA*nB];
        double app2[nB*nB];
        Matrix<double> SigmaAB(nA,nB,app1);
        Matrix<double> SigmaB(nB,nB,app2);

        //Rprintf(" %p %p\n", SigmaAB , SigmaB );
        //Matrix<double> *SigmaApp = new Matrix<double>(nA,nB,1);


        //Vector <double> omegaBLmuB      = Vector<double>(nB,1);
        int IndexB_P [nB];
        Vector <int> IndexB             = Vector<int>(nB,IndexB_P);



        int iRowA =0;
        int iRowB =0;

        int iColA =0;
        int iColB =0;
        for(int i=0;i<nB+nA;i++)
        {
            if(IndexA[0].vec(iRowA)!=i)
            {
                IndexB.Pvec(iRowB)[0] = i;
                iRowB++;
            }else{
                iRowA++;
            }
        }


        iRowA = 0;
        iRowB = 0;
        for(int i=0;i<nA+nB;i++)
        {
            if(IndexA[0].vec(iRowA)==i)
            {
               // muA->Pvec(iRowA)[0]       = 0.0;
                // allora metto dentro A
                iColA = iRowA;
                for(int j=i;j<nA+nB;j++)
                {
                    if(IndexA[0].vec(iColA)==j)
                    {
                        F[0].Pmat(iRowA, iColA)[0] =  Sigma[0].mat(i,j);
                        iColA++;
                    }
                }
                iRowA++;
            }else{
                //omegaBLmuB.Pvec(iRowB)[0]    = omega->vec(i)-mu->vec(i);
                iColB = iRowB;
                for(int j=i;j<nA+nB;j++)
                {
                    if(IndexB.vec(iColB)==j)
                    {
                        SigmaB.Pmat(iRowB, iColB)[0] =  Sigma[0].mat(i,j);
                        iColB++;
                    }
                }
                iRowB++;
            }
        }


        int iRowAB = 0;
        int iColAB = 0;
        for(int i=0;i<nA+nB;i++)
        {
            if(IndexA[0].vec(iRowAB)==i)
            {
                iColAB = 0;
                for(int j=0;j<nA+nB;j++)
                {
                    if(IndexB.vec(iColAB)==j)
                    {
                        if(i<j)
                        {
                            SigmaAB.Pmat(iRowAB, iColAB)[0] =  Sigma[0].mat(i,j);
                        }else{
                            SigmaAB.Pmat(iRowAB, iColAB)[0] = Sigma[0].mat(j,i);
                        }
                        iColAB++;

                    }
                }
                iRowAB++;
            }
        }



        /**** INVERT MATRICES ******/
        int info;
        double Done = 1.0;
        double DLone = -1.0;
        double Dzero = 0.0;

        F77_NAME(dpotrf)("L",&nB, SigmaB.P, &nB, &info);
        if(info != 0)
        {
            //SigmaB.Print("Sigma");
            
            error("Cpp error Cholesky failed - function: external_computeConditioanlMeanAndVariance1\n");
        }
        F77_NAME(dpotri)("L",&nB, SigmaB.P, &nB, &info);
        if(info != 0)
        {
            error("Cpp error Cholesky inverse - function: external_computeConditioanlMeanAndVariance1\n");
        }

        //
        F77_NAME(dsymm)("L", "L", &nB, &nA, &Done, SigmaB.P, &nB, SigmaAB.P, &nB, &Dzero, B->P, &nB);
        F77_NAME(dgemm)("T", "N", &nA, &nA, &nB, &DLone, B->P,  &nB, SigmaAB.P, &nB, &Done, F->P, &nA);
        //F77_NAME(dgemv)("T",  &nB, &nA, &Done, SigmaApp->P,  &nB, omegaBLmuB.P, &Ione, &Done, muA->P, &Ione);

//
//
//        SigmaAB.Destroy();
//        SigmaB.Destroy();
//        IndexB.Destroy();
    }else{
        for(int i=0;i<nA;i++)
        {
            for(int j=i;j<nA;j++)
            {
                F->Pmat(i,j)[0] = Sigma->mat(i,j);
            }
            //muA->Pvec(i)[0] = mu->vec(i);
        }
        for(int i=0;i<B->nRows;i++)
        {
            for(int j=0;j<B->nCols;j++)
            {
                B->Pmat(i,j)[0] = 0.0;
            }
            //muA->Pvec(i)[0] = mu->vec(i);
        }
    }


    //    muA->Print("muA");
    //    SigmaA->Print("SIGMAA");

}









vector<string>      Class_Categorial::get_NameHyperparams(int k)
{
    Rprintf("COntrollare che funzioni per Catgorial");
    string pi   = "pi_";
    vector <string> ret;
    string app;
    for(int j=0;j<k;j++)
    {
        app = pi+to_string(j);
        ret.push_back(app);
    }
    return(ret);
}






double  Class_TruncatedNormal::sample(double mu, double sd, double trunc, int left_trunc)
{
    // dal paper Simulation of truncated normal variables di robert
    // se left = 1 la distr è definita in [trunc,infty)

    double des;
    if(left_trunc!=1)
    {
        mu = -1.0*mu;
        trunc = -1.0*trunc;
    }

    if(mu>trunc)
    {
        double z;
        int i=0;

        do
        {
            i++;
            z =rnorm(mu, sd);
            if(i>100000){error("Troppe iterazioni troncata normale\n");}

        }while(z<trunc);

        if(left_trunc!=1)
        {
            des = -1.0*(z);
        }else{
            des = z;
        }

    }else{
        // Rprintf("AAAA");
        double z;
        int i=0;
        double trunc1 = (trunc-mu)/sd;
        double rho;
        double a = (trunc1+sqrt(pow(trunc1,2.0)+4))/2;
        do
        {
            i++;
            z = trunc1+rgamma(1,1/a);
            rho = exp(-pow(z-a,2.0)/2);
            //z =rnorm(mu, sigma);
            if(i>100000){Rprintf(" %f %f %f %f %f %f",z, mu, sd, trunc, trunc1, rho);error("Truncated normal sample");}

        }while(runif(0.0,1.0)>rho);

        if(left_trunc!=1)
        {
            des = -1.0*(z*sd+mu);
        }else{
            des = z*sd+mu;
        }

    }
    return(des);

}

double  Class_TruncatedNormal::ab_sample(double mu, double sd, double a, double b)
{
    double Stand1;
    double Stand1_cdf;
    double Stand2;
    double Stand2_cdf;
    double u;
    double x;
    double xi;
    double xi_cdf;
    
    Stand1 = ( a - mu ) / sd;
    Stand2 = ( b - mu ) / sd;
    
    Stand1_cdf = pnorm ( Stand1,0.0,1.0, 1,0);
    Stand2_cdf = pnorm ( Stand2,0.0,1.0, 1,0);
    u = runif(0.0,1.0);
    xi_cdf = Stand1_cdf + u * ( Stand2_cdf - Stand1_cdf );
    xi = qnorm( xi_cdf,0.0,1.0,1,0 );
    
    x = mu + sd * xi;
    
    return x;
}
