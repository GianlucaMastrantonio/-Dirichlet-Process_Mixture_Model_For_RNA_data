//
#ifndef ODE_H
#define ODE_H
#include "MatricesAndVectors.h"
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>
#include "DensityPriorParam.h"
#include <boost/numeric/odeint.hpp>
using namespace boost::numeric::odeint;


class Function_K_T2
{
private:
  
public:
  
  int typefunc;
  typedef double (Function_K_T2::*FuncK)(double t,double minV, double eta1, double eta2, double mean, double var);
  
  FuncK Function[10];
	double LimEta;
  
  Class_Parameter *MinK;
  Class_Parameter *VarK;
  Class_Parameter *MeanK;
  Class_Parameter *EtaK1;
  Class_Parameter *EtaK2;
  
  
  Function_K_T2(Class_Parameter *vark, Class_Parameter *mink, Class_Parameter *meank, Class_Parameter *eta1,Class_Parameter *eta2, int typef)
  {
    
    Function[0] = &Function_K_T2::DoubleNormal;
    Function[1] = &Function_K_T2::DoubleNormal_Rparam;
    typefunc = typef;
    
    MinK    = mink;
    VarK    = vark;
    MeanK   = meank;
    EtaK1   = eta1;
    EtaK2   = eta2;

  };
	Function_K_T2(Class_Parameter *vark, Class_Parameter *mink, Class_Parameter *meank, Class_Parameter *eta1,Class_Parameter *eta2, int typef, double etalim)
	{
	  
	  Function[0] = &Function_K_T2::DoubleNormal;
	  Function[1] = &Function_K_T2::DoubleNormal_Rparam;
	  Function[2] = &Function_K_T2::DoubleNormal_Spike;// typek=1
	  Function[3] = &Function_K_T2::DoubleNormal_NoLogistic_Spike;// typek=2
		
	  Function[4] = &Function_K_T2::DoubleNormal_DoubleSpike;// typek=3
	  Function[5] = &Function_K_T2::DoubleNormal_NoLogistic_DoubleSpike; // typek=4
	  typefunc = typef;
	  
		if(typefunc>5)
		{
			error("typefunc>5");
		}
	  MinK    = mink;
	  VarK    = vark;
	  MeanK   = meank;
	  EtaK1   = eta1;
	  EtaK2   = eta2;
		
		LimEta = etalim;

	};
  // DESTRUCTORS
  ~Function_K_T2(){};

	double DoubleNormal_NoLogistic_DoubleSpike(double t,double minV, double eta1, double eta2, double mean, double var)
	{
	  //REprintf("A %f %f %f %f %f %f\n",t, minV,  eta1,  eta2,  mean,  var);
	  //REprintf("SINGLE");
		//()
		
		
		
		if((eta1>(-1.0*LimEta) )&& (eta1<LimEta))
		{
			eta1 = 0.0;
		}else{
			if(eta1>=LimEta)
			{
				eta1 = eta1-LimEta;
			}else{
				eta1 = eta1+LimEta;
			}
		}
		if((eta2>(-1.0*LimEta) )&& (eta2<LimEta))
		{
			eta2 = 0.0;
		}else{
			if(eta2>=LimEta)
			{
				eta2 = eta2-LimEta;
			}else{
				eta2 = eta2+LimEta;
			}
		}
		
		double abseta1 = fabs(eta1);
		double abseta2 = fabs(eta2);
		if((eta1*eta2)>0)
		{
			if(abseta1>abseta2)
			{
				abseta1 = abseta1-LimEta;
				if(abseta1<abseta2)
				{
					abseta1 = abseta2;
				}
			}
			if(abseta2>abseta1)
			{
				abseta2 = abseta2-LimEta;
				if(abseta2<abseta1)
				{
					abseta2 = abseta1;
				}
			}
			if(eta1<0)
			{
				eta1 = -1.0*abseta1;
				eta2 = -1.0*abseta2;
			}else{
				eta1 = abseta1;
				eta2 = abseta2;
			}
		}
		
		
		
	  minV = fabs(minV);
	  mean = fabs(mean); 
	  var  = fabs(var);
	  double ret;
		double peak = minV*exp(eta1);
		 double c1   = peak-minV;
		  
		 double end = peak/exp(eta2);
		 double c2  = peak-end;
		if(t<mean)
		{
		  ret = minV+dnorm(t,mean,pow(var,0.5),0)*pow(2*M_PI*var,0.5)*c1;
		
		}else{
		  ret = end+dnorm(t,mean,pow(var,0.5),0)*pow(2*M_PI*var,0.5)*c2;
		}
		
	  return(ret);
	}
		
	
	
	double DoubleNormal_DoubleSpike(double t,double minV, double eta1, double eta2, double mean, double var)
	{
	  //REprintf("A %f %f %f %f %f %f\n",t, minV,  eta1,  eta2,  mean,  var);
	  //REprintf("SINGLE");
		//()
		if((eta1>(-1.0*LimEta) )&& (eta1<LimEta))
		{
			eta1 = 0.0;
		}else{
			if(eta1>=LimEta)
			{
				eta1 = eta1-LimEta;
			}else{
				eta1 = eta1+LimEta;
			}
		}
		if((eta2>(-1.0*LimEta) )&& (eta2<LimEta))
		{
			eta2 = 0.0;
		}else{
			if(eta2>=LimEta)
			{
				eta2 = eta2-LimEta;
			}else{
				eta2 = eta2+LimEta;
			}
		}
		
		
		double abseta1 = fabs(eta1);
		double abseta2 = fabs(eta2);
		if((eta1*eta2)>0)
		{
			if(abseta1>abseta2)
			{
				abseta1 = abseta1-LimEta;
				if(abseta1<abseta2)
				{
					abseta1 = abseta2;
				}
			}
			if(abseta2>abseta1)
			{
				abseta2 = abseta2-LimEta;
				if(abseta2<abseta1)
				{
					abseta2 = abseta1;
				}
			}
			if(eta1<0)
			{
				eta1 = -1.0*abseta1;
				eta2 = -1.0*abseta2;
			}else{
				eta1 = abseta1;
				eta2 = abseta2;
			}
		}
		
		
		
	  minV = fabs(minV);
	  mean = fabs(mean); 
	  var  = fabs(var);
	  double ret;
//	  double peak = minV*exp(eta1);
//	  double c1   = peak-minV;
//		
//	  double end = peak/exp(eta2);
//	  double c2  = peak-end;
//	  
	  if((eta1*eta2)>=0)
	  {
		  double peak = minV*exp(eta1);
		  double c1   = peak-minV;
			
		  double end = peak/exp(eta2);
		  double c2  = peak-end;
		 if(t<mean)
		 {
			ret = minV+dnorm(t,mean,pow(var,0.5),0)*pow(2*M_PI*var,0.5)*c1;
		 
		 }else{
			ret = end+dnorm(t,mean,pow(var,0.5),0)*pow(2*M_PI*var,0.5)*c2;
		 }
	  }else{
//		 double c = fabs(c2/c1);
//		 double z = c/(1+c);
//		 double k = 4*0.5*sqrt(-2*log(0.5))/pow(var,0.5);
//		 double s = 1/k;
//		 double add =  sqrt(-2*var*log(0.5));
//		 ret = minV+(end-minV)/(1+exp(-(t-mean+add-2*add*z)/s  ));
//		  
		  double signR1 = 1.0;
		  if(eta1<0)
		  {
			  signR1 = -1.0;
		  }
		  double ratiotot = fabs(eta1) +fabs(eta2);
		  double k        = 4*0.5*sqrt(-2.0*log(0.5))/pow(var,0.5);
		  double end      = minV*exp(  signR1*ratiotot );
		  double s        = 1/k;
		  double logf     = minV+(end-minV)/(1+exp(-(t-mean)/s  ));
		  double w;
		  double dn;
		  double peak;
		  if(abs(eta1)<abs(eta2))
		  {
			  w    = 1.0-2.0*fabs(eta1)/ratiotot;
			  peak = minV*exp(0.0);
			  end  = peak/exp(-ratiotot*signR1);
		  }else{
			  w    = 1.0-2.0*fabs(eta2)/ratiotot;
			  peak = minV*exp(ratiotot*signR1);
			  end  = peak/exp(0.0);
			}
		  
		  double c1  = peak-minV;
		  double c2  = peak-end;
		  
		  if(t<mean)
		  {
			 dn = minV+dnorm(t,mean,pow(var,0.5),0)*pow(2*M_PI*var,0.5)*c1;
		  
		  }else{
			 dn = end+dnorm(t,mean,pow(var,0.5),0)*pow(2*M_PI*var,0.5)*c2;
		  }
		  ret = w*dn+(1-w)*logf;

		  
	  }
	  return(ret);
	}
	
	double DoubleNormal_NoLogistic_Spike(double t,double minV, double eta1, double eta2, double mean, double var)
	{
	  //REprintf("A %f %f %f %f %f %f\n",t, minV,  eta1,  eta2,  mean,  var);
	  //REprintf("SINGLE");
		//()
		if((eta1>(-1.0*LimEta) )&& (eta1<LimEta))
		{
			eta1 = 0.0;
		}else{
			if(eta1>=LimEta)
			{
				eta1 = eta1-LimEta;
			}else{
				eta1 = eta1+LimEta;
			}
		}
		if((eta2>(-1.0*LimEta) )&& (eta2<LimEta))
		{
			eta2 = 0.0;
		}else{
			if(eta2>=LimEta)
			{
				eta2 = eta2-LimEta;
			}else{
				eta2 = eta2+LimEta;
			}
		}
		
	  minV = fabs(minV);
	  mean = fabs(mean); 
	  var  = fabs(var);
	  double ret;
		double peak = minV*exp(eta1);
		 double c1   = peak-minV;
		  
		 double end = peak/exp(eta2);
		 double c2  = peak-end;
		if(t<mean)
		{
		  ret = minV+dnorm(t,mean,pow(var,0.5),0)*pow(2*M_PI*var,0.5)*c1;
		
		}else{
		  ret = end+dnorm(t,mean,pow(var,0.5),0)*pow(2*M_PI*var,0.5)*c2;
		}
		
	  return(ret);
	}
		
	
	
	double DoubleNormal_Spike(double t,double minV, double eta1, double eta2, double mean, double var)
	{
	  //REprintf("A %f %f %f %f %f %f\n",t, minV,  eta1,  eta2,  mean,  var);
	  //REprintf("SINGLE");
		//()
		if((eta1>(-1.0*LimEta) )&& (eta1<LimEta))
		{
			eta1 = 0.0;
		}else{
			if(eta1>=LimEta)
			{
				eta1 = eta1-LimEta;
			}else{
				eta1 = eta1+LimEta;
			}
		}
		if((eta2>(-1.0*LimEta) )&& (eta2<LimEta))
		{
			eta2 = 0.0;
		}else{
			if(eta2>=LimEta)
			{
				eta2 = eta2-LimEta;
			}else{
				eta2 = eta2+LimEta;
			}
		}
		
	  minV = fabs(minV);
	  mean = fabs(mean); 
	  var  = fabs(var);
	  double ret;
//	  double peak = minV*exp(eta1);
//	  double c1   = peak-minV;
//		
//	  double end = peak/exp(eta2);
//	  double c2  = peak-end;
//	  
	  if((eta1*eta2)>=0)
	  {
		  double peak = minV*exp(eta1);
		  double c1   = peak-minV;
			
		  double end = peak/exp(eta2);
		  double c2  = peak-end;
		 if(t<mean)
		 {
			ret = minV+dnorm(t,mean,pow(var,0.5),0)*pow(2*M_PI*var,0.5)*c1;
		 
		 }else{
			ret = end+dnorm(t,mean,pow(var,0.5),0)*pow(2*M_PI*var,0.5)*c2;
		 }
	  }else{
//		 double c = fabs(c2/c1);
//		 double z = c/(1+c);
//		 double k = 4*0.5*sqrt(-2*log(0.5))/pow(var,0.5);
//		 double s = 1/k;
//		 double add =  sqrt(-2*var*log(0.5));
//		 ret = minV+(end-minV)/(1+exp(-(t-mean+add-2*add*z)/s  ));
//		  
		  double signR1 = 1.0;
		  if(eta1<0)
		  {
			  signR1 = -1.0;
		  }
		  double ratiotot = fabs(eta1) +fabs(eta2);
		  double k        = 4*0.5*sqrt(-2.0*log(0.5))/pow(var,0.5);
		  double end      = minV*exp(  signR1*ratiotot );
		  double s        = 1/k;
		  double logf     = minV+(end-minV)/(1+exp(-(t-mean)/s  ));
		  double w;
		  double dn;
		  double peak;
		  if(abs(eta1)<abs(eta2))
		  {
			  w    = 1.0-2.0*fabs(eta1)/ratiotot;
			  peak = minV*exp(0.0);
			  end  = peak/exp(-ratiotot*signR1);
		  }else{
			  w    = 1.0-2.0*fabs(eta2)/ratiotot;
			  peak = minV*exp(ratiotot*signR1);
			  end  = peak/exp(0.0);
			}
		  
		  double c1  = peak-minV;
		  double c2  = peak-end;
		  
		  if(t<mean)
		  {
			 dn = minV+dnorm(t,mean,pow(var,0.5),0)*pow(2*M_PI*var,0.5)*c1;
		  
		  }else{
			 dn = end+dnorm(t,mean,pow(var,0.5),0)*pow(2*M_PI*var,0.5)*c2;
		  }
		  ret = w*dn+(1-w)*logf;

		  
	  }
	  return(ret);
	}
	
  double DoubleNormal(double t,double minV, double eta1, double eta2, double mean, double var)
  {
    //REprintf("A %f %f %f %f %f %f\n",t, minV,  eta1,  eta2,  mean,  var);
    //REprintf("SINGLE");
    minV = fabs(minV);
	 mean = fabs(mean); 
	 var  = fabs(var);
    double ret;
    double peak = minV*exp(eta1);
    double c1   = peak-minV;
     
    double end = peak/exp(eta2);
    double c2  = peak-end;
    
    if((eta1*eta2)>=0)
    {
      if(t<mean)
      {
        ret = minV+dnorm(t,mean,pow(var,0.5),0)*pow(2*M_PI*var,0.5)*c1;
      
      }else{
        ret = end+dnorm(t,mean,pow(var,0.5),0)*pow(2*M_PI*var,0.5)*c2;
      }
    }else{
      double c = fabs(c2/c1);
      double z = c/(1+c);
      double k = 4*0.5*sqrt(-2*log(0.5))/pow(var,0.5);
      double s = 1/k;
      double add =  sqrt(-2*var*log(0.5));
      ret = minV+(end-minV)/(1+exp(-(t-mean+add-2*add*z)/s  ));
    }
    return(ret);
  }
  
  double DoubleNormal_Rparam(double t,double minV, double eta1, double eta2, double mean, double var)
  {
    error("DoubleNormal_Rparam");
    //REprintf("DOUBLE");
    double ret;
    double peak = exp(minV)*exp(eta1);
    double c1   = peak-exp(minV);
     
    double end = peak/exp(eta2);
    double c2  = peak-end;
     
    if(t<exp(mean))
    {
      ret = exp(minV)+dnorm(t,exp(mean),pow(exp(var),0.5),0)*pow(2*M_PI*exp(var),0.5)*c1;
    
    }else{
      ret = end+dnorm(t,exp(mean),pow(exp(var),0.5),0)*pow(2*M_PI*exp(var),0.5)*c2;
    }
    return(ret);
  }
  
  double compute_Func(double t, int choiceFunc)
  {
    double ret = (this->*Function[choiceFunc])(t, MinK->ParameterAcc, EtaK1->ParameterAcc, EtaK2->ParameterAcc, MeanK->ParameterAcc, VarK->ParameterAcc);
    return(ret);
  }
  double compute_Func_Prop(double t, int choiceFunc)
  {
    double ret = (this->*Function[choiceFunc])(t, MinK->ParameterProp, EtaK1->ParameterProp, EtaK2->ParameterProp, MeanK->ParameterProp, VarK->ParameterProp);
    return(ret);
  }
  double compute_Func(double t)
  {
    return(compute_Func(t, typefunc));
  }
  double compute_Func_Prop(double t)
  {
    return(compute_Func_Prop(t, typefunc));
  }
  
  
//  
//
//  
//  double compute_Func_SelFuncProp(double t)
//  {
//    return(compute_Func(t, SelFuncProp));
//  }

  
  
//  
//  
//  
//  void PrintObject()
//  {
//    REprintf("MinV=%f MaxV=%f xo=%f lambda=%f\n",MinK->ParameterAcc, EtaK1->ParameterAcc, EtaK2->ParameterAcc, MeanK->ParameterAcc, VarK->ParameterAcc);
//  }
};





class ODE_FURLAN_T2
{
  private:
  
  public:
  typedef std::vector< double > state_type;
  //typedef runge_kutta_cash_karp54< state_type > error_stepper_type_karp54;
  typedef runge_kutta_dopri5< state_type > error_stepper_type;
  typedef controlled_runge_kutta< error_stepper_type > controlled_stepper_type;

  
  double abs_err;
  double rel_err;
  double a_x;
  double a_dxdt;
  
  
  int ntime;
  int nvariables;
  double tmin;
  double tmax;
  double deltat;
  int nstep;
  int nlatentk;
  double ndelta;
  double SepObsTime;
  Matrix <double> ODEMAT;
  Matrix <double> ODEMATProp;
  
	Vector<double> TimeObs;
	Vector<int> IndexObs;
	
  vector<Function_K_T2> *FuncsParams;
  vector<Class_Parameter> *StartingValues;
  
  ODE_FURLAN_T2(int nt, int nvar,vector<Function_K_T2> *FP, double tmn, double tmx, double dtt, int Nstep,vector<Class_Parameter> *StartV, double abs_e, double rel_e){
    
    StartingValues = StartV;
    ntime = nt;
    nvariables = nvar;
    
    ODEMAT = Matrix<double>(ntime,nvariables,1);
    ODEMAT.Init(0.0);
    ODEMATProp = Matrix<double>(ntime,nvariables,1);
    ODEMATProp.Init(0.0);
    
    
    
    FuncsParams = FP;
    
    tmin = tmn;
    tmax = tmx;
    deltat = dtt;
    nstep = Nstep;
    
    nlatentk = 3;
    ndelta = 3.0;
    
    SepObsTime = deltat*nstep;
    
    abs_err = abs_e;//10
    rel_err = rel_e;//6
    a_x = 1.0;
    a_dxdt = 1.0;
	  
	  
	  TimeObs = Vector<double>(11,1);
	  IndexObs  = Vector<int> (11,1);
	  
	  TimeObs.Pvec(0)[0] = 0.0;
	  TimeObs.Pvec(1)[0] = 0.5/3.0;
	  TimeObs.Pvec(2)[0] = 1.0/3.0;
	  TimeObs.Pvec(3)[0] = 0.5;
	  TimeObs.Pvec(4)[0] = 1.0;
	  TimeObs.Pvec(5)[0] = 1.5;
	  TimeObs.Pvec(6)[0] = 2.0;
	  TimeObs.Pvec(7)[0] = 4.0;
	  TimeObs.Pvec(8)[0] = 8.0;
	  TimeObs.Pvec(9)[0] = 12.0;
	  TimeObs.Pvec(10)[0] = 16.0;
	  
//	  IndexObs.Pvec(0)[0] = 0;
//	  IndexObs.Pvec(1)[0] = 1;
//	  IndexObs.Pvec(2)[0] = 2;
//	  IndexObs.Pvec(3)[0] = 3;
//	  IndexObs.Pvec(4)[0] = 6;
//	  IndexObs.Pvec(5)[0] = 9;
//	  IndexObs.Pvec(6)[0] = 12;
//	  IndexObs.Pvec(7)[0] = 24;
//	  IndexObs.Pvec(8)[0] = 48;
//	  IndexObs.Pvec(9)[0] = 72;
//	  IndexObs.Pvec(10)[0] = 96;
	  
	  IndexObs.Pvec(0)[0] = 0;
	  IndexObs.Pvec(1)[0] = 1;
	  IndexObs.Pvec(2)[0] = 2;
	  IndexObs.Pvec(3)[0] = 3;
	  IndexObs.Pvec(4)[0] = 4;
	  IndexObs.Pvec(5)[0] = 5;
	  IndexObs.Pvec(6)[0] = 6;
	  IndexObs.Pvec(7)[0] = 7;
	  IndexObs.Pvec(8)[0] = 8;
	  IndexObs.Pvec(9)[0] = 9;
	  IndexObs.Pvec(10)[0] = 10;
	  

    
  };
  
  ODE_FURLAN_T2(int nt, int nvar,vector<Function_K_T2> *FP, double tmn, double tmx, double dtt, int Nstep,  vector<Class_Parameter> *StartV,ODE_FURLAN_T2 *odetocopymatrix, double abs_e, double rel_e){
     
    StartingValues = StartV;
     ntime = nt;
     nvariables = nvar;
     
     ODEMAT = Matrix<double>(ntime,nvariables,odetocopymatrix->ODEMAT.P);
     ODEMAT.Init(0.0);
     ODEMATProp = Matrix<double>(ntime,nvariables,odetocopymatrix->ODEMATProp.P);
     ODEMATProp.Init(0.0);
     
     FuncsParams = FP;
     
     tmin = tmn;
     tmax = tmx;
     deltat = dtt;
     nstep = Nstep;
     
     nlatentk = 3;
    ndelta = 3.0;
    SepObsTime = deltat*nstep;
    
     abs_err = abs_e;//10
     rel_err = rel_e;//6
     a_x = 1.0;
     a_dxdt = 1.0;
    
	  TimeObs = Vector<double>(11,1);
	  IndexObs  = Vector<int> (11,1);
	  
	  TimeObs.Pvec(0)[0] = 0.0;
	  TimeObs.Pvec(1)[0] = 0.5/3.0;
	  TimeObs.Pvec(2)[0] = 1.0/3.0;
	  TimeObs.Pvec(3)[0] = 0.5;
	  TimeObs.Pvec(4)[0] = 1.0;
	  TimeObs.Pvec(5)[0] = 1.5;
	  TimeObs.Pvec(6)[0] = 2.0;
	  TimeObs.Pvec(7)[0] = 4.0;
	  TimeObs.Pvec(8)[0] = 8.0;
	  TimeObs.Pvec(9)[0] = 12.0;
	  TimeObs.Pvec(10)[0] = 16.0;
	  
	  IndexObs.Pvec(0)[0] = 0;
	  IndexObs.Pvec(1)[0] = 1;
	  IndexObs.Pvec(2)[0] = 2;
	  IndexObs.Pvec(3)[0] = 3;
	  IndexObs.Pvec(4)[0] = 6;
	  IndexObs.Pvec(5)[0] = 9;
	  IndexObs.Pvec(6)[0] = 12;
	  IndexObs.Pvec(7)[0] = 24;
	  IndexObs.Pvec(8)[0] = 48;
	  IndexObs.Pvec(9)[0] = 72;
	  IndexObs.Pvec(10)[0] = 96;
   };
  


  // DESTRUCTORS
  ~ODE_FURLAN_T2(){};

  
////  void sub_pointer_ODEMAT(double *p)
////  {
////    ODEMAT.P = p;
////  }
  struct ODE_formula_V2
  {

    vector<Function_K_T2> *FuncP;

    ODE_formula_V2( vector<Function_K_T2> * FP  )
      : FuncP( FP ) { }

    void operator()( const state_type &x , state_type &dxdt , double t ) const
    {
      double kk1 = FuncP[0][0].compute_Func(t);
      double kk2 = FuncP[0][1].compute_Func(t);
      double kk3 = FuncP[0][2].compute_Func(t);
      
      dxdt[0] = kk1-kk2*x[0];
      dxdt[1] = kk2*x[0]-kk3*x[1];
        
    }
  };
  struct ODE_formula_V2_Prop
  {

    vector<Function_K_T2> *FuncP;

    ODE_formula_V2_Prop( vector<Function_K_T2> * FP  )
      : FuncP( FP ) { }

    void operator()( const state_type &x , state_type &dxdt , double t ) const
    {
      double kk1 = FuncP[0][0].compute_Func_Prop(t);
      double kk2 = FuncP[0][1].compute_Func_Prop(t);
      double kk3 = FuncP[0][2].compute_Func_Prop(t);
      
      dxdt[0] = kk1-kk2*x[0];
      dxdt[1] = kk2*x[0]-kk3*x[1];
        
    }
  };
  struct ODE_formula
  {
    double k1;
    double k2;
    double k3;

      ODE_formula( double kappa1 , double kappa2,double kappa3 )
      : k1( kappa1 ) , k2( kappa2 ) ,k3( kappa3 )  { }

    void operator()( const state_type &x , state_type &dxdt , double t ) const
    {
        dxdt[0] = k1-k2*x[0];
        dxdt[1] = k2*x[0]-k3*x[1];
        
    }
  };
  void copyFromODEMATPropToAcc()
  {
    for(int i=0;i<ODEMAT.nRows;i++)
    {
      for(int j=0;j<ODEMAT.nCols;j++)
      {
        ODEMAT.Pmat(i,j)[0] = ODEMATProp.mat(i,j); 
      }
    }
  }
  void ODE_compute_V2()
  {

    controlled_stepper_type controlled_stepper(
    default_error_checker< double , range_algebra , default_operations >( abs_err , rel_err , a_x , a_dxdt ) );
    
    double delta_v = deltat;
    //runge_kutta_dopri5< state_type > stepper;
    
    state_type x;    
    for(int i=0;i<nvariables;i++)
    {
      ODEMAT.Pmat(0,i)[0] = StartingValues[0][i].ParameterAcc;
      x.push_back(ODEMAT.mat(0,i));
    }

    double t        = tmin;
    double kk1         = FuncsParams[0][0].compute_Func(t);
    
    double ConstI =  ODEMAT.mat(0,nvariables-1)/kk1;
    for(int t1=0;t1<ntime-1;t1++)
    {
      //integrate( ODE_formula_V2(FuncsParams) ,x,t ,  t+SepObsTime, delta_v);
      integrate_adaptive(controlled_stepper,ODE_formula_V2(FuncsParams) ,x,t ,  t+SepObsTime, delta_v);
      t += SepObsTime;
      for(int i=0;i<nvariables-1;i++)
      {
			//REprintf("ZERO");
        if(x[i]>0.0)
        {
          ODEMAT.Pmat(t1+1,i)[0] = x[i];
        }else{
          ODEMAT.Pmat(t1+1,i)[0] = 0.0;
          x[i] = 0.0;
        }
        
      }
      int i = nvariables-1;
      ODEMAT.Pmat(t1+1,i)[0] = ConstI*FuncsParams[0][0].compute_Func(t);
    }    
  }

  int  ODE_compute_V2_Prop()
  {
    controlled_stepper_type controlled_stepper(
    default_error_checker< double , range_algebra , default_operations >( abs_err , rel_err , a_x , a_dxdt ) );
    
    
    double delta_v = deltat;
    //runge_kutta_dopri5< state_type > stepper;
    int TT = 0;
    int OUT = 0;
    state_type x;    
    for(int i=0;i<nvariables;i++)
    {
      ODEMATProp.Pmat(0,i)[0] = StartingValues[0][i].ParameterProp;
      x.push_back(ODEMATProp.mat(0,i));
    }

    double t        = tmin;
    double kk1         = FuncsParams[0][0].compute_Func_Prop(t);
    
    double ConstI   = ODEMATProp.mat(0,nvariables-1)/kk1;
    for(int t1=0;t1<ntime-1;t1++)
    {
      //REprintf("%f \n", t);
      //integrate_n_steps(stepper,ODE_formula_V2_Prop(FuncsParams),x,t,deltat,nstep );
      //integrate( ODE_formula_V2_Prop(FuncsParams) ,x,t ,  t+SepObsTime, delta_v );
      TT += integrate_adaptive(controlled_stepper,ODE_formula_V2_Prop(FuncsParams) ,x,t ,  t+SepObsTime, delta_v);
      
      t += SepObsTime;
      if((!isfinite(x[0]))|(!isfinite(x[1]))|(!isfinite(x[2])))
      {
        OUT = 2;
      }
      for(int i=0;i<nvariables-1;i++)
      {
        if(x[i]>0.0)
        {
          ODEMATProp.Pmat(t1+1,i)[0] = x[i];
        }else{
          ODEMATProp.Pmat(t1+1,i)[0] = 0.0;
          x[i] = 0.0;
        }
      }
      //REprintf("%i\n",TT);
      //REprintf("%f %f\n",t, t+deltat*nstep);
      int i = nvariables-1;
      ODEMATProp.Pmat(t1+1,i)[0] = ConstI*FuncsParams[0][0].compute_Func_Prop(t);
    } 
    if(OUT==2)
    {
     REprintf("Indefinito");
    }
    //REprintf("%i\n",TT);
    return(OUT);
  }
	struct ODE_formula_V3
	{

	  vector<Function_K_T2> *FuncP;

	  ODE_formula_V3( vector<Function_K_T2> * FP  )
		 : FuncP( FP ) { }

	  void operator()( const state_type &x , state_type &dxdt , double t ) const
	  {
		 double kk1 = FuncP[0][0].compute_Func(t);
		 double kk2 = FuncP[0][1].compute_Func(t);
		 double kk3 = FuncP[0][2].compute_Func(t);
		 
		 dxdt[0] = kk1-kk2*x[0];
		 dxdt[1] = kk2*x[0]-kk3*x[1];
			
	  }
	};
	struct ODE_formula_V3_Prop
	{

	  vector<Function_K_T2> *FuncP;

	  ODE_formula_V3_Prop( vector<Function_K_T2> * FP  )
		 : FuncP( FP ) { }

	  void operator()( const state_type &x , state_type &dxdt , double t ) const
	  {
		 double kk1 = FuncP[0][0].compute_Func_Prop(t);
		 double kk2 = FuncP[0][1].compute_Func_Prop(t);
		 double kk3 = FuncP[0][2].compute_Func_Prop(t);
		 
		 dxdt[0] = kk1-kk2*x[0];
		 dxdt[1] = kk2*x[0]-kk3*x[1];
			
	  }
	};
	void ODE_compute_V3()
	{
		typedef runge_kutta_dopri5< state_type > stepper_type;
		boost::numeric::odeint::result_of::make_dense_output< stepper_type >::type stepper =  make_dense_output( abs_err , rel_err ,   stepper_type() );
		
		state_type xObs;
		state_type x;  
		for(int i=0;i<nvariables;i++)
		{
		  ODEMAT.Pmat(0,i)[0] = StartingValues[0][i].ParameterAcc;
		  x.push_back(ODEMAT.mat(0,i));
		  xObs.push_back(0.0);
		}

		//TimeObs = Vector<double>(11,1);
		//IndexObs  = Vector<int> (11,1);

	   double t        = TimeObs.vec(0);
	   double kk1      = FuncsParams[0][0].compute_Func(t);
		
		ODEMAT.Pmat(0,nvariables-1)[0] = kk1*5.0;
	   double ConstI =  ODEMAT.mat(0,nvariables-1)/kk1;
		
		int IsGreaterMax = 0;
		for(int t1=0;t1<TimeObs.nElem-1;t1++)
		{
			if(IsGreaterMax==0)
			{
				double tmax = TimeObs.vec(t1+1);
				//size_t imax = (int)round(nstep*( TimeObs.vec(t1+1)-TimeObs.vec(t1) )/( TimeObs.vec(1)-TimeObs.vec(0) ));
				size_t imax = 100000;
				size_t i = 0;
				stepper.initialize( x , TimeObs.vec(t1) ,TimeObs.vec(t1+1)-TimeObs.vec(t1) );
				while ( ( stepper.current_time() < tmax ) && ( i < imax ) )
				{
					 //observer( stepper.current_state() , stepper.current_time() );
					 stepper.do_step( ODE_formula_V3(FuncsParams));
					 ++i;
				}
				//REprintf("%i %i \n",i,imax );
				if(i >= imax)
				{
					IsGreaterMax = 1;
				}else{
					stepper.calc_state( tmax , xObs );
					for(int i=0;i<nvariables-1;i++)
					{
						//REprintf("ZERO");
					  if(xObs[i]>0.0)
					  {
						 ODEMAT.Pmat(IndexObs.vec(t1+1),i)[0] = xObs[i];
						  x[i] = xObs[i];
					  }else{
						 ODEMAT.Pmat(IndexObs.vec(t1+1),i)[0] = 0.0;
						 x[i] = 0.0;
					  }
					}
					int i = nvariables-1;
					ODEMAT.Pmat(IndexObs.vec(t1+1),i)[0] = ConstI*FuncsParams[0][0].compute_Func(tmax);
				}
			}
		}
		if(IsGreaterMax!=0)
		{
			//error("Inizializzazione Ode non riuscita");
		}
	}

	int  ODE_compute_V3_Prop()
	{
	  
		//max_step_checker checker(10);
		typedef runge_kutta_dopri5< state_type > stepper_type;
		boost::numeric::odeint::result_of::make_dense_output< stepper_type >::type stepper =  make_dense_output( abs_err , rel_err ,stepper_type() );
		
		state_type xObs;
		state_type x;  
		for(int i=0;i<nvariables;i++)
		{
		  ODEMATProp.Pmat(0,i)[0] = StartingValues[0][i].ParameterProp;
		  x.push_back(ODEMATProp.mat(0,i));
		  xObs.push_back(0.0);
		}


	   double t        = TimeObs.vec(0);
	   double kk1      = FuncsParams[0][0].compute_Func_Prop(t);
		
		ODEMATProp.Pmat(0,nvariables-1)[0] = kk1*5.0;
	   double ConstI   = ODEMATProp.mat(0,nvariables-1)/kk1;
		
		int IsGreaterMax = 0;
		for(int t1=0;t1<TimeObs.nElem-1;t1++)
		{
			if(IsGreaterMax==0)
			{
				double tmax = TimeObs.vec(t1+1);
				//size_t imax = (int)round(nstep*( TimeObs.vec(t1+1)-TimeObs.vec(t1) )/( TimeObs.vec(1)-TimeObs.vec(0) ));
				size_t imax = nstep;
				size_t i = 0;
				stepper.initialize( x , TimeObs.vec(t1) ,TimeObs.vec(t1+1)-TimeObs.vec(t1) );
				while ( ( stepper.current_time() < tmax ) && ( i < imax ) )
				{
					 //observer( stepper.current_state() , stepper.current_time() );
					 stepper.do_step( ODE_formula_V3_Prop(FuncsParams)  );
					 ++i;
				}
				//REprintf("%i %i \n",i,imax );
				if(i >= imax)
				{
					IsGreaterMax = 1;
				}else{
					stepper.calc_state( tmax , xObs );
					for(int i=0;i<nvariables-1;i++)
					{
						//REprintf("ZERO");
					  if(xObs[i]>0.0)
					  {
						 ODEMATProp.Pmat(IndexObs.vec(t1+1),i)[0] = xObs[i];
						  x[i] = xObs[i];
					  }else{
						 ODEMATProp.Pmat(IndexObs.vec(t1+1),i)[0] = 0.0;
						 x[i] = 0.0;
					  }
					}
					if((!isfinite(x[0]))|(!isfinite(x[1]))|(!isfinite(x[2])))
					{
					  IsGreaterMax = 2;
					}
					int i = nvariables-1;
					ODEMATProp.Pmat(IndexObs.vec(t1+1),i)[0] = ConstI*FuncsParams[0][0].compute_Func_Prop(tmax);
				}
			}
		} 
		return(IsGreaterMax);
//		
//		
//	  for(int t1=0;t1<ntime-1;t1++)
//	  {
//		 //REprintf("%f \n", t);
//		 //integrate_n_steps(stepper,ODE_formula_V2_Prop(FuncsParams),x,t,deltat,nstep );
//		 //integrate( ODE_formula_V2_Prop(FuncsParams) ,x,t ,  t+SepObsTime, delta_v );
//		 TT += integrate_adaptive(controlled_stepper,ODE_formula_V2_Prop(FuncsParams) ,x,t ,  t+SepObsTime, delta_v);
//		 
//		 t += SepObsTime;
//		 if((!isfinite(x[0]))|(!isfinite(x[1]))|(!isfinite(x[2])))
//		 {
//			OUT = 2;
//		 }
//		 for(int i=0;i<nvariables-1;i++)
//		 {
//			if(x[i]>0.0)
//			{
//			  ODEMATProp.Pmat(t1+1,i)[0] = x[i];
//			}else{
//			  ODEMATProp.Pmat(t1+1,i)[0] = 0.0;
//			  x[i] = 0.0;
//			}
//		 }
//		 //REprintf("%i\n",TT);
//		 //REprintf("%f %f\n",t, t+deltat*nstep);
//		 int i = nvariables-1;
//		 ODEMATProp.Pmat(t1+1,i)[0] = ConstI*FuncsParams[0][0].compute_Func_Prop(t);
//	  } 
//	  if(OUT==2)
//	  {
//		REprintf("Indefinito");
//	  }
//	  //REprintf("%i\n",TT);
	  
	}
  void ODE_compute()
  {
    state_type x;
    runge_kutta_dopri5< state_type > stepper;
    
    for(int i=0;i<nvariables;i++)
    {
      ODEMAT.Pmat(0,i)[0] = StartingValues[0][i].ParameterAcc;
      x.push_back(ODEMAT.mat(0,i));
    }

    double t = tmin;
    double tPdelta = t;
    double kk1, kk2,kk3;
    kk1 = FuncsParams[0][0].compute_Func(t);
    double ConstI =  ODEMAT.mat(0,nvariables-1)/kk1;
    for(int t1=0;t1<ntime-1;t1++)
    {
      for(int t2=0;t2<nstep;t2++)
      {
        int k;
        k = 0;
        kk1 = FuncsParams[0][k].compute_Func(t);
        k = 1;
        kk2 = FuncsParams[0][k].compute_Func(t);
        k = 2;
        kk3 = FuncsParams[0][k].compute_Func(t);
        
        tPdelta += deltat;
        //integrate( ODE_formula(kk1,kk2,kk3) ,x,t ,  tPdelta , deltat/ndelta ); 
        stepper.do_step(ODE_formula(kk1,kk2,kk3),x,t,deltat);
        t = tPdelta;
        
        
        
        //REprintf("%f %f %f %i %i %f %i %f\n",kk1,kk2,kk3,t1 ,t2,t,nstep, deltat);
      }
      
      for(int i=0;i<nvariables-1;i++)
      {
        if(x[i]>0.0)
        {
          ODEMAT.Pmat(t1+1,i)[0] = x[i];
        }else{
          ODEMAT.Pmat(t1+1,i)[0] = 0.0;
          x[i] = 0.0;
        }
      }
//      for(int i=0;i<nvariables-1;i++)
//      {
//        ODEMAT.Pmat(t1+1,i)[0] = x[i];
//      }
      int i = nvariables-1;
      ODEMAT.Pmat(t1+1,i)[0] = ConstI*FuncsParams[0][0].compute_Func(t);
      
    }
    //ODEMAT.Print("Odema");
    //error("");
    
  }

  int  ODE_compute_Prop()
  {
    int OUT = 0;
    state_type x;
    //runge_kutta4< state_type > stepper;
    runge_kutta_dopri5< state_type > stepper;
    
    for(int i=0;i<nvariables;i++)
    {
      ODEMATProp.Pmat(0,i)[0] = StartingValues[0][i].ParameterProp;
      x.push_back(ODEMATProp.mat(0,i));
    }

    double t = tmin;
    double tPdelta = t;
    double kk1, kk2,kk3;
    kk1 = FuncsParams[0][0].compute_Func_Prop(t);
    double ConstI =  ODEMATProp.mat(0,nvariables-1)/kk1;
    for(int t1=0;t1<ntime-1;t1++)
    {
      for(int t2=0;t2<nstep;t2++)
      {
        int k;
        k = 0;
        kk1 = FuncsParams[0][k].compute_Func_Prop(t);
        k = 1;
        kk2 = FuncsParams[0][k].compute_Func_Prop(t);
        k = 2;
        kk3 = FuncsParams[0][k].compute_Func_Prop(t);
        
        tPdelta += deltat;
        //integrate( ODE_formula(kk1,kk2,kk3) ,x,t ,  tPdelta , deltat/ndelta ); 
        stepper.do_step(ODE_formula(kk1,kk2,kk3),x,t,deltat);
        t = tPdelta;
//        for(int aha=0;aha<3;aha++)
//        {
//          if((x[0]<0)|(x[1]<0)|(x[2]<0))
//          {
//            OUT = 1;
//          }
//          if((!isfinite(x[0]))|(!isfinite(x[1]))|(!isfinite(x[2])))
//          {
//            OUT = 2;
//          }
//        }
        //REprintf("%f %f %f %i %i %f %i %f\n",kk1,kk2,kk3,t1 ,t2,t,nstep, deltat);
      }
      if((!isfinite(x[0]))|(!isfinite(x[1]))|(!isfinite(x[2])))
      {
        OUT = 2;
      }
      for(int i=0;i<nvariables-1;i++)
      {
        if(x[i]>0.0)
        {
          ODEMATProp.Pmat(t1+1,i)[0] = x[i];
        }else{
          ODEMATProp.Pmat(t1+1,i)[0] = 0.0;
          x[i] = 0.0;
        }
      }
//      for(int i=0;i<nvariables-1;i++)
//      { 
//        ODEMATProp.Pmat(t1+1,i)[0] = x[i];
//      }  
      int i = nvariables-1;
      ODEMATProp.Pmat(t1+1,i)[0] = ConstI*FuncsParams[0][0].compute_Func_Prop(t);  
      

      if(OUT==2)
      {
        REprintf("Indefinito\n");
        

      }
      // test
    }
    return(OUT);
  }
   
  

  

};
































class ODE_FURLAN_T2_BACKUP_PRIMACAMBIO_STEPPER
{
  private:
  
  public:
  typedef std::vector< double > state_type;
  
  int ntime;
  int nvariables;
  double tmin;
  double tmax;
  double deltat;
  int nstep;
  int nlatentk;
  Matrix <double> ODEMAT;
  Matrix <double> ODEMATProp;
  
  vector<Function_K_T2> *FuncsParams;
  vector<Class_Parameter> *StartingValues;
  
  ODE_FURLAN_T2_BACKUP_PRIMACAMBIO_STEPPER(int nt, int nvar,vector<Function_K_T2> *FP, double tmn, double tmx, double dtt, int Nstep,vector<Class_Parameter> *StartV){
    
    StartingValues = StartV;
    ntime = nt;
    nvariables = nvar;
    
    ODEMAT = Matrix<double>(ntime,nvariables,1);
    ODEMAT.Init(0.0);
    ODEMATProp = Matrix<double>(ntime,nvariables,1);
    ODEMATProp.Init(0.0);
    
    
    
    FuncsParams = FP;
    
    tmin = tmn;
    tmax = tmx;
    deltat = dtt;
    nstep = Nstep;
    
    nlatentk = 3;
    
    
  };
  
  ODE_FURLAN_T2_BACKUP_PRIMACAMBIO_STEPPER(int nt, int nvar,vector<Function_K_T2> *FP, double tmn, double tmx, double dtt, int Nstep,  vector<Class_Parameter> *StartV,ODE_FURLAN_T2 *odetocopymatrix){
     
    StartingValues = StartV;
     ntime = nt;
     nvariables = nvar;
     
     ODEMAT = Matrix<double>(ntime,nvariables,odetocopymatrix->ODEMAT.P);
     ODEMAT.Init(0.0);
     ODEMATProp = Matrix<double>(ntime,nvariables,odetocopymatrix->ODEMATProp.P);
     ODEMATProp.Init(0.0);
     
     FuncsParams = FP;
     
     tmin = tmn;
     tmax = tmx;
     deltat = dtt;
     nstep = Nstep;
     nlatentk = 3;

    
   };
  


  // DESTRUCTORS
  ~ODE_FURLAN_T2_BACKUP_PRIMACAMBIO_STEPPER(){};

  static int test()
  {
    return(1);
  }
  
  struct ODE_formula
  {
    double k1;
    double k2;
    double k3;

      ODE_formula( double kappa1 , double kappa2,double kappa3 )
      : k1( kappa1 ) , k2( kappa2 ) ,k3( kappa3 )  { }

    void operator()( const state_type &x , state_type &dxdt , double t ) const
    {
        dxdt[0] = k1-k2*x[0];
        dxdt[1] = k2*x[0]-k3*x[1];

        
    }
  };
  void copyFromODEMATPropToAcc()
  {
    for(int i=0;i<ODEMAT.nRows;i++)
    {
      for(int j=0;j<ODEMAT.nCols;j++)
      {
        ODEMAT.Pmat(i,j)[0] = ODEMATProp.mat(i,j); 
      }
    }
  }
  void ODE_compute()
  {
    state_type x;
    runge_kutta_dopri5< state_type > stepper;
    
    for(int i=0;i<nvariables;i++)
    {
      ODEMAT.Pmat(0,i)[0] = StartingValues[0][i].ParameterAcc;
      x.push_back(ODEMAT.mat(0,i));
    }

    double t = tmin;
    double kk1, kk2,kk3;
    kk1 = FuncsParams[0][0].compute_Func(t);
    double ConstI =  ODEMAT.mat(0,nvariables-1)/kk1;
    for(int t1=0;t1<ntime-1;t1++)
    {
      for(int t2=0;t2<nstep;t2++)
      {
        int k;
        k = 0;
        kk1 = FuncsParams[0][k].compute_Func(t);
        k = 1;
        kk2 = FuncsParams[0][k].compute_Func(t);
        k = 2;
        kk3 = FuncsParams[0][k].compute_Func(t);
        
        stepper.do_step(ODE_formula(kk1,kk2,kk3),x,t,deltat);
        t += deltat;
        //REprintf("%f %f %f %i %i %f %i %f\n",kk1,kk2,kk3,t1 ,t2,t,nstep, deltat);
      }
      for(int i=0;i<nvariables-1;i++)
      {
        ODEMAT.Pmat(t1+1,i)[0] = x[i];
      }
      int i = nvariables-1;
      ODEMAT.Pmat(t1+1,i)[0] = ConstI*FuncsParams[0][0].compute_Func(t);
      
    }
    //ODEMAT.Print("Odema");
    //error("");
    
  }

  int  ODE_compute_Prop()
  {
    int OUT = 0;
    state_type x;
    //runge_kutta4< state_type > stepper;
    runge_kutta_dopri5< state_type > stepper;
    
    for(int i=0;i<nvariables;i++)
    {
      ODEMATProp.Pmat(0,i)[0] = StartingValues[0][i].ParameterProp;
      x.push_back(ODEMATProp.mat(0,i));
    }

    double t = tmin;
    double kk1, kk2,kk3;
    kk1 = FuncsParams[0][0].compute_Func_Prop(t);
    double ConstI =  ODEMATProp.mat(0,nvariables-1)/kk1;
    for(int t1=0;t1<ntime-1;t1++)
    {
      for(int t2=0;t2<nstep;t2++)
      {
        int k;
        k = 0;
        kk1 = FuncsParams[0][k].compute_Func_Prop(t);
        k = 1;
        kk2 = FuncsParams[0][k].compute_Func_Prop(t);
        k = 2;
        kk3 = FuncsParams[0][k].compute_Func_Prop(t);
        
        stepper.do_step(ODE_formula(kk1,kk2,kk3),x,t,deltat);
        t += deltat;
        for(int aha=0;aha<3;aha++)
        {
          if((x[0]<0)|(x[1]<0)|(x[2]<0))
          {
            OUT = 1;
          }
          if((!isfinite(x[0]))|(!isfinite(x[1]))|(!isfinite(x[2])))
          {
            OUT = 2;
          }
        }
        //REprintf("%f %f %f %i %i %f %i %f\n",kk1,kk2,kk3,t1 ,t2,t,nstep, deltat);
      }

      for(int i=0;i<nvariables-1;i++)
      { 
        ODEMATProp.Pmat(t1+1,i)[0] = x[i];
      }  
      int i = nvariables-1;
      ODEMATProp.Pmat(t1+1,i)[0] = ConstI*FuncsParams[0][0].compute_Func_Prop(t);  
      
      if(OUT==1)
      {
        REprintf("Minore\n");
        int k;
        k = 0;
        for(k=0;k<3;k++)
        {
          FuncsParams[0][k].MinK->PrintObject("1");
          FuncsParams[0][k].VarK->PrintObject("1");
          FuncsParams[0][k].MeanK->PrintObject("1");
          FuncsParams[0][k].EtaK1->PrintObject("1");
          FuncsParams[0][k].EtaK2->PrintObject("1");
        }
        error("");
      }
      if(OUT==2)
      {
        REprintf("Indefinito\n");
        int k;
        k = 0;
        for(k=0;k<3;k++)
        {
          FuncsParams[0][k].MinK->PrintObject("1");
          FuncsParams[0][k].VarK->PrintObject("1");
          FuncsParams[0][k].MeanK->PrintObject("1");
          FuncsParams[0][k].EtaK1->PrintObject("1");
          FuncsParams[0][k].EtaK2->PrintObject("1");
        }
        error("");

      }
      // test
    }
    return(OUT);
  }
   
  void ODE_compute_TEST_TODELETE()
  {
    state_type x;
    //runge_kutta4< state_type > stepper;
    runge_kutta_dopri5< state_type > stepper;
    
    for(int i=0;i<nvariables;i++)
    {
      ODEMAT.Pmat(0,i)[0] = StartingValues[0][i].ParameterAcc;
      x.push_back(ODEMAT.mat(0,i));
    }

    double t = tmin;
    double kk1, kk2,kk3;
    kk1 = FuncsParams[0][0].compute_Func(t);
    double ConstI =  ODEMAT.mat(0,nvariables-1)/kk1;
    for(int t1=0;t1<ntime-1;t1++)
    {
      for(int t2=0;t2<nstep;t2++)
      {
        int k;
        k = 0;
        kk1 = FuncsParams[0][k].compute_Func(t);
        k = 1;
        kk2 = FuncsParams[0][k].compute_Func(t);
        k = 2;
        kk3 = FuncsParams[0][k].compute_Func(t);
        
        stepper.do_step(ODE_formula(kk1,kk2,kk3),x,t,deltat);
        t += deltat;
        REprintf("%f %f %f %i %i %f %i %f\n",kk1,kk2,kk3,t1 ,t2,t,nstep, deltat);
      }
      for(int i=0;i<nvariables-1;i++)
      {
        ODEMAT.Pmat(t1+1,i)[0] = x[i];
      }
      int i = nvariables-1;
      ODEMAT.Pmat(t1+1,i)[0] = ConstI*FuncsParams[0][0].compute_Func(t);
      
    }
    //ODEMAT.Print("Odema");
    
  }
  
  
  

};






class Function_K
{
private:
  
public:
  
  int     nFuncK;
  int     SelFunc; // quale delle tre funzioni si usa
  int     SelFuncProp;
  //double (Function_K::*Func[3])(double t,double minV, double maxV, double x0, double lambda);
  
  typedef double (Function_K::*ArrayFuncK)(double t,double minV, double maxV, double x0, double lambda);
  ArrayFuncK Func[3];
  
  
  Class_Parameter *MinV;
  Class_Parameter *MaxV;
  Class_Parameter *Lambda;
  Class_Parameter *X0;
  
  
  Function_K(Class_Parameter *mnV, Class_Parameter *mxV, Class_Parameter *lm, Class_Parameter *x, int typefunc)
  {
    SelFunc = typefunc; 
    SelFuncProp = typefunc;
    
    nFuncK = 3;
    Func[0] = &Function_K::ConstantK;
    Func[1] = &Function_K::DerivativeLogisticK;
    Func[2] = &Function_K::LogisticK;
    
    MinV = mnV;
    MaxV = mxV;
    Lambda = lm;
    X0 = x;
    
    
    
  };
  // DESTRUCTORS
  ~Function_K(){};

  
//  double LogisticK(double t,double minV, double maxV, double x0, double lambda)
//  {
//    double expon =  exp(lambda*(t-x0));
//    double ret =  expon/(1+ expon);
//    ret = ret*(maxV-minV)+minV;
//    return(ret);
//  }
//  
//  double DerivativeLogisticK(double t,double minV, double maxV, double x0, double lambda)
//  {
//    double expon =  exp(lambda*(t-x0)); 
//    double ret =  expon/pow(1+ expon,2)*4.0;
//    ret = ret*(maxV-minV)+minV;
//    return(ret);
//  }
  double LogisticK(double t,double minV, double maxV, double x0, double lambda)
  {
    double expon =  exp(lambda*(t-x0));
    double ret =  expon/(1+ expon);
    ret = ret*maxV+minV;
    return(ret);
  }
  
  double DerivativeLogisticK(double t,double minV, double maxV, double x0, double lambda)
  {
    double expon =  exp(lambda*(t-x0)); 
    double ret =  expon/pow(1+ expon,2)*4.0;
    ret = ret*maxV+minV;
    return(ret);
  }
  
  double ConstantK(double t,double minV, double maxV, double x0, double lambda)
  {
    return(minV);
  }
  
  double compute_Func_SelFuncProp(double t)
  {
    return(compute_Func(t, SelFuncProp));
  }
  double compute_Func(double t)
  {
    return(compute_Func(t, SelFunc));
  }
  double compute_Func_Prop(double t)
  {
    return(compute_Func_Prop(t, SelFunc));
  }
  
  double compute_Func(double t, int choiceFunc)
  {
    double ret = (this->*Func[choiceFunc])(t, MinV->ParameterAcc, MaxV->ParameterAcc, X0->ParameterAcc, Lambda->ParameterAcc);
    return(ret);
  }
  double compute_Func_Prop(double t, int choiceFunc)
  {
    double ret = (this->*Func[choiceFunc])(t, MinV->ParameterProp, MaxV->ParameterProp, X0->ParameterProp, Lambda->ParameterProp);
    return(ret);
  }
  
  
  void PrintObject()
  {
    REprintf("MinV=%f MaxV=%f xo=%f lambda=%f\n",MinV->ParameterAcc,MaxV->ParameterAcc, X0->ParameterAcc,Lambda->ParameterAcc);
  }
};




class ODE_FURLAN
{
  private:
  
  public:
  typedef std::vector< double > state_type;
  
  int ntime;
  int nvariables;
  double tmin;
  double tmax;
  double deltat;
  int nstep;
  int nlatentk;
  Matrix <double> ODEMAT;
  Matrix <double> ODEMATProp;
  
  vector<Function_K> *FuncsParams;
  vector<Class_Parameter> *StartingValues;
  
  ODE_FURLAN(int nt, int nvar,vector<Function_K> *FP, double tmn, double tmx, double dtt, int Nstep, vector<Class_Parameter> *StartV){
    
    StartingValues = StartV;
    ntime = nt;
    nvariables = nvar;
    
    ODEMAT = Matrix<double>(ntime,nvariables,1);
    ODEMAT.Init(0.0);
    ODEMATProp = Matrix<double>(ntime,nvariables,1);
    ODEMATProp.Init(0.0);
    
    FuncsParams = FP;
    
    tmin = tmn;
    tmax = tmx;
    deltat = dtt;
    nstep = Nstep;
    
    nlatentk = 3;
  };
  
  ODE_FURLAN(int nt, int nvar,vector<Function_K> *FP, double tmn, double tmx, double dtt, int Nstep, vector<Class_Parameter> *StartV, ODE_FURLAN *odetocopymatrix){
     
     StartingValues = StartV;
     ntime = nt;
     nvariables = nvar;
     
     ODEMAT = Matrix<double>(ntime,nvariables,odetocopymatrix->ODEMAT.P);
     ODEMAT.Init(0.0);
     ODEMATProp = Matrix<double>(ntime,nvariables,odetocopymatrix->ODEMATProp.P);
     ODEMATProp.Init(0.0);
     
     FuncsParams = FP;
     
     tmin = tmn;
     tmax = tmx;
     deltat = dtt;
     nstep = Nstep;
     
     nlatentk = 3;
   };

  // DESTRUCTORS
  ~ODE_FURLAN(){};

  
//  void sub_pointer_ODEMAT(double *p)
//  {
//    ODEMAT.P = p;
//  }
  struct ODE_formula
  {
    double k1;
    double k2;
    double k3;

      ODE_formula( double kappa1 , double kappa2,double kappa3 )
      : k1( kappa1 ) , k2( kappa2 ) ,k3( kappa3 )  { }

//      void operator()( const state_type &x , state_type &dxdt , double t ) const
//      {
//          dxdt[0] = k1-k2*x[0];
//          dxdt[1] = k2*x[0]-k3*x[1];
//          dxdt[2] = k1;
//      }
    void operator()( const state_type &x , state_type &dxdt , double t ) const
    {
        dxdt[0] = k1-k2*x[0];
        dxdt[1] = k2*x[0]-k3*x[1];
        
    }
  };
  void copyFromODEMATPropToAcc()
  {
    for(int i=0;i<ODEMAT.nRows;i++)
    {
      for(int j=0;j<ODEMAT.nCols;j++)
      {
        ODEMAT.Pmat(i,j)[0] = ODEMATProp.mat(i,j); 
      }
    }
  }
  void ODE_compute()
  {
    state_type x;
    runge_kutta4< state_type > stepper;
    
    for(int i=0;i<nvariables;i++)
    {
      ODEMAT.Pmat(0,i)[0] = StartingValues[0][i].ParameterAcc;
      x.push_back(ODEMAT.mat(0,i));
    }

    double t = tmin;
    double kk1, kk2,kk3;
    kk1 = FuncsParams[0][0].compute_Func(t);
    double ConstI =  ODEMAT.mat(0,nvariables-1)/kk1;
    for(int t1=0;t1<ntime-1;t1++)
    {
      for(int t2=0;t2<nstep;t2++)
      {
        int k;
        k = 0;
        kk1 = FuncsParams[0][k].compute_Func(t);
        k = 1;
        kk2 = FuncsParams[0][k].compute_Func(t);
        k = 2;
        kk3 = FuncsParams[0][k].compute_Func(t);
        
        stepper.do_step(ODE_formula(kk1,kk2,kk3),x,t,deltat);
        t += deltat;
        //REprintf("%f %f %f %i %i %f %i %f\n",kk1,kk2,kk3,t1 ,t2,t,nstep, deltat);
      }
      for(int i=0;i<nvariables-1;i++)
      {
        ODEMAT.Pmat(t1+1,i)[0] = x[i];
      }
      int i = nvariables-1;
      ODEMAT.Pmat(t1+1,i)[0] = ConstI*kk1;
    }
  }
  void ODE_compute_SelFuncProp()
  {
    state_type x;
    runge_kutta4< state_type > stepper;
    
    for(int i=0;i<nvariables;i++)
    {
      ODEMATProp.Pmat(0,i)[0] = StartingValues[0][i].ParameterAcc;
      x.push_back(ODEMATProp.mat(0,i));
    }

    double t = tmin;
    double kk1, kk2,kk3;
    kk1 = FuncsParams[0][0].compute_Func_SelFuncProp(t);
    double ConstI =  ODEMATProp.mat(0,nvariables-1)/kk1;
    for(int t1=0;t1<ntime-1;t1++)
    {
      for(int t2=0;t2<nstep;t2++)
      {
        int k;
        k = 0;
        kk1 = FuncsParams[0][k].compute_Func_SelFuncProp(t);
        k = 1;
        kk2 = FuncsParams[0][k].compute_Func_SelFuncProp(t);
        k = 2;
        kk3 = FuncsParams[0][k].compute_Func_SelFuncProp(t);
        
        stepper.do_step(ODE_formula(kk1,kk2,kk3),x,t,deltat);
        t += deltat;
        //REprintf("%f %f %f %i %i %f %i %f\n",kk1,kk2,kk3,t1 ,t2,t,nstep, deltat);
      }
//      for(int i=0;i<nvariables;i++)
//      {
//        ODEMATProp.Pmat(t1+1,i)[0] = x[i];
//      }
      for(int i=0;i<nvariables-1;i++)
      {
        ODEMATProp.Pmat(t1+1,i)[0] = x[i];
      }
      int i = nvariables-1;
      ODEMATProp.Pmat(t1+1,i)[0] = ConstI*kk1;
    }
  }
  void ODE_compute_Prop()
  {
    state_type x;
    runge_kutta4< state_type > stepper;
    
    for(int i=0;i<nvariables;i++)
    {
      ODEMATProp.Pmat(0,i)[0] = StartingValues[0][i].ParameterProp;
      x.push_back(ODEMATProp.mat(0,i));
    }

    double t = tmin;
    double kk1, kk2,kk3;
    kk1 = FuncsParams[0][0].compute_Func_Prop(t);
    double ConstI =  ODEMATProp.mat(0,nvariables-1)/kk1;
    for(int t1=0;t1<ntime-1;t1++)
    {
      for(int t2=0;t2<nstep;t2++)
      {
        int k;
        k = 0;
        kk1 = FuncsParams[0][k].compute_Func_Prop(t);
        k = 1;
        kk2 = FuncsParams[0][k].compute_Func_Prop(t);
        k = 2;
        kk3 = FuncsParams[0][k].compute_Func_Prop(t);
        
        stepper.do_step(ODE_formula(kk1,kk2,kk3),x,t,deltat);
        t += deltat;
        //REprintf("%f %f %f %i %i %f %i %f\n",kk1,kk2,kk3,t1 ,t2,t,nstep, deltat);
      }
//      for(int i=0;i<nvariables;i++)
//      {
//        ODEMATProp.Pmat(t1+1,i)[0] = x[i];
//      }
      for(int i=0;i<nvariables-1;i++)
      { 
        ODEMATProp.Pmat(t1+1,i)[0] = x[i];
      }  
      int i = nvariables-1;
      ODEMATProp.Pmat(t1+1,i)[0] = ConstI*kk1;    
      // test
    }
  }
   
  
};




#endif




















