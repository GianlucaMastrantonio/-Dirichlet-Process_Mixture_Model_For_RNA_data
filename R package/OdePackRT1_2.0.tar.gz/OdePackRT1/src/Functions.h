

#include <iostream>
//#include <iomanip>
#include <string>
#include <sstream>
#include <vector>
#include <map>
using namespace std;

#include <R.h>
#include <Rmath.h>
#include <Rinternals.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>
#include <R_ext/Utils.h>
#define _USE_MATH_DEFINES

//
//double ModOp(double x, double y);
//void log_sum_exp(double *ret, int k, double *x);
//void log_sum_exp(double *ret, int k, double *x, int* nonzero);
//void PrintTemplate(double val);
//void PrintTemplate(int val);
//double log1mexp(double x); // calcpla log(1-exp(x)) senza cancellazione numerica, con x<0
//double CircDist(double dist, double Cicle);
//SEXP getListElement(SEXP list, const char *str);
//int FindIndexString(vector <string> *Names, string *name);
//
//int sample_DiscreteVar(double *logprob_NonNormalized, int K);


//double FromSegmentToR(double val, double lim1, double lim2);
//double FromRToSegment(double val, double lim1, double lim2);
//double logJacobianFromSegmentToR(double ValOnR);
//void SwitchAdresses(double **par1, double **par2);
//void FromVecProbToVarInR(double *prob, double *VarInR, int dim, int refClass);
//void FromVecProbToVarInR(double *prob, double *VarInR, double *mu, int dim, int refClass);
//void copyElements(int dim, double *from, double *to);
//void CondParametersRegCoefMNorm(int niid, int n, int ncov, double *y, double *covariates, double *sigmainv, double *desmean, double *descov, double *deschol,  double moltBeta_ie_add);
//void CondParametersRegCoefMNorm(int n, int ncov, double *y, double *covariates, double *sigmainv, double *desmean, double *descov, double *deschol,  double moltBeta_ie_add);
//
//





